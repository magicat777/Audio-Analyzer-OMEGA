#!/usr/bin/env python3
"""
Live Audio Analyzer v4 OMEGA-3 - Professional Studio-Grade Analysis
Modular, high-performance implementation with enhanced architecture

Version OMEGA-3 Features:
- Modular architecture for better maintainability
- Optimized FFT processing with GPU support
- Parallel analysis with thread pool
- Improved performance monitoring
- All features from OMEGA-2 maintained
"""

import sys
import os

# Add omega3 module to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'omega3'))

from omega3.main import OmegaAnalyzerApp

def main():
    """Entry point for OMEGA-3 analyzer"""
    app = OmegaAnalyzerApp()
    app.run()

if __name__ == "__main__":
    main()