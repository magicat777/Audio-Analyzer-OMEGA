#!/usr/bin/env python3
"""Test and fix frequency display issues"""

import numpy as np
from omega3.processing.config import ProcessingConfig
from omega3.processing.spectrum import SpectrumProcessor

# Create processor
processor = SpectrumProcessor(bars=256, sample_rate=48000)

# Test with different signals
print("Testing frequency display with various signals:\n")

# Test 1: White noise (all frequencies)
print("1. White noise test:")
fft_size = 4096
freqs = np.fft.rfftfreq(fft_size, 1/48000)
white_noise = np.random.random(len(freqs)) * 0.1
result = processor.process_fft_data(white_noise)
non_zero = np.count_nonzero(result)
print(f"   Non-zero bars: {non_zero}/{len(result)}")
if non_zero > 0:
    last_non_zero = np.max(np.nonzero(result)[0])
    freq_range = processor.get_frequency_range_for_bar(last_non_zero)
    print(f"   Last non-zero bar: {last_non_zero} ({freq_range[0]:.0f}-{freq_range[1]:.0f}Hz)")

# Test 2: Single high frequency tone
print("\n2. 10kHz tone test:")
tone_10k = np.zeros_like(freqs)
idx_10k = np.argmin(np.abs(freqs - 10000))
tone_10k[idx_10k] = 1.0
result = processor.process_fft_data(tone_10k)
non_zero = np.count_nonzero(result)
print(f"   Non-zero bars: {non_zero}/{len(result)}")
if non_zero > 0:
    peak_bar = np.argmax(result)
    freq_range = processor.get_frequency_range_for_bar(peak_bar)
    print(f"   Peak bar: {peak_bar} ({freq_range[0]:.0f}-{freq_range[1]:.0f}Hz)")

# Test 3: Silence
print("\n3. Silence test:")
silence = np.zeros_like(freqs)
result = processor.process_fft_data(silence)
non_zero = np.count_nonzero(result)
print(f"   Non-zero bars: {non_zero}/{len(result)}")

# Test 4: Low frequency only (up to 500Hz)
print("\n4. Low frequency only test (up to 500Hz):")
low_freq = np.zeros_like(freqs)
low_freq[freqs <= 500] = 0.1
result = processor.process_fft_data(low_freq)
non_zero = np.count_nonzero(result)
print(f"   Non-zero bars: {non_zero}/{len(result)}")
if non_zero > 0:
    last_non_zero = np.max(np.nonzero(result)[0])
    freq_range = processor.get_frequency_range_for_bar(last_non_zero)
    print(f"   Last non-zero bar: {last_non_zero} ({freq_range[0]:.0f}-{freq_range[1]:.0f}Hz)")

# Find which bar corresponds to 575Hz
for i in range(256):
    freq_range = processor.get_frequency_range_for_bar(i)
    if freq_range[0] <= 575 <= freq_range[1]:
        print(f"\n575Hz is in bar {i} (user reports seeing up to this frequency)")
        break