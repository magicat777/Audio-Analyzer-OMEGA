#!/usr/bin/env python3
"""Test spectrum coverage and mapping"""

import numpy as np
from omega3.processing.config import ProcessingConfig
from omega3.processing.spectrum import SpectrumProcessor

# Create processor
processor = SpectrumProcessor(bars=256, sample_rate=48000)

# Create test FFT data
fft_size = 4096
freqs = np.fft.rfftfreq(fft_size, 1/48000)
fft_data = np.ones(len(freqs))  # Flat spectrum

# Process the data
result = processor.process_fft_data(fft_data)

print(f"Input FFT bins: {len(fft_data)}")
print(f"Output bars: {len(result)}")
print(f"Frequency range: {freqs[0]:.1f}Hz - {freqs[-1]:.1f}Hz")

# Check which frequencies each bar represents
print("\nBar frequency ranges:")
for i in range(0, 256, 10):  # Every 10th bar
    freq_range = processor.get_frequency_range_for_bar(i)
    print(f"Bar {i:3d}: {freq_range[0]:7.1f} - {freq_range[1]:7.1f} Hz")

# Find where 575Hz falls
for i in range(256):
    freq_range = processor.get_frequency_range_for_bar(i)
    if freq_range[0] <= 575 <= freq_range[1]:
        print(f"\n575Hz is in bar {i}")
        break

# Check the last few bars
print("\nLast 5 bars:")
for i in range(251, 256):
    freq_range = processor.get_frequency_range_for_bar(i)
    print(f"Bar {i}: {freq_range[0]:.1f} - {freq_range[1]:.1f} Hz")