#!/usr/bin/env python3
"""Test frequency band creation"""

import numpy as np
from omega3.processing.config import ProcessingConfig
from omega3.processing.base_spectrum import PerceptualSpectrumProcessor

# Create config
config = ProcessingConfig(
    sample_rate=48000,
    bars_default=256,
    fft_size_base=4096
)

# Create processor
processor = PerceptualSpectrumProcessor(config)

# Initialize with FFT size
fft_size = 4096
processor.initialize(fft_size)

# Print band information
print(f"\nTotal bands created: {len(processor.band_mappings)}")
print(f"Frequency bins available: {len(processor.frequency_bins)}")
print(f"Frequency range: {processor.frequency_bins[0]:.1f}Hz - {processor.frequency_bins[-1]:.1f}Hz")

# Check frequency coverage
if processor.band_mappings:
    min_freq = processor.band_mappings[0].frequency_range.start_hz
    max_freq = processor.band_mappings[-1].frequency_range.end_hz
    print(f"\nActual frequency coverage: {min_freq:.1f}Hz - {max_freq:.1f}Hz")
    
    # Find where coverage stops
    print("\nBand frequency ranges:")
    for i, bm in enumerate(processor.band_mappings):
        if bm.frequency_range.start_hz > 500:  # Show bands around 575Hz
            print(f"Band {i}: {bm.frequency_range.start_hz:.1f}-{bm.frequency_range.end_hz:.1f}Hz")
            if bm.frequency_range.end_hz > 600:
                break