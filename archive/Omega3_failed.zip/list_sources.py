#!/usr/bin/env python3
"""
OMEGA-3 Audio Source Lister
Lists available PipeWire monitor sources with index numbers
"""

from omega3.audio.capture import PipeWireMonitorCapture
import os
import sys

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main():
    """List available audio sources"""
    print("OMEGA-3 Audio Source Lister")
    print("=" * 40)

    capture = PipeWireMonitorCapture()
    sources = capture.get_monitor_sources()

    if not sources:
        print("❌ No monitor sources found!")
        return 1

    print("\n🔊 Available Monitor Sources:")
    print("=" * 50)
    for idx, (source_id, source_name) in enumerate(sources):
        print(f"{idx}: {source_name}")
    print("=" * 50)

    print("\nTo use a source, run:")
    print("python3 run_omega3.py --source-index [NUMBER]")
    print("\nFor interactive selection:")
    print("python3 run_omega3.py --interactive")

    return 0


if __name__ == "__main__":
    sys.exit(main())
