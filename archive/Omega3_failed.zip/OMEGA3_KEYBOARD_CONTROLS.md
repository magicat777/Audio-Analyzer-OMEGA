# OMEGA-3 Keyboard Controls Reference

## System & Application Controls
- **ESC** - Exit the analyzer
- **H, ?, /** - Toggle help display
- **S** - Save screenshot with timestamp
- **D** - Print debug information to terminal
- **Y** - Toggle dynamic quality mode (quality ↔ performance)

## Audio Processing Controls
- **+ / =** - Increase input gain (max +24dB)
- **-** - Decrease input gain (min -12dB) 
- **0** - Reset gain to default (+12.0dB)

## Display Toggle Controls
- **M** - Toggle professional meters (LUFS, True Peak, etc.)
- **J** - Toggle VU meters (classic analog-style)
- **Z** - Toggle bass zoom window (20-500Hz detail panel)
- **R** - Toggle harmonic analysis display
- **V** - Toggle voice analysis display
- **T** - Toggle technical overlay (performance stats)

## OMEGA Feature Controls
- **P** - Toggle OMEGA pitch detection panel
- **K** - Toggle OMEGA-1 chromagram & key detection panel
- **N** - Toggle OMEGA-2 genre classification panel

## Window Size Presets
- **1** - Professional Compact (1400x900)
- **2** - Professional Standard (1800x1000) 
- **3** - Professional Wide (2200x1200)
- **4** - Professional Ultra-Wide (2600x1400)
- **5** - Professional Cinema (3000x1600)
- **6** - Professional Studio (3400x1800)
- **7** - Full HD Standard (1920x1080)
- **8** - 2K Monitor (2560x1440)
- **9** - 4K Monitor (3840x2160)

## Panel-Specific Controls (when panels are active)

### Bass Detail Panel
- **+ / -** - Zoom in/out on frequency range
- **H** - Toggle harmonics display
- **N** - Toggle note labels

### VU Meters Panel  
- **V** - Cycle through meter modes (VU, PPM, BBC, Nordic)
- **R** - Reset peak holds

### Pitch Panel
- **TAB** - Cycle through view modes (Timeline, Spiral, Piano Roll, 3D Spectrum)
- **R** - Reset pitch statistics

### Chromagram Panel
- **C** - Cycle through view modes (Circular, Timeline, 3D Helix, Tonnetz)
- **R** - Reset chromagram data

### Genre Panel
- **G** - Cycle through view modes (Radar Chart, Timeline, Feature Space, Genre Map)
- **R** - Reset genre history

## Debug Features
When **D** is pressed, the following information is printed to terminal:
- Sample Rate and Input Gain
- Quality Mode and Window Size
- Current Frame Rate and Latency
- Active Panel Status
- Registered Analyzer Modules

## Real-Time Feedback
All keyboard commands provide immediate terminal feedback showing:
- Current setting values
- ON/OFF status for toggles
- Confirmation of actions performed

## Professional Features
- All changes are applied in real-time without interrupting audio processing
- Panel visibility is preserved between sessions
- Window size presets are optimized for different monitor configurations
- Quality mode automatically adapts based on system performance

## Notes
- Screenshot files are saved with timestamp format: `omega3_screenshot_YYYYMMDD_HHMMSS.png`
- Help display can be toggled with **H**, **?**, or **/** keys
- All panels have independent visibility controls
- Panel-specific controls only work when the respective panel is active
- Window resizing automatically repositions all panels and UI elements