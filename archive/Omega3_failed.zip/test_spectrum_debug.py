#!/usr/bin/env python3
"""Debug test to understand spectrum processing"""

import numpy as np
from omega3.processing.config import ProcessingConfig
from omega3.processing.base_spectrum import PerceptualSpectrumProcessor
from omega3.processing.math_utils import linear_to_db, normalize_to_range

# Create simple test signal
sample_rate = 48000
fft_size = 4096
t = np.linspace(0, fft_size/sample_rate, fft_size)

# Single tone at 1kHz with moderate amplitude
test_signal = 0.1 * np.sin(2 * np.pi * 1000 * t)

# Perform FFT
fft_data = np.abs(np.fft.rfft(test_signal))

print("Raw FFT analysis:")
print(f"  Max magnitude: {np.max(fft_data):.6f}")
print(f"  Mean magnitude: {np.mean(fft_data):.6f}")
print(f"  Peak location: {np.argmax(fft_data)} (bin)")

# Find the 1kHz bin
freq_bins = np.fft.rfftfreq(fft_size, 1/sample_rate)
khz_bin = np.argmin(np.abs(freq_bins - 1000))
print(f"  1kHz bin: {khz_bin}, actual freq: {freq_bins[khz_bin]:.1f} Hz")
print(f"  1kHz magnitude: {fft_data[khz_bin]:.6f}")

# Convert to dB
fft_db = linear_to_db(fft_data, min_db=-60.0)
print(f"\nAfter dB conversion:")
print(f"  1kHz value: {fft_db[khz_bin]:.1f} dB")
print(f"  Max dB: {np.max(fft_db):.1f}")
print(f"  Min dB: {np.min(fft_db):.1f}")

# Test normalization function directly
test_range = np.array([-60, -40, -20, -6, 0])
normalized = normalize_to_range(test_range, -60.0, -6.0, 0.0, 1.0)
print(f"\nNormalization test:")
for i, (db, norm) in enumerate(zip(test_range, normalized)):
    print(f"  {db:3.0f} dB -> {norm:.3f}")

# Now test the full processor
config = ProcessingConfig(
    sample_rate=48000,
    bars_default=256,
    fft_size_base=4096
)

processor = PerceptualSpectrumProcessor(config)
processor.initialize(fft_size)

# Process without compensation first
spectrum_no_comp = processor.process(fft_data, apply_compensation=False, normalize_output=True)
spectrum_with_comp = processor.process(fft_data, apply_compensation=True, normalize_output=True)

print(f"\nProcessed spectrum (no compensation):")
print(f"  Max: {np.max(spectrum_no_comp):.3f}")
print(f"  Mean: {np.mean(spectrum_no_comp):.3f}")
print(f"  Non-zero bars: {np.sum(spectrum_no_comp > 0.01)}")

print(f"\nProcessed spectrum (with compensation):")
print(f"  Max: {np.max(spectrum_with_comp):.3f}")
print(f"  Mean: {np.mean(spectrum_with_comp):.3f}")
print(f"  Non-zero bars: {np.sum(spectrum_with_comp > 0.01)}")

# Find which bar contains 1kHz
for i, band in enumerate(processor.band_mappings):
    if band.frequency_range.contains(1000):
        print(f"\n1kHz is in bar {i}:")
        print(f"  Frequency range: {band.frequency_range.start_hz:.1f} - {band.frequency_range.end_hz:.1f} Hz")
        print(f"  Value (no comp): {spectrum_no_comp[i]:.3f}")
        print(f"  Value (with comp): {spectrum_with_comp[i]:.3f}")
        print(f"  Compensation gain: {processor.compensation_curve.get_gain_at_frequency(1000):.3f}")
        break

# Test with quieter signal
quiet_signal = 0.01 * np.sin(2 * np.pi * 1000 * t)
quiet_fft = np.abs(np.fft.rfft(quiet_signal))
quiet_spectrum = processor.process(quiet_fft, apply_compensation=True, normalize_output=True)

print(f"\nQuiet signal test (0.01 amplitude):")
print(f"  Max: {np.max(quiet_spectrum):.3f}")
print(f"  1kHz bar value: {quiet_spectrum[i]:.3f}")

# Test with loud signal
loud_signal = 0.5 * np.sin(2 * np.pi * 1000 * t)
loud_fft = np.abs(np.fft.rfft(loud_signal))
loud_spectrum = processor.process(loud_fft, apply_compensation=True, normalize_output=True)

print(f"\nLoud signal test (0.5 amplitude):")
print(f"  Max: {np.max(loud_spectrum):.3f}")
print(f"  1kHz bar value: {loud_spectrum[i]:.3f}")