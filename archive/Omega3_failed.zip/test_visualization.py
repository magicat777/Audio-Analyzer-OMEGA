#!/usr/bin/env python3
"""Test visualization to verify spectrum display"""

import pygame
import numpy as np
import time
from omega3.processing.config import ProcessingConfig
from omega3.processing.base_spectrum import PerceptualSpectrumProcessor
from omega3.visualization.panels.spectrum_panel import SpectrumPanel

# Initialize pygame
pygame.init()
screen = pygame.display.set_mode((1200, 600))
pygame.display.set_caption("Spectrum Visualization Test")
clock = pygame.time.Clock()

# Create spectrum processor
config = ProcessingConfig(
    sample_rate=48000,
    bars_default=256,
    fft_size_base=4096
)
processor = PerceptualSpectrumProcessor(config)
processor.initialize(4096)

# Create spectrum panel
panel = SpectrumPanel(0, 0, 1200, 600)
panel.color_mode = "gradient"
panel.visualization_mode = "bars"

# Generate test signal with sweep
duration = 0.1
sample_rate = 48000
fft_size = 4096

running = True
phase = 0
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_SPACE:
                # Toggle visualization mode
                modes = ["bars", "lines", "dots", "filled"]
                current_idx = modes.index(panel.visualization_mode)
                panel.visualization_mode = modes[(current_idx + 1) % len(modes)]
                print(f"Visualization mode: {panel.visualization_mode}")
    
    # Generate dynamic test signal
    t = np.linspace(0, fft_size/sample_rate, fft_size)
    
    # Frequency sweep
    sweep_freq = 100 + (10000 - 100) * (0.5 + 0.5 * np.sin(phase))
    test_signal = 0.3 * np.sin(2 * np.pi * sweep_freq * t)
    
    # Add some harmonics
    test_signal += 0.1 * np.sin(2 * np.pi * sweep_freq * 2 * t)
    test_signal += 0.05 * np.sin(2 * np.pi * sweep_freq * 3 * t)
    
    # Add background noise for visual effect
    test_signal += 0.01 * np.random.randn(len(test_signal))
    
    # Process spectrum
    fft_data = np.abs(np.fft.rfft(test_signal))
    spectrum = processor.process(fft_data, apply_compensation=True, normalize_output=True)
    
    # Update panel
    panel.update(spectrum)
    
    # Clear screen
    screen.fill((20, 20, 25))
    
    # Render panel
    panel.render(screen)
    
    # Draw info text
    font = pygame.font.Font(None, 24)
    info_text = [
        f"Sweep Frequency: {sweep_freq:.0f} Hz",
        f"Mode: {panel.visualization_mode}",
        f"Press SPACE to change mode, ESC to exit"
    ]
    y_offset = 10
    for text in info_text:
        text_surface = font.render(text, True, (255, 255, 255))
        screen.blit(text_surface, (10, y_offset))
        y_offset += 30
    
    # Update display
    pygame.display.flip()
    clock.tick(30)
    
    # Update phase for animation
    phase += 0.05

pygame.quit()
print("Test completed")