#!/usr/bin/env python3
"""Debug spectrum processing step by step"""

import numpy as np
from omega3.processing.config import ProcessingConfig
from omega3.processing.base_spectrum import PerceptualSpectrumProcessor

# Create processor
config = ProcessingConfig(sample_rate=48000, bars_default=256)
processor = PerceptualSpectrumProcessor(config)

# Initialize
fft_size = 4096
processor.initialize(fft_size)

# Create test data - white noise
freqs = np.fft.rfftfreq(fft_size, 1/48000)
fft_data = np.random.random(len(freqs)) * 0.1

print(f"Input FFT data: {len(fft_data)} bins")
print(f"Input range: {np.min(fft_data):.6f} to {np.max(fft_data):.6f}")
print(f"Non-zero inputs: {np.count_nonzero(fft_data)}")

# Process manually to debug
output = np.zeros(len(processor.band_mappings), dtype=np.float32)

# Step 1: Map FFT to bands
processor._map_fft_to_bands(fft_data, output)
print(f"\nAfter _map_fft_to_bands:")
print(f"  Output range: {np.min(output):.6f} to {np.max(output):.6f}")
print(f"  Non-zero outputs: {np.count_nonzero(output)}")

# Step 2: Apply compensation
if processor.compensation_curve:
    processor._apply_compensation(output)
    print(f"\nAfter _apply_compensation:")
    print(f"  Output range: {np.min(output):.6f} to {np.max(output):.6f}")
    print(f"  Non-zero outputs: {np.count_nonzero(output)}")

# Step 3: Convert to dB and normalize
processor._convert_to_db_and_normalize(output)
print(f"\nAfter _convert_to_db_and_normalize:")
print(f"  Output range: {np.min(output):.6f} to {np.max(output):.6f}")
print(f"  Non-zero outputs: {np.count_nonzero(output)}")

# Check noise threshold
print(f"\nNoise threshold (linear): {config.noise_threshold_linear:.6f}")
print(f"Noise threshold (dB): {config.noise_threshold_db:.1f}")

# Test with a louder signal
print("\n--- Testing with louder signal ---")
fft_data_loud = np.random.random(len(freqs)) * 1.0  # 10x louder
output_loud = np.zeros(len(processor.band_mappings), dtype=np.float32)
processor._map_fft_to_bands(fft_data_loud, output_loud)
print(f"After mapping (loud): {np.min(output_loud):.6f} to {np.max(output_loud):.6f}")
processor._convert_to_db_and_normalize(output_loud)
print(f"After normalization (loud): {np.min(output_loud):.6f} to {np.max(output_loud):.6f}")
print(f"Non-zero outputs (loud): {np.count_nonzero(output_loud)}")