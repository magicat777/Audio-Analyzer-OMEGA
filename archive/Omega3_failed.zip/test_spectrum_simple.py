#!/usr/bin/env python3
"""Simple test script to verify spectrum processing fixes"""

import numpy as np
from omega3.processing.config import ProcessingConfig
from omega3.processing.base_spectrum import PerceptualSpectrumProcessor

# Create test configuration
config = ProcessingConfig(
    sample_rate=48000,
    bars_default=256,
    fft_size_base=4096
)

# Create processor
processor = PerceptualSpectrumProcessor(config)

# Initialize with FFT size
fft_size = 4096
processor.initialize(fft_size)

# Create test signal with multiple frequency components
sample_rate = 48000
duration = 0.1
t = np.linspace(0, duration, int(sample_rate * duration))

# Generate test signal with known frequencies
test_signal = (
    0.5 * np.sin(2 * np.pi * 50 * t) +     # 50Hz bass
    0.3 * np.sin(2 * np.pi * 200 * t) +    # 200Hz low-mid
    0.2 * np.sin(2 * np.pi * 1000 * t) +   # 1kHz mid
    0.1 * np.sin(2 * np.pi * 5000 * t) +   # 5kHz high-mid
    0.05 * np.sin(2 * np.pi * 10000 * t) + # 10kHz high
    0.02 * np.sin(2 * np.pi * 15000 * t)   # 15kHz ultra-high
)

# Perform FFT
fft_data = np.abs(np.fft.rfft(test_signal[:fft_size]))

# Process spectrum
spectrum = processor.process(fft_data, apply_compensation=True, normalize_output=True)

# Print information
print(f"FFT size: {fft_size}")
print(f"Number of FFT bins: {len(fft_data)}")
print(f"Frequency resolution: {sample_rate/fft_size:.2f} Hz/bin")
print(f"Max frequency: {processor.frequency_bins[-1]:.0f} Hz")
print(f"Number of spectrum bars: {len(spectrum)}")
print(f"Number of band mappings: {len(processor.band_mappings)}")

# Check frequency coverage
print("\nFrequency band coverage:")
print("First 10 bands:")
for i, band in enumerate(processor.band_mappings[:10]):
    print(f"  Band {i:3d}: {band.frequency_range.start_hz:7.1f} - {band.frequency_range.end_hz:7.1f} Hz")

print("\nLast 10 bands:")
for i, band in enumerate(processor.band_mappings[-10:], len(processor.band_mappings)-10):
    print(f"  Band {i:3d}: {band.frequency_range.start_hz:7.1f} - {band.frequency_range.end_hz:7.1f} Hz")

# Check spectrum values
print(f"\nSpectrum statistics:")
print(f"  Min value: {np.min(spectrum):.3f}")
print(f"  Max value: {np.max(spectrum):.3f}")
print(f"  Mean value: {np.mean(spectrum):.3f}")
print(f"  Std dev: {np.std(spectrum):.3f}")

# Find bands with significant energy
significant_bands = []
for i, value in enumerate(spectrum):
    if value > 0.3:
        freq_range = processor.band_mappings[i].frequency_range
        significant_bands.append((i, freq_range.center_hz, value))

print(f"\nBands with significant energy (>0.3):")
for band_idx, center_freq, value in significant_bands[:10]:
    print(f"  Band {band_idx:3d}: {center_freq:7.1f} Hz, value={value:.3f}")

# Test different input levels
print("\n\nTesting different input levels:")
print("Gain | Max Value | Mean Value | Status")
print("-----|-----------|------------|-------")
for gain in [0.1, 0.5, 1.0, 2.0, 5.0, 10.0]:
    scaled_fft = fft_data * gain
    spectrum = processor.process(scaled_fft, apply_compensation=True, normalize_output=True)
    max_val = np.max(spectrum)
    mean_val = np.mean(spectrum)
    status = "OK" if max_val <= 1.0 else "CLIPPING!"
    print(f"{gain:4.1f}x | {max_val:9.3f} | {mean_val:10.3f} | {status}")

# Check if high frequencies are present
high_freq_bands = [i for i, band in enumerate(processor.band_mappings) if band.frequency_range.center_hz > 2000]
high_freq_values = spectrum[high_freq_bands]
print(f"\nHigh frequency check (>2kHz):")
print(f"  Number of bands above 2kHz: {len(high_freq_bands)}")
print(f"  Max value in high frequencies: {np.max(high_freq_values):.3f}")
print(f"  Mean value in high frequencies: {np.mean(high_freq_values):.3f}")

# Test with pink noise to check full spectrum coverage
print("\nTesting with pink noise:")
pink_noise = np.random.randn(fft_size)
# Simple pink noise approximation
for i in range(1, len(pink_noise)):
    pink_noise[i] = 0.9 * pink_noise[i-1] + 0.1 * pink_noise[i]

pink_fft = np.abs(np.fft.rfft(pink_noise))
pink_spectrum = processor.process(pink_fft, apply_compensation=True, normalize_output=True)

# Check coverage across frequency ranges
freq_ranges = [
    (20, 60, "Sub-bass"),
    (60, 250, "Bass"),
    (250, 500, "Low-mid"),
    (500, 2000, "Mid"),
    (2000, 6000, "High-mid"),
    (6000, 20000, "High")
]

for start_f, end_f, name in freq_ranges:
    bands_in_range = [i for i, band in enumerate(processor.band_mappings) 
                      if start_f <= band.frequency_range.center_hz < end_f]
    if bands_in_range:
        values = pink_spectrum[bands_in_range]
        print(f"  {name:10s} ({start_f:5d}-{end_f:5d} Hz): {len(bands_in_range):3d} bands, "
              f"mean={np.mean(values):.3f}, max={np.max(values):.3f}")