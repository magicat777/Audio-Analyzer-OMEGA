#!/usr/bin/env python3
"""Test script to verify spectrum processing fixes"""

import numpy as np
import matplotlib.pyplot as plt
from omega3.processing.config import ProcessingConfig
from omega3.processing.base_spectrum import PerceptualSpectrumProcessor

# Create test configuration
config = ProcessingConfig(
    sample_rate=48000,
    bars_default=256,
    fft_size_base=4096
)

# Create processor
processor = PerceptualSpectrumProcessor(config)

# Initialize with FFT size
fft_size = 4096
processor.initialize(fft_size)

# Create test signal with multiple frequency components
sample_rate = 48000
duration = 0.1
t = np.linspace(0, duration, int(sample_rate * duration))

# Generate test signal with known frequencies
test_signal = (
    0.5 * np.sin(2 * np.pi * 50 * t) +     # 50Hz bass
    0.3 * np.sin(2 * np.pi * 200 * t) +    # 200Hz low-mid
    0.2 * np.sin(2 * np.pi * 1000 * t) +   # 1kHz mid
    0.1 * np.sin(2 * np.pi * 5000 * t) +   # 5kHz high-mid
    0.05 * np.sin(2 * np.pi * 10000 * t) + # 10kHz high
    0.02 * np.sin(2 * np.pi * 15000 * t)   # 15kHz ultra-high
)

# Add some noise
test_signal += 0.01 * np.random.randn(len(test_signal))

# Perform FFT
fft_data = np.abs(np.fft.rfft(test_signal[:fft_size]))

# Process spectrum
spectrum = processor.process(fft_data, apply_compensation=True, normalize_output=True)

# Print information
print(f"FFT size: {fft_size}")
print(f"Number of FFT bins: {len(fft_data)}")
print(f"Frequency resolution: {sample_rate/fft_size:.2f} Hz/bin")
print(f"Max frequency: {processor.frequency_bins[-1]:.0f} Hz")
print(f"Number of spectrum bars: {len(spectrum)}")
print(f"Number of band mappings: {len(processor.band_mappings)}")

# Check frequency coverage
print("\nFrequency band coverage:")
for i, band in enumerate(processor.band_mappings[:10]):  # First 10 bands
    print(f"Band {i}: {band.frequency_range.start_hz:.1f} - {band.frequency_range.end_hz:.1f} Hz")

print("...")

for i, band in enumerate(processor.band_mappings[-10:], len(processor.band_mappings)-10):  # Last 10 bands
    print(f"Band {i}: {band.frequency_range.start_hz:.1f} - {band.frequency_range.end_hz:.1f} Hz")

# Check spectrum values
print(f"\nSpectrum statistics:")
print(f"Min value: {np.min(spectrum):.3f}")
print(f"Max value: {np.max(spectrum):.3f}")
print(f"Mean value: {np.mean(spectrum):.3f}")
print(f"Std dev: {np.std(spectrum):.3f}")

# Find peaks
peak_indices = np.where(spectrum > 0.5)[0]
print(f"\nPeaks found at bands: {peak_indices}")

# Create visualization
plt.figure(figsize=(12, 8))

# Plot raw FFT
plt.subplot(3, 1, 1)
freqs = np.fft.rfftfreq(fft_size, 1/sample_rate)
plt.semilogy(freqs, fft_data)
plt.xlabel('Frequency (Hz)')
plt.ylabel('Magnitude')
plt.title('Raw FFT Data')
plt.grid(True)
plt.xlim(20, 20000)

# Plot spectrum bars
plt.subplot(3, 1, 2)
bar_freqs = [band.frequency_range.center_hz for band in processor.band_mappings]
plt.bar(range(len(spectrum)), spectrum, width=1.0)
plt.xlabel('Bar Index')
plt.ylabel('Normalized Value')
plt.title('Processed Spectrum Bars')
plt.grid(True)

# Plot frequency distribution
plt.subplot(3, 1, 3)
plt.semilogx(bar_freqs, spectrum, 'o-', markersize=2)
plt.xlabel('Frequency (Hz)')
plt.ylabel('Normalized Value')
plt.title('Spectrum vs Frequency')
plt.grid(True)
plt.xlim(20, 20000)

plt.tight_layout()
plt.savefig('spectrum_test_results.png', dpi=150)
print("\nTest plot saved to spectrum_test_results.png")

# Test different input levels
print("\n\nTesting different input levels:")
for gain in [0.1, 0.5, 1.0, 2.0, 5.0]:
    scaled_fft = fft_data * gain
    spectrum = processor.process(scaled_fft, apply_compensation=True, normalize_output=True)
    print(f"Gain {gain:4.1f}x: max={np.max(spectrum):.3f}, mean={np.mean(spectrum):.3f}")