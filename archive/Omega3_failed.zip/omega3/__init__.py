"""
OMEGA-3 Professional Audio Analyzer Package
High-performance modular audio analysis system
"""

__version__ = "4.0.0-OMEGA3"
__author__ = "OMEGA Audio Analysis Team"
