"""
Frequency compensation and equalization for OMEGA-3.
Provides various compensation curves and EQ capabilities.
"""

from enum import Enum
from typing import Callable
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np


class CompensationCurve(Enum):
    """Standard compensation curves."""

    FLAT = "flat"
    PINK_NOISE = "pink_noise"
    A_WEIGHTING = "a_weighting"
    C_WEIGHTING = "c_weighting"
    EQUAL_LOUDNESS = "equal_loudness"
    HARMAN = "harman"
    CUSTOM = "custom"
    VISUAL = "visual"  # Optimized for visualization


class FrequencyCompensator:
    """Applies frequency compensation for balanced visualization."""

    def __init__(self, sample_rate: int = 48000):
        self.sample_rate = sample_rate
        self.nyquist = sample_rate / 2

        # Compensation curves
        self.curves = {
            CompensationCurve.FLAT: self._flat_curve,
            CompensationCurve.PINK_NOISE: self._pink_noise_curve,
            CompensationCurve.A_WEIGHTING: self._a_weighting_curve,
            CompensationCurve.C_WEIGHTING: self._c_weighting_curve,
            CompensationCurve.EQUAL_LOUDNESS: self._equal_loudness_curve,
            CompensationCurve.VISUAL: self._visual_curve,
            CompensationCurve.HARMAN: self._harman_curve,
        }

        # Current curve
        self.current_curve = CompensationCurve.VISUAL

        # Custom EQ bands
        self.custom_eq_bands = self._init_custom_eq_bands()

    def _init_custom_eq_bands(self) -> List[Dict[str, float]]:
        """Initialize custom EQ bands."""
        return [
            {"freq": 32, "gain": 0.0, "q": 0.7},
            {"freq": 64, "gain": 0.0, "q": 0.7},
            {"freq": 125, "gain": 0.0, "q": 0.7},
            {"freq": 250, "gain": 0.0, "q": 0.7},
            {"freq": 500, "gain": 0.0, "q": 0.7},
            {"freq": 1000, "gain": 0.0, "q": 0.7},
            {"freq": 2000, "gain": 0.0, "q": 0.7},
            {"freq": 4000, "gain": 0.0, "q": 0.7},
            {"freq": 8000, "gain": 0.0, "q": 0.7},
            {"freq": 16000, "gain": 0.0, "q": 0.7},
        ]

    def get_compensation_gain(
        self, frequency: float, curve: Optional[CompensationCurve] = None
    ) -> float:
        """Get compensation gain for a specific frequency."""
        if curve is None:
            curve = self.current_curve

        if curve in self.curves:
            return self.curves[curve](frequency)
        else:
            return 1.0

    def apply_compensation(
        self,
        frequencies: np.ndarray,
        magnitudes: np.ndarray,
        curve: Optional[CompensationCurve] = None,
    ) -> np.ndarray:
        """Apply compensation curve to frequency magnitudes."""
        if curve is None:
            curve = self.current_curve

        # Get compensation gains for all frequencies
        gains = np.array([self.get_compensation_gain(f, curve) for f in frequencies])

        # Apply gains
        return magnitudes * gains

    def _flat_curve(self, frequency: float) -> float:
        """Flat response (no compensation)."""
        return 1.0

    def _pink_noise_curve(self, frequency: float) -> float:
        """Pink noise compensation (-3dB/octave)."""
        if frequency <= 0:
            return 1.0

        # Pink noise has 1/f spectrum
        # Compensate by multiplying by sqrt(f)
        reference_freq = 1000.0
        return np.sqrt(frequency / reference_freq)

    def _a_weighting_curve(self, frequency: float) -> float:
        """A-weighting curve for perceived loudness."""
        if frequency <= 0:
            return 0.0

        f2 = frequency ** 2
        f4 = f2 ** 2

        c1 = 12194.217 ** 2
        c2 = 20.598997 ** 2
        c3 = 107.65265 ** 2
        c4 = 737.86223 ** 2

        num = c1 * f4
        den = (f2 + c2) * np.sqrt((f2 + c3) * (f2 + c4)) * (f2 + c1)

        a_weight = 1.2589 * num / den

        return a_weight

    def _c_weighting_curve(self, frequency: float) -> float:
        """C-weighting curve."""
        if frequency <= 0:
            return 0.0

        f2 = frequency ** 2

        c1 = 12194.217 ** 2
        c2 = 20.598997 ** 2

        num = c1 * f2
        den = (f2 + c2) * (f2 + c1)

        c_weight = 0.0619 * num / den

        return c_weight

    def _equal_loudness_curve(self, frequency: float, phon: float = 60) -> float:
        """ISO 226:2003 equal loudness contour compensation."""
        if frequency <= 0 or frequency > 20000:
            return 0.0

        # Simplified approximation of 60 phon curve
        # Based on Fletcher-Munson curves

        # Reference frequencies and levels for 60 phon
        ref_freqs = np.array(
            [
                20,
                25,
                31.5,
                40,
                50,
                63,
                80,
                100,
                125,
                160,
                200,
                250,
                315,
                400,
                500,
                630,
                800,
                1000,
                1250,
                1600,
                2000,
                2500,
                3150,
                4000,
                5000,
                6300,
                8000,
                10000,
                12500,
                16000,
                20000,
            ]
        )

        ref_levels = np.array(
            [
                109.5,
                104.5,
                99.5,
                94.5,
                90.0,
                85.5,
                80.5,
                76.0,
                71.5,
                66.5,
                62.0,
                57.5,
                53.0,
                48.5,
                44.5,
                40.5,
                36.5,
                33.0,
                29.5,
                26.0,
                22.5,
                19.5,
                16.5,
                13.5,
                11.0,
                8.5,
                6.0,
                4.0,
                2.5,
                1.5,
                1.0,
            ]
        )

        # Interpolate
        level_db = np.interp(frequency, ref_freqs, ref_levels)

        # Convert to linear gain (inverse of the curve for compensation)
        reference_level = 33.0  # 60 phon at 1kHz
        compensation_db = reference_level - level_db

        return 10 ** (compensation_db / 20)

    def _visual_curve(self, frequency: float) -> float:
        """Optimized curve for visual appeal in audio visualization."""
        if frequency <= 0:
            return 0.0

        # Custom curve that balances frequency response for visualization
        # Reduces bass dominance while maintaining presence

        if frequency < 30:
            gain = 0.1
        elif frequency < 60:
            gain = 0.15
        elif frequency < 100:
            gain = 0.2
        elif frequency < 250:
            gain = 0.4
        elif frequency < 500:
            gain = 2.0
        elif frequency < 1000:
            gain = 3.5
        elif frequency < 2000:
            gain = 4.0
        elif frequency < 4000:
            gain = 3.5
        elif frequency < 8000:
            gain = 2.5
        elif frequency < 12000:
            gain = 1.5
        elif frequency < 16000:
            gain = 1.0
        else:
            gain = 0.7

        return gain

    def _harman_curve(self, frequency: float) -> float:
        """Harman target curve compensation."""
        if frequency <= 0:
            return 0.0

        # Simplified Harman curve
        # Bass boost below 100Hz, slight treble boost above 10kHz

        if frequency < 100:
            # +6dB at 20Hz, rolling off to 0dB at 100Hz
            boost_db = 6 * (1 - frequency / 100)
        elif frequency > 10000:
            # +2dB above 10kHz
            boost_db = 2
        else:
            boost_db = 0

        return 10 ** (boost_db / 20)

    def create_custom_curve(
        self, control_points: List[Tuple[float, float]]
    ) -> Callable[[float], float]:
        """Create a custom compensation curve from control points."""
        # Sort control points by frequency
        points = sorted(control_points, key=lambda x: x[0])

        freqs = [p[0] for p in points]
        gains_db = [p[1] for p in points]

        def custom_curve(frequency: float) -> float:
            if frequency <= 0:
                return 0.0

            # Interpolate in dB domain
            gain_db = np.interp(
                np.log10(frequency), [np.log10(f) for f in freqs], gains_db
            )

            return 10 ** (gain_db / 20)

        return custom_curve

    def apply_parametric_eq(
        self, frequencies: np.ndarray, magnitudes: np.ndarray
    ) -> np.ndarray:
        """Apply parametric EQ based on custom bands."""
        result = magnitudes.copy()

        for band in self.custom_eq_bands:
            if band["gain"] == 0:
                continue

            # Calculate filter response
            gains = self._calculate_parametric_filter(
                frequencies, band["freq"], band["gain"], band["q"]
            )

            result *= gains

        return result

    def _calculate_parametric_filter(
        self, frequencies: np.ndarray, center_freq: float, gain_db: float, q: float
    ) -> np.ndarray:
        """Calculate parametric filter response."""
        # Peaking EQ filter
        omega = 2 * np.pi * frequencies / self.sample_rate
        omega_c = 2 * np.pi * center_freq / self.sample_rate

        # Calculate filter coefficients
        A = 10 ** (gain_db / 40)
        alpha = np.sin(omega_c) / (2 * q)

        # Transfer function
        cos_omega = np.cos(omega)
        cos_omega_c = np.cos(omega_c)

        b0 = 1 + alpha * A
        b1 = -2 * cos_omega_c
        b2 = 1 - alpha * A
        a0 = 1 + alpha / A
        a1 = -2 * cos_omega_c
        a2 = 1 - alpha / A

        # Normalize
        b0 /= a0
        b1 /= a0
        b2 /= a0
        a1 /= a0
        a2 /= a0

        # Calculate magnitude response
        num = (
            b0 ** 2
            + b1 ** 2
            + b2 ** 2
            + 2 * (b0 * b2 - b1 ** 2) * cos_omega
            + 2 * b1 * (b0 + b2) * cos_omega
        )
        den = (
            1
            + a1 ** 2
            + a2 ** 2
            + 2 * (a2 - a1 ** 2) * cos_omega
            + 2 * a1 * (1 + a2) * cos_omega
        )

        magnitude = np.sqrt(np.abs(num / den))

        return magnitude

    def apply_dynamic_compensation(
        self, frequencies: np.ndarray, magnitudes: np.ndarray, overall_level: float
    ) -> np.ndarray:
        """Apply dynamic compensation based on signal level."""
        # Adjust compensation based on overall signal level
        # Louder signals need less compensation

        # Calculate dynamic factor (0-1)
        # Assuming overall_level is in dB, with -60dB = silence, 0dB = full scale
        level_factor = np.clip((overall_level + 60) / 60, 0, 1)

        # Blend between full compensation and flat response
        static_compensation = self.apply_compensation(frequencies, magnitudes)

        # More compensation at low levels, less at high levels
        blend_factor = 1 - (level_factor * 0.5)  # 50% reduction at full scale

        return magnitudes + (static_compensation - magnitudes) * blend_factor

    def get_compensation_curve_points(
        self, num_points: int = 100
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Get points for plotting compensation curve."""
        # Generate log-spaced frequencies
        freq_min = 20
        freq_max = min(20000, self.nyquist)

        frequencies = np.logspace(np.log10(freq_min), np.log10(freq_max), num_points)
        gains = np.array([self.get_compensation_gain(f) for f in frequencies])

        # Convert to dB
        gains_db = 20 * np.log10(gains + 1e-10)

        return frequencies, gains_db

    def save_preset(self, name: str) -> Dict[str, any]:
        """Save current compensation settings as preset."""
        return {
            "name": name,
            "curve": self.current_curve.value,
            "custom_eq_bands": [
                {"freq": band["freq"], "gain": band["gain"], "q": band["q"]}
                for band in self.custom_eq_bands
            ],
        }

    def load_preset(self, preset: Dict[str, any]):
        """Load compensation preset."""
        if "curve" in preset:
            self.current_curve = CompensationCurve(preset["curve"])

        if "custom_eq_bands" in preset:
            self.custom_eq_bands = preset["custom_eq_bands"]
