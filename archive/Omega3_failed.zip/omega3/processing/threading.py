"""
Thread pool manager for parallel analyzer processing
"""

import queue
import threading
import time
from concurrent.futures import Future
from concurrent.futures import ThreadPoolExecutor
from typing import Any
from typing import Callable
from typing import Dict
from typing import List
from typing import Optional

import numpy as np

try:
    from ..analyzers.base import AnalyzerResult, BaseAnalyzer
    from ..config import MAX_PROCESSING_TIME_MS, THREAD_POOL_SIZE
except ImportError:
    # Fallback to direct imports for standalone execution
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from analyzers.base import AnalyzerResult, BaseAnalyzer
    from config import MAX_PROCESSING_TIME_MS, THREAD_POOL_SIZE


class AnalyzerThreadPool:
    """Manages parallel processing of analyzers"""

    def __init__(self, max_workers: int = THREAD_POOL_SIZE):
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.analyzers: Dict[str, BaseAnalyzer] = {}
        self.futures: Dict[str, Future] = {}
        self.results: Dict[str, AnalyzerResult] = {}
        self.result_queue = queue.Queue()
        self._shutdown = False

    def register_analyzer(self, name: str, analyzer: BaseAnalyzer):
        """Register an analyzer for parallel processing"""
        self.analyzers[name] = analyzer

    def submit_batch(
        self, audio_data: np.ndarray, fft_data: Optional[np.ndarray] = None
    ):
        """Submit all registered analyzers for parallel processing"""
        if self._shutdown:
            return

        # Clear previous futures
        self.futures.clear()

        # Submit each analyzer
        for name, analyzer in self.analyzers.items():
            if analyzer.enabled:
                future = self.executor.submit(
                    analyzer.process_with_timing,
                    audio_data.copy(),  # Copy to avoid race conditions
                    fft_data.copy() if fft_data is not None else None,
                )
                self.futures[name] = future

    def collect_results(
        self, timeout: float = MAX_PROCESSING_TIME_MS / 1000
    ) -> Dict[str, AnalyzerResult]:
        """Collect results from all analyzers with timeout"""
        results = {}
        deadline = time.time() + timeout

        for name, future in self.futures.items():
            remaining_time = deadline - time.time()
            if remaining_time <= 0:
                break

            try:
                result = future.result(timeout=remaining_time)
                results[name] = result
            except Exception as e:
                import traceback
                print(f"Analyzer {name} failed: {type(e).__name__}: {e}")
                print(f"Traceback: {traceback.format_exc()}")
                # Return empty result on failure
                results[name] = AnalyzerResult({}, time.time(), 0.0)

        self.results = results
        return results

    def get_performance_stats(self) -> Dict[str, float]:
        """Get performance statistics for all analyzers"""
        stats = {}
        for name, analyzer in self.analyzers.items():
            stats[name] = analyzer.get_average_processing_time()
        return stats

    def shutdown(self):
        """Shutdown the thread pool"""
        self._shutdown = True
        self.executor.shutdown(wait=True)


class AsyncProcessor:
    """Async processor for specific heavy operations"""

    def __init__(self, process_func: Callable, name: str = "AsyncProcessor"):
        self.process_func = process_func
        self.name = name
        self.input_queue = queue.Queue(maxsize=2)
        self.output_queue = queue.Queue(maxsize=2)
        self._running = True
        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()

    def _worker(self):
        """Worker thread for async processing"""
        while self._running:
            try:
                data = self.input_queue.get(timeout=0.1)
                if data is None:
                    break

                result = self.process_func(data)

                # Try to put result, drop old results if queue is full
                try:
                    self.output_queue.put_nowait(result)
                except queue.Full:
                    # Drop oldest result
                    try:
                        self.output_queue.get_nowait()
                        self.output_queue.put_nowait(result)
                    except queue.Empty:
                        pass

            except queue.Empty:
                continue
            except Exception as e:
                print(f"Error in {self.name}: {e}")

    def submit(self, data: Any) -> bool:
        """Submit data for processing"""
        try:
            self.input_queue.put_nowait(data)
            return True
        except queue.Full:
            return False

    def get_latest_result(self) -> Optional[Any]:
        """Get the latest processed result"""
        result = None
        # Drain queue to get latest
        while True:
            try:
                result = self.output_queue.get_nowait()
            except queue.Empty:
                break
        return result

    def stop(self):
        """Stop the processor"""
        self._running = False
        self.input_queue.put(None)
        self._thread.join(timeout=1.0)
