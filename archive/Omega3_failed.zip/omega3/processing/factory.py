"""
Factory for creating spectrum processors with proper configuration
Provides centralized creation and validation of spectrum processing components
"""

from typing import Dict, Type, Optional, Union
import logging

from .config import (
    ProcessingConfig, 
    DEFAULT_PROCESSING_CONFIG, 
    STUDIO_PROCESSING_CONFIG, 
    PERFORMANCE_PROCESSING_CONFIG
)
from .base_spectrum import BaseSpectrumProcessor, PerceptualSpectrumProcessor, LinearSpectrumProcessor
from .spectrum import SpectrumProcessor, BassDetailProcessor
from .math_utils import validate_positive, validate_range


class SpectrumProcessorFactory:
    """
    Factory for creating spectrum processors with proper configuration
    Handles validation, logging, and centralized creation logic
    """
    
    # Registry of available processor types
    _PROCESSOR_TYPES: Dict[str, Type[BaseSpectrumProcessor]] = {
        "perceptual": PerceptualSpectrumProcessor,
        "linear": LinearSpectrumProcessor,
    }
    
    # Predefined configurations
    _CONFIGS: Dict[str, ProcessingConfig] = {
        "default": DEFAULT_PROCESSING_CONFIG,
        "studio": STUDIO_PROCESSING_CONFIG,
        "performance": PERFORMANCE_PROCESSING_CONFIG,
    }
    
    def __init__(self):
        self.logger = logging.getLogger("omega3.SpectrumProcessorFactory")
        self._created_processors = []  # Track created processors for cleanup
    
    @classmethod
    def create_spectrum_processor(
        cls,
        processor_type: str = "perceptual",
        config: Optional[Union[ProcessingConfig, str]] = None,
        **config_overrides
    ) -> BaseSpectrumProcessor:
        """
        Create a spectrum processor with specified configuration
        
        Args:
            processor_type: Type of processor ("perceptual" or "linear")
            config: Configuration object or preset name
            **config_overrides: Override specific config parameters
        
        Returns:
            Configured spectrum processor
        
        Raises:
            ValueError: If processor type or config is invalid
        """
        factory = cls()
        return factory._create_processor(processor_type, config, **config_overrides)
    
    def _create_processor(
        self,
        processor_type: str,
        config: Optional[Union[ProcessingConfig, str]],
        **config_overrides
    ) -> BaseSpectrumProcessor:
        """Internal processor creation method"""
        
        # Validate processor type
        if processor_type not in self._PROCESSOR_TYPES:
            available = ", ".join(self._PROCESSOR_TYPES.keys())
            raise ValueError(f"Unknown processor type '{processor_type}'. Available: {available}")
        
        # Resolve configuration
        final_config = self._resolve_config(config, **config_overrides)
        
        # Validate configuration
        self._validate_config(final_config)
        
        # Create processor
        processor_class = self._PROCESSOR_TYPES[processor_type]
        processor = processor_class(final_config)
        
        # Track created processor
        self._created_processors.append(processor)
        
        self.logger.info(f"Created {processor_type} processor with config: {final_config}")
        return processor
    
    def _resolve_config(
        self,
        config: Optional[Union[ProcessingConfig, str]],
        **overrides
    ) -> ProcessingConfig:
        """Resolve configuration from various input types"""
        
        base_config = None
        
        if config is None:
            base_config = DEFAULT_PROCESSING_CONFIG
        elif isinstance(config, str):
            if config not in self._CONFIGS:
                available = ", ".join(self._CONFIGS.keys())
                raise ValueError(f"Unknown config preset '{config}'. Available: {available}")
            base_config = self._CONFIGS[config]
        elif isinstance(config, ProcessingConfig):
            base_config = config
        else:
            raise TypeError(f"Config must be ProcessingConfig or string, got {type(config)}")
        
        # Apply overrides if provided
        if overrides:
            config_dict = {
                'sample_rate': overrides.get('sample_rate', base_config.sample_rate),
                'fft_size_base': overrides.get('fft_size_base', base_config.fft_size_base),
                'max_freq': overrides.get('max_freq', base_config.max_freq),
                'bars_default': overrides.get('bars_default', base_config.bars_default),
                'min_freq': overrides.get('min_freq', base_config.min_freq),
                'sub_bass_ratio': overrides.get('sub_bass_ratio', base_config.sub_bass_ratio),
                'bass_ratio': overrides.get('bass_ratio', base_config.bass_ratio),
                'low_mid_ratio': overrides.get('low_mid_ratio', base_config.low_mid_ratio),
                'mid_ratio': overrides.get('mid_ratio', base_config.mid_ratio),
                'high_mid_ratio': overrides.get('high_mid_ratio', base_config.high_mid_ratio),
                'midrange_boost_enabled': overrides.get('midrange_boost_enabled', base_config.midrange_boost_enabled),
                'midrange_boost_factor': overrides.get('midrange_boost_factor', base_config.midrange_boost_factor),
                'noise_threshold_db': overrides.get('noise_threshold_db', base_config.noise_threshold_db),
                'reference_level_db': overrides.get('reference_level_db', base_config.reference_level_db),
                'enable_vectorization': overrides.get('enable_vectorization', base_config.enable_vectorization),
                'pre_allocate_arrays': overrides.get('pre_allocate_arrays', base_config.pre_allocate_arrays),
            }
            base_config = ProcessingConfig(**config_dict)
        
        return base_config
    
    def _validate_config(self, config: ProcessingConfig) -> None:
        """Validate configuration parameters"""
        try:
            # Basic validation is handled by ProcessingConfig.__post_init__
            # Add additional validation here if needed
            
            # Validate sample rate ranges
            validate_range(config.sample_rate, 8000, 192000, "sample_rate")
            
            # Validate FFT size
            if config.fft_size_base < 256 or config.fft_size_base > 32768:
                raise ValueError(f"FFT size {config.fft_size_base} out of range [256, 32768]")
            
            # Validate bar count
            validate_range(config.bars_default, 16, 2048, "bars_default")
            
            self.logger.debug(f"Configuration validation passed: {config}")
            
        except Exception as e:
            self.logger.error(f"Configuration validation failed: {e}")
            raise
    
    @classmethod
    def create_legacy_spectrum_processor(
        cls,
        bars: int = None,
        sample_rate: int = None,
        **kwargs
    ) -> SpectrumProcessor:
        """
        Create legacy SpectrumProcessor for backward compatibility
        
        Args:
            bars: Number of spectrum bars
            sample_rate: Audio sample rate
            **kwargs: Additional parameters
        
        Returns:
            Legacy SpectrumProcessor instance
        """
        factory = cls()
        
        # Create config from legacy parameters
        config_params = {}
        if bars is not None:
            config_params['bars_default'] = bars
        if sample_rate is not None:
            config_params['sample_rate'] = sample_rate
        
        # Add any additional config overrides
        config_params.update(kwargs)
        
        # Use default config as base
        config = factory._resolve_config("default", **config_params)
        factory._validate_config(config)
        
        # Create legacy processor
        processor = SpectrumProcessor(config=config)
        factory._created_processors.append(processor)
        
        factory.logger.info(f"Created legacy SpectrumProcessor with {bars} bars at {sample_rate}Hz")
        return processor
    
    @classmethod
    def create_bass_detail_processor(
        cls,
        sample_rate: int = None,
        config: Optional[Union[ProcessingConfig, str]] = None,
        **config_overrides
    ) -> BassDetailProcessor:
        """
        Create bass detail processor for enhanced low-frequency analysis
        
        Args:
            sample_rate: Audio sample rate
            config: Configuration object or preset name
            **config_overrides: Override specific config parameters
        
        Returns:
            Configured bass detail processor
        """
        factory = cls()
        
        # Resolve configuration
        if sample_rate is not None:
            config_overrides['sample_rate'] = sample_rate
        
        final_config = factory._resolve_config(config or "default", **config_overrides)
        factory._validate_config(final_config)
        
        # Create bass processor
        processor = BassDetailProcessor(final_config.sample_rate)
        factory._created_processors.append(processor)
        
        factory.logger.info(f"Created BassDetailProcessor at {final_config.sample_rate}Hz")
        return processor
    
    @classmethod
    def get_available_processor_types(cls) -> Dict[str, str]:
        """
        Get available processor types with descriptions
        
        Returns:
            Dictionary mapping processor type names to descriptions
        """
        return {
            "perceptual": "Perceptual frequency mapping optimized for musical content",
            "linear": "Linear frequency mapping for technical analysis",
        }
    
    @classmethod
    def get_available_presets(cls) -> Dict[str, str]:
        """
        Get available configuration presets with descriptions
        
        Returns:
            Dictionary mapping preset names to descriptions
        """
        return {
            "default": "Balanced settings for general use (48kHz, 256 bars)",
            "studio": "High-quality settings for studio applications (96kHz, 512 bars)",
            "performance": "Optimized settings for real-time performance (44.1kHz, 128 bars)",
        }
    
    @classmethod
    def create_for_audio_source(
        cls,
        source_sample_rate: int,
        target_latency_ms: float = 10.0,
        quality_preference: str = "balanced"
    ) -> BaseSpectrumProcessor:
        """
        Create processor optimized for specific audio source
        
        Args:
            source_sample_rate: Sample rate of audio source
            target_latency_ms: Target processing latency in milliseconds
            quality_preference: "performance", "balanced", or "quality"
        
        Returns:
            Optimized spectrum processor
        """
        factory = cls()
        
        # Determine optimal configuration based on requirements
        if quality_preference == "performance":
            base_config = "performance"
            bars = 128
            fft_size = 2048
        elif quality_preference == "quality":
            base_config = "studio"
            bars = 512
            fft_size = 8192
        else:  # balanced
            base_config = "default"
            bars = 256
            fft_size = 4096
        
        # Adjust for target latency
        if target_latency_ms < 5.0:
            bars = min(bars, 128)
            fft_size = min(fft_size, 2048)
        elif target_latency_ms > 20.0:
            bars = min(bars * 2, 1024)
            fft_size = min(fft_size * 2, 16384)
        
        # Create optimized processor
        processor = factory._create_processor(
            "perceptual",
            base_config,
            sample_rate=source_sample_rate,
            bars_default=bars,
            fft_size_base=fft_size
        )
        
        factory.logger.info(
            f"Created optimized processor for {source_sample_rate}Hz source, "
            f"target latency {target_latency_ms}ms, quality: {quality_preference}"
        )
        
        return processor
    
    def cleanup(self) -> None:
        """Clean up created processors"""
        for processor in self._created_processors:
            if hasattr(processor, 'cleanup'):
                try:
                    processor.cleanup()
                except Exception as e:
                    self.logger.warning(f"Error cleaning up processor {processor}: {e}")
        
        self._created_processors.clear()
        self.logger.info("Cleaned up all created processors")
    
    def __del__(self):
        """Cleanup on destruction"""
        try:
            self.cleanup()
        except Exception:
            pass  # Ignore errors during cleanup in destructor


# Convenience functions for common use cases

def create_spectrum_processor(
    processor_type: str = "perceptual",
    config: Optional[Union[ProcessingConfig, str]] = None,
    **config_overrides
) -> BaseSpectrumProcessor:
    """
    Convenience function to create a spectrum processor
    
    Args:
        processor_type: Type of processor ("perceptual" or "linear")
        config: Configuration object or preset name
        **config_overrides: Override specific config parameters
    
    Returns:
        Configured spectrum processor
    """
    return SpectrumProcessorFactory.create_spectrum_processor(
        processor_type, config, **config_overrides
    )


def create_legacy_processor(bars: int = 256, sample_rate: int = 48000) -> SpectrumProcessor:
    """
    Convenience function to create legacy SpectrumProcessor
    
    Args:
        bars: Number of spectrum bars
        sample_rate: Audio sample rate
    
    Returns:
        Legacy SpectrumProcessor instance
    """
    return SpectrumProcessorFactory.create_legacy_spectrum_processor(bars, sample_rate)


def create_optimized_processor(
    source_sample_rate: int,
    target_latency_ms: float = 10.0,
    quality_preference: str = "balanced"
) -> BaseSpectrumProcessor:
    """
    Convenience function to create optimized processor for audio source
    
    Args:
        source_sample_rate: Sample rate of audio source
        target_latency_ms: Target processing latency in milliseconds
        quality_preference: "performance", "balanced", or "quality"
    
    Returns:
        Optimized spectrum processor
    """
    return SpectrumProcessorFactory.create_for_audio_source(
        source_sample_rate, target_latency_ms, quality_preference
    )