"""
Advanced smoothing algorithms for OMEGA-3.
Provides various smoothing methods for audio visualizations.
"""

from collections import deque
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import numpy as np


class SmoothingMethod:
    """Available smoothing methods."""

    NONE = "none"
    EXPONENTIAL = "exponential"
    GAUSSIAN = "gaussian"
    SAVITZKY_GOLAY = "savitzky_golay"
    MOVING_AVERAGE = "moving_average"
    KALMAN = "kalman"
    BUTTERWORTH = "butterworth"
    ADAPTIVE = "adaptive"


class Smoother:
    """Base class for smoothing implementations."""

    def __init__(self, size: int, alpha: float = 0.5):
        self.size = size
        self.alpha = alpha
        self.history = None

    def smooth(self, data: np.ndarray) -> np.ndarray:
        """Apply smoothing to data."""
        raise NotImplementedError

    def reset(self):
        """Reset smoother state."""
        self.history = None


class ExponentialSmoother(Smoother):
    """Exponential smoothing with configurable attack/decay."""

    def __init__(self, size: int, attack: float = 0.8, decay: float = 0.3):
        super().__init__(size)
        self.attack = attack  # How quickly to rise
        self.decay = decay  # How quickly to fall

    def smooth(self, data: np.ndarray) -> np.ndarray:
        """Apply exponential smoothing with different attack/decay rates."""
        if self.history is None:
            self.history = data.copy()
            return data

        result = np.zeros_like(data)

        for i in range(len(data)):
            if data[i] > self.history[i]:
                # Rising - use attack rate
                result[i] = self.history[i] + self.attack * (data[i] - self.history[i])
            else:
                # Falling - use decay rate
                result[i] = self.history[i] + self.decay * (data[i] - self.history[i])

        self.history = result.copy()
        return result


class GaussianSmoother(Smoother):
    """Gaussian smoothing for frequency domain data."""

    def __init__(self, size: int, sigma: float = 1.0):
        super().__init__(size)
        self.sigma = sigma
        self._create_kernel()

    def _create_kernel(self):
        """Create Gaussian kernel."""
        kernel_size = int(4 * self.sigma) + 1
        x = np.arange(kernel_size) - kernel_size // 2
        self.kernel = np.exp(-0.5 * (x / self.sigma) ** 2)
        self.kernel /= self.kernel.sum()

    def smooth(self, data: np.ndarray) -> np.ndarray:
        """Apply Gaussian smoothing."""
        # Pad data for convolution
        pad_width = len(self.kernel) // 2
        padded = np.pad(data, pad_width, mode="edge")

        # Convolve with kernel
        smoothed = np.convolve(padded, self.kernel, mode="valid")

        return smoothed


class SavitzkyGolaySmoother(Smoother):
    """Savitzky-Golay filter for smooth derivatives."""

    def __init__(self, size: int, window_length: int = 5, polyorder: int = 2):
        super().__init__(size)
        self.window_length = window_length
        self.polyorder = polyorder
        self._create_coefficients()

    def _create_coefficients(self):
        """Create Savitzky-Golay coefficients."""
        # Simplified implementation
        # In practice, would use scipy.signal.savgol_coeffs
        self.coeffs = np.ones(self.window_length) / self.window_length

    def smooth(self, data: np.ndarray) -> np.ndarray:
        """Apply Savitzky-Golay filter."""
        if len(data) < self.window_length:
            return data

        # Pad data
        pad_width = self.window_length // 2
        padded = np.pad(data, pad_width, mode="edge")

        # Apply filter
        smoothed = np.convolve(padded, self.coeffs, mode="valid")

        return smoothed


class MovingAverageSmoother(Smoother):
    """Simple moving average smoother."""

    def __init__(self, size: int, window_size: int = 3):
        super().__init__(size)
        self.window_size = window_size
        self.buffer = deque(maxlen=window_size)

    def smooth(self, data: np.ndarray) -> np.ndarray:
        """Apply moving average."""
        self.buffer.append(data.copy())

        if len(self.buffer) < self.window_size:
            return data

        # Average over window
        return np.mean(np.array(self.buffer), axis=0)

    def reset(self):
        """Reset buffer."""
        super().reset()
        self.buffer.clear()


class KalmanSmoother(Smoother):
    """Kalman filter for optimal state estimation."""

    def __init__(
        self, size: int, process_noise: float = 0.01, measurement_noise: float = 0.1
    ):
        super().__init__(size)
        self.process_noise = process_noise
        self.measurement_noise = measurement_noise

        # Kalman filter state
        self.state = None
        self.covariance = None

    def smooth(self, data: np.ndarray) -> np.ndarray:
        """Apply Kalman filtering."""
        if self.state is None:
            self.state = data.copy()
            self.covariance = np.ones_like(data) * 0.1
            return data

        # Prediction step
        predicted_state = self.state
        predicted_covariance = self.covariance + self.process_noise

        # Update step
        kalman_gain = predicted_covariance / (
            predicted_covariance + self.measurement_noise
        )
        self.state = predicted_state + kalman_gain * (data - predicted_state)
        self.covariance = (1 - kalman_gain) * predicted_covariance

        return self.state

    def reset(self):
        """Reset Kalman filter state."""
        super().reset()
        self.state = None
        self.covariance = None


class ButterworthSmoother(Smoother):
    """Butterworth low-pass filter smoother."""

    def __init__(self, size: int, cutoff: float = 0.1, order: int = 2):
        super().__init__(size)
        self.cutoff = cutoff  # Normalized cutoff frequency (0-1)
        self.order = order

        # Filter state
        self.z = None

        # Calculate filter coefficients
        self._calculate_coefficients()

    def _calculate_coefficients(self):
        """Calculate Butterworth filter coefficients."""
        # Simplified 2nd order Butterworth
        # In practice, would use scipy.signal.butter
        wc = np.tan(np.pi * self.cutoff)
        k1 = np.sqrt(2) * wc
        k2 = wc * wc
        a = k2 / (1 + k1 + k2)

        self.b = np.array([a, 2 * a, a])
        self.a = np.array(
            [1, -2 * (k2 - 1) / (1 + k1 + k2), (1 - k1 + k2) / (1 + k1 + k2)]
        )

    def smooth(self, data: np.ndarray) -> np.ndarray:
        """Apply Butterworth filtering."""
        if self.z is None:
            self.z = np.zeros((max(len(self.a), len(self.b)) - 1, len(data)))

        # Apply filter sample by sample
        filtered = np.zeros_like(data)

        for i in range(len(data)):
            # Direct Form II implementation
            filtered[i] = self.b[0] * data[i] + self.z[0, i]

            # Update state
            if len(self.z) > 1:
                for j in range(len(self.z) - 1):
                    if j + 1 < len(self.b):
                        self.z[j, i] = (
                            self.b[j + 1] * data[i]
                            - self.a[j + 1] * filtered[i]
                            + self.z[j + 1, i]
                        )
                    else:
                        self.z[j, i] = -self.a[j + 1] * filtered[i] + self.z[j + 1, i]

                # Last state
                if len(self.b) > len(self.z):
                    self.z[-1, i] = self.b[-1] * data[i] - self.a[-1] * filtered[i]
                else:
                    self.z[-1, i] = -self.a[-1] * filtered[i]

        return filtered


class AdaptiveSmoother(Smoother):
    """Adaptive smoothing that adjusts based on signal characteristics."""

    def __init__(self, size: int):
        super().__init__(size)
        self.smoothers = {
            "slow": ExponentialSmoother(size, attack=0.3, decay=0.1),
            "medium": ExponentialSmoother(size, attack=0.6, decay=0.3),
            "fast": ExponentialSmoother(size, attack=0.9, decay=0.7),
        }
        self.activity_threshold = 0.1
        self.change_history = deque(maxlen=10)

    def smooth(self, data: np.ndarray) -> np.ndarray:
        """Apply adaptive smoothing based on signal activity."""
        # Calculate change from previous
        if self.history is not None:
            change = np.mean(np.abs(data - self.history))
            self.change_history.append(change)
        else:
            self.history = data.copy()
            return data

        # Determine activity level
        if len(self.change_history) > 0:
            avg_change = np.mean(self.change_history)

            if avg_change < self.activity_threshold * 0.5:
                # Low activity - heavy smoothing
                result = self.smoothers["slow"].smooth(data)
            elif avg_change < self.activity_threshold:
                # Medium activity
                result = self.smoothers["medium"].smooth(data)
            else:
                # High activity - light smoothing
                result = self.smoothers["fast"].smooth(data)
        else:
            result = self.smoothers["medium"].smooth(data)

        self.history = result.copy()
        return result


class SmootherBank:
    """Bank of smoothers for different frequency ranges."""

    def __init__(self, size: int, config: Optional[Dict[str, Dict[str, any]]] = None):
        self.size = size

        # Default configuration
        if config is None:
            config = {
                "bass": {
                    "method": SmoothingMethod.EXPONENTIAL,
                    "attack": 0.7,
                    "decay": 0.2,
                },
                "mid": {
                    "method": SmoothingMethod.EXPONENTIAL,
                    "attack": 0.8,
                    "decay": 0.4,
                },
                "high": {
                    "method": SmoothingMethod.EXPONENTIAL,
                    "attack": 0.9,
                    "decay": 0.6,
                },
            }

        self.smoothers = {}
        self._create_smoothers(config)

    def _create_smoothers(self, config: Dict[str, Dict[str, any]]):
        """Create smoothers based on configuration."""
        for range_name, params in config.items():
            method = params.get("method", SmoothingMethod.EXPONENTIAL)

            if method == SmoothingMethod.EXPONENTIAL:
                self.smoothers[range_name] = ExponentialSmoother(
                    self.size,
                    attack=params.get("attack", 0.8),
                    decay=params.get("decay", 0.3),
                )
            elif method == SmoothingMethod.GAUSSIAN:
                self.smoothers[range_name] = GaussianSmoother(
                    self.size, sigma=params.get("sigma", 1.0)
                )
            elif method == SmoothingMethod.KALMAN:
                self.smoothers[range_name] = KalmanSmoother(
                    self.size,
                    process_noise=params.get("process_noise", 0.01),
                    measurement_noise=params.get("measurement_noise", 0.1),
                )
            else:
                self.smoothers[range_name] = ExponentialSmoother(self.size)

    def smooth_with_ranges(
        self, data: np.ndarray, ranges: Dict[str, Tuple[int, int]]
    ) -> np.ndarray:
        """Apply different smoothing to different frequency ranges."""
        result = data.copy()

        for range_name, (start, end) in ranges.items():
            if range_name in self.smoothers:
                smoother = self.smoothers[range_name]
                result[start:end] = smoother.smooth(data[start:end])

        return result

    def reset(self):
        """Reset all smoothers."""
        for smoother in self.smoothers.values():
            smoother.reset()


class TemporalSmoother:
    """Temporal smoothing for time-series data."""

    def __init__(self, history_size: int = 30):
        self.history_size = history_size
        self.history = deque(maxlen=history_size)

    def add_frame(self, data: np.ndarray):
        """Add a frame to history."""
        self.history.append(data.copy())

    def get_smoothed(self, method: str = "median") -> Optional[np.ndarray]:
        """Get temporally smoothed data."""
        if len(self.history) == 0:
            return None

        history_array = np.array(self.history)

        if method == "mean":
            return np.mean(history_array, axis=0)
        elif method == "median":
            return np.median(history_array, axis=0)
        elif method == "weighted":
            # Recent frames have more weight
            weights = np.linspace(0.1, 1.0, len(self.history))
            weights /= weights.sum()
            return np.average(history_array, axis=0, weights=weights)
        else:
            return history_array[-1]  # Most recent

    def get_trend(self) -> Optional[np.ndarray]:
        """Calculate trend direction."""
        if len(self.history) < 2:
            return None

        # Simple linear trend
        history_array = np.array(self.history)
        x = np.arange(len(self.history))

        trends = np.zeros(history_array.shape[1])
        for i in range(history_array.shape[1]):
            # Linear regression
            coef = np.polyfit(x, history_array[:, i], 1)
            trends[i] = coef[0]  # Slope

        return trends
