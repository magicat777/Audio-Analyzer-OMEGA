"""
Spectrum processing with perceptual frequency mapping
Industry-standard frequency band mapping and compensation
Refactored to use new architecture with improved performance and robustness
"""

from typing import Dict, List, Optional, Tuple
import numpy as np
import logging

from .config import ProcessingConfig, DEFAULT_PROCESSING_CONFIG
from .base_spectrum import PerceptualSpectrumProcessor, LinearSpectrumProcessor
from .math_utils import profile_performance, validate_array_1d, validate_positive


class SpectrumProcessor:
    """Process FFT data into perceptually mapped spectrum bars with improved architecture"""

    def __init__(self, bars: int = None, sample_rate: int = None, config: Optional[ProcessingConfig] = None):
        # Use provided config or create from parameters
        if config is None:
            config = ProcessingConfig(
                bars_default=bars or DEFAULT_PROCESSING_CONFIG.bars_default,
                sample_rate=sample_rate or DEFAULT_PROCESSING_CONFIG.sample_rate
            )
        
        self.config = config
        self.bars = config.bars_default
        self.sample_rate = config.sample_rate
        self.nyquist = config.nyquist_freq
        
        # Use new base processor architecture
        self._processor = PerceptualSpectrumProcessor(config)
        self.logger = logging.getLogger("omega3.SpectrumProcessor")
        
        # Legacy compatibility
        self.freqs = None
        self.band_indices = []
        self.freq_compensation_gains = None
        self._initialized = False
        
        # Performance monitoring
        self._process_count = 0
        
        self.logger.info(f"Initialized with {self.bars} bars at {self.sample_rate}Hz")

    def _ensure_initialized(self, fft_size: int) -> None:
        """Ensure processor is initialized for given FFT size"""
        if not self._initialized or (self.freqs is not None and len(self.freqs) != fft_size // 2 + 1):
            self._initialize_for_fft_size(fft_size)
    
    def _initialize_for_fft_size(self, fft_size: int) -> None:
        """Initialize processor for specific FFT size"""
        validate_positive(fft_size, "fft_size")
        
        # Initialize underlying processor
        self._processor.initialize(fft_size)
        
        # Set up legacy compatibility
        self.freqs = self._processor.frequency_bins
        self.band_indices = [list(bm.fft_bin_indices) for bm in self._processor.band_mappings]
        
        # Ensure we have exactly the requested number of bars
        actual_bars = len(self.band_indices)
        if actual_bars != self.bars:
            self.logger.warning(f"Created {actual_bars} bands, expected {self.bars}. Adjusting.")
            # Pad or trim to match expected size
            if actual_bars < self.bars:
                # Pad with empty bands
                for _ in range(self.bars - actual_bars):
                    self.band_indices.append([])
            else:
                # Trim excess bands
                self.band_indices = self.band_indices[:self.bars]
        
        # Create legacy compensation gains array
        self.freq_compensation_gains = np.ones(self.bars, dtype=np.float32)
        for i, band_mapping in enumerate(self._processor.band_mappings):
            center_freq = band_mapping.frequency_range.center_hz
            if self._processor.compensation_curve:
                self.freq_compensation_gains[i] = self._processor.compensation_curve.get_gain_at_frequency(center_freq)
        
        self._initialized = True
        self.logger.info(f"Initialized for FFT size {fft_size}, created {self.bars} bands")

    @property
    def midrange_boost_enabled(self) -> bool:
        """Legacy compatibility for midrange boost"""
        return self.config.midrange_boost_enabled
    
    @property
    def midrange_boost_factor(self) -> float:
        """Legacy compatibility for midrange boost factor"""
        return self.config.midrange_boost_factor

    def _setup_optimized_band_mapping(self):
        """Legacy method - now handled by base processor"""
        # This is now handled by the base processor automatically
        pass

    def _setup_frequency_ranges(self):
        """Legacy method - now handled by base processor"""
        # This is now handled by the base processor automatically
        pass

    def freq_to_x_position(self, freq: float, width: int) -> int:
        """Convert frequency to x-position for rendering"""
        if not self._initialized:
            self.logger.warning("Processor not initialized, using default FFT size")
            self._initialize_for_fft_size(self.config.fft_size_base)
        
        return self._processor.freq_to_x_position(freq, width)

    def get_frequency_range_for_bar(self, bar_index: int) -> Tuple[float, float]:
        """Get frequency range for a specific bar"""
        if not self._initialized:
            return (0, 0)
        
        freq_range = self._processor.get_frequency_range_for_band(bar_index)
        if freq_range:
            return (freq_range.start_hz, freq_range.end_hz)
        return (0, 0)

    @profile_performance
    def process_fft_data(
        self, fft_data: np.ndarray, apply_compensation: bool = True
    ) -> np.ndarray:
        """Process FFT data into spectrum bars with perceptual mapping"""
        try:
            validate_array_1d(fft_data, "fft_data")
            
            # Ensure processor is initialized for this FFT size
            fft_size = 2 * (len(fft_data) - 1)
            self._ensure_initialized(fft_size)
            
            # Use new base processor
            result = self._processor.process(
                fft_data, 
                apply_compensation=apply_compensation, 
                normalize_output=True
            )
            
            
            # Ensure result matches expected bar count
            if len(result) != self.bars:
                self.logger.warning(f"Result has {len(result)} values, expected {self.bars}. Adjusting.")
                if len(result) < self.bars:
                    # Pad with zeros
                    padded_result = np.zeros(self.bars, dtype=np.float32)
                    padded_result[:len(result)] = result
                    result = padded_result
                else:
                    # Trim excess
                    result = result[:self.bars]
            
            self._process_count += 1
            return result
            
        except Exception as e:
            self.logger.error(f"Error processing FFT data: {e}")
            # Return safe fallback
            return np.zeros(self.bars, dtype=np.float32)

    def update_midrange_boost(self, factor: float):
        """Update midrange boost factor and recalculate compensation"""
        validate_positive(factor, "midrange_boost_factor")
        
        # Create new config with updated boost factor
        new_config = ProcessingConfig(
            sample_rate=self.config.sample_rate,
            bars_default=self.config.bars_default,
            midrange_boost_factor=factor,
            midrange_boost_enabled=True
        )
        
        # Reinitialize processor with new config
        old_fft_size = len(self.freqs) * 2 - 2 if self.freqs is not None else self.config.fft_size_base
        self.config = new_config
        self._processor = PerceptualSpectrumProcessor(new_config)
        self._initialized = False
        
        if old_fft_size:
            self._initialize_for_fft_size(old_fft_size)
        
        self.logger.info(f"Updated midrange boost factor to {factor}")
    
    def get_performance_stats(self) -> Dict[str, float]:
        """Get performance statistics"""
        if self._initialized:
            return self._processor.get_performance_stats()
        return {"process_count": self._process_count}
    
    def validate_configuration(self) -> List[str]:
        """Validate processor configuration"""
        if self._initialized:
            return self._processor.validate_configuration()
        return ["Processor not initialized"]


class BassDetailProcessor:
    """Process bass frequencies with enhanced detail using new architecture"""

    def __init__(self, sample_rate: int = None, config: Optional[ProcessingConfig] = None):
        if config is None:
            config = ProcessingConfig(sample_rate=sample_rate or DEFAULT_PROCESSING_CONFIG.sample_rate)
        
        self.config = config
        self.sample_rate = config.sample_rate
        self.logger = logging.getLogger("omega3.BassDetailProcessor")

        # Larger FFT for better bass resolution
        self.bass_fft_size = 8192
        self.bass_freqs = np.fft.rfftfreq(self.bass_fft_size, 1 / self.sample_rate)

        # Setup bass frequency mapping
        self._setup_bass_frequency_mapping()
        
        self.logger.info(f"Initialized bass processor with {self.bass_detail_bars} bars")

    def _setup_bass_frequency_mapping(self):
        """Create frequency mapping for bass detail panel"""
        bass_min_freq = 20.0
        bass_max_freq = 200.0

        # Find FFT bins that cover bass range
        valid_bins = np.where(
            (self.bass_freqs >= bass_min_freq) & (self.bass_freqs <= bass_max_freq)
        )[0]

        if len(valid_bins) == 0:
            self.bass_freq_ranges = [(20, 200)]
            self.bass_bin_mapping = [[]]
            self.bass_detail_bars = 1
            self.logger.warning("No valid bass frequency bins found")
            return

        # Create frequency ranges
        self.bass_freq_ranges = []
        self.bass_bin_mapping = []

        # Target ~31 bars for good visual density
        bins_per_bar = max(1, len(valid_bins) // 31)

        for i in range(0, len(valid_bins), bins_per_bar):
            end_idx = min(i + bins_per_bar, len(valid_bins))
            bin_group = valid_bins[i:end_idx]

            if len(bin_group) > 0:
                f_start = self.bass_freqs[bin_group[0]]
                f_end = self.bass_freqs[bin_group[-1]]

                # Ensure ranges don't overlap
                if len(self.bass_freq_ranges) > 0:
                    f_start = max(f_start, self.bass_freq_ranges[-1][1])

                self.bass_freq_ranges.append((f_start, f_end))
                self.bass_bin_mapping.append(bin_group)

        self.bass_detail_bars = len(self.bass_freq_ranges)

    @profile_performance
    def process_bass_fft(self, fft_data: np.ndarray, bass_gain: float = 4.0) -> np.ndarray:
        """Process FFT data for bass detail visualization"""
        try:
            validate_array_1d(fft_data, "fft_data")
            validate_positive(bass_gain, "bass_gain")
            
            bass_values = np.zeros(self.bass_detail_bars, dtype=np.float32)

            for i, bin_indices in enumerate(self.bass_bin_mapping):
                if len(bin_indices) > 0 and np.max(bin_indices) < len(fft_data):
                    bass_values[i] = np.mean(fft_data[bin_indices])

            # Apply bass-specific noise gate using config
            noise_threshold = self.config.noise_threshold_linear * 0.1  # More sensitive for bass
            bass_values = np.where(bass_values < noise_threshold, 0.0, bass_values)
            
            # Apply bass gain
            bass_values = bass_values * bass_gain
            
            # Convert to dB and normalize using math utils
            from .math_utils import linear_to_db, normalize_to_range
            bass_values_db = linear_to_db(bass_values, min_db=self.config.noise_threshold_db - 10)
            bass_values_normalized = normalize_to_range(
                bass_values_db, 
                self.config.noise_threshold_db - 10, 
                self.config.reference_level_db,
                0.0, 1.0
            )

            return bass_values_normalized
            
        except Exception as e:
            self.logger.error(f"Error processing bass FFT: {e}")
            return np.zeros(self.bass_detail_bars, dtype=np.float32)
