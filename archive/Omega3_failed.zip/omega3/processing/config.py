"""
Processing configuration objects for OMEGA-3
Centralized configuration management for spectrum processing components
"""

from dataclasses import dataclass
from typing import Optional, Tuple
import numpy as np


@dataclass(frozen=True)
class ProcessingConfig:
    """Immutable configuration for spectrum processing"""
    
    # Audio parameters
    sample_rate: int = 48000
    fft_size_base: int = 4096
    max_freq: float = 20000.0
    
    # Spectrum parameters
    bars_default: int = 256
    min_freq: float = 20.0
    
    # Frequency band distribution (percentages)
    sub_bass_ratio: float = 0.08    # 20-60Hz
    bass_ratio: float = 0.17        # 60-250Hz
    low_mid_ratio: float = 0.15     # 250-500Hz
    mid_ratio: float = 0.25         # 500-2000Hz (critical)
    high_mid_ratio: float = 0.20    # 2000-6000Hz
    # high_ratio calculated as remainder
    
    # Frequency compensation settings
    midrange_boost_enabled: bool = True
    midrange_boost_factor: float = 2.0
    
    # dB conversion settings
    noise_threshold_db: float = -60.0
    reference_level_db: float = 0.0
    
    # Performance settings
    enable_vectorization: bool = True
    pre_allocate_arrays: bool = True
    
    def __post_init__(self):
        """Validate configuration parameters"""
        if self.sample_rate <= 0:
            raise ValueError("Sample rate must be positive")
        if self.fft_size_base <= 0 or (self.fft_size_base & (self.fft_size_base - 1)) != 0:
            raise ValueError("FFT size must be a power of 2")
        if self.bars_default <= 0:
            raise ValueError("Number of bars must be positive")
        if self.min_freq >= self.max_freq:
            raise ValueError("Min frequency must be less than max frequency")
        
        # Validate frequency ratios sum to <= 1.0
        total_ratio = (self.sub_bass_ratio + self.bass_ratio + self.low_mid_ratio + 
                      self.mid_ratio + self.high_mid_ratio)
        if total_ratio > 1.0:
            raise ValueError(f"Frequency ratios sum to {total_ratio:.3f}, must be <= 1.0")
    
    @property
    def nyquist_freq(self) -> float:
        """Get Nyquist frequency"""
        return self.sample_rate / 2.0
    
    @property
    def effective_max_freq(self) -> float:
        """Get effective maximum frequency (limited by Nyquist)"""
        return min(self.max_freq, self.nyquist_freq)
    
    @property
    def high_ratio(self) -> float:
        """Calculate high frequency ratio as remainder"""
        return 1.0 - (self.sub_bass_ratio + self.bass_ratio + self.low_mid_ratio + 
                     self.mid_ratio + self.high_mid_ratio)
    
    @property
    def noise_threshold_linear(self) -> float:
        """Convert noise threshold from dB to linear scale"""
        return 10.0 ** (self.noise_threshold_db / 20.0)


@dataclass(frozen=True)
class FrequencyRange:
    """Immutable frequency range specification"""
    
    start_hz: float
    end_hz: float
    center_hz: Optional[float] = None
    
    def __post_init__(self):
        """Calculate center frequency if not provided"""
        if self.start_hz > self.end_hz:
            raise ValueError(f"Start frequency ({self.start_hz}) must be less than or equal to end frequency ({self.end_hz})")
        
        # Handle equal start and end frequencies by adding small epsilon
        if self.start_hz == self.end_hz:
            object.__setattr__(self, 'end_hz', self.end_hz + 0.1)  # Add 0.1 Hz epsilon
        
        if self.center_hz is None:
            # Use geometric mean for center frequency
            object.__setattr__(self, 'center_hz', np.sqrt(self.start_hz * self.end_hz))
    
    @property
    def bandwidth(self) -> float:
        """Get bandwidth in Hz"""
        return self.end_hz - self.start_hz
    
    def contains(self, frequency: float) -> bool:
        """Check if frequency is within this range"""
        return self.start_hz <= frequency <= self.end_hz
    
    def overlap_with(self, other: 'FrequencyRange') -> Optional['FrequencyRange']:
        """Find overlap with another frequency range"""
        overlap_start = max(self.start_hz, other.start_hz)
        overlap_end = min(self.end_hz, other.end_hz)
        
        if overlap_start < overlap_end:
            return FrequencyRange(overlap_start, overlap_end)
        return None


@dataclass(frozen=True)
class BandMapping:
    """Immutable frequency band to FFT bin mapping"""
    
    frequency_range: FrequencyRange
    fft_bin_indices: Tuple[int, ...]  # Immutable tuple of bin indices
    weight: float = 1.0
    
    def __post_init__(self):
        """Validate band mapping"""
        # Allow empty bin indices for padding bands
        if self.weight < 0:
            raise ValueError("Weight must be non-negative")
    
    @property
    def num_bins(self) -> int:
        """Get number of FFT bins in this band"""
        return len(self.fft_bin_indices)
    
    @property
    def bin_range(self) -> Tuple[int, int]:
        """Get min and max bin indices"""
        return (min(self.fft_bin_indices), max(self.fft_bin_indices))


@dataclass(frozen=True)
class CompensationCurve:
    """Immutable frequency compensation curve"""
    
    frequency_gains: Tuple[Tuple[float, float], ...]  # (frequency_hz, gain)
    
    def __post_init__(self):
        """Validate compensation curve"""
        if not self.frequency_gains:
            raise ValueError("Compensation curve cannot be empty")
        
        # Ensure frequencies are sorted
        frequencies = [fg[0] for fg in self.frequency_gains]
        if frequencies != sorted(frequencies):
            raise ValueError("Frequencies must be sorted in ascending order")
    
    def get_gain_at_frequency(self, frequency: float) -> float:
        """Get interpolated gain at specific frequency"""
        if not self.frequency_gains:
            return 1.0
        
        # Handle edge cases
        if frequency <= self.frequency_gains[0][0]:
            return self.frequency_gains[0][1]
        if frequency >= self.frequency_gains[-1][0]:
            return self.frequency_gains[-1][1]
        
        # Linear interpolation
        for i in range(len(self.frequency_gains) - 1):
            f1, g1 = self.frequency_gains[i]
            f2, g2 = self.frequency_gains[i + 1]
            
            if f1 <= frequency <= f2:
                # Linear interpolation
                t = (frequency - f1) / (f2 - f1)
                return g1 + t * (g2 - g1)
        
        return 1.0  # Fallback


# Default configurations
DEFAULT_PROCESSING_CONFIG = ProcessingConfig()

STUDIO_PROCESSING_CONFIG = ProcessingConfig(
    sample_rate=96000,
    fft_size_base=8192,
    bars_default=512,
    midrange_boost_factor=1.5,
    noise_threshold_db=-80.0
)

PERFORMANCE_PROCESSING_CONFIG = ProcessingConfig(
    sample_rate=44100,
    fft_size_base=2048,
    bars_default=128,
    midrange_boost_factor=1.2,
    enable_vectorization=True,
    pre_allocate_arrays=True
)