"""
Frequency mapping utilities for OMEGA-3.
Handles perceptual frequency scaling and band mapping.
"""

from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import numpy as np


class FrequencyScale:
    """Available frequency scaling methods."""

    LINEAR = "linear"
    LOG = "log"
    MEL = "mel"
    BARK = "bark"
    ERB = "erb"
    OCTAVE = "octave"
    MUSIC = "music"


class FrequencyMapper:
    """Maps frequencies to visual representation using various scales."""

    def __init__(self, sample_rate: int = 48000, scale: str = FrequencyScale.LOG):
        self.sample_rate = sample_rate
        self.nyquist = sample_rate / 2
        self.scale = scale

        # Frequency range limits
        self.min_freq = 20.0
        self.max_freq = min(20000.0, self.nyquist)

        # Musical note frequencies (A4 = 440Hz)
        self.note_frequencies = self._generate_note_frequencies()

    def _generate_note_frequencies(self) -> Dict[str, float]:
        """Generate frequencies for musical notes."""
        notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        frequencies = {}

        # Generate frequencies for octaves 0-9
        for octave in range(10):
            for i, note in enumerate(notes):
                # A4 = 440Hz, A0 = 27.5Hz
                freq = 27.5 * (2 ** (octave + i / 12))
                frequencies[f"{note}{octave}"] = freq

        return frequencies

    def frequency_to_scaled(self, freq: float) -> float:
        """Convert frequency to scaled value based on selected scale."""
        if freq <= 0:
            return 0.0

        freq = np.clip(freq, self.min_freq, self.max_freq)

        if self.scale == FrequencyScale.LINEAR:
            return self._linear_scale(freq)
        elif self.scale == FrequencyScale.LOG:
            return self._log_scale(freq)
        elif self.scale == FrequencyScale.MEL:
            return self._mel_scale(freq)
        elif self.scale == FrequencyScale.BARK:
            return self._bark_scale(freq)
        elif self.scale == FrequencyScale.ERB:
            return self._erb_scale(freq)
        elif self.scale == FrequencyScale.OCTAVE:
            return self._octave_scale(freq)
        elif self.scale == FrequencyScale.MUSIC:
            return self._music_scale(freq)
        else:
            return self._log_scale(freq)

    def scaled_to_frequency(self, scaled: float) -> float:
        """Convert scaled value back to frequency."""
        if self.scale == FrequencyScale.LINEAR:
            return self._linear_inverse(scaled)
        elif self.scale == FrequencyScale.LOG:
            return self._log_inverse(scaled)
        elif self.scale == FrequencyScale.MEL:
            return self._mel_inverse(scaled)
        elif self.scale == FrequencyScale.BARK:
            return self._bark_inverse(scaled)
        elif self.scale == FrequencyScale.ERB:
            return self._erb_inverse(scaled)
        elif self.scale == FrequencyScale.OCTAVE:
            return self._octave_inverse(scaled)
        elif self.scale == FrequencyScale.MUSIC:
            return self._music_inverse(scaled)
        else:
            return self._log_inverse(scaled)

    def _linear_scale(self, freq: float) -> float:
        """Linear frequency scaling."""
        return (freq - self.min_freq) / (self.max_freq - self.min_freq)

    def _linear_inverse(self, scaled: float) -> float:
        """Inverse linear scaling."""
        return self.min_freq + scaled * (self.max_freq - self.min_freq)

    def _log_scale(self, freq: float) -> float:
        """Logarithmic frequency scaling."""
        log_min = np.log10(self.min_freq)
        log_max = np.log10(self.max_freq)
        log_freq = np.log10(freq)
        return (log_freq - log_min) / (log_max - log_min)

    def _log_inverse(self, scaled: float) -> float:
        """Inverse logarithmic scaling."""
        log_min = np.log10(self.min_freq)
        log_max = np.log10(self.max_freq)
        log_freq = log_min + scaled * (log_max - log_min)
        return 10 ** log_freq

    def _mel_scale(self, freq: float) -> float:
        """Mel scale conversion."""
        mel = 2595 * np.log10(1 + freq / 700)
        mel_min = 2595 * np.log10(1 + self.min_freq / 700)
        mel_max = 2595 * np.log10(1 + self.max_freq / 700)
        return (mel - mel_min) / (mel_max - mel_min)

    def _mel_inverse(self, scaled: float) -> float:
        """Inverse mel scale."""
        mel_min = 2595 * np.log10(1 + self.min_freq / 700)
        mel_max = 2595 * np.log10(1 + self.max_freq / 700)
        mel = mel_min + scaled * (mel_max - mel_min)
        return 700 * (10 ** (mel / 2595) - 1)

    def _bark_scale(self, freq: float) -> float:
        """Bark scale conversion."""
        bark = 13 * np.arctan(0.00076 * freq) + 3.5 * np.arctan((freq / 7500) ** 2)
        bark_min = 13 * np.arctan(0.00076 * self.min_freq) + 3.5 * np.arctan(
            (self.min_freq / 7500) ** 2
        )
        bark_max = 13 * np.arctan(0.00076 * self.max_freq) + 3.5 * np.arctan(
            (self.max_freq / 7500) ** 2
        )
        return (bark - bark_min) / (bark_max - bark_min)

    def _bark_inverse(self, scaled: float) -> float:
        """Inverse Bark scale (approximation)."""
        # Simplified inverse - exact inverse is complex
        return self._log_inverse(scaled)  # Fallback to log

    def _erb_scale(self, freq: float) -> float:
        """ERB (Equivalent Rectangular Bandwidth) scale."""
        erb = 21.4 * np.log10(1 + 0.00437 * freq)
        erb_min = 21.4 * np.log10(1 + 0.00437 * self.min_freq)
        erb_max = 21.4 * np.log10(1 + 0.00437 * self.max_freq)
        return (erb - erb_min) / (erb_max - erb_min)

    def _erb_inverse(self, scaled: float) -> float:
        """Inverse ERB scale."""
        erb_min = 21.4 * np.log10(1 + 0.00437 * self.min_freq)
        erb_max = 21.4 * np.log10(1 + 0.00437 * self.max_freq)
        erb = erb_min + scaled * (erb_max - erb_min)
        return (10 ** (erb / 21.4) - 1) / 0.00437

    def _octave_scale(self, freq: float) -> float:
        """Octave-based scaling."""
        octave = np.log2(freq / self.min_freq)
        max_octaves = np.log2(self.max_freq / self.min_freq)
        return octave / max_octaves

    def _octave_inverse(self, scaled: float) -> float:
        """Inverse octave scaling."""
        max_octaves = np.log2(self.max_freq / self.min_freq)
        octave = scaled * max_octaves
        return self.min_freq * (2 ** octave)

    def _music_scale(self, freq: float) -> float:
        """Musical scale - emphasizes musical note frequencies."""
        # Find nearest note
        nearest_note_freq = self._find_nearest_note(freq)

        # Use logarithmic scale with slight attraction to notes
        log_scaled = self._log_scale(freq)
        note_scaled = self._log_scale(nearest_note_freq)

        # Blend between actual and note frequency (90% actual, 10% note)
        return 0.9 * log_scaled + 0.1 * note_scaled

    def _music_inverse(self, scaled: float) -> float:
        """Inverse musical scale."""
        # For simplicity, use log inverse
        return self._log_inverse(scaled)

    def _find_nearest_note(self, freq: float) -> float:
        """Find the nearest musical note frequency."""
        min_diff = float("inf")
        nearest_freq = freq

        for note_freq in self.note_frequencies.values():
            diff = abs(freq - note_freq)
            if diff < min_diff:
                min_diff = diff
                nearest_freq = note_freq

        return nearest_freq

    def create_frequency_bands(
        self, num_bands: int, distribution: str = "perceptual"
    ) -> List[Tuple[float, float]]:
        """Create frequency bands with specified distribution."""
        if distribution == "linear":
            return self._create_linear_bands(num_bands)
        elif distribution == "octave":
            return self._create_octave_bands(num_bands)
        elif distribution == "perceptual":
            return self._create_perceptual_bands(num_bands)
        elif distribution == "musical":
            return self._create_musical_bands(num_bands)
        else:
            return self._create_perceptual_bands(num_bands)

    def _create_linear_bands(self, num_bands: int) -> List[Tuple[float, float]]:
        """Create linearly spaced frequency bands."""
        bands = []
        bandwidth = (self.max_freq - self.min_freq) / num_bands

        for i in range(num_bands):
            start = self.min_freq + i * bandwidth
            end = start + bandwidth
            bands.append((start, end))

        return bands

    def _create_octave_bands(self, num_bands: int) -> List[Tuple[float, float]]:
        """Create octave-spaced frequency bands."""
        bands = []

        # Standard octave bands
        center_freqs = [31.5, 63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000]

        for center in center_freqs:
            if center > self.max_freq:
                break

            # Octave band edges
            lower = center / np.sqrt(2)
            upper = center * np.sqrt(2)

            if lower >= self.min_freq:
                bands.append((lower, upper))

        # If we need more bands, subdivide
        while len(bands) < num_bands and len(bands) > 0:
            new_bands = []
            for lower, upper in bands:
                center = np.sqrt(lower * upper)
                new_bands.extend([(lower, center), (center, upper)])
            bands = new_bands[:num_bands]

        return bands[:num_bands]

    def _create_perceptual_bands(self, num_bands: int) -> List[Tuple[float, float]]:
        """Create perceptually balanced frequency bands."""
        # Use scaled positions to create bands
        bands = []

        for i in range(num_bands):
            scaled_start = i / num_bands
            scaled_end = (i + 1) / num_bands

            freq_start = self.scaled_to_frequency(scaled_start)
            freq_end = self.scaled_to_frequency(scaled_end)

            bands.append((freq_start, freq_end))

        return bands

    def _create_musical_bands(self, num_bands: int) -> List[Tuple[float, float]]:
        """Create bands aligned with musical frequency ranges."""
        ranges = [
            (20, 60),  # Sub-bass
            (60, 250),  # Bass
            (250, 500),  # Low-mid
            (500, 2000),  # Mid
            (2000, 4000),  # High-mid
            (4000, 8000),  # Presence
            (8000, 20000),  # Brilliance
        ]

        bands = []

        # Distribute bands across ranges
        for start, end in ranges:
            if start > self.max_freq:
                break

            # Number of bands for this range (proportional to log width)
            range_width = np.log10(end) - np.log10(start)
            total_width = np.log10(self.max_freq) - np.log10(self.min_freq)
            range_bands = max(1, int(num_bands * range_width / total_width))

            # Create bands within range
            for i in range(range_bands):
                band_start = start * ((end / start) ** (i / range_bands))
                band_end = start * ((end / start) ** ((i + 1) / range_bands))

                if band_end <= self.max_freq:
                    bands.append((band_start, band_end))

        # Adjust to exact number of bands
        if len(bands) > num_bands:
            bands = bands[:num_bands]
        elif len(bands) < num_bands:
            # Add more bands in the mid range
            # This is a simplified approach
            bands = self._create_perceptual_bands(num_bands)

        return bands

    def map_fft_to_bands(
        self, fft_freqs: np.ndarray, bands: List[Tuple[float, float]]
    ) -> List[np.ndarray]:
        """Map FFT frequency bins to frequency bands."""
        band_indices = []

        for band_start, band_end in bands:
            # Find bins within this band
            indices = np.where((fft_freqs >= band_start) & (fft_freqs < band_end))[0]
            band_indices.append(indices)

        return band_indices

    def apply_a_weighting(
        self, frequencies: np.ndarray, magnitudes: np.ndarray
    ) -> np.ndarray:
        """Apply A-weighting to frequency magnitudes."""
        # A-weighting formula
        f2 = frequencies ** 2
        f4 = f2 ** 2

        c1 = 12194 ** 2
        c2 = 20.6 ** 2
        c3 = 107.7 ** 2
        c4 = 737.9 ** 2

        num = c1 * f4
        den = (f2 + c2) * np.sqrt((f2 + c3) * (f2 + c4)) * (f2 + c1)

        a_weight = num / den
        a_weight_db = 20 * np.log10(a_weight + 1e-10)

        # Normalize to 0 dB at 1 kHz
        ref_idx = np.argmin(np.abs(frequencies - 1000))
        if ref_idx < len(a_weight_db):
            a_weight_db -= a_weight_db[ref_idx]

        # Convert back to linear
        a_weight_linear = 10 ** (a_weight_db / 20)

        return magnitudes * a_weight_linear

    def apply_c_weighting(
        self, frequencies: np.ndarray, magnitudes: np.ndarray
    ) -> np.ndarray:
        """Apply C-weighting to frequency magnitudes."""
        # C-weighting formula (simplified)
        f2 = frequencies ** 2

        c1 = 12194 ** 2
        c2 = 20.6 ** 2

        num = c1 * f2
        den = (f2 + c2) * (f2 + c1)

        c_weight = num / den
        c_weight_db = 20 * np.log10(c_weight + 1e-10)

        # Normalize to 0 dB at 1 kHz
        ref_idx = np.argmin(np.abs(frequencies - 1000))
        if ref_idx < len(c_weight_db):
            c_weight_db -= c_weight_db[ref_idx]

        # Convert back to linear
        c_weight_linear = 10 ** (c_weight_db / 20)

        return magnitudes * c_weight_linear
