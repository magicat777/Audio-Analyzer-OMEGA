"""
Mathematical utilities for spectrum processing
Safe operations with proper bounds checking and error handling
"""

import numpy as np
from typing import Union, Optional
import warnings


def safe_log10(x: Union[float, np.ndarray], 
               min_value: float = 1e-10,
               replace_with: Optional[float] = None) -> Union[float, np.ndarray]:
    """
    Safe logarithm base 10 with protection against log(0) and negative values
    
    Args:
        x: Input value(s)
        min_value: Minimum value to clamp to before taking log
        replace_with: Value to use for invalid inputs (None uses log10(min_value))
    
    Returns:
        Safe log10 result
    """
    if replace_with is None:
        replace_with = np.log10(min_value)
    
    if isinstance(x, np.ndarray):
        # Vectorized operation
        safe_x = np.where(x > min_value, x, min_value)
        result = np.log10(safe_x)
        
        # Replace any remaining invalid values
        invalid_mask = ~np.isfinite(result)
        if np.any(invalid_mask):
            result[invalid_mask] = replace_with
            
        return result
    else:
        # Scalar operation
        if x <= 0 or not np.isfinite(x):
            return replace_with
        return np.log10(max(x, min_value))


def safe_log(x: Union[float, np.ndarray], 
             min_value: float = 1e-10,
             replace_with: Optional[float] = None) -> Union[float, np.ndarray]:
    """
    Safe natural logarithm with protection against log(0) and negative values
    
    Args:
        x: Input value(s)
        min_value: Minimum value to clamp to before taking log
        replace_with: Value to use for invalid inputs (None uses log(min_value))
    
    Returns:
        Safe log result
    """
    if replace_with is None:
        replace_with = np.log(min_value)
    
    if isinstance(x, np.ndarray):
        safe_x = np.where(x > min_value, x, min_value)
        result = np.log(safe_x)
        
        invalid_mask = ~np.isfinite(result)
        if np.any(invalid_mask):
            result[invalid_mask] = replace_with
            
        return result
    else:
        if x <= 0 or not np.isfinite(x):
            return replace_with
        return np.log(max(x, min_value))


def clamp(x: Union[float, np.ndarray], 
          min_val: float, 
          max_val: float) -> Union[float, np.ndarray]:
    """
    Clamp values to specified range
    
    Args:
        x: Input value(s)
        min_val: Minimum allowed value
        max_val: Maximum allowed value
    
    Returns:
        Clamped value(s)
    """
    if min_val > max_val:
        raise ValueError(f"min_val ({min_val}) must be <= max_val ({max_val})")
    
    return np.clip(x, min_val, max_val)


def linear_to_db(x: Union[float, np.ndarray], 
                reference: float = 1.0,
                min_db: float = -80.0) -> Union[float, np.ndarray]:
    """
    Convert linear amplitude to dB scale
    
    Args:
        x: Linear amplitude value(s)
        reference: Reference level (typically 1.0 for full scale)
        min_db: Minimum dB value for numerical stability
    
    Returns:
        dB values
    """
    if isinstance(reference, (list, tuple, np.ndarray)):
        if np.any(np.array(reference) <= 0):
            raise ValueError("Reference must be positive")
    else:
        if reference <= 0:
            raise ValueError("Reference must be positive")
    
    # Calculate minimum linear value corresponding to min_db
    min_linear = reference * (10.0 ** (min_db / 20.0))
    
    # Safe conversion
    safe_x = np.maximum(np.abs(x), min_linear)
    return 20.0 * safe_log10(safe_x / reference)


def db_to_linear(x_db: Union[float, np.ndarray], 
                reference: float = 1.0) -> Union[float, np.ndarray]:
    """
    Convert dB scale to linear amplitude
    
    Args:
        x_db: dB value(s)
        reference: Reference level (typically 1.0 for full scale)
    
    Returns:
        Linear amplitude values
    """
    if isinstance(reference, (list, tuple, np.ndarray)):
        if np.any(np.array(reference) <= 0):
            raise ValueError("Reference must be positive")
    else:
        if reference <= 0:
            raise ValueError("Reference must be positive")
    
    return reference * (10.0 ** (x_db / 20.0))


def normalize_to_range(x: Union[float, np.ndarray],
                      input_min: float,
                      input_max: float,
                      output_min: float = 0.0,
                      output_max: float = 1.0) -> Union[float, np.ndarray]:
    """
    Normalize values from input range to output range
    
    Args:
        x: Input value(s)
        input_min: Minimum of input range
        input_max: Maximum of input range
        output_min: Minimum of output range
        output_max: Maximum of output range
    
    Returns:
        Normalized value(s)
    """
    if input_min >= input_max:
        raise ValueError(f"input_min ({input_min}) must be < input_max ({input_max})")
    
    if output_min >= output_max:
        raise ValueError(f"output_min ({output_min}) must be < output_max ({output_max})")
    
    # Clamp input to valid range
    x_clamped = clamp(x, input_min, input_max)
    
    # Normalize to 0-1
    normalized = (x_clamped - input_min) / (input_max - input_min)
    
    # Scale to output range
    return output_min + normalized * (output_max - output_min)


def smooth_exponential(current: Union[float, np.ndarray], 
                      target: Union[float, np.ndarray], 
                      alpha: float) -> Union[float, np.ndarray]:
    """
    Exponential smoothing filter
    
    Args:
        current: Current smoothed value(s)
        target: Target value(s) to approach
        alpha: Smoothing factor (0 = no change, 1 = immediate)
    
    Returns:
        New smoothed value(s)
    """
    if not 0.0 <= alpha <= 1.0:
        raise ValueError(f"Alpha ({alpha}) must be in range [0, 1]")
    
    return current * (1.0 - alpha) + target * alpha


def calculate_rms(x: np.ndarray, axis: Optional[int] = None) -> Union[float, np.ndarray]:
    """
    Calculate Root Mean Square (RMS) value
    
    Args:
        x: Input array
        axis: Axis along which to calculate RMS (None for all)
    
    Returns:
        RMS value(s)
    """
    if x.size == 0:
        return 0.0
    
    return np.sqrt(np.mean(x**2, axis=axis))


def calculate_peak(x: np.ndarray, axis: Optional[int] = None) -> Union[float, np.ndarray]:
    """
    Calculate peak (maximum absolute) value
    
    Args:
        x: Input array
        axis: Axis along which to calculate peak (None for all)
    
    Returns:
        Peak value(s)
    """
    if x.size == 0:
        return 0.0
    
    return np.max(np.abs(x), axis=axis)


def calculate_crest_factor(x: np.ndarray, axis: Optional[int] = None) -> Union[float, np.ndarray]:
    """
    Calculate crest factor (peak/RMS ratio) in dB
    
    Args:
        x: Input array
        axis: Axis along which to calculate crest factor (None for all)
    
    Returns:
        Crest factor in dB
    """
    if x.size == 0:
        return 0.0
    
    rms = calculate_rms(x, axis)
    peak = calculate_peak(x, axis)
    
    # Avoid division by zero
    rms = np.maximum(rms, 1e-10)
    
    return linear_to_db(peak / rms)


def interpolate_linear(x: Union[float, np.ndarray],
                      x_points: np.ndarray,
                      y_points: np.ndarray) -> Union[float, np.ndarray]:
    """
    Linear interpolation
    
    Args:
        x: Point(s) to interpolate at
        x_points: Known x coordinates (must be sorted)
        y_points: Known y coordinates
    
    Returns:
        Interpolated value(s)
    """
    if len(x_points) != len(y_points):
        raise ValueError("x_points and y_points must have same length")
    
    if len(x_points) < 2:
        raise ValueError("Need at least 2 points for interpolation")
    
    # Check if x_points are sorted
    if not np.all(x_points[:-1] <= x_points[1:]):
        raise ValueError("x_points must be sorted in ascending order")
    
    return np.interp(x, x_points, y_points)


def apply_window(x: np.ndarray, window_type: str = 'hann') -> np.ndarray:
    """
    Apply windowing function to reduce spectral leakage
    
    Args:
        x: Input signal
        window_type: Type of window ('hann', 'hamming', 'blackman', 'kaiser')
    
    Returns:
        Windowed signal
    """
    n = len(x)
    
    if window_type == 'hann':
        window = np.hanning(n)
    elif window_type == 'hamming':
        window = np.hamming(n)
    elif window_type == 'blackman':
        window = np.blackman(n)
    elif window_type == 'kaiser':
        window = np.kaiser(n, beta=8.6)  # Good general-purpose beta
    else:
        raise ValueError(f"Unknown window type: {window_type}")
    
    return x * window


def zero_pad_to_power_of_2(x: np.ndarray) -> np.ndarray:
    """
    Zero-pad array to next power of 2 length for efficient FFT
    
    Args:
        x: Input array
    
    Returns:
        Zero-padded array
    """
    n = len(x)
    next_power_of_2 = 2 ** int(np.ceil(np.log2(n)))
    
    if next_power_of_2 == n:
        return x.copy()
    
    padded = np.zeros(next_power_of_2, dtype=x.dtype)
    padded[:n] = x
    return padded


def validate_array_1d(x: np.ndarray, name: str = "array") -> None:
    """
    Validate that input is a 1D numpy array
    
    Args:
        x: Array to validate
        name: Name for error messages
    
    Raises:
        ValueError: If array is not 1D or is empty
    """
    if not isinstance(x, np.ndarray):
        raise TypeError(f"{name} must be a numpy array")
    
    if x.ndim != 1:
        raise ValueError(f"{name} must be 1-dimensional, got {x.ndim}D")
    
    if x.size == 0:
        raise ValueError(f"{name} cannot be empty")


def validate_positive(x: Union[float, int], name: str = "value") -> None:
    """
    Validate that value is positive
    
    Args:
        x: Value to validate
        name: Name for error messages
    
    Raises:
        ValueError: If value is not positive
    """
    if not isinstance(x, (int, float)):
        raise TypeError(f"{name} must be a number")
    
    if x <= 0:
        raise ValueError(f"{name} must be positive, got {x}")


def validate_range(x: Union[float, int], min_val: float, max_val: float, name: str = "value") -> None:
    """
    Validate that value is within specified range
    
    Args:
        x: Value to validate
        min_val: Minimum allowed value
        max_val: Maximum allowed value
        name: Name for error messages
    
    Raises:
        ValueError: If value is outside range
    """
    if not isinstance(x, (int, float)):
        raise TypeError(f"{name} must be a number")
    
    if not min_val <= x <= max_val:
        raise ValueError(f"{name} must be in range [{min_val}, {max_val}], got {x}")


# Performance monitoring decorator
def profile_performance(func):
    """
    Decorator to profile function performance
    
    Usage:
        @profile_performance
        def my_function():
            pass
    """
    import time
    import functools
    
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.perf_counter()
        try:
            result = func(*args, **kwargs)
            return result
        finally:
            end_time = time.perf_counter()
            elapsed = (end_time - start_time) * 1000  # Convert to ms
            if elapsed > 50:  # Only warn for very slow operations (increased threshold)
                warnings.warn(f"{func.__name__} took {elapsed:.2f}ms", 
                            UserWarning, stacklevel=2)
    
    return wrapper