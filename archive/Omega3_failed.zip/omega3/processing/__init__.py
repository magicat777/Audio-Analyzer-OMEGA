"""
OMEGA-3 Spectrum Processing Module
Improved architecture with configuration management, error handling, and performance optimizations
"""

# Import core classes for external use
from .config import (
    ProcessingConfig, 
    FrequencyRange, 
    BandMapping, 
    CompensationCurve,
    DEFAULT_PROCESSING_CONFIG,
    STUDIO_PROCESSING_CONFIG,
    PERFORMANCE_PROCESSING_CONFIG
)

from .base_spectrum import (
    BaseSpectrumProcessor,
    PerceptualSpectrumProcessor,
    LinearSpectrumProcessor
)

from .spectrum import (
    SpectrumProcessor,
    BassDetailProcessor
)

from .factory import (
    SpectrumProcessorFactory,
    create_spectrum_processor,
    create_legacy_processor,
    create_optimized_processor
)

# Import bass processor creation function separately to avoid circular imports
def create_bass_detail_processor(sample_rate=None, **kwargs):
    """Create bass detail processor"""
    from .spectrum import BassDetailProcessor
    return BassDetailProcessor(sample_rate=sample_rate, **kwargs)

# Import legacy modules for compatibility
from .fft import MultiResolutionFFT
from .threading import AnalyzerThreadPool

__version__ = "3.0.0"
__author__ = "OMEGA Team"

__all__ = [
    # Configuration
    "ProcessingConfig",
    "FrequencyRange", 
    "BandMapping",
    "CompensationCurve",
    "DEFAULT_PROCESSING_CONFIG",
    "STUDIO_PROCESSING_CONFIG", 
    "PERFORMANCE_PROCESSING_CONFIG",
    
    # Base processors
    "BaseSpectrumProcessor",
    "PerceptualSpectrumProcessor",
    "LinearSpectrumProcessor",
    
    # Concrete processors
    "SpectrumProcessor",
    "BassDetailProcessor",
    
    # Factory
    "SpectrumProcessorFactory",
    "create_spectrum_processor",
    "create_legacy_processor", 
    "create_optimized_processor",
    "create_bass_detail_processor",
    
    # Legacy components
    "MultiResolutionFFT",
    "AnalyzerThreadPool"
]
