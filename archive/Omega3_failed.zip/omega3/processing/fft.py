"""
Optimized Multi-resolution FFT processing
"""

from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
from scipy import signal as scipy_signal
from scipy.fft import rfft
from scipy.fft import rfftfreq

try:
    from ..config import FFT_CONFIGS, FFT_SIZE_BASE, SAMPLE_RATE
except ImportError:
    # Fallback to direct imports for standalone execution
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from config import FFT_CONFIGS, FFT_SIZE_BASE, SAMPLE_RATE

# Try to import CuPy for GPU acceleration
try:
    import cupy as cp

    GPU_AVAILABLE = True
except ImportError:
    GPU_AVAILABLE = False
    cp = None


class MultiResolutionFFT:
    """Optimized multi-resolution FFT analysis"""

    def __init__(self, sample_rate: int = SAMPLE_RATE, use_gpu: bool = False):
        self.sample_rate = sample_rate
        self.nyquist = sample_rate / 2
        self.use_gpu = use_gpu and GPU_AVAILABLE

        if self.use_gpu:
            print("🚀 GPU acceleration enabled for FFT processing")

        # FFT configurations
        self.fft_configs = FFT_CONFIGS

        # Pre-compute windows
        self.windows = {}
        for i, config in enumerate(self.fft_configs):
            fft_size = config["fft_size"]
            # Blackman-Harris for better frequency resolution
            window = np.blackman(fft_size).astype(np.float32)
            if self.use_gpu:
                window = cp.asarray(window)
            self.windows[i] = window

        # Ring buffers for each resolution
        self.audio_buffers = {}
        self.buffer_positions = {}
        for i, config in enumerate(self.fft_configs):
            fft_size = config["fft_size"]
            buffer_size = fft_size * 2
            if self.use_gpu:
                self.audio_buffers[i] = cp.zeros(buffer_size, dtype=cp.float32)
            else:
                self.audio_buffers[i] = np.zeros(buffer_size, dtype=np.float32)
            self.buffer_positions[i] = 0

        # FFT planning for better performance
        self._setup_fft_plans()

        # Cache for frequency bins
        self.freq_bins_cache = {}
        self._setup_frequency_bins()

    def _setup_fft_plans(self):
        """Setup FFT plans for better performance"""
        # Note: scipy doesn't have explicit FFT planning like FFTW
        # but we can pre-allocate arrays for better performance
        self.fft_outputs = {}
        for i, config in enumerate(self.fft_configs):
            fft_size = config["fft_size"]
            self.fft_outputs[i] = np.zeros(fft_size // 2 + 1, dtype=np.complex64)

    def _setup_frequency_bins(self):
        """Pre-calculate frequency bins for each FFT size"""
        for i, config in enumerate(self.fft_configs):
            fft_size = config["fft_size"]
            freqs = rfftfreq(fft_size, 1 / self.sample_rate)
            self.freq_bins_cache[i] = freqs

    def process_multi_resolution(
        self, audio_chunk: np.ndarray, apply_weighting: bool = True
    ) -> Dict[int, np.ndarray]:
        """
        Process audio with multiple FFT resolutions

        Args:
            audio_chunk: Input audio samples
            apply_weighting: Apply frequency weighting

        Returns:
            Dictionary of FFT results for each resolution
        """
        results = {}

        # Convert to GPU if needed
        if self.use_gpu:
            audio_chunk = cp.asarray(audio_chunk, dtype=cp.float32)

        for i, config in enumerate(self.fft_configs):
            fft_size = config["fft_size"]

            # Update ring buffer
            self._update_buffer(i, audio_chunk)

            # Extract samples for FFT
            buffer = self.audio_buffers[i]
            pos = self.buffer_positions[i]

            if pos >= fft_size:
                samples = buffer[pos - fft_size: pos]
            else:
                # Wrap around
                samples = self._get_wrapped_samples(buffer, pos, fft_size)

            # Apply window
            windowed = samples * self.windows[i]

            # Perform FFT
            if self.use_gpu:
                fft_result = cp.fft.rfft(windowed)
                magnitude = cp.abs(fft_result)
                if apply_weighting:
                    magnitude = magnitude * config["weight"]
                results[i] = magnitude
            else:
                fft_result = rfft(windowed)
                magnitude = np.abs(fft_result)
                if apply_weighting:
                    magnitude = magnitude * config["weight"]
                results[i] = magnitude

        return results

    def _update_buffer(self, buffer_idx: int, audio_chunk: np.ndarray):
        """Update ring buffer with new audio data"""
        chunk_len = len(audio_chunk)
        buffer = self.audio_buffers[buffer_idx]
        pos = self.buffer_positions[buffer_idx]

        if pos + chunk_len <= len(buffer):
            buffer[pos: pos + chunk_len] = audio_chunk
        else:
            # Wrap around
            first_part = len(buffer) - pos
            buffer[pos:] = audio_chunk[:first_part]
            buffer[: chunk_len - first_part] = audio_chunk[first_part:]

        self.buffer_positions[buffer_idx] = (pos + chunk_len) % len(buffer)

    def _get_wrapped_samples(
        self, buffer: np.ndarray, pos: int, fft_size: int
    ) -> np.ndarray:
        """Get samples from ring buffer with wrapping"""
        if self.use_gpu:
            samples = cp.zeros(fft_size, dtype=cp.float32)
        else:
            samples = np.zeros(fft_size, dtype=np.float32)

        first_part = pos
        second_part = fft_size - first_part

        samples[:first_part] = buffer[:first_part]
        samples[first_part:] = buffer[-second_part:]

        return samples

    def combine_results(self, multi_res_results: Dict[int, np.ndarray]) -> np.ndarray:
        """Combine multi-resolution results into single spectrum"""
        # Determine output size
        max_size = max(len(result) for result in multi_res_results.values())

        if self.use_gpu:
            combined = cp.zeros(max_size, dtype=cp.float32)
        else:
            combined = np.zeros(max_size, dtype=np.float32)

        for i, (config, result) in enumerate(
            zip(self.fft_configs, multi_res_results.values())
        ):
            freq_range = config["range"]
            freqs = self.freq_bins_cache[i]

            # Find indices for frequency range
            idx_start = np.searchsorted(freqs, freq_range[0])
            idx_end = np.searchsorted(freqs, freq_range[1])

            # Map to combined spectrum
            for j in range(idx_start, min(idx_end, len(result))):
                freq = freqs[j]
                combined_idx = int(freq / self.nyquist * (max_size - 1))
                if 0 <= combined_idx < max_size:
                    combined[combined_idx] = max(combined[combined_idx], result[j])

        # Convert back to CPU if needed
        if self.use_gpu:
            combined = cp.asnumpy(combined)

        return combined

    def get_frequency_bins(self, fft_size: Optional[int] = None) -> np.ndarray:
        """Get frequency bins for given FFT size"""
        if fft_size is None:
            fft_size = FFT_SIZE_BASE
        return rfftfreq(fft_size, 1 / self.sample_rate)
