"""
Base spectrum processor classes with shared functionality
Eliminates duplicate logic and provides consistent interfaces
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Tuple, Union
import numpy as np
import logging

from .config import ProcessingConfig, FrequencyRange, BandMapping, CompensationCurve
from .math_utils import (
    safe_log10, clamp, linear_to_db, normalize_to_range, 
    validate_array_1d, validate_positive, profile_performance
)


class BaseSpectrumProcessor(ABC):
    """
    Abstract base class for spectrum processors
    Provides common functionality and enforces interface consistency
    """
    
    def __init__(self, 
                 config: ProcessingConfig, 
                 processor_name: str = "BaseSpectrumProcessor"):
        """
        Initialize base spectrum processor
        
        Args:
            config: Processing configuration object
            processor_name: Name for logging and debugging
        """
        self.config = config
        self.processor_name = processor_name
        self.logger = logging.getLogger(f"omega3.{processor_name}")
        
        # Pre-allocated arrays for performance
        self._output_buffer = None
        self._temp_buffer = None
        self._initialized = False
        
        # Frequency mapping
        self.frequency_bins = None
        self.band_mappings: List[BandMapping] = []
        self.compensation_curve: Optional[CompensationCurve] = None
        
        # Performance monitoring
        self._process_count = 0
        self._total_time = 0.0
        
        self.logger.info(f"Initialized {processor_name} with config: {config}")
    
    def initialize(self, fft_size: int) -> None:
        """
        Initialize processor for specific FFT size
        
        Args:
            fft_size: FFT size for frequency bin calculation
        """
        if self._initialized:
            self.logger.warning("Processor already initialized, reinitializing...")
        
        validate_positive(fft_size, "fft_size")
        
        # Calculate frequency bins
        self.frequency_bins = np.fft.rfftfreq(fft_size, 1 / self.config.sample_rate)
        
        # Create band mappings
        self.band_mappings = self._create_band_mappings()
        
        # Create compensation curve
        self.compensation_curve = self._create_compensation_curve()
        
        # Pre-allocate arrays if enabled
        if self.config.pre_allocate_arrays:
            self._allocate_buffers()
        
        self._initialized = True
        self.logger.info(f"Initialized for FFT size {fft_size}, {len(self.band_mappings)} bands")
    
    @abstractmethod
    def _create_band_mappings(self) -> List[BandMapping]:
        """
        Create frequency band to FFT bin mappings
        Must be implemented by subclasses
        
        Returns:
            List of band mappings
        """
        pass
    
    @abstractmethod
    def _create_compensation_curve(self) -> CompensationCurve:
        """
        Create frequency compensation curve
        Must be implemented by subclasses
        
        Returns:
            Compensation curve
        """
        pass
    
    def _allocate_buffers(self) -> None:
        """Allocate buffers for performance optimization"""
        num_bands = len(self.band_mappings)
        if num_bands > 0:
            self._output_buffer = np.zeros(num_bands, dtype=np.float32)
            self._temp_buffer = np.zeros(num_bands, dtype=np.float32)
            self.logger.debug(f"Allocated buffers for {num_bands} bands")
    
    @profile_performance
    def process(self, 
                fft_data: np.ndarray, 
                apply_compensation: bool = True,
                normalize_output: bool = True) -> np.ndarray:
        """
        Process FFT data into spectrum bars
        
        Args:
            fft_data: FFT magnitude data
            apply_compensation: Whether to apply frequency compensation
            normalize_output: Whether to normalize output to 0-1 range
        
        Returns:
            Processed spectrum data
        """
        if not self._initialized:
            raise RuntimeError("Processor not initialized. Call initialize() first.")
        
        validate_array_1d(fft_data, "fft_data")
        
        if len(fft_data) != len(self.frequency_bins):
            raise ValueError(f"FFT data length ({len(fft_data)}) doesn't match "
                           f"frequency bins ({len(self.frequency_bins)})")
        
        # Use pre-allocated buffer if available
        if self._output_buffer is not None:
            output = self._output_buffer
            output.fill(0.0)  # Reset buffer
        else:
            output = np.zeros(len(self.band_mappings), dtype=np.float32)
        
        # Map FFT data to frequency bands
        self._map_fft_to_bands(fft_data, output)
        
        # Apply frequency compensation
        if apply_compensation and self.compensation_curve is not None:
            self._apply_compensation(output)
        
        # Convert to dB and normalize
        if normalize_output:
            self._convert_to_db_and_normalize(output)
        
        # Update performance stats
        self._process_count += 1
        
        # Return copy if using pre-allocated buffer (thread safety)
        return output.copy() if self._output_buffer is not None else output
    
    def _map_fft_to_bands(self, fft_data: np.ndarray, output: np.ndarray) -> None:
        """
        Map FFT data to frequency bands using vectorized operations
        
        Args:
            fft_data: Input FFT magnitude data
            output: Output array to fill (modified in-place)
        """
        # For magnitude spectrum from FFT, we typically don't need additional normalization
        # as the FFT output is already properly scaled. Only normalize if values are very large.
        max_fft_value = np.max(fft_data) if len(fft_data) > 0 else 1.0
        if max_fft_value > 10.0:  # Only normalize if values seem unnormalized
            fft_size = 2 * (len(fft_data) - 1)
            normalization_factor = 2.0 / fft_size
        else:
            normalization_factor = 1.0  # Already normalized
        
        for i, band_mapping in enumerate(self.band_mappings):
            if band_mapping.num_bins > 0 and i < len(output):
                # Get values for this band's bins
                bin_indices = list(band_mapping.fft_bin_indices)
                # Ensure indices are within bounds
                valid_indices = [idx for idx in bin_indices if idx < len(fft_data)]
                
                if valid_indices:
                    bin_values = fft_data[valid_indices] * normalization_factor
                    # Calculate band value (mean with optional weighting)
                    if len(bin_values) > 0:
                        output[i] = np.mean(bin_values) * band_mapping.weight
    
    def _apply_compensation(self, data: np.ndarray) -> None:
        """
        Apply frequency compensation curve
        
        Args:
            data: Spectrum data to compensate (modified in-place)
        """
        if self.compensation_curve is None:
            return
        
        for i, band_mapping in enumerate(self.band_mappings):
            center_freq = band_mapping.frequency_range.center_hz
            gain = self.compensation_curve.get_gain_at_frequency(center_freq)
            data[i] *= gain
    
    def _convert_to_db_and_normalize(self, data: np.ndarray) -> None:
        """
        Convert to dB scale and normalize to 0-1 range
        
        Args:
            data: Linear amplitude data (modified in-place)
        """
        # Apply noise gate - set values below threshold to minimum, not threshold itself
        noise_threshold = self.config.noise_threshold_linear
        data[data < noise_threshold] = noise_threshold
        
        # Convert to dB
        data_db = linear_to_db(data, min_db=self.config.noise_threshold_db)
        
        # Normalize to 0-1 range with wider dynamic range
        # Use -60dB as the lower bound and -6dB as upper bound
        # This provides better dynamic range visualization
        normalized = normalize_to_range(
            data_db,
            -60.0,  # Lower bound matches noise floor
            -6.0,   # Upper bound at -6dB to prevent clipping
            0.0, 1.0
        )
        
        # Apply a gentler compression curve to preserve dynamics
        # This helps make quiet parts visible without destroying dynamics
        normalized = np.power(normalized, 1.2)  # Gentle expansion for better contrast
        
        # Copy back to original array
        data[:] = normalized
    
    def get_frequency_range_for_band(self, band_index: int) -> Optional[FrequencyRange]:
        """
        Get frequency range for a specific band
        
        Args:
            band_index: Index of the band
        
        Returns:
            Frequency range or None if invalid index
        """
        if 0 <= band_index < len(self.band_mappings):
            return self.band_mappings[band_index].frequency_range
        return None
    
    def get_band_for_frequency(self, frequency: float) -> Optional[int]:
        """
        Find which band contains a specific frequency
        
        Args:
            frequency: Frequency in Hz
        
        Returns:
            Band index or None if frequency not covered
        """
        for i, band_mapping in enumerate(self.band_mappings):
            if band_mapping.frequency_range.contains(frequency):
                return i
        return None
    
    def freq_to_x_position(self, frequency: float, width: int) -> int:
        """
        Convert frequency to x-position for visualization
        
        Args:
            frequency: Frequency in Hz
            width: Display width in pixels
        
        Returns:
            X position in pixels
        """
        if frequency <= 0 or frequency > self.config.effective_max_freq:
            return 0
        
        freq_min = max(self.config.min_freq, self.frequency_bins[1])
        freq_max = self.config.effective_max_freq
        
        if frequency < freq_min:
            return 0
        if frequency > freq_max:
            return width - 1
        
        # Logarithmic mapping
        log_freq = safe_log10(frequency)
        log_min = safe_log10(freq_min)
        log_max = safe_log10(freq_max)
        
        normalized = (log_freq - log_min) / (log_max - log_min)
        return int(clamp(normalized * (width - 1), 0, width - 1))
    
    def get_performance_stats(self) -> Dict[str, float]:
        """
        Get performance statistics
        
        Returns:
            Dictionary with performance metrics
        """
        avg_time = self._total_time / max(1, self._process_count)
        return {
            "process_count": self._process_count,
            "total_time_ms": self._total_time,
            "average_time_ms": avg_time,
            "frequency_range_hz": (self.config.min_freq, self.config.effective_max_freq),
            "num_bands": len(self.band_mappings),
            "sample_rate": self.config.sample_rate
        }
    
    def reset_performance_stats(self) -> None:
        """Reset performance monitoring counters"""
        self._process_count = 0
        self._total_time = 0.0
    
    def validate_configuration(self) -> List[str]:
        """
        Validate processor configuration
        
        Returns:
            List of validation warnings/errors
        """
        issues = []
        
        if not self._initialized:
            issues.append("Processor not initialized")
        
        if len(self.band_mappings) == 0:
            issues.append("No frequency bands configured")
        
        # Check for overlapping bands
        for i, band1 in enumerate(self.band_mappings):
            for j, band2 in enumerate(self.band_mappings[i + 1:], i + 1):
                if band1.frequency_range.overlap_with(band2.frequency_range):
                    issues.append(f"Bands {i} and {j} have overlapping frequencies")
        
        # Check frequency coverage
        covered_min = min(bm.frequency_range.start_hz for bm in self.band_mappings)
        covered_max = max(bm.frequency_range.end_hz for bm in self.band_mappings)
        
        if covered_min > self.config.min_freq:
            issues.append(f"Frequency coverage gap below {covered_min}Hz")
        
        if covered_max < self.config.effective_max_freq:
            issues.append(f"Frequency coverage gap above {covered_max}Hz")
        
        return issues
    
    def __str__(self) -> str:
        """String representation"""
        status = "initialized" if self._initialized else "uninitialized"
        return (f"{self.processor_name}({status}, "
                f"{len(self.band_mappings)} bands, "
                f"{self.config.sample_rate}Hz)")
    
    def __repr__(self) -> str:
        """Detailed representation"""
        return (f"{self.__class__.__name__}("
                f"config={self.config}, "
                f"initialized={self._initialized}, "
                f"bands={len(self.band_mappings)})")


class PerceptualSpectrumProcessor(BaseSpectrumProcessor):
    """
    Spectrum processor using perceptual frequency mapping
    Implements musical frequency distribution with proper weighting
    """
    
    def __init__(self, config: ProcessingConfig):
        super().__init__(config, "PerceptualSpectrumProcessor")
    
    def _create_band_mappings(self) -> List[BandMapping]:
        """Create perceptual frequency band mappings"""
        if self.frequency_bins is None:
            raise RuntimeError("Frequency bins not initialized")
        
        band_mappings = []
        target_bars = self.config.bars_default
        
        # Find valid frequency range
        freq_mask = ((self.frequency_bins >= self.config.min_freq) & 
                    (self.frequency_bins <= self.config.effective_max_freq))
        valid_bins = np.where(freq_mask)[0]
        
        if len(valid_bins) == 0:
            self.logger.error("No valid frequency bins found")
            return band_mappings
        
        # If we have fewer valid bins than target bars, use linear mapping
        if len(valid_bins) < target_bars:
            self.logger.warning(f"Only {len(valid_bins)} valid bins for {target_bars} bars, using linear mapping")
            return self._create_linear_mapping(valid_bins, target_bars)
        
        # Define frequency ranges with musical importance
        # Ensure we use the full frequency range up to Nyquist
        actual_max_freq = min(self.config.effective_max_freq, self.frequency_bins[-1])
        ranges_and_ratios = [
            (self.config.min_freq, 60, self.config.sub_bass_ratio),      # Sub-bass
            (60, 250, self.config.bass_ratio),                           # Bass
            (250, 500, self.config.low_mid_ratio),                       # Low-mid
            (500, 2000, self.config.mid_ratio),                          # Mid (critical)
            (2000, 6000, self.config.high_mid_ratio),                    # High-mid
            (6000, actual_max_freq, self.config.high_ratio)              # High (use actual max)
        ]
        
        # Calculate actual bars per range
        bars_allocated = 0
        range_bars = []
        
        for i, (start_freq, end_freq, ratio) in enumerate(ranges_and_ratios):
            if i == len(ranges_and_ratios) - 1:
                # Last range gets remaining bars
                num_bars = target_bars - bars_allocated
            else:
                num_bars = max(1, int(target_bars * ratio))
                bars_allocated += num_bars
            
            range_bars.append((start_freq, end_freq, num_bars))
        
        # Create bands for each range
        for start_freq, end_freq, num_bands in range_bars:
            # Find FFT bins in this range
            freq_mask = ((self.frequency_bins >= start_freq) & 
                        (self.frequency_bins < end_freq))
            range_bins = np.where(freq_mask)[0]
            
            if len(range_bins) > 0 and num_bands > 0:
                if len(range_bins) < num_bands:
                    # If we have fewer bins than bands, distribute evenly
                    bins_per_band = 1
                    actual_bands = len(range_bins)
                else:
                    bins_per_band = len(range_bins) // num_bands
                    actual_bands = num_bands
                
                for i in range(actual_bands):
                    if bins_per_band == 1:
                        # One bin per band
                        if i < len(range_bins):
                            band_bins = [range_bins[i]]
                    else:
                        # Multiple bins per band
                        bin_start = i * bins_per_band
                        bin_end = ((i + 1) * bins_per_band 
                                  if i < actual_bands - 1 else len(range_bins))
                        band_bins = range_bins[bin_start:bin_end]
                    
                    if len(band_bins) > 0:
                        freq_start = self.frequency_bins[band_bins[0]]
                        freq_end = self.frequency_bins[band_bins[-1]]
                        
                        # Ensure we don't have equal frequencies
                        if freq_start == freq_end:
                            freq_end = freq_start + (self.frequency_bins[1] - self.frequency_bins[0])
                        
                        freq_range = FrequencyRange(freq_start, freq_end)
                        
                        # Weight based on musical importance
                        weight = self._calculate_perceptual_weight(freq_range.center_hz)
                        
                        band_mappings.append(BandMapping(
                            frequency_range=freq_range,
                            fft_bin_indices=tuple(band_bins),
                            weight=weight
                        ))
        
        # Ensure we have exactly the target number of bars
        while len(band_mappings) < target_bars:
            # Add empty bands if needed
            last_freq = band_mappings[-1].frequency_range.end_hz if band_mappings else self.config.min_freq
            empty_range = FrequencyRange(last_freq, last_freq + 1.0)
            band_mappings.append(BandMapping(
                frequency_range=empty_range,
                fft_bin_indices=tuple(),
                weight=0.0
            ))
        
        # Trim excess bands if any
        band_mappings = band_mappings[:target_bars]
        
        self.logger.info(f"Created {len(band_mappings)} perceptual bands "
                        f"(target: {target_bars})")
        
        
        return band_mappings
    
    def _create_linear_mapping(self, valid_bins: np.ndarray, target_bars: int) -> List[BandMapping]:
        """Create linear frequency mapping when perceptual mapping isn't possible"""
        band_mappings = []
        
        if len(valid_bins) >= target_bars:
            # Standard linear mapping
            bins_per_band = len(valid_bins) // target_bars
            
            for i in range(target_bars):
                bin_start = i * bins_per_band
                bin_end = ((i + 1) * bins_per_band 
                          if i < target_bars - 1 else len(valid_bins))
                
                band_bins = valid_bins[bin_start:bin_end]
                
                if len(band_bins) > 0:
                    freq_start = self.frequency_bins[band_bins[0]]
                    freq_end = self.frequency_bins[band_bins[-1]]
                    
                    if freq_start == freq_end:
                        freq_end = freq_start + (self.frequency_bins[1] - self.frequency_bins[0])
                    
                    freq_range = FrequencyRange(freq_start, freq_end)
                    
                    band_mappings.append(BandMapping(
                        frequency_range=freq_range,
                        fft_bin_indices=tuple(band_bins),
                        weight=1.0
                    ))
        else:
            # Each bin becomes a band, then pad
            for i, bin_idx in enumerate(valid_bins):
                freq = self.frequency_bins[bin_idx]
                freq_range = FrequencyRange(freq, freq + (self.frequency_bins[1] - self.frequency_bins[0]))
                
                band_mappings.append(BandMapping(
                    frequency_range=freq_range,
                    fft_bin_indices=(bin_idx,),
                    weight=1.0
                ))
            
            # Pad with empty bands
            while len(band_mappings) < target_bars:
                last_freq = band_mappings[-1].frequency_range.end_hz if band_mappings else self.config.min_freq
                empty_range = FrequencyRange(last_freq, last_freq + 1.0)
                band_mappings.append(BandMapping(
                    frequency_range=empty_range,
                    fft_bin_indices=tuple(),
                    weight=0.0
                ))
        
        return band_mappings
    
    def _calculate_perceptual_weight(self, center_freq: float) -> float:
        """Calculate perceptual weighting for frequency"""
        # A-weighting inspired curve for perceptual importance
        if center_freq < 100:
            return 0.8  # Reduced bass weight
        elif center_freq < 1000:
            return 1.0 + 0.2 * (center_freq - 100) / 900  # Gradual increase
        elif center_freq < 4000:
            return 1.2  # Peak importance for speech/music
        elif center_freq < 8000:
            return 1.1  # High frequency clarity
        else:
            return 0.9  # Slight reduction for very high frequencies
    
    def _create_compensation_curve(self) -> CompensationCurve:
        """Create perceptual frequency compensation curve"""
        # Define compensation points based on psychoacoustic research
        # Reduced low frequency boost to prevent "off the charts" issue
        compensation_points = [
            (20, 0.5),     # Sub-bass stronger reduction
            (60, 0.7),     # Bass reduction
            (100, 0.8),    # Bass moderate reduction
            (250, 0.9),    # Low-mid slight reduction
            (500, 1.0),    # Low-mid reference
            (1000, 1.1),   # Mid slight boost for intelligibility
            (2000, 1.2),   # Upper mid boost
            (4000, 1.15),  # Presence boost
            (8000, 1.1),   # High frequency boost
            (12000, 1.05), # Upper high slight boost
            (20000, 1.0)   # Air flat
        ]
        
        # Apply midrange boost if enabled
        if self.config.midrange_boost_enabled:
            enhanced_points = []
            for freq, gain in compensation_points:
                if 1000 <= freq <= 6000:
                    gain *= self.config.midrange_boost_factor
                enhanced_points.append((freq, gain))
            compensation_points = enhanced_points
        
        return CompensationCurve(tuple(compensation_points))


class LinearSpectrumProcessor(BaseSpectrumProcessor):
    """
    Linear frequency mapping spectrum processor
    Simple uniform frequency distribution for analysis purposes
    """
    
    def __init__(self, config: ProcessingConfig):
        super().__init__(config, "LinearSpectrumProcessor")
    
    def _create_band_mappings(self) -> List[BandMapping]:
        """Create linear frequency band mappings"""
        if self.frequency_bins is None:
            raise RuntimeError("Frequency bins not initialized")
        
        band_mappings = []
        
        # Find valid frequency range
        freq_mask = ((self.frequency_bins >= self.config.min_freq) & 
                    (self.frequency_bins <= self.config.effective_max_freq))
        valid_bins = np.where(freq_mask)[0]
        
        if len(valid_bins) == 0:
            self.logger.error("No valid frequency bins found")
            return band_mappings
        
        # Linear distribution
        num_bands = min(self.config.bars_default, len(valid_bins))
        bins_per_band = len(valid_bins) // num_bands
        
        for i in range(num_bands):
            bin_start = i * bins_per_band
            bin_end = ((i + 1) * bins_per_band 
                      if i < num_bands - 1 else len(valid_bins))
            
            band_bins = valid_bins[bin_start:bin_end]
            
            if len(band_bins) > 0:
                freq_range = FrequencyRange(
                    self.frequency_bins[band_bins[0]],
                    self.frequency_bins[band_bins[-1]]
                )
                
                band_mappings.append(BandMapping(
                    frequency_range=freq_range,
                    fft_bin_indices=tuple(band_bins),
                    weight=1.0
                ))
        
        self.logger.info(f"Created {len(band_mappings)} linear bands")
        return band_mappings
    
    def _create_compensation_curve(self) -> CompensationCurve:
        """Create flat frequency compensation curve"""
        # No compensation for linear mapping
        return CompensationCurve((
            (self.config.min_freq, 1.0),
            (self.config.effective_max_freq, 1.0)
        ))