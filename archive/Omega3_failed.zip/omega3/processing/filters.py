"""
Audio filtering utilities for OMEGA-3.
Provides various filter types for audio processing.
"""

from enum import Enum
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import numpy as np


class FilterType(Enum):
    """Available filter types."""

    LOWPASS = "lowpass"
    HIGHPASS = "highpass"
    BANDPASS = "bandpass"
    BANDSTOP = "bandstop"
    PEAKING = "peaking"
    LOWSHELF = "lowshelf"
    HIGHSHELF = "highshelf"
    ALLPASS = "allpass"
    NOTCH = "notch"


class Filter:
    """Base class for digital filters."""

    def __init__(self, sample_rate: int = 48000):
        self.sample_rate = sample_rate
        self.coefficients = None
        self.state = None

    def process(self, audio_data: np.ndarray) -> np.ndarray:
        """Process audio through filter."""
        raise NotImplementedError

    def reset(self):
        """Reset filter state."""
        self.state = None

    def get_frequency_response(self, frequencies: np.ndarray) -> np.ndarray:
        """Get magnitude response at given frequencies."""
        raise NotImplementedError


class BiquadFilter(Filter):
    """Biquad filter implementation for various filter types."""

    def __init__(
        self,
        sample_rate: int = 48000,
        filter_type: FilterType = FilterType.LOWPASS,
        frequency: float = 1000.0,
        q: float = 0.707,
        gain: float = 0.0,
    ):
        super().__init__(sample_rate)
        self.filter_type = filter_type
        self.frequency = frequency
        self.q = q
        self.gain = gain

        # Calculate coefficients
        self._calculate_coefficients()

        # Initialize state
        self.reset()

    def _calculate_coefficients(self):
        """Calculate biquad filter coefficients."""
        omega = 2 * np.pi * self.frequency / self.sample_rate
        sin_omega = np.sin(omega)
        cos_omega = np.cos(omega)
        alpha = sin_omega / (2 * self.q)
        A = 10 ** (self.gain / 40)

        if self.filter_type == FilterType.LOWPASS:
            b0 = (1 - cos_omega) / 2
            b1 = 1 - cos_omega
            b2 = (1 - cos_omega) / 2
            a0 = 1 + alpha
            a1 = -2 * cos_omega
            a2 = 1 - alpha

        elif self.filter_type == FilterType.HIGHPASS:
            b0 = (1 + cos_omega) / 2
            b1 = -(1 + cos_omega)
            b2 = (1 + cos_omega) / 2
            a0 = 1 + alpha
            a1 = -2 * cos_omega
            a2 = 1 - alpha

        elif self.filter_type == FilterType.BANDPASS:
            b0 = alpha
            b1 = 0
            b2 = -alpha
            a0 = 1 + alpha
            a1 = -2 * cos_omega
            a2 = 1 - alpha

        elif self.filter_type == FilterType.BANDSTOP:
            b0 = 1
            b1 = -2 * cos_omega
            b2 = 1
            a0 = 1 + alpha
            a1 = -2 * cos_omega
            a2 = 1 - alpha

        elif self.filter_type == FilterType.PEAKING:
            b0 = 1 + alpha * A
            b1 = -2 * cos_omega
            b2 = 1 - alpha * A
            a0 = 1 + alpha / A
            a1 = -2 * cos_omega
            a2 = 1 - alpha / A

        elif self.filter_type == FilterType.LOWSHELF:
            sqrt_2A = np.sqrt(2 * A)
            b0 = A * ((A + 1) - (A - 1) * cos_omega + sqrt_2A * alpha)
            b1 = 2 * A * ((A - 1) - (A + 1) * cos_omega)
            b2 = A * ((A + 1) - (A - 1) * cos_omega - sqrt_2A * alpha)
            a0 = (A + 1) + (A - 1) * cos_omega + sqrt_2A * alpha
            a1 = -2 * ((A - 1) + (A + 1) * cos_omega)
            a2 = (A + 1) + (A - 1) * cos_omega - sqrt_2A * alpha

        elif self.filter_type == FilterType.HIGHSHELF:
            sqrt_2A = np.sqrt(2 * A)
            b0 = A * ((A + 1) + (A - 1) * cos_omega + sqrt_2A * alpha)
            b1 = -2 * A * ((A - 1) + (A + 1) * cos_omega)
            b2 = A * ((A + 1) + (A - 1) * cos_omega - sqrt_2A * alpha)
            a0 = (A + 1) - (A - 1) * cos_omega + sqrt_2A * alpha
            a1 = 2 * ((A - 1) - (A + 1) * cos_omega)
            a2 = (A + 1) - (A - 1) * cos_omega - sqrt_2A * alpha

        elif self.filter_type == FilterType.ALLPASS:
            b0 = 1 - alpha
            b1 = -2 * cos_omega
            b2 = 1 + alpha
            a0 = 1 + alpha
            a1 = -2 * cos_omega
            a2 = 1 - alpha

        elif self.filter_type == FilterType.NOTCH:
            b0 = 1
            b1 = -2 * cos_omega
            b2 = 1
            a0 = 1 + alpha
            a1 = -2 * cos_omega
            a2 = 1 - alpha

        else:
            # Default to bypass
            b0 = 1
            b1 = 0
            b2 = 0
            a0 = 1
            a1 = 0
            a2 = 0

        # Normalize coefficients
        self.b0 = b0 / a0
        self.b1 = b1 / a0
        self.b2 = b2 / a0
        self.a1 = a1 / a0
        self.a2 = a2 / a0

    def process(self, audio_data: np.ndarray) -> np.ndarray:
        """Process audio through biquad filter."""
        if self.state is None:
            self.state = np.zeros(2)

        output = np.zeros_like(audio_data)

        # Direct Form I implementation
        for i in range(len(audio_data)):
            # Calculate output
            output[i] = (
                self.b0 * audio_data[i]
                + self.b1 * self.state[0]
                + self.b2 * self.state[1]
                - self.a1 * (self.state[0] if i > 0 else 0)
                - self.a2 * (self.state[1] if i > 1 else 0)
            )

            # Update state
            self.state[1] = self.state[0]
            self.state[0] = audio_data[i] if i > 0 else 0

        return output

    def get_frequency_response(self, frequencies: np.ndarray) -> np.ndarray:
        """Calculate magnitude response at given frequencies."""
        omega = 2 * np.pi * frequencies / self.sample_rate

        # Calculate transfer function H(z) at z = e^(j*omega)
        z = np.exp(1j * omega)

        numerator = self.b0 + self.b1 * z ** (-1) + self.b2 * z ** (-2)
        denominator = 1 + self.a1 * z ** (-1) + self.a2 * z ** (-2)

        H = numerator / denominator

        # Return magnitude in dB
        return 20 * np.log10(np.abs(H) + 1e-10)

    def set_parameters(
        self,
        frequency: Optional[float] = None,
        q: Optional[float] = None,
        gain: Optional[float] = None,
    ):
        """Update filter parameters."""
        if frequency is not None:
            self.frequency = frequency
        if q is not None:
            self.q = q
        if gain is not None:
            self.gain = gain

        self._calculate_coefficients()


class FilterBank:
    """Bank of filters for multi-band processing."""

    def __init__(self, sample_rate: int = 48000):
        self.sample_rate = sample_rate
        self.filters = []

    def add_filter(
        self,
        filter_type: FilterType,
        frequency: float,
        q: float = 0.707,
        gain: float = 0.0,
    ) -> int:
        """Add a filter to the bank."""
        filter = BiquadFilter(self.sample_rate, filter_type, frequency, q, gain)
        self.filters.append(filter)
        return len(self.filters) - 1

    def remove_filter(self, index: int):
        """Remove a filter from the bank."""
        if 0 <= index < len(self.filters):
            del self.filters[index]

    def process(self, audio_data: np.ndarray) -> np.ndarray:
        """Process audio through all filters in series."""
        output = audio_data.copy()

        for filter in self.filters:
            output = filter.process(output)

        return output

    def process_parallel(self, audio_data: np.ndarray) -> np.ndarray:
        """Process audio through filters in parallel and sum."""
        if not self.filters:
            return audio_data

        output = np.zeros_like(audio_data)

        for filter in self.filters:
            output += filter.process(audio_data) / len(self.filters)

        return output

    def get_overall_response(self, frequencies: np.ndarray) -> np.ndarray:
        """Get combined frequency response of all filters."""
        if not self.filters:
            return np.zeros_like(frequencies)

        response_db = np.zeros_like(frequencies)

        for filter in self.filters:
            response_db += filter.get_frequency_response(frequencies)

        return response_db

    def reset(self):
        """Reset all filters."""
        for filter in self.filters:
            filter.reset()


class CrossoverFilter:
    """Multi-way crossover filter for band separation."""

    def __init__(
        self, sample_rate: int = 48000, crossover_frequencies: List[float] = None
    ):
        self.sample_rate = sample_rate

        if crossover_frequencies is None:
            # Default 3-way crossover
            self.crossover_frequencies = [200.0, 2000.0]
        else:
            self.crossover_frequencies = sorted(crossover_frequencies)

        self.num_bands = len(self.crossover_frequencies) + 1

        # Create filters
        self._create_filters()

    def _create_filters(self):
        """Create Linkwitz-Riley crossover filters."""
        self.lowpass_filters = []
        self.highpass_filters = []

        # For each crossover frequency, create LP and HP filters
        for freq in self.crossover_frequencies:
            # 4th order Linkwitz-Riley = two 2nd order Butterworth in series
            lp1 = BiquadFilter(self.sample_rate, FilterType.LOWPASS, freq, 0.707)
            lp2 = BiquadFilter(self.sample_rate, FilterType.LOWPASS, freq, 0.707)
            self.lowpass_filters.append([lp1, lp2])

            hp1 = BiquadFilter(self.sample_rate, FilterType.HIGHPASS, freq, 0.707)
            hp2 = BiquadFilter(self.sample_rate, FilterType.HIGHPASS, freq, 0.707)
            self.highpass_filters.append([hp1, hp2])

    def process(self, audio_data: np.ndarray) -> List[np.ndarray]:
        """Process audio and return separated bands."""
        bands = []

        # Process each band
        for i in range(self.num_bands):
            band_data = audio_data.copy()

            # Apply highpass for this band (except first)
            if i > 0:
                for hp in self.highpass_filters[i - 1]:
                    band_data = hp.process(band_data)

            # Apply lowpass for this band (except last)
            if i < self.num_bands - 1:
                for lp in self.lowpass_filters[i]:
                    band_data = lp.process(band_data)

            bands.append(band_data)

        return bands

    def get_band_ranges(self) -> List[Tuple[float, float]]:
        """Get frequency ranges for each band."""
        ranges = []

        for i in range(self.num_bands):
            if i == 0:
                # First band
                low = 0
                high = self.crossover_frequencies[0]
            elif i == self.num_bands - 1:
                # Last band
                low = self.crossover_frequencies[-1]
                high = self.sample_rate / 2
            else:
                # Middle bands
                low = self.crossover_frequencies[i - 1]
                high = self.crossover_frequencies[i]

            ranges.append((low, high))

        return ranges

    def reset(self):
        """Reset all filters."""
        for lp_pair in self.lowpass_filters:
            for lp in lp_pair:
                lp.reset()

        for hp_pair in self.highpass_filters:
            for hp in hp_pair:
                hp.reset()


class AdaptiveFilter:
    """Adaptive filter that adjusts based on signal characteristics."""

    def __init__(self, sample_rate: int = 48000, adaptation_rate: float = 0.01):
        self.sample_rate = sample_rate
        self.adaptation_rate = adaptation_rate

        # Adaptive parameters
        self.center_frequency = 1000.0
        self.bandwidth = 500.0
        self.filter = BiquadFilter(
            sample_rate, FilterType.BANDPASS, self.center_frequency, 1.0
        )

        # Analysis buffer
        self.buffer_size = int(0.1 * sample_rate)  # 100ms
        self.buffer = np.zeros(self.buffer_size)
        self.buffer_pos = 0

    def process(self, audio_data: np.ndarray) -> np.ndarray:
        """Process audio with adaptive filtering."""
        output = np.zeros_like(audio_data)

        for i in range(len(audio_data)):
            # Update buffer
            self.buffer[self.buffer_pos] = audio_data[i]
            self.buffer_pos = (self.buffer_pos + 1) % self.buffer_size

            # Periodically update filter parameters
            if self.buffer_pos == 0:
                self._adapt_filter()

            # Process sample
            output[i] = self.filter.process(audio_data[i: i + 1])[0]

        return output

    def _adapt_filter(self):
        """Adapt filter parameters based on signal analysis."""
        # Compute spectrum of buffer
        fft = np.fft.rfft(self.buffer * np.hanning(len(self.buffer)))
        magnitude = np.abs(fft)
        freqs = np.fft.rfftfreq(len(self.buffer), 1 / self.sample_rate)

        # Find peak frequency
        peak_idx = np.argmax(magnitude[1:]) + 1  # Skip DC
        peak_freq = freqs[peak_idx]

        # Update center frequency with smoothing
        self.center_frequency = (
            self.center_frequency * (1 - self.adaptation_rate)
            + peak_freq * self.adaptation_rate
        )

        # Update filter
        q = self.center_frequency / self.bandwidth
        self.filter.set_parameters(frequency=self.center_frequency, q=q)

    def reset(self):
        """Reset adaptive filter."""
        self.filter.reset()
        self.buffer.fill(0)
        self.buffer_pos = 0
