"""
Main application for OMEGA-3 Professional Audio Analyzer
"""

import argparse
import time
from collections import deque
from typing import Any
from typing import Dict
from typing import Optional

import numpy as np
import pygame

try:
    from .audio import PipeWireMonitorCapture
    from .config import *
    from .processing import AnalyzerThreadPool
    from .processing import MultiResolutionFFT
    from .processing import create_legacy_processor, create_bass_detail_processor
    from .processing.config import ProcessingConfig, DEFAULT_PROCESSING_CONFIG
    from .utils import PerformanceMonitor
    from .visualization.main_display import SpectrumRenderer
    from .visualization.panels import BassDetailPanel
    from .visualization.panels import ChromagramPanel
    from .visualization.panels import GenrePanel
    from .visualization.panels import HarmonicPanel
    from .visualization.panels import MetersPanel
    from .visualization.panels import PitchPanel
    from .visualization.panels import TechnicalPanel
    from .visualization.panels import VoicePanel
    from .visualization.panels import VUMetersPanel
    from .visualization.ui.colors import ColorManager
    from .visualization.ui.layout import LayoutManager
except ImportError:
    # Handle direct execution
    from audio import PipeWireMonitorCapture
    from config import *
    from processing import AnalyzerThreadPool
    from processing import MultiResolutionFFT
    from processing import create_legacy_processor, create_bass_detail_processor
    from processing.config import ProcessingConfig, DEFAULT_PROCESSING_CONFIG
    from utils import PerformanceMonitor
    from visualization.main_display import SpectrumRenderer
    from visualization.panels import BassDetailPanel
    from visualization.panels import ChromagramPanel
    from visualization.panels import GenrePanel
    from visualization.panels import HarmonicPanel
    from visualization.panels import MetersPanel
    from visualization.panels import PitchPanel
    from visualization.panels import TechnicalPanel
    from visualization.panels import VoicePanel
    from visualization.panels import VUMetersPanel
    from visualization.ui.colors import ColorManager
    from visualization.ui.layout import LayoutManager


class OmegaAnalyzerApp:
    """Main application class for OMEGA-3 analyzer"""

    def __init__(
        self,
        width: int = DEFAULT_WIDTH,
        height: int = DEFAULT_HEIGHT,
        bars: int = BARS_DEFAULT,
        source_name: Optional[str] = None,
        source_index: Optional[int] = None,
        interactive: bool = False,
    ):
        self.width = width
        self.height = height
        self.bars = bars
        self.running = False

        # Initialize pygame
        pygame.init()
        self.screen = pygame.display.set_mode((width, height), pygame.RESIZABLE)
        pygame.display.set_caption("Professional Audio Analyzer v4 OMEGA-3")
        self.clock = pygame.time.Clock()

        # Create processing configuration
        self.processing_config = ProcessingConfig(
            sample_rate=SAMPLE_RATE,
            bars_default=bars,
            fft_size_base=FFT_SIZE_BASE
        )
        
        # Core components using new factory system
        self.audio_capture = PipeWireMonitorCapture(
            source_name=source_name, source_index=source_index, interactive=interactive
        )
        self.fft_processor = MultiResolutionFFT(SAMPLE_RATE, use_gpu=False)
        self.spectrum_processor = create_legacy_processor(bars, SAMPLE_RATE)
        self.bass_processor = create_bass_detail_processor(SAMPLE_RATE)
        self.thread_pool = AnalyzerThreadPool()
        self.renderer = SpectrumRenderer(self.screen, bars)
        self.performance_monitor = PerformanceMonitor()

        # UI Management
        self.layout_manager = LayoutManager(width, height)
        self.color_manager = ColorManager()

        # Audio processing state
        self.audio_buffer = deque(maxlen=FFT_SIZE_BASE * 2)
        self.spectrum_data = np.zeros(self.spectrum_processor.bars, dtype=np.float32)
        self.spectrum_peaks = np.zeros(self.spectrum_processor.bars, dtype=np.float32)
        self.peak_timestamps = np.zeros(self.spectrum_processor.bars, dtype=np.float64)
        self.bass_spectrum_data = np.zeros(
            self.bass_processor.bass_detail_bars, dtype=np.float32
        )

        # Settings
        self.input_gain = 0.5  # Start with reduced gain to prevent clipping
        self.bass_gain = 2.0   # Further reduced bass gain
        self.auto_gain_enabled = True  # Enable automatic gain control
        self.show_help = False
        self.quality_mode = "quality"
        self.frame_counter = 0
        
        # Event handling state
        self.last_key_time = {}  # Track last time each key was pressed

        # Initialize analyzers (will be loaded dynamically)
        self._load_analyzers()

        # Initialize panels
        self._setup_panels()

    def _load_analyzers(self):
        """Dynamically load analyzer modules"""
        try:
            from .analyzers import DrumDetector
            from .analyzers import HarmonicAnalyzer
            from .analyzers import VoiceAnalyzer
        except ImportError:
            from analyzers import DrumDetector
            from analyzers import HarmonicAnalyzer
            from analyzers import VoiceAnalyzer

        # Register analyzers with thread pool
        self.thread_pool.register_analyzer(
            "HarmonicAnalyzer", HarmonicAnalyzer(self.audio_capture.sample_rate)
        )
        self.thread_pool.register_analyzer(
            "DrumDetector", DrumDetector(self.audio_capture.sample_rate)
        )
        self.thread_pool.register_analyzer(
            "VoiceAnalyzer", VoiceAnalyzer(self.audio_capture.sample_rate)
        )

    def _setup_panels(self):
        """Setup visualization panels"""
        panel_width = 300
        panel_height = 200
        right_margin = 20
        panel_spacing = 10

        # Position panels on the right side
        x = self.width - panel_width - right_margin
        y = 150

        # Create all panels
        self.panels = {
            "harmonic": HarmonicPanel(self.screen, x, y, panel_width, panel_height),
            "voice": VoicePanel(
                self.screen,
                x,
                y + (panel_height + panel_spacing),
                panel_width,
                panel_height,
            ),
            "meters": MetersPanel(
                self.screen,
                x,
                y + 2 * (panel_height + panel_spacing),
                panel_width,
                panel_height,
            ),
            "bass_detail": BassDetailPanel(
                self.screen, 50, self.height - 150, self.width - 400, 120
            ),
            "technical": TechnicalPanel(self.screen, 10, 10, 300, 100),
        }

        # Optional panels (can be toggled)
        self.optional_panels = {
            "pitch": PitchPanel(self.screen, x, y, panel_width, panel_height),
            "chromagram": ChromagramPanel(self.screen, x, y, panel_width, panel_height),
            "genre": GenrePanel(self.screen, x, y, panel_width, panel_height),
            "vu_meters": VUMetersPanel(self.screen, x, y, panel_width, panel_height),
        }

        # Panel visibility
        self.panel_visibility = {
            "harmonic": True,
            "voice": True,
            "meters": True,
            "bass_detail": True,
            "technical": True,
            "pitch": False,
            "chromagram": False,
            "genre": False,
            "vu_meters": False,
        }

    def process_audio_frame(self, audio_data: np.ndarray) -> Dict[str, Any]:
        """Process one frame of audio data"""
        # Automatic gain control
        if self.auto_gain_enabled:
            rms_level = np.sqrt(np.mean(audio_data ** 2))
            if rms_level > 1e-6:  # Only adjust if there's signal
                # Target RMS level (around -26dB for more headroom)
                target_rms = 0.05
                auto_gain = target_rms / (rms_level + 1e-10)
                # Smooth the gain changes with more conservative limits
                auto_gain = np.clip(auto_gain, 0.1, 5.0)
                self.input_gain = self.input_gain * 0.95 + auto_gain * 0.05
        
        # Apply input gain
        audio_data = audio_data * self.input_gain

        # Multi-resolution FFT processing
        fft_results = self.fft_processor.process_multi_resolution(audio_data)
        combined_fft = self.fft_processor.combine_results(fft_results)

        # Map to display bars
        spectrum_data = self._map_fft_to_bars(combined_fft)

        # Process bass detail spectrum
        bass_fft = fft_results.get(
            0, combined_fft
        )  # Use bass-specific FFT if available
        bass_spectrum = self.bass_processor.process_bass_fft(bass_fft, self.bass_gain)

        # Submit analyzers for parallel processing
        self.thread_pool.submit_batch(audio_data, combined_fft)

        return {
            "spectrum": spectrum_data,
            "bass_spectrum": bass_spectrum,
            "fft_results": fft_results,
            "combined_fft": combined_fft,
        }

    def _map_fft_to_bars(self, fft_data: np.ndarray) -> np.ndarray:
        """Map FFT data to display bars using perceptual frequency mapping"""
        # Use the spectrum processor for perceptual mapping
        return self.spectrum_processor.process_fft_data(
            fft_data, apply_compensation=True
        )

    def update_spectrum_display(
        self, spectrum_data: np.ndarray, bass_spectrum: Optional[np.ndarray] = None
    ):
        """Update spectrum with smoothing and peak detection"""
        # Smooth spectrum data
        alpha = 0.3  # Smoothing factor
        self.spectrum_data = alpha * spectrum_data + (1 - alpha) * self.spectrum_data

        # Update bass spectrum if provided
        if bass_spectrum is not None:
            self.bass_spectrum_data = (
                alpha * bass_spectrum + (1 - alpha) * self.bass_spectrum_data
            )

        # Update peaks
        current_time = time.time()
        peak_decay_time = 2.0  # seconds

        for i in range(len(self.spectrum_data)):
            if self.spectrum_data[i] > self.spectrum_peaks[i]:
                self.spectrum_peaks[i] = self.spectrum_data[i]
                self.peak_timestamps[i] = current_time
            else:
                # Decay peaks
                time_since_peak = current_time - self.peak_timestamps[i]
                if time_since_peak > peak_decay_time:
                    self.spectrum_peaks[i] = self.spectrum_data[i]

    def handle_events(self) -> bool:
        """Handle pygame events with comprehensive keyboard controls"""
        current_time = time.time()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN:
                # Key debouncing - prevent rapid toggling
                key_name = pygame.key.name(event.key)
                if key_name in self.last_key_time:
                    if current_time - self.last_key_time[key_name] < 0.2:  # 200ms debounce
                        continue
                self.last_key_time[key_name] = current_time
                # System & Application Controls
                if event.key == pygame.K_ESCAPE:
                    return False
                elif event.key == pygame.K_h:
                    self.show_help = not self.show_help
                    print(f"Help display: {'ON' if self.show_help else 'OFF'}")
                elif event.key == pygame.K_s:
                    # Screenshot
                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                    filename = f"omega3_screenshot_{timestamp}.png"
                    pygame.image.save(self.screen, filename)
                    print(f"Screenshot saved: {filename}")
                elif event.key == pygame.K_d:
                    # Debug output
                    self._print_debug_info()
                elif event.key == pygame.K_SLASH or event.key == pygame.K_QUESTION:
                    self.show_help = not self.show_help
                    print(f"Help display: {'ON' if self.show_help else 'OFF'}")

                # Audio Processing Controls
                elif event.key == pygame.K_EQUALS or event.key == pygame.K_PLUS:
                    self.input_gain = min(self.input_gain * 1.5, 16.0)
                    print(f"Input gain: {20 * np.log10(self.input_gain):.1f}dB")
                elif event.key == pygame.K_MINUS:
                    self.input_gain = max(self.input_gain / 1.5, 0.25)
                    print(f"Input gain: {20 * np.log10(self.input_gain):.1f}dB")
                elif event.key == pygame.K_0:
                    # Reset gain to default
                    self.input_gain = 4.0  # +12dB
                    print(f"Input gain reset: {20 * np.log10(self.input_gain):.1f}dB")
                elif event.key == pygame.K_LEFTBRACKET:
                    # Decrease bass gain
                    self.bass_gain = max(self.bass_gain - 1.0, 1.0)
                    print(f"Bass gain: {self.bass_gain:.1f}x")
                elif event.key == pygame.K_RIGHTBRACKET:
                    # Increase bass gain
                    self.bass_gain = min(self.bass_gain + 1.0, 20.0)
                    print(f"Bass gain: {self.bass_gain:.1f}x")
                elif event.key == pygame.K_g:
                    # Toggle auto-gain
                    self.auto_gain_enabled = not self.auto_gain_enabled
                    print(f"Auto-gain: {'ON' if self.auto_gain_enabled else 'OFF'}")
                    if not self.auto_gain_enabled:
                        self.input_gain = 1.0  # Reset to unity when disabled

                # Display Toggle Controls
                elif event.key == pygame.K_m:
                    self.panel_visibility["meters"] = not self.panel_visibility[
                        "meters"
                    ]
                    print(
                        f"Professional meters: {'ON' if self.panel_visibility['meters'] else 'OFF'}"
                    )
                elif event.key == pygame.K_j:
                    self.panel_visibility["vu_meters"] = not self.panel_visibility[
                        "vu_meters"
                    ]
                    print(
                        f"VU meters: {'ON' if self.panel_visibility['vu_meters'] else 'OFF'}"
                    )
                elif event.key == pygame.K_z:
                    self.panel_visibility["bass_detail"] = not self.panel_visibility[
                        "bass_detail"
                    ]
                    print(
                        f"Bass zoom window: {'ON' if self.panel_visibility['bass_detail'] else 'OFF'}"
                    )
                elif event.key == pygame.K_r:
                    self.panel_visibility["harmonic"] = not self.panel_visibility[
                        "harmonic"
                    ]
                    print(
                        f"Harmonic analysis: {'ON' if self.panel_visibility['harmonic'] else 'OFF'}"
                    )
                elif event.key == pygame.K_v:
                    self.panel_visibility["voice"] = not self.panel_visibility["voice"]
                    print(
                        f"Voice analysis: {'ON' if self.panel_visibility['voice'] else 'OFF'}"
                    )
                elif event.key == pygame.K_t:
                    self.panel_visibility["technical"] = not self.panel_visibility[
                        "technical"
                    ]
                    print(
                        f"Technical overlay: {'ON' if self.panel_visibility['technical'] else 'OFF'}"
                    )

                # OMEGA Feature Controls
                elif event.key == pygame.K_p:
                    self.panel_visibility["pitch"] = not self.panel_visibility["pitch"]
                    print(
                        f"OMEGA Pitch detection: {'ON' if self.panel_visibility['pitch'] else 'OFF'}"
                    )
                elif event.key == pygame.K_k:
                    self.panel_visibility["chromagram"] = not self.panel_visibility[
                        "chromagram"
                    ]
                    print(
                        f"OMEGA-1 Chromagram/Key detection: {'ON' if self.panel_visibility['chromagram'] else 'OFF'}"
                    )
                elif event.key == pygame.K_n:
                    self.panel_visibility["genre"] = not self.panel_visibility["genre"]
                    print(
                        f"OMEGA-2 Genre classification: {'ON' if self.panel_visibility['genre'] else 'OFF'}"
                    )

                # Quality and Performance Controls
                elif event.key == pygame.K_y:
                    # Toggle dynamic quality mode
                    self.quality_mode = (
                        "performance" if self.quality_mode == "quality" else "quality"
                    )
                    print(f"Quality mode: {self.quality_mode.upper()}")

                # Window Size Presets
                elif event.key == pygame.K_1:
                    self._set_window_size(1400, 900, "Professional Compact")
                elif event.key == pygame.K_2:
                    self._set_window_size(1800, 1000, "Professional Standard")
                elif event.key == pygame.K_3:
                    self._set_window_size(2200, 1200, "Professional Wide")
                elif event.key == pygame.K_4:
                    self._set_window_size(2600, 1400, "Professional Ultra-Wide")
                elif event.key == pygame.K_5:
                    self._set_window_size(3000, 1600, "Professional Cinema")
                elif event.key == pygame.K_6:
                    self._set_window_size(3400, 1800, "Professional Studio")
                elif event.key == pygame.K_7:
                    self._set_window_size(1920, 1080, "Full HD Standard")
                elif event.key == pygame.K_8:
                    self._set_window_size(2560, 1440, "2K Monitor")
                elif event.key == pygame.K_9:
                    self._set_window_size(3840, 2160, "4K Monitor")

                # Forward events to active panels for panel-specific controls
                else:
                    self._handle_panel_events(event)

        return True

    def _handle_panel_events(self, event):
        """Forward events to active panels for panel-specific keyboard controls"""
        # Forward to active panels that have handle_event methods
        for panel_name, panel in self.panels.items():
            if self.panel_visibility.get(panel_name, True) and hasattr(
                panel, "handle_event"
            ):
                if panel.handle_event(event):
                    return  # Event was handled, don't forward to other panels

        for panel_name, panel in self.optional_panels.items():
            if self.panel_visibility.get(panel_name, False) and hasattr(
                panel, "handle_event"
            ):
                if panel.handle_event(event):
                    return  # Event was handled

    def _print_debug_info(self):
        """Print debug information to terminal"""
        print("\n" + "=" * 50)
        print("OMEGA-3 DEBUG INFORMATION")
        print("=" * 50)
        print(f"Sample Rate: {self.audio_capture.sample_rate}Hz")
        print(f"Input Gain: {20 * np.log10(self.input_gain):.1f}dB")
        print(f"Quality Mode: {self.quality_mode}")
        print(f"Window Size: {self.width}x{self.height}")
        print(f"Spectrum Bars: {self.bars}")
        print(f"Frame Rate: {self.clock.get_fps():.1f} FPS")
        print(
            f"Average Latency: {self.performance_monitor.get_average_latency():.1f}ms"
        )

        print("\nActive Panels:")
        for panel, visible in self.panel_visibility.items():
            status = "ON" if visible else "OFF"
            print(f"  {panel}: {status}")

        print(f"\nRegistered Analyzers: {list(self.thread_pool.analyzers.keys())}")
        print("=" * 50 + "\n")

    def _set_window_size(self, width: int, height: int, name: str):
        """Set window size with proper scaling"""
        try:
            self.width = width
            self.height = height
            self.screen = pygame.display.set_mode((width, height), pygame.RESIZABLE)

            # Update layout manager
            self.layout_manager = LayoutManager(width, height)

            # Recreate renderer with new dimensions
            self.renderer = SpectrumRenderer(self.screen, self.bars)

            # Reposition panels
            self._setup_panels()

            print(f"Window size changed to {name}: {width}x{height}")
        except Exception as e:
            print(f"Failed to set window size {name}: {e}")

    def draw_frame(self):
        """Draw the current frame"""
        # Clear screen
        self.screen.fill((20, 20, 30))

        # Draw spectrum
        self.renderer.draw_spectrum(self.spectrum_data, self.spectrum_peaks)

        # Draw bass detail spectrum if available
        if hasattr(self, "bass_spectrum_data") and len(self.bass_spectrum_data) > 0:
            self.renderer.draw_bass_detail(self.bass_spectrum_data)

        # Draw UI elements
        self.renderer.draw_header_info(
            {
                "fps": self.clock.get_fps(),
                "latency": self.performance_monitor.get_average_latency(),
                "quality_mode": self.quality_mode,
                "input_gain": 20 * np.log10(self.input_gain),
            }
        )

        # Draw analysis panels
        if hasattr(self, "last_analyzer_results"):
            self._draw_panels(self.last_analyzer_results)

        # Draw help if enabled
        if self.show_help:
            self.renderer.draw_help()

        # Update display
        pygame.display.flip()

    def _draw_panels(self, analyzer_results: Dict[str, Any]):
        """Draw all active panels"""
        # Draw core panels
        for panel_name, panel in self.panels.items():
            if self.panel_visibility.get(panel_name, True):
                if panel_name == "harmonic" and "HarmonicAnalyzer" in analyzer_results:
                    panel.draw(analyzer_results["HarmonicAnalyzer"].data)
                elif panel_name == "voice" and "VoiceAnalyzer" in analyzer_results:
                    panel.draw(analyzer_results["VoiceAnalyzer"].data)
                elif panel_name == "meters" and "ProfessionalMeter" in analyzer_results:
                    panel.draw(analyzer_results["ProfessionalMeter"].data)
                elif panel_name == "bass_detail":
                    panel.draw(self.bass_spectrum_data)
                elif panel_name == "technical":
                    tech_data = {
                        "fps": self.clock.get_fps(),
                        "latency": self.performance_monitor.get_average_latency() / 1000.0,  # Convert to seconds
                        "quality_mode": self.quality_mode,
                        "input_gain": 20 * np.log10(self.input_gain),
                        "analyzer_count": len(analyzer_results),
                        "sample_rate": self.audio_capture.sample_rate,
                        "bit_depth": 32,  # Assuming 32-bit float
                        "channels": 2,    # Stereo
                        "buffer_size": 512,
                        "rms_level": np.sqrt(np.mean(self.spectrum_data ** 2)) if len(self.spectrum_data) > 0 else 0,
                        "peak_level": np.max(self.spectrum_data) if len(self.spectrum_data) > 0 else 0,
                        "cpu_usage": self.performance_monitor.get_average_latency() / 16.67 * 100,  # Estimate CPU %
                        "processing_time": self.performance_monitor.get_average_latency() / 1000.0,
                        "buffer_underruns": 0,
                    }
                    panel.update(tech_data)
                    panel.draw(tech_data)
                else:
                    panel.draw({})

        # Draw optional panels
        for panel_name, panel in self.optional_panels.items():
            if self.panel_visibility.get(panel_name, False):
                if panel_name == "pitch" and "PitchDetector" in analyzer_results:
                    panel.draw(analyzer_results["PitchDetector"].data)
                elif (
                    panel_name == "chromagram"
                    and "ChromagramAnalyzer" in analyzer_results
                ):
                    panel.draw(analyzer_results["ChromagramAnalyzer"].data)
                elif panel_name == "genre" and "GenreClassifier" in analyzer_results:
                    panel.draw(analyzer_results["GenreClassifier"].data)
                elif panel_name == "vu_meters":
                    # Use basic RMS for VU meters if no professional meter available
                    vu_data = {"rms": np.sqrt(np.mean(self.spectrum_data ** 2))}
                    panel.draw(vu_data)
                else:
                    panel.draw({})

    def run(self):
        """Main application loop"""
        print("\n" + "=" * 60)
        print("OMEGA-3 Professional Audio Analyzer")
        print("=" * 60)
        print("Modular architecture with optimized performance")
        print("Press 'H' for help")
        print("=" * 60)

        # Start audio capture
        print("🚀 Attempting to start audio capture...")
        if not self.audio_capture.start_capture():
            print("❌ Failed to start audio capture")
            return

        print("✅ Audio capture started successfully")
        self.running = True

        try:
            print("🔄 Entering main processing loop...")
            while self.running:
                frame_start = time.perf_counter()

                # Handle events
                if not self.handle_events():
                    break

                # Get audio data
                audio_data = self.audio_capture.get_audio_data()
                if audio_data is not None:
                    # Process audio
                    results = self.process_audio_frame(audio_data)

                    # Update display
                    self.update_spectrum_display(
                        results["spectrum"], results.get("bass_spectrum")
                    )

                    # Collect analyzer results (non-blocking)
                    analyzer_results = self.thread_pool.collect_results(timeout=0.005)
                    if analyzer_results:
                        self.last_analyzer_results = analyzer_results

                # Draw frame
                self.draw_frame()

                # Frame timing
                self.clock.tick(TARGET_FPS)

                # Performance monitoring
                frame_time = (time.perf_counter() - frame_start) * 1000
                self.performance_monitor.add_frame_time(frame_time)

                # Dynamic quality adjustment
                if self.frame_counter % 30 == 0:
                    avg_latency = self.performance_monitor.get_average_latency()
                    if (
                        avg_latency > PERFORMANCE_MODE_THRESHOLD_MS
                        and self.quality_mode == "quality"
                    ):
                        self.quality_mode = "performance"
                        print(
                            f"Switching to performance mode (latency: {avg_latency:.1f}ms)"
                        )
                    elif (
                        avg_latency < QUALITY_MODE_THRESHOLD_MS
                        and self.quality_mode == "performance"
                    ):
                        self.quality_mode = "quality"
                        print(
                            f"Switching to quality mode (latency: {avg_latency:.1f}ms)"
                        )

                self.frame_counter += 1

        finally:
            # Cleanup
            self.audio_capture.stop_capture()
            self.thread_pool.shutdown()
            pygame.quit()


def main():
    """Entry point with argument parsing"""
    parser = argparse.ArgumentParser(description="OMEGA-3 Professional Audio Analyzer")
    parser.add_argument("--width", type=int, default=DEFAULT_WIDTH, help="Window width")
    parser.add_argument(
        "--height", type=int, default=DEFAULT_HEIGHT, help="Window height"
    )
    parser.add_argument(
        "--bars", type=int, default=BARS_DEFAULT, help="Number of spectrum bars"
    )
    parser.add_argument("--source", type=str, default=None, help="PipeWire source name")
    parser.add_argument(
        "--source-index", type=int, default=None, help="Audio source index (0-N)"
    )
    parser.add_argument(
        "--interactive", action="store_true", help="Interactive source selection"
    )

    args = parser.parse_args()

    app = OmegaAnalyzerApp(
        width=args.width,
        height=args.height,
        bars=args.bars,
        source_name=args.source,
        source_index=args.source_index,
        interactive=args.interactive,
    )

    app.run()


if __name__ == "__main__":
    main()
