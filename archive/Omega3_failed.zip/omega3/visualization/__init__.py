"""
Visualization package for OMEGA-3
Professional audio visualization system
"""

from .effects.peak_hold import PeakHoldEffect
from .effects.reactivity import ReactiveEffect
from .main_display import SpectrumRenderer
from .panels import BassDetailPanel
from .panels import ChromagramPanel
from .panels import GenrePanel
from .panels import HarmonicPanel
from .panels import MetersPanel
from .panels import PitchPanel
from .panels import TechnicalPanel
from .panels import VoicePanel
from .panels import VUMetersPanel
from .ui.colors import ColorManager
from .ui.layout import LayoutManager

__all__ = [
    "SpectrumRenderer",
    "HarmonicPanel",
    "VoicePanel",
    "PitchPanel",
    "ChromagramPanel",
    "GenrePanel",
    "BassDetailPanel",
    "VUMetersPanel",
    "TechnicalPanel",
    "MetersPanel",
    "LayoutManager",
    "ColorManager",
    "PeakHoldEffect",
    "ReactiveEffect",
]
