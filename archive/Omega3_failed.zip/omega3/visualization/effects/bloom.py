"""
Bloom and glow effects for OMEGA-3.
Post-processing visual effects.
"""

from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class BloomEffect:
    """Bloom/glow post-processing effect."""

    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height

        # Effect parameters
        self.intensity = 1.0
        self.threshold = 0.8
        self.blur_passes = 3
        self.blur_scale = 0.5

        # Create surfaces for effect pipeline
        self.threshold_surface = pygame.Surface((width, height))
        self.blur_surface = pygame.Surface(
            (int(width * self.blur_scale), int(height * self.blur_scale))
        )
        self.glow_surface = pygame.Surface((width, height))

    def apply(self, surface: pygame.Surface) -> pygame.Surface:
        """Apply bloom effect to surface."""
        if self.intensity <= 0:
            return surface

        # Extract bright areas
        self._extract_bright_areas(surface, self.threshold_surface)

        # Downscale for performance
        pygame.transform.smoothscale(
            self.threshold_surface,
            (self.blur_surface.get_width(), self.blur_surface.get_height()),
            self.blur_surface,
        )

        # Apply blur
        for _ in range(self.blur_passes):
            self._blur_surface(self.blur_surface)

        # Upscale back
        pygame.transform.smoothscale(
            self.blur_surface, (self.width, self.height), self.glow_surface
        )

        # Blend with original
        result = surface.copy()
        self.glow_surface.set_alpha(int(255 * self.intensity))
        result.blit(self.glow_surface, (0, 0), special_flags=pygame.BLEND_ADD)

        return result

    def _extract_bright_areas(self, source: pygame.Surface, dest: pygame.Surface):
        """Extract pixels above threshold."""
        # Convert surface to array
        pixels = pygame.surfarray.array3d(source)

        # Calculate luminance
        luminance = (
            0.299 * pixels[:, :, 0] + 0.587 * pixels[:, :, 1] + 0.114 * pixels[:, :, 2]
        )
        luminance = luminance / 255.0

        # Apply threshold
        mask = luminance > self.threshold

        # Create output
        output = pixels.copy()
        output[~mask] = 0

        # Convert back to surface
        pygame.surfarray.blit_array(dest, output)

    def _blur_surface(self, surface: pygame.Surface):
        """Apply simple box blur to surface."""
        # Convert to array
        pixels = pygame.surfarray.array3d(surface)

        # Simple 3x3 box blur
        kernel_size = 3
        pad = kernel_size // 2

        # Pad array
        padded = np.pad(pixels, ((pad, pad), (pad, pad), (0, 0)), mode="edge")

        # Apply blur
        blurred = np.zeros_like(pixels)
        for i in range(kernel_size):
            for j in range(kernel_size):
                blurred += padded[i: i + pixels.shape[0], j: j + pixels.shape[1], :]

        blurred = blurred / (kernel_size * kernel_size)

        # Convert back
        pygame.surfarray.blit_array(surface, blurred.astype(np.uint8))

    def set_intensity(self, intensity: float):
        """Set bloom intensity (0-1)."""
        self.intensity = np.clip(intensity, 0, 1)

    def set_threshold(self, threshold: float):
        """Set brightness threshold (0-1)."""
        self.threshold = np.clip(threshold, 0, 1)


class GlowEffect:
    """Simpler glow effect for specific elements."""

    def __init__(self):
        self.glow_color = (255, 255, 255)
        self.glow_size = 10
        self.glow_intensity = 0.5

    def apply_to_surface(
        self, surface: pygame.Surface, color: Optional[Tuple[int, int, int]] = None
    ) -> pygame.Surface:
        """Apply glow to a surface."""
        if color:
            self.glow_color = color

        # Create glow surface
        glow_surface = pygame.Surface(
            (
                surface.get_width() + 2 * self.glow_size,
                surface.get_height() + 2 * self.glow_size,
            ),
            pygame.SRCALPHA,
        )

        # Draw multiple layers for glow
        for i in range(self.glow_size):
            alpha = int(255 * self.glow_intensity * (1 - i / self.glow_size))
            color_with_alpha = (*self.glow_color, alpha)

            # Create temp surface
            temp = pygame.Surface(glow_surface.get_size(), pygame.SRCALPHA)
            temp.fill(color_with_alpha)

            # Mask with original shape
            mask_surface = surface.copy()
            mask_surface.set_alpha(255)
            temp.blit(mask_surface, (self.glow_size, self.glow_size))

            # Add to glow
            glow_surface.blit(temp, (0, 0))

        # Add original on top
        glow_surface.blit(surface, (self.glow_size, self.glow_size))

        return glow_surface

    def draw_glowing_line(
        self,
        surface: pygame.Surface,
        start: Tuple[int, int],
        end: Tuple[int, int],
        color: Tuple[int, int, int],
        width: int = 2,
    ):
        """Draw a line with glow effect."""
        # Draw glow layers
        for i in range(self.glow_size, 0, -1):
            alpha = int(255 * self.glow_intensity * (1 - i / self.glow_size))
            glow_width = width + i * 2

            # Create temp surface for alpha
            temp = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            pygame.draw.line(temp, (*color, alpha), start, end, glow_width)
            surface.blit(temp, (0, 0))

        # Draw main line
        pygame.draw.line(surface, color, start, end, width)

    def draw_glowing_circle(
        self,
        surface: pygame.Surface,
        center: Tuple[int, int],
        radius: int,
        color: Tuple[int, int, int],
        width: int = 0,
    ):
        """Draw a circle with glow effect."""
        # Draw glow layers
        for i in range(self.glow_size, 0, -1):
            alpha = int(255 * self.glow_intensity * (1 - i / self.glow_size))
            glow_radius = radius + i

            # Create temp surface for alpha
            temp = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            pygame.draw.circle(temp, (*color, alpha), center, glow_radius, width)
            surface.blit(temp, (0, 0))

        # Draw main circle
        pygame.draw.circle(surface, color, center, radius, width)
