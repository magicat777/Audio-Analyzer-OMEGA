"""
Beat and voice reactive effects for visualizations
"""

import math
import time
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class ReactiveEffect:
    """Base class for reactive effects"""

    def __init__(self):
        self.intensity = 0.0
        self.last_trigger = 0
        self.decay_rate = 0.95
        self.threshold = 0.5
        self.cooldown = 0.1  # seconds

        # Animation state
        self.animation_phase = 0
        self.animation_speed = 1.0
        self.last_update = time.time()

    def update(self, trigger_value: float):
        """Update effect based on trigger value"""
        current_time = time.time()
        dt = current_time - self.last_update
        self.last_update = current_time

        # Update animation
        self.animation_phase += dt * self.animation_speed * 2 * np.pi

        # Check trigger
        if (
            trigger_value > self.threshold
            and current_time - self.last_trigger > self.cooldown
        ):
            self.intensity = min(1.0, self.intensity + trigger_value)
            self.last_trigger = current_time

        # Decay
        self.intensity *= self.decay_rate

    def get_intensity(self) -> float:
        """Get current effect intensity"""
        return self.intensity


class BeatReactiveEffect(ReactiveEffect):
    """Beat-reactive visual effects"""

    def __init__(self):
        super().__init__()
        self.beat_history = []
        self.beat_phase = 0
        self.tempo = 120  # BPM
        self.beat_strength = 0

        # Visual parameters
        self.pulse_scale = 1.0
        self.color_shift = 0
        self.rotation = 0

        # Beat patterns
        self.pattern_length = 4  # 4/4 time
        self.beat_pattern = [1.0, 0.5, 0.75, 0.5]  # Emphasis pattern
        self.current_beat = 0

    def on_beat(self, strength: float, tempo: Optional[float] = None):
        """Called when a beat is detected"""
        self.beat_strength = strength
        self.intensity = strength
        self.last_trigger = time.time()

        if tempo:
            self.tempo = tempo

        # Update beat pattern position
        self.current_beat = (self.current_beat + 1) % self.pattern_length

        # Store in history
        self.beat_history.append(
            {"time": time.time(), "strength": strength, "beat_num": self.current_beat}
        )

        # Limit history
        if len(self.beat_history) > 100:
            self.beat_history.pop(0)

    def update(self, dt: float):
        """Update beat reactive effects"""
        # Update beat phase based on tempo
        beat_period = 60.0 / self.tempo
        self.beat_phase = (self.beat_phase + dt / beat_period) % 1.0

        # Decay intensity
        self.intensity *= self.decay_rate

        # Update visual parameters
        self.pulse_scale = 1.0 + self.intensity * 0.2 * math.sin(
            self.beat_phase * 2 * np.pi
        )
        self.color_shift = self.intensity * 360
        self.rotation += self.intensity * dt * 90  # degrees per second

    def apply_to_surface(
        self, surface: pygame.Surface, original: pygame.Surface
    ) -> pygame.Surface:
        """Apply beat-reactive effects to a surface"""
        if self.intensity < 0.01:
            return original

        # Create working surface
        width, height = original.get_size()
        result = pygame.Surface((width, height), pygame.SRCALPHA)

        # Apply pulse scaling
        if self.pulse_scale != 1.0:
            scaled_width = int(width * self.pulse_scale)
            scaled_height = int(height * self.pulse_scale)
            scaled = pygame.transform.scale(original, (scaled_width, scaled_height))

            # Center the scaled image
            x = (width - scaled_width) // 2
            y = (height - scaled_height) // 2
            result.blit(scaled, (x, y))
        else:
            result.blit(original, (0, 0))

        # Apply color shift
        if self.color_shift > 0:
            # Create color overlay
            overlay = pygame.Surface((width, height), pygame.SRCALPHA)
            hue = self.color_shift % 360
            color = self._hsv_to_rgb(hue / 360, 0.8, 1.0)
            overlay.fill((*color, int(self.intensity * 50)))
            result.blit(overlay, (0, 0), special_flags=pygame.BLEND_ADD)

        # Apply rotation
        if abs(self.rotation) > 0.1:
            result = pygame.transform.rotate(result, self.rotation % 360)

        return result

    def draw_beat_indicator(self, surface: pygame.Surface, x: int, y: int, size: int):
        """Draw beat indicator"""
        # Draw beat circles
        for i, beat in enumerate(self.beat_pattern):
            beat_x = x + i * (size + 10)

            # Background circle
            pygame.draw.circle(surface, (50, 50, 60), (beat_x, y), size, 1)

            # Active beat
            if i == self.current_beat:
                radius = int(size * (0.8 + 0.2 * self.intensity))
                color = (255, int(200 - 100 * self.intensity), 100)
                pygame.draw.circle(surface, color, (beat_x, y), radius)

            # Beat strength indicator
            strength_radius = int(size * beat * 0.7)
            pygame.draw.circle(
                surface, (100, 100, 120), (beat_x, y), strength_radius, 2
            )

    def _hsv_to_rgb(self, h: float, s: float, v: float) -> Tuple[int, int, int]:
        """Convert HSV to RGB"""
        import colorsys

        rgb = colorsys.hsv_to_rgb(h, s, v)
        return tuple(int(c * 255) for c in rgb)


class VoiceReactiveEffect(ReactiveEffect):
    """Voice-reactive visual effects"""

    def __init__(self):
        super().__init__()
        self.voice_active = False
        self.voice_confidence = 0
        self.pitch_value = 0
        self.formants = []

        # Visual parameters
        self.glow_intensity = 0
        self.wave_amplitude = 0
        self.particle_emission = 0

        # Voice characteristics
        self.voice_color = (100, 200, 255)
        self.voice_type = "normal"

    def on_voice_detected(
        self,
        confidence: float,
        pitch: Optional[float] = None,
        formants: Optional[List[float]] = None,
    ):
        """Called when voice is detected"""
        self.voice_active = True
        self.voice_confidence = confidence
        self.intensity = confidence

        if pitch:
            self.pitch_value = pitch
        if formants:
            self.formants = formants

        # Update voice color based on pitch
        if pitch:
            # Map pitch to color (low = blue, high = red)
            hue = np.clip((pitch - 80) / 400, 0, 1) * 0.8  # 80-480 Hz range
            self.voice_color = self._hsv_to_rgb(hue, 0.8, 1.0)

    def update(self, dt: float):
        """Update voice reactive effects"""
        # Update visual parameters
        if self.voice_active:
            self.glow_intensity = min(1.0, self.glow_intensity + dt * 3)
            self.wave_amplitude = self.voice_confidence * 50
            self.particle_emission = self.voice_confidence * 10
        else:
            self.glow_intensity *= 0.9
            self.wave_amplitude *= 0.9
            self.particle_emission *= 0.9

        # Reset voice active flag (needs to be set each frame)
        self.voice_active = False

    def draw_voice_glow(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        """Draw voice-activated glow effect"""
        if self.glow_intensity < 0.01:
            return

        # Create glow layers
        glow_surface = pygame.Surface((width, height), pygame.SRCALPHA)

        # Multiple glow layers for soft effect
        for i in range(5):
            alpha = int(self.glow_intensity * 50 / (i + 1))
            size_factor = 1.0 + i * 0.1

            glow_width = int(width * size_factor)
            glow_height = int(height * size_factor)
            glow_x = (width - glow_width) // 2
            glow_y = (height - glow_height) // 2

            pygame.draw.ellipse(
                glow_surface,
                (*self.voice_color, alpha),
                (glow_x, glow_y, glow_width, glow_height),
            )

        surface.blit(glow_surface, (x, y), special_flags=pygame.BLEND_ADD)

    def draw_voice_waveform(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        """Draw voice-reactive waveform"""
        if self.wave_amplitude < 0.1:
            return

        # Generate waveform points
        points = []
        num_points = 100

        for i in range(num_points):
            px = x + i * width // num_points

            # Combine multiple frequencies for complex waveform
            py = y + height // 2

            # Fundamental frequency
            py += int(self.wave_amplitude * math.sin(i * 0.1 + self.animation_phase))

            # Add formant influences
            if self.formants:
                for j, formant in enumerate(self.formants[:3]):
                    freq_factor = formant / 1000  # Normalize formant frequency
                    py += int(
                        self.wave_amplitude
                        * 0.3
                        * math.sin(
                            i * freq_factor * 0.5 + self.animation_phase * (j + 1)
                        )
                    )

            points.append((px, py))

        # Draw waveform
        if len(points) > 1:
            pygame.draw.lines(surface, self.voice_color, False, points, 2)

    def _hsv_to_rgb(self, h: float, s: float, v: float) -> Tuple[int, int, int]:
        """Convert HSV to RGB"""
        import colorsys

        rgb = colorsys.hsv_to_rgb(h, s, v)
        return tuple(int(c * 255) for c in rgb)


class CombinedReactiveEffect:
    """Combined beat and voice reactive effects"""

    def __init__(self):
        self.beat_effect = BeatReactiveEffect()
        self.voice_effect = VoiceReactiveEffect()

        # Interaction parameters
        self.beat_voice_sync = 0
        self.combined_intensity = 0

    def update(self, dt: float):
        """Update all effects"""
        self.beat_effect.update(dt)
        self.voice_effect.update(dt)

        # Calculate combined intensity
        self.combined_intensity = max(
            self.beat_effect.intensity, self.voice_effect.glow_intensity
        )

        # Check for beat-voice synchronization
        if self.beat_effect.intensity > 0.5 and self.voice_effect.voice_active:
            self.beat_voice_sync = min(1.0, self.beat_voice_sync + dt * 2)
        else:
            self.beat_voice_sync *= 0.95

    def draw_combined_effects(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        """Draw combined reactive effects"""
        # Draw voice glow first (background)
        self.voice_effect.draw_voice_glow(surface, x, y, width, height)

        # Draw beat indicators
        indicator_y = y + height - 50
        self.beat_effect.draw_beat_indicator(surface, x + 20, indicator_y, 15)

        # Draw sync indicator
        if self.beat_voice_sync > 0.1:
            sync_color = (
                255,
                int(200 * self.beat_voice_sync),
                int(100 * self.beat_voice_sync),
            )
            sync_text = f"SYNC {self.beat_voice_sync * 100:.0f}%"

            # Create glowing text effect
            font = pygame.font.Font(None, 24)
            text_surface = font.render(sync_text, True, sync_color)
            text_rect = text_surface.get_rect(center=(x + width // 2, y + 30))

            # Glow
            for i in range(3):
                glow_surf = font.render(
                    sync_text,
                    True,
                    (*sync_color, int(100 * self.beat_voice_sync / (i + 1))),
                )
                glow_rect = glow_surf.get_rect(
                    center=(text_rect.centerx, text_rect.centery)
                )
                surface.blit(glow_surf, glow_rect)

            surface.blit(text_surface, text_rect)
