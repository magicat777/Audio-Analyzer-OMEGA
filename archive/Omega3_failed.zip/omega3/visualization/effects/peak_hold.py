"""
Peak hold visualization effect
"""

import time
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class PeakHoldEffect:
    """Peak hold visualization with decay"""

    def __init__(self, hold_time: float = 2.0, decay_time: float = 0.5):
        self.hold_time = hold_time
        self.decay_time = decay_time

        # Peak storage
        self.peaks: Dict[int, float] = {}  # index: value
        self.peak_times: Dict[int, float] = {}  # index: timestamp
        self.peak_colors: Dict[int, Tuple[int, int, int]] = {}

        # Visual settings
        self.peak_color = (255, 200, 100)
        self.peak_width = 3
        self.show_decay = True
        self.decay_style = "fade"  # "fade", "fall", "shrink"

        # Animation
        self.glow_phase = 0
        self.last_update = time.time()

    def update(self, values: List[float], indices: Optional[List[int]] = None):
        """Update peak values"""
        current_time = time.time()
        dt = current_time - self.last_update
        self.last_update = current_time

        # Update glow animation
        self.glow_phase += dt * 3

        if indices is None:
            indices = list(range(len(values)))

        # Update peaks
        for i, idx in enumerate(indices):
            if i < len(values):
                value = values[i]

                # Check if new peak
                if idx not in self.peaks or value > self.peaks[idx]:
                    self.peaks[idx] = value
                    self.peak_times[idx] = current_time
                    self.peak_colors[idx] = self._generate_peak_color(value)

        # Clean old peaks
        self._cleanup_old_peaks(current_time)

    def _cleanup_old_peaks(self, current_time: float):
        """Remove peaks that have fully decayed"""
        indices_to_remove = []

        for idx in list(self.peaks.keys()):
            age = current_time - self.peak_times[idx]

            if age > self.hold_time + self.decay_time:
                indices_to_remove.append(idx)

        for idx in indices_to_remove:
            del self.peaks[idx]
            del self.peak_times[idx]
            del self.peak_colors[idx]

    def _generate_peak_color(self, value: float) -> Tuple[int, int, int]:
        """Generate color based on peak value"""
        # Higher peaks get more intense colors
        if value > 0.9:
            return (255, 100, 100)  # Red for very high peaks
        elif value > 0.7:
            return (255, 200, 100)  # Orange for high peaks
        else:
            return (255, 255, 100)  # Yellow for normal peaks

    def draw_spectrum_peaks(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        width: int,
        height: int,
        num_bins: int,
    ):
        """Draw peak hold for spectrum display"""
        if not self.peaks:
            return

        current_time = time.time()
        bin_width = width / num_bins

        for idx, peak_value in self.peaks.items():
            if 0 <= idx < num_bins:
                age = current_time - self.peak_times[idx]

                # Calculate decay
                if age > self.hold_time:
                    decay_progress = min((age - self.hold_time) / self.decay_time, 1.0)
                else:
                    decay_progress = 0

                # Calculate position
                x_pos = x + idx * bin_width + bin_width / 2

                if self.decay_style == "fall":
                    # Peak falls down
                    y_offset = int(decay_progress * height * 0.3)
                    y_pos = y + height - int(peak_value * height) + y_offset
                else:
                    # Peak stays in place
                    y_pos = y + height - int(peak_value * height)

                # Calculate visual properties
                if self.decay_style == "fade":
                    alpha = int(255 * (1 - decay_progress))
                    width_mod = 1.0
                elif self.decay_style == "shrink":
                    alpha = 255
                    width_mod = 1 - decay_progress
                else:
                    alpha = int(255 * (1 - decay_progress))
                    width_mod = 1.0

                # Draw peak
                color = self.peak_colors.get(idx, self.peak_color)

                if alpha > 0:
                    # Glow effect
                    glow_size = int(3 + 2 * np.sin(self.glow_phase + idx * 0.1))
                    for i in range(glow_size):
                        glow_alpha = alpha // (i + 1)
                        glow_color = tuple(min(255, c + i * 20) for c in color)

                        pygame.draw.line(
                            surface,
                            (*glow_color, glow_alpha),
                            (x_pos - self.peak_width * width_mod / 2 - i, y_pos),
                            (x_pos + self.peak_width * width_mod / 2 + i, y_pos),
                            1,
                        )

                    # Main peak line
                    pygame.draw.line(
                        surface,
                        (*color, alpha),
                        (x_pos - self.peak_width * width_mod / 2, y_pos),
                        (x_pos + self.peak_width * width_mod / 2, y_pos),
                        max(1, int(self.peak_width * width_mod)),
                    )

    def draw_waveform_peaks(
        self, surface: pygame.Surface, points: List[Tuple[int, int]]
    ):
        """Draw peak hold for waveform display"""
        # For waveform, track envelope peaks
        pass

    def draw_meter_peaks(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        width: int,
        height: int,
        orientation: str = "horizontal",
    ):
        """Draw peak hold for meter display"""
        if not self.peaks:
            return

        current_time = time.time()

        for idx, peak_value in self.peaks.items():
            if idx == 0:  # Single meter
                age = current_time - self.peak_times[idx]

                # Calculate decay
                if age > self.hold_time:
                    decay_progress = min((age - self.hold_time) / self.decay_time, 1.0)
                    alpha = int(255 * (1 - decay_progress))
                else:
                    alpha = 255

                if alpha > 0:
                    color = (*self.peak_color, alpha)

                    if orientation == "horizontal":
                        x_pos = x + int(peak_value * width)
                        pygame.draw.line(
                            surface, color, (x_pos, y), (x_pos, y + height), 2
                        )
                    else:  # vertical
                        y_pos = y + height - int(peak_value * height)
                        pygame.draw.line(
                            surface, color, (x, y_pos), (x + width, y_pos), 2
                        )

    def reset(self):
        """Reset all peaks"""
        self.peaks.clear()
        self.peak_times.clear()
        self.peak_colors.clear()

    def set_hold_time(self, hold_time: float):
        """Set peak hold time"""
        self.hold_time = max(0.1, hold_time)

    def set_decay_time(self, decay_time: float):
        """Set peak decay time"""
        self.decay_time = max(0.1, decay_time)

    def set_decay_style(self, style: str):
        """Set decay animation style"""
        if style in ["fade", "fall", "shrink"]:
            self.decay_style = style


class MultiPeakHoldEffect:
    """Peak hold effect for multiple channels"""

    def __init__(self, num_channels: int = 2, **kwargs):
        self.num_channels = num_channels
        self.channel_effects = [PeakHoldEffect(**kwargs) for _ in range(num_channels)]

        # Channel colors
        self.channel_colors = [
            (255, 100, 100),  # Red
            (100, 255, 100),  # Green
            (100, 100, 255),  # Blue
            (255, 255, 100),  # Yellow
            (255, 100, 255),  # Magenta
            (100, 255, 255),  # Cyan
        ]

    def update(self, channel_values: List[List[float]]):
        """Update peaks for all channels"""
        for i, values in enumerate(channel_values):
            if i < self.num_channels:
                self.channel_effects[i].update(values)

    def draw(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        width: int,
        height: int,
        num_bins: int,
    ):
        """Draw all channel peaks"""
        for i, effect in enumerate(self.channel_effects):
            # Set channel-specific color
            effect.peak_color = self.channel_colors[i % len(self.channel_colors)]
            effect.draw_spectrum_peaks(surface, x, y, width, height, num_bins)

    def reset(self):
        """Reset all channel peaks"""
        for effect in self.channel_effects:
            effect.reset()

    def set_hold_time(self, hold_time: float):
        """Set hold time for all channels"""
        for effect in self.channel_effects:
            effect.set_hold_time(hold_time)

    def set_decay_time(self, decay_time: float):
        """Set decay time for all channels"""
        for effect in self.channel_effects:
            effect.set_decay_time(decay_time)
