"""
Grid, scale, and formant overlays for visualizations
"""

import math
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class GridOverlay:
    """Grid overlay for visualizations"""

    def __init__(self):
        self.show_grid = True
        self.grid_color = (50, 50, 60)
        self.grid_alpha = 100
        self.grid_style = "lines"  # "lines", "dots", "crosses"

        # Grid spacing
        self.x_divisions = 10
        self.y_divisions = 10
        self.adaptive_grid = True

        # Sub-grid
        self.show_subgrid = True
        self.subgrid_color = (30, 30, 40)
        self.subgrid_alpha = 50
        self.subgrid_divisions = 4

    def draw(self, surface: pygame.Surface, x: int, y: int, width: int, height: int):
        """Draw grid overlay"""
        if not self.show_grid:
            return

        # Create overlay surface
        overlay = pygame.Surface((width, height), pygame.SRCALPHA)

        # Calculate grid spacing
        x_spacing = width / self.x_divisions
        y_spacing = height / self.y_divisions

        # Draw sub-grid first
        if self.show_subgrid:
            sub_x_spacing = x_spacing / self.subgrid_divisions
            sub_y_spacing = y_spacing / self.subgrid_divisions

            self._draw_grid_lines(
                overlay,
                sub_x_spacing,
                sub_y_spacing,
                self.subgrid_color,
                self.subgrid_alpha,
                1,
            )

        # Draw main grid
        self._draw_grid_lines(
            overlay, x_spacing, y_spacing, self.grid_color, self.grid_alpha, 2
        )

        # Blit overlay
        surface.blit(overlay, (x, y))

    def _draw_grid_lines(
        self,
        surface: pygame.Surface,
        x_spacing: float,
        y_spacing: float,
        color: Tuple[int, int, int],
        alpha: int,
        thickness: int,
    ):
        """Draw grid lines"""
        width, height = surface.get_size()

        if self.grid_style == "lines":
            # Vertical lines
            x_pos = x_spacing
            while x_pos < width:
                pygame.draw.line(
                    surface,
                    (*color, alpha),
                    (int(x_pos), 0),
                    (int(x_pos), height),
                    thickness,
                )
                x_pos += x_spacing

            # Horizontal lines
            y_pos = y_spacing
            while y_pos < height:
                pygame.draw.line(
                    surface,
                    (*color, alpha),
                    (0, int(y_pos)),
                    (width, int(y_pos)),
                    thickness,
                )
                y_pos += y_spacing

        elif self.grid_style == "dots":
            # Draw dots at intersections
            x_pos = x_spacing
            while x_pos < width:
                y_pos = y_spacing
                while y_pos < height:
                    pygame.draw.circle(
                        surface, (*color, alpha), (int(x_pos), int(y_pos)), thickness
                    )
                    y_pos += y_spacing
                x_pos += x_spacing

        elif self.grid_style == "crosses":
            # Draw crosses at intersections
            cross_size = thickness * 3
            x_pos = x_spacing
            while x_pos < width:
                y_pos = y_spacing
                while y_pos < height:
                    # Horizontal line of cross
                    pygame.draw.line(
                        surface,
                        (*color, alpha),
                        (int(x_pos - cross_size), int(y_pos)),
                        (int(x_pos + cross_size), int(y_pos)),
                        thickness,
                    )
                    # Vertical line of cross
                    pygame.draw.line(
                        surface,
                        (*color, alpha),
                        (int(x_pos), int(y_pos - cross_size)),
                        (int(x_pos), int(y_pos + cross_size)),
                        thickness,
                    )
                    y_pos += y_spacing
                x_pos += x_spacing


class FrequencyScaleOverlay:
    """Frequency scale overlay for spectrum displays"""

    def __init__(self, min_freq: float = 20, max_freq: float = 20000):
        self.min_freq = min_freq
        self.max_freq = max_freq
        self.log_scale = True

        # Visual settings
        self.scale_color = (180, 180, 200)
        self.text_color = (200, 200, 220)
        self.font_size = 14
        self.font = pygame.font.Font(None, self.font_size)

        # Scale markers
        self.major_markers = [20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000]
        self.minor_markers = [30, 70, 150, 300, 700, 1500, 3000, 7000, 15000]

        # Note frequencies
        self.show_notes = False
        self.note_frequencies = self._generate_note_frequencies()

    def _generate_note_frequencies(self) -> Dict[float, str]:
        """Generate musical note frequencies"""
        notes = {}
        note_names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

        # A4 = 440 Hz
        for octave in range(0, 9):
            for i, note in enumerate(note_names):
                freq = 440.0 * (2.0 ** ((octave - 4) + (i - 9) / 12.0))
                if self.min_freq <= freq <= self.max_freq:
                    notes[freq] = f"{note}{octave}"

        return notes

    def draw(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        width: int,
        height: int,
        orientation: str = "horizontal",
    ):
        """Draw frequency scale overlay"""
        if orientation == "horizontal":
            self._draw_horizontal_scale(surface, x, y, width, height)
        else:
            self._draw_vertical_scale(surface, x, y, width, height)

    def _draw_horizontal_scale(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        """Draw horizontal frequency scale"""
        # Draw major markers
        for freq in self.major_markers:
            if self.min_freq <= freq <= self.max_freq:
                x_pos = self._freq_to_x(freq, x, width)

                # Tick mark
                pygame.draw.line(
                    surface, self.scale_color, (x_pos, y), (x_pos, y + 10), 2
                )

                # Label
                label = self._format_frequency(freq)
                text = self.font.render(label, True, self.text_color)
                text_rect = text.get_rect(centerx=x_pos, top=y + 12)
                surface.blit(text, text_rect)

        # Draw minor markers
        for freq in self.minor_markers:
            if self.min_freq <= freq <= self.max_freq:
                x_pos = self._freq_to_x(freq, x, width)
                pygame.draw.line(
                    surface, self.scale_color, (x_pos, y), (x_pos, y + 5), 1
                )

        # Draw note markers if enabled
        if self.show_notes:
            for freq, note in self.note_frequencies.items():
                x_pos = self._freq_to_x(freq, x, width)

                # Note indicator
                pygame.draw.line(
                    surface, (255, 200, 100), (x_pos, y - 5), (x_pos, y), 1
                )

                # Note label (only for C notes)
                if "C" in note and "#" not in note:
                    text = self.font.render(note, True, (255, 200, 100))
                    text_rect = text.get_rect(centerx=x_pos, bottom=y - 7)
                    surface.blit(text, text_rect)

    def _draw_vertical_scale(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        """Draw vertical frequency scale"""
        # Draw major markers
        for freq in self.major_markers:
            if self.min_freq <= freq <= self.max_freq:
                y_pos = self._freq_to_y(freq, y, height)

                # Tick mark
                pygame.draw.line(
                    surface,
                    self.scale_color,
                    (x + width - 10, y_pos),
                    (x + width, y_pos),
                    2,
                )

                # Label
                label = self._format_frequency(freq)
                text = self.font.render(label, True, self.text_color)
                text_rect = text.get_rect(right=x + width - 12, centery=y_pos)
                surface.blit(text, text_rect)

    def _freq_to_x(self, freq: float, x: int, width: int) -> int:
        """Convert frequency to x position"""
        if self.log_scale:
            log_freq = np.log10(freq / self.min_freq)
            log_range = np.log10(self.max_freq / self.min_freq)
            normalized = log_freq / log_range
        else:
            normalized = (freq - self.min_freq) / (self.max_freq - self.min_freq)

        return x + int(normalized * width)

    def _freq_to_y(self, freq: float, y: int, height: int) -> int:
        """Convert frequency to y position"""
        if self.log_scale:
            log_freq = np.log10(freq / self.min_freq)
            log_range = np.log10(self.max_freq / self.min_freq)
            normalized = log_freq / log_range
        else:
            normalized = (freq - self.min_freq) / (self.max_freq - self.min_freq)

        return y + height - int(normalized * height)

    def _format_frequency(self, freq: float) -> str:
        """Format frequency for display"""
        if freq >= 1000:
            return f"{freq/1000:.0f}k"
        else:
            return f"{freq:.0f}"


class FormantOverlay:
    """Formant frequency overlay for voice analysis"""

    def __init__(self):
        self.show_formants = True
        self.formant_colors = {
            "F1": (255, 100, 100),
            "F2": (100, 255, 100),
            "F3": (100, 100, 255),
            "F4": (255, 255, 100),
            "F5": (255, 100, 255),
        }

        # Vowel formant references
        self.vowel_formants = {
            "i": {"F1": 270, "F2": 2300},  # "ee"
            "e": {"F1": 390, "F2": 2000},  # "ay"
            "a": {"F1": 700, "F2": 1220},  # "ah"
            "o": {"F1": 460, "F2": 870},  # "oh"
            "u": {"F1": 300, "F2": 750},  # "oo"
        }

        # Visual settings
        self.line_width = 2
        self.label_font = pygame.font.Font(None, 16)
        self.show_vowel_regions = True

    def draw(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        width: int,
        height: int,
        formants: Dict[str, float],
        frequency_range: Tuple[float, float],
    ):
        """Draw formant overlay"""
        if not self.show_formants or not formants:
            return

        min_freq, max_freq = frequency_range

        # Draw formant lines
        for formant_name, freq in formants.items():
            if formant_name in self.formant_colors and min_freq <= freq <= max_freq:
                color = self.formant_colors[formant_name]

                # Calculate position
                x_pos = x + int((freq - min_freq) / (max_freq - min_freq) * width)

                # Draw formant line
                pygame.draw.line(
                    surface, color, (x_pos, y), (x_pos, y + height), self.line_width
                )

                # Draw label
                label = self.label_font.render(formant_name, True, color)
                label_rect = label.get_rect(centerx=x_pos, bottom=y - 2)
                surface.blit(label, label_rect)

                # Draw frequency value
                freq_text = f"{freq:.0f}Hz"
                freq_label = self.label_font.render(freq_text, True, color)
                freq_rect = freq_label.get_rect(centerx=x_pos, top=y + height + 2)
                surface.blit(freq_label, freq_rect)

        # Draw vowel regions
        if self.show_vowel_regions:
            self._draw_vowel_regions(surface, x, y, width, height, frequency_range)

    def _draw_vowel_regions(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        width: int,
        height: int,
        frequency_range: Tuple[float, float],
    ):
        """Draw vowel formant regions"""
        min_freq, max_freq = frequency_range

        # Create semi-transparent overlay
        overlay = pygame.Surface((width, height), pygame.SRCALPHA)

        for vowel, formants in self.vowel_formants.items():
            f1 = formants["F1"]
            f2 = formants["F2"]

            # Only draw if both formants are in range
            if min_freq <= f1 <= max_freq and min_freq <= f2 <= max_freq:
                # Calculate positions
                x1 = int((f1 - min_freq) / (max_freq - min_freq) * width)
                x2 = int((f2 - min_freq) / (max_freq - min_freq) * width)

                # Draw region between F1 and F2
                region_width = abs(x2 - x1)
                region_x = min(x1, x2)

                # Semi-transparent fill
                pygame.draw.rect(
                    overlay, (200, 200, 100, 30), (region_x, 0, region_width, height)
                )

                # Vowel label
                label = self.label_font.render(vowel, True, (255, 255, 200))
                label_rect = label.get_rect(
                    centerx=region_x + region_width // 2, centery=height // 2
                )
                overlay.blit(label, label_rect)

        surface.blit(overlay, (x, y))


class AmplitudeScaleOverlay:
    """Amplitude/dB scale overlay"""

    def __init__(self, min_db: float = -60, max_db: float = 0):
        self.min_db = min_db
        self.max_db = max_db

        # Visual settings
        self.scale_color = (150, 150, 170)
        self.text_color = (180, 180, 200)
        self.font = pygame.font.Font(None, 14)

        # Scale divisions
        self.major_divisions = 6
        self.minor_divisions = 2

    def draw(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        width: int,
        height: int,
        orientation: str = "vertical",
    ):
        """Draw amplitude scale"""
        if orientation == "vertical":
            self._draw_vertical_scale(surface, x, y, width, height)
        else:
            self._draw_horizontal_scale(surface, x, y, width, height)

    def _draw_vertical_scale(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        """Draw vertical dB scale"""
        # Major divisions
        db_range = self.max_db - self.min_db
        major_step = db_range / self.major_divisions

        for i in range(self.major_divisions + 1):
            db_value = self.max_db - i * major_step
            y_pos = y + int(i * height / self.major_divisions)

            # Tick mark
            pygame.draw.line(surface, self.scale_color, (x, y_pos), (x + 10, y_pos), 2)

            # Label
            label = f"{db_value:.0f}dB"
            text = self.font.render(label, True, self.text_color)
            text_rect = text.get_rect(left=x + 12, centery=y_pos)
            surface.blit(text, text_rect)

            # Minor divisions
            if i < self.major_divisions:
                minor_step = height / self.major_divisions / (self.minor_divisions + 1)
                for j in range(1, self.minor_divisions + 1):
                    minor_y = y_pos + int(j * minor_step)
                    pygame.draw.line(
                        surface, self.scale_color, (x, minor_y), (x + 5, minor_y), 1
                    )

    def _draw_horizontal_scale(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        """Draw horizontal dB scale"""
        # Similar to vertical but rotated
        db_range = self.max_db - self.min_db
        major_step = db_range / self.major_divisions

        for i in range(self.major_divisions + 1):
            db_value = self.min_db + i * major_step
            x_pos = x + int(i * width / self.major_divisions)

            # Tick mark
            pygame.draw.line(
                surface,
                self.scale_color,
                (x_pos, y + height - 10),
                (x_pos, y + height),
                2,
            )

            # Label
            label = f"{db_value:.0f}"
            text = self.font.render(label, True, self.text_color)
            text_rect = text.get_rect(centerx=x_pos, top=y + height - 25)
            surface.blit(text, text_rect)
