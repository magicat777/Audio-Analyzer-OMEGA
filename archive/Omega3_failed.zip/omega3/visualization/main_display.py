"""
Main spectrum renderer for OMEGA-3
"""

from typing import Any
from typing import Dict
from typing import Optional
from typing import Tuple

import numpy as np
import pygame

from .panels import DrumPanel
from .panels import HarmonicPanel
from .panels import VoicePanel


class SpectrumRenderer:
    """Handles all visualization rendering"""

    def __init__(self, screen: pygame.Surface, bars: int):
        self.screen = screen
        self.bars = bars
        self.width = screen.get_width()
        self.height = screen.get_height()

        # Fonts
        self.font_small = pygame.font.Font(None, 24)
        self.font_medium = pygame.font.Font(None, 32)
        self.font_large = pygame.font.Font(None, 48)

        # Colors
        self.bg_color = (20, 20, 30)
        self.grid_color = (40, 40, 50)
        self.text_color = (200, 200, 220)
        self.peak_color = (255, 100, 100)

        # Spectrum colors (gradient)
        self._generate_spectrum_colors()

        # Analysis panels
        self._setup_panels()

    def _generate_spectrum_colors(self):
        """Generate color gradient for spectrum bars"""
        self.spectrum_colors = []

        for i in range(self.bars):
            # Create gradient from purple to blue to cyan to green to yellow to red
            t = i / self.bars

            if t < 0.2:  # Purple to blue
                r = int(128 * (1 - t * 5))
                g = 0
                b = 255
            elif t < 0.4:  # Blue to cyan
                r = 0
                g = int(255 * ((t - 0.2) * 5))
                b = 255
            elif t < 0.6:  # Cyan to green
                r = 0
                g = 255
                b = int(255 * (1 - (t - 0.4) * 5))
            elif t < 0.8:  # Green to yellow
                r = int(255 * ((t - 0.6) * 5))
                g = 255
                b = 0
            else:  # Yellow to red
                r = 255
                g = int(255 * (1 - (t - 0.8) * 5))
                b = 0

            self.spectrum_colors.append((r, g, b))

    def draw_spectrum(self, spectrum_data: np.ndarray, peak_data: np.ndarray):
        """Draw the main spectrum display"""
        
        # Calculate dimensions (leave room for panels on the right and bass detail below)
        margin = 50
        panel_space = 350  # Space for panels
        bass_detail_height = 150  # Space for bass detail panel
        header_height = 120  # Space for header
        
        spectrum_width = self.width - margin - panel_space
        spectrum_height = self.height - header_height - bass_detail_height - 40  # 40px bottom margin
        spectrum_y = header_height
        
        # Ensure spectrum stays within bounds
        spectrum_width = max(spectrum_width, 400)  # Minimum width
        spectrum_height = max(spectrum_height, 200)  # Minimum height

        # Use actual data length for bar count
        num_bars = len(spectrum_data)
        bar_width = spectrum_width / num_bars

        # Draw background grid
        self._draw_grid(margin, spectrum_y, spectrum_width, spectrum_height)

        # Draw spectrum bars
        for i in range(num_bars):
            x = margin + i * bar_width

            # Bar height (normalized to display height)
            bar_height = int(spectrum_data[i] * spectrum_height)
            bar_height = min(bar_height, spectrum_height)

            # Draw bar
            if bar_height > 0:
                # Get color (cycle if needed)
                color_idx = i % len(self.spectrum_colors)
                bar_rect = pygame.Rect(
                    int(x),
                    spectrum_y + spectrum_height - bar_height,
                    max(1, int(bar_width - 1)),
                    bar_height,
                )
                pygame.draw.rect(self.screen, self.spectrum_colors[color_idx], bar_rect)

            # Draw peak indicator
            if i < len(peak_data):
                peak_height = int(peak_data[i] * spectrum_height)
                if peak_height > 0:
                    peak_y = spectrum_y + spectrum_height - peak_height
                    pygame.draw.line(
                        self.screen,
                        self.peak_color,
                        (int(x), peak_y),
                        (int(x + bar_width - 1), peak_y),
                        2,
                    )

    def _draw_grid(self, x: int, y: int, width: int, height: int):
        """Draw background grid"""
        # Horizontal lines (dB levels)
        db_levels = [0, -10, -20, -30, -40, -50, -60]

        for db in db_levels:
            normalized = (db + 60) / 60  # Normalize to 0-1
            grid_y = y + height * (1 - normalized)

            pygame.draw.line(
                self.screen,
                self.grid_color,
                (x, int(grid_y)),
                (x + width, int(grid_y)),
                1,
            )

            # Label
            label = self.font_small.render(f"{db}dB", True, self.text_color)
            self.screen.blit(label, (x - 40, int(grid_y) - 10))

        # Vertical lines (frequency markers) - logarithmic scale 0Hz to 20kHz
        freq_markers = [20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000]

        for freq in freq_markers:
            # Logarithmic frequency mapping
            if freq > 20:  # Avoid log(0)
                freq_normalized = np.log10(freq / 20) / np.log10(20000 / 20)
                grid_x = x + width * freq_normalized

                pygame.draw.line(
                    self.screen,
                    self.grid_color,
                    (int(grid_x), y),
                    (int(grid_x), y + height),
                    1,
                )

                # Label formatting
                if freq < 1000:
                    label_text = f"{freq}Hz"
                else:
                    label_text = f"{freq//1000}kHz"
                    
                label = self.font_small.render(label_text, True, self.text_color)
                label_rect = label.get_rect(center=(int(grid_x), y + height + 15))
                self.screen.blit(label, label_rect)

    def draw_header_info(self, info: Dict[str, Any]):
        """Draw header information"""
        y_offset = 10

        # Title
        title = self.font_large.render(
            "OMEGA-3 Professional Audio Analyzer", True, self.text_color
        )
        title_rect = title.get_rect(centerx=self.width // 2, y=y_offset)
        self.screen.blit(title, title_rect)

        # Performance info
        y_offset = 60
        perf_text = f"FPS: {info.get('fps', 0):.1f} | Latency: {info.get('latency', 0):.1f}ms | Mode: {info.get('quality_mode', 'N/A')}"
        perf_surface = self.font_medium.render(perf_text, True, self.text_color)
        self.screen.blit(perf_surface, (10, y_offset))

        # Gain info
        gain_text = f"Gain: {info.get('input_gain', 0):.1f}dB"
        gain_surface = self.font_medium.render(gain_text, True, self.text_color)
        self.screen.blit(gain_surface, (self.width - 200, y_offset))

    def draw_help(self):
        """Draw comprehensive help overlay"""
        # Semi-transparent background
        overlay = pygame.Surface((self.width, self.height))
        overlay.set_alpha(220)
        overlay.fill((0, 0, 0))
        self.screen.blit(overlay, (0, 0))

        # Create help content in columns
        help_sections = {
            "System Controls": [
                "ESC - Exit application",
                "H, ?, / - Toggle help display",
                "S - Save screenshot",
                "D - Print debug info",
                "Y - Toggle quality mode",
            ],
            "Audio Controls": [
                "+/= - Increase input gain",
                "- - Decrease input gain", 
                "0 - Reset gain to default",
                "G - Toggle auto-gain control",
                "[ - Decrease bass gain",
                "] - Increase bass gain",
            ],
            "Display Toggles": [
                "M - Professional meters",
                "J - VU meters",
                "Z - Bass zoom window",
                "R - Harmonic analysis",
                "V - Voice analysis",
                "T - Technical overlay",
            ],
            "OMEGA Features": [
                "P - Pitch detection",
                "K - Chromagram/Key detection",
                "N - Genre classification",
            ],
            "Window Presets": [
                "1 - Professional Compact (1400x900)",
                "2 - Professional Standard (1800x1000)",
                "3 - Professional Wide (2200x1200)",
                "4 - Professional Ultra-Wide (2600x1400)",
                "7 - Full HD (1920x1080)",
                "8 - 2K Monitor (2560x1440)",
                "9 - 4K Monitor (3840x2160)",
            ],
        }

        # Title
        title = self.font_large.render(
            "OMEGA-3 Professional Audio Analyzer - Keyboard Controls",
            True,
            (100, 200, 255),
        )
        title_rect = title.get_rect(centerx=self.width // 2, y=30)
        self.screen.blit(title, title_rect)

        # Draw sections in columns
        section_width = self.width // 3
        x_positions = [50, self.width // 3 + 50, 2 * self.width // 3 + 50]
        y_start = 80

        sections = list(help_sections.items())
        for col in range(3):
            x_pos = x_positions[col]
            y_offset = y_start

            # Draw sections for this column
            start_idx = col * 2
            end_idx = min(start_idx + 2, len(sections))

            for section_name, commands in sections[start_idx:end_idx]:
                # Section header
                header = self.font_medium.render(section_name, True, (255, 200, 100))
                self.screen.blit(header, (x_pos, y_offset))
                y_offset += 35

                # Commands
                for command in commands:
                    text = self.font_small.render(command, True, (220, 220, 220))
                    self.screen.blit(text, (x_pos + 10, y_offset))
                    y_offset += 25

                y_offset += 15  # Extra space between sections

        # Footer
        footer_lines = [
            "Press H again to close this help",
            "Professional features are optimized for studio use",
            "All changes are applied in real-time",
        ]

        footer_y = self.height - 80
        for line in footer_lines:
            footer_text = self.font_small.render(line, True, (150, 150, 170))
            footer_rect = footer_text.get_rect(centerx=self.width // 2, y=footer_y)
            self.screen.blit(footer_text, footer_rect)
            footer_y += 25

    def _setup_panels(self):
        """Setup analysis panels"""
        # Panel dimensions
        panel_width = 300
        panel_height = 200
        right_margin = 20
        panel_spacing = 10

        # Position panels on the right side
        x = self.width - panel_width - right_margin
        y = 150

        # Create panels
        self.harmonic_panel = HarmonicPanel(
            self.screen, x, y, panel_width, panel_height
        )
        y += panel_height + panel_spacing

        self.drum_panel = DrumPanel(self.screen, x, y, panel_width, panel_height)
        y += panel_height + panel_spacing

        self.voice_panel = VoicePanel(self.screen, x, y, panel_width, panel_height)

    def draw_analysis_panels(self, analyzer_results: Dict[str, Any]):
        """Draw all analysis panels"""
        # Draw harmonic analysis
        if "HarmonicAnalyzer" in analyzer_results:
            harmonic_data = analyzer_results["HarmonicAnalyzer"].data
            self.harmonic_panel.draw(harmonic_data)

        # Draw drum detection
        if "DrumDetector" in analyzer_results:
            drum_data = analyzer_results["DrumDetector"].data
            self.drum_panel.draw(drum_data)

        # Draw voice analysis
        if "VoiceAnalyzer" in analyzer_results:
            voice_data = analyzer_results["VoiceAnalyzer"].data
            self.voice_panel.draw(voice_data)

    def draw_bass_detail(self, bass_spectrum: np.ndarray):
        """Draw bass detail spectrum (20-200Hz enhanced view)"""
        # Position bass detail panel at the bottom
        margin = 50
        panel_height = 120
        panel_y = self.height - panel_height - 30
        panel_width = self.width - margin - 350  # Match main spectrum width

        # Background
        panel_rect = pygame.Rect(margin, panel_y, panel_width, panel_height)
        pygame.draw.rect(self.screen, (15, 15, 25), panel_rect)
        pygame.draw.rect(self.screen, self.grid_color, panel_rect, 2)

        # Title
        title = self.font_small.render("Bass Detail (20-200Hz)", True, self.text_color)
        self.screen.blit(title, (margin + 10, panel_y - 25))

        # Draw bass spectrum bars
        num_bars = len(bass_spectrum)
        if num_bars > 0:
            bar_width = panel_width / num_bars

            for i in range(num_bars):
                x = margin + i * bar_width
                bar_height = int(bass_spectrum[i] * (panel_height - 10))
                bar_height = min(bar_height, panel_height - 10)

                if bar_height > 0:
                    # Color gradient for bass (deep purple to orange)
                    t = i / num_bars
                    r = int(100 + 155 * t)
                    g = int(50 + 100 * t)
                    b = int(200 * (1 - t))

                    bar_rect = pygame.Rect(
                        int(x),
                        panel_y + panel_height - bar_height - 5,
                        max(1, int(bar_width - 1)),
                        bar_height,
                    )
                    pygame.draw.rect(self.screen, (r, g, b), bar_rect)

        # Frequency labels
        freq_labels = [(20, "20Hz"), (50, "50Hz"), (100, "100Hz"), (200, "200Hz")]
        for freq, label in freq_labels:
            x_pos = margin + (np.log10(freq / 20) / np.log10(200 / 20)) * panel_width
            label_surface = self.font_small.render(label, True, self.text_color)
            self.screen.blit(
                label_surface, (int(x_pos) - 20, panel_y + panel_height + 5)
            )

    def update_dimensions(self, width: int, height: int):
        """Update renderer dimensions"""
        self.width = width
        self.height = height
        # Recreate panels with new dimensions
        self._setup_panels()
        # Regenerate colors for new bar count if needed
        if hasattr(self, "bars"):
            self._generate_spectrum_colors()
