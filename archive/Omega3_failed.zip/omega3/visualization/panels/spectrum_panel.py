"""
Spectrum visualization panel for OMEGA-3.
Main frequency spectrum display with various visualization modes.
"""

from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame

# Import fallbacks if relative imports fail
try:
    from ...utils.constants import COLORS
    from ...utils.constants import GRADIENTS
    from ...utils.math_utils import linear_to_db
    from ...utils.math_utils import normalize
except ImportError:
    # Fallback definitions
    COLORS = {
        "ACCENT": (100, 150, 255),
        "PANEL_BG": (20, 20, 25),
        "GRID": (40, 40, 50),
        "GRID_MAJOR": (60, 60, 80),
        "TEXT_DIM": (120, 120, 140),
        "WHITE": (255, 255, 255),
    }
    GRADIENTS = {
        "SPECTRUM": [
            (100, 0, 255),
            (0, 100, 255),
            (0, 255, 100),
            (255, 255, 0),
            (255, 0, 0),
        ]
    }

    def linear_to_db(x):
        return 20 * np.log10(x + 1e-10)

    def normalize(x, a=0, b=1):
        return a + (b - a) * (x - np.min(x)) / (np.max(x) - np.min(x) + 1e-10)


class SpectrumPanel:
    """Main spectrum visualization panel."""

    def __init__(self, x: int, y: int, width: int, height: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

        # Visualization settings
        self.visualization_mode = "bars"  # bars, lines, dots, filled
        self.color_mode = "gradient"  # solid, gradient, spectrum
        self.scale_mode = "linear"  # linear, logarithmic, perceptual

        # Visual parameters
        self.bar_width_ratio = 0.8
        self.bar_spacing_ratio = 0.2
        self.line_thickness = 2
        self.dot_size = 4

        # Colors
        self.primary_color = COLORS["ACCENT"]
        self.gradient = GRADIENTS["SPECTRUM"]

        # Animation
        self.peak_hold = True
        self.peak_decay_rate = 0.01
        self.peaks = None
        self.peak_hold_time = None

        # Grid
        self.show_grid = True
        self.grid_divisions_x = 10
        self.grid_divisions_y = 10

        # Surface for rendering
        self.screen = pygame.Surface((width, height))
        self.screen.set_alpha(255)

    def update(
        self,
        spectrum_data: np.ndarray,
        frequency_ranges: Optional[List[Tuple[float, float]]] = None,
    ):
        """Update spectrum visualization with new data."""
        if spectrum_data is None or len(spectrum_data) == 0:
            return

        # Initialize peaks if needed
        if self.peaks is None or len(self.peaks) != len(spectrum_data):
            self.peaks = np.zeros_like(spectrum_data)
            self.peak_hold_time = np.zeros_like(spectrum_data)

        # Update peaks
        if self.peak_hold:
            self._update_peaks(spectrum_data)

        # Clear surface
        self.screen.fill(COLORS["PANEL_BG"])

        # Draw grid
        if self.show_grid:
            self._draw_grid()

        # Draw spectrum based on mode
        if self.visualization_mode == "bars":
            self._draw_bars(spectrum_data)
        elif self.visualization_mode == "lines":
            self._draw_lines(spectrum_data)
        elif self.visualization_mode == "dots":
            self._draw_dots(spectrum_data)
        elif self.visualization_mode == "filled":
            self._draw_filled(spectrum_data)

        # Draw frequency labels if available
        if frequency_ranges:
            self._draw_frequency_labels(frequency_ranges)

    def _update_peaks(self, spectrum_data: np.ndarray):
        """Update peak hold values."""
        # Update peaks where current value exceeds
        exceeds = spectrum_data > self.peaks
        self.peaks[exceeds] = spectrum_data[exceeds]
        self.peak_hold_time[exceeds] = 0

        # Decay peaks
        self.peak_hold_time += 1
        decay_mask = self.peak_hold_time > 60  # Hold for 1 second at 60 FPS
        self.peaks[decay_mask] *= 1 - self.peak_decay_rate

    def _draw_grid(self):
        """Draw background grid."""
        # Vertical lines
        for i in range(self.grid_divisions_x + 1):
            x = int(i * self.width / self.grid_divisions_x)
            color = COLORS["GRID_MAJOR"] if i % 5 == 0 else COLORS["GRID"]
            pygame.draw.line(self.screen, color, (x, 0), (x, self.height), 1)

        # Horizontal lines
        for i in range(self.grid_divisions_y + 1):
            y = int(i * self.height / self.grid_divisions_y)
            color = COLORS["GRID_MAJOR"] if i % 5 == 0 else COLORS["GRID"]
            pygame.draw.line(self.screen, color, (0, y), (self.width, y), 1)

    def _draw_bars(self, spectrum_data: np.ndarray):
        """Draw spectrum as bars."""
        num_bars = len(spectrum_data)
        if num_bars == 0:
            return

        bar_width = self.width / num_bars
        actual_bar_width = bar_width * self.bar_width_ratio
        bar_spacing = bar_width * self.bar_spacing_ratio / 2

        for i, value in enumerate(spectrum_data):
            # Calculate bar position and height
            x = i * bar_width + bar_spacing
            height = int(value * self.height)
            y = self.height - height

            # Get color
            color = self._get_color_for_bar(i, num_bars, value)

            # Draw bar
            pygame.draw.rect(
                self.screen, color, (int(x), y, int(actual_bar_width), height)
            )

            # Draw peak if enabled
            if self.peak_hold and self.peaks is not None:
                peak_height = int(self.peaks[i] * self.height)
                peak_y = self.height - peak_height
                pygame.draw.line(
                    self.screen,
                    COLORS["WHITE"],
                    (int(x), peak_y),
                    (int(x + actual_bar_width), peak_y),
                    2,
                )

    def _draw_lines(self, spectrum_data: np.ndarray):
        """Draw spectrum as connected lines."""
        if len(spectrum_data) < 2:
            return

        points = []
        for i, value in enumerate(spectrum_data):
            x = int(i * self.width / (len(spectrum_data) - 1))
            y = int(self.height - value * self.height)
            points.append((x, y))

        # Draw main line
        pygame.draw.lines(
            self.screen, self.primary_color, False, points, self.line_thickness
        )

        # Draw peak line if enabled
        if self.peak_hold and self.peaks is not None:
            peak_points = []
            for i, peak in enumerate(self.peaks):
                x = int(i * self.width / (len(self.peaks) - 1))
                y = int(self.height - peak * self.height)
                peak_points.append((x, y))
            pygame.draw.lines(self.screen, COLORS["WHITE"], False, peak_points, 1)

    def _draw_dots(self, spectrum_data: np.ndarray):
        """Draw spectrum as dots."""
        for i, value in enumerate(spectrum_data):
            x = int(i * self.width / (len(spectrum_data) - 1))
            y = int(self.height - value * self.height)

            color = self._get_color_for_bar(i, len(spectrum_data), value)
            pygame.draw.circle(self.screen, color, (x, y), self.dot_size)

    def _draw_filled(self, spectrum_data: np.ndarray):
        """Draw spectrum as filled area."""
        if len(spectrum_data) < 2:
            return

        # Create polygon points
        points = [(0, self.height)]  # Start at bottom left

        for i, value in enumerate(spectrum_data):
            x = int(i * self.width / (len(spectrum_data) - 1))
            y = int(self.height - value * self.height)
            points.append((x, y))

        points.append((self.width, self.height))  # End at bottom right

        # Draw filled polygon with gradient effect
        if self.color_mode == "gradient":
            # Draw multiple polygons for gradient effect
            prev_y = self.height
            for i in range(1, len(spectrum_data)):
                x1 = int((i - 1) * self.width / (len(spectrum_data) - 1))
                x2 = int(i * self.width / (len(spectrum_data) - 1))
                y1 = int(self.height - spectrum_data[i - 1] * self.height)
                y2 = int(self.height - spectrum_data[i] * self.height)

                color = self._get_color_for_bar(i, len(spectrum_data), spectrum_data[i])
                pygame.draw.polygon(
                    self.screen,
                    color,
                    [(x1, self.height), (x1, y1), (x2, y2), (x2, self.height)],
                )
        else:
            pygame.draw.polygon(self.screen, self.primary_color, points)

    def _get_color_for_bar(
        self, index: int, total: int, value: float
    ) -> Tuple[int, int, int]:
        """Get color for a bar based on mode and position."""
        if self.color_mode == "solid":
            return self.primary_color
        elif self.color_mode == "gradient":
            # Interpolate through gradient
            position = index / max(1, total - 1)
            gradient_index = int(position * (len(self.gradient) - 1))

            if gradient_index < len(self.gradient) - 1:
                # Interpolate between colors
                t = (position * (len(self.gradient) - 1)) - gradient_index
                c1 = self.gradient[gradient_index]
                c2 = self.gradient[gradient_index + 1]

                r = int(c1[0] + t * (c2[0] - c1[0]))
                g = int(c1[1] + t * (c2[1] - c1[1]))
                b = int(c1[2] + t * (c2[2] - c1[2]))

                # Apply intensity based on value
                r = int(r * (0.3 + 0.7 * value))
                g = int(g * (0.3 + 0.7 * value))
                b = int(b * (0.3 + 0.7 * value))

                return (r, g, b)
            else:
                return self.gradient[-1]
        elif self.color_mode == "spectrum":
            # Rainbow spectrum based on frequency
            hue = index / max(1, total) * 360
            return self._hsv_to_rgb(hue, 1.0, value)
        else:
            return self.primary_color

    def _hsv_to_rgb(self, h: float, s: float, v: float) -> Tuple[int, int, int]:
        """Convert HSV to RGB color."""
        h = h / 60
        c = v * s
        x = c * (1 - abs((h % 2) - 1))
        m = v - c

        if 0 <= h < 1:
            r, g, b = c, x, 0
        elif 1 <= h < 2:
            r, g, b = x, c, 0
        elif 2 <= h < 3:
            r, g, b = 0, c, x
        elif 3 <= h < 4:
            r, g, b = 0, x, c
        elif 4 <= h < 5:
            r, g, b = x, 0, c
        else:
            r, g, b = c, 0, x

        return (int((r + m) * 255), int((g + m) * 255), int((b + m) * 255))

    def _draw_frequency_labels(self, frequency_ranges: List[Tuple[float, float]]):
        """Draw frequency labels on the x-axis."""
        font = pygame.font.Font(None, 12)

        for i, (start, end) in enumerate(frequency_ranges):
            if i % max(1, len(frequency_ranges) // 10) == 0:  # Show every nth label
                x = int(i * self.width / len(frequency_ranges))

                # Format frequency
                center_freq = (start + end) / 2
                if center_freq < 1000:
                    label = f"{int(center_freq)}Hz"
                else:
                    label = f"{center_freq/1000:.1f}kHz"

                text = font.render(label, True, COLORS["TEXT_DIM"])
                text_rect = text.get_rect()
                text_rect.centerx = x
                text_rect.bottom = self.height - 2

                self.screen.blit(text, text_rect)

    def render(self, screen: pygame.Surface):
        """Render panel to screen."""
        screen.blit(self.screen, (self.x, self.y))

    def set_visualization_mode(self, mode: str):
        """Set visualization mode."""
        if mode in ["bars", "lines", "dots", "filled"]:
            self.visualization_mode = mode

    def set_color_mode(self, mode: str):
        """Set color mode."""
        if mode in ["solid", "gradient", "spectrum"]:
            self.color_mode = mode

    def set_gradient(self, gradient_name: str):
        """Set gradient preset."""
        if gradient_name in GRADIENTS:
            self.gradient = GRADIENTS[gradient_name]
