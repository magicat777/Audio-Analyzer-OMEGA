"""
Spectrogram visualization panel for OMEGA-3.
Displays time-frequency representation of audio.
"""

from collections import deque
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame

# Import fallbacks if relative imports fail
try:
    from ...utils.constants import COLORS
    from ...utils.constants import GRADIENTS
    from ...utils.math_utils import linear_to_db
except ImportError:
    # Fallback definitions
    COLORS = {"PANEL_BG": (20, 20, 25), "GRID": (40, 40, 50), "WHITE": (255, 255, 255)}
    GRADIENTS = {"PLASMA": [(100, 0, 255), (255, 0, 100), (255, 100, 0), (255, 255, 0)]}

    def linear_to_db(x):
        return 20 * np.log10(x + 1e-10)


class SpectrogramPanel:
    """Spectrogram visualization panel with waterfall display."""

    def __init__(self, x: int, y: int, width: int, height: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

        # Display settings
        self.display_mode = "waterfall"  # waterfall, static, 3d
        self.color_map = "plasma"  # plasma, fire, ice, spectrum
        self.db_range = 80  # Dynamic range in dB
        self.db_floor = -80  # Noise floor in dB

        # Time settings
        self.time_window = 5.0  # Seconds to display
        self.scroll_speed = 1  # Pixels per update

        # Frequency settings
        self.freq_min = 20  # Hz
        self.freq_max = 20000  # Hz
        self.freq_scale = "log"  # log, linear, mel

        # History buffer
        self.history_size = self.width
        self.spectrogram_history = deque(maxlen=self.history_size)

        # Color map
        self.colormap = self._create_colormap()

        # Surface for rendering
        self.screen = pygame.Surface((width, height))
        self.spectrogram_surface = pygame.Surface((width, height))

        # Frequency axis
        self.freq_labels = []
        self._update_frequency_axis()

    def _create_colormap(self) -> np.ndarray:
        """Create color map for spectrogram."""
        num_colors = 256
        colormap = np.zeros((num_colors, 3), dtype=np.uint8)

        if self.color_map in GRADIENTS:
            gradient = GRADIENTS[self.color_map]
        else:
            gradient = GRADIENTS["PLASMA"]

        # Interpolate gradient to create colormap
        for i in range(num_colors):
            position = i / (num_colors - 1)
            gradient_pos = position * (len(gradient) - 1)
            idx = int(gradient_pos)

            if idx < len(gradient) - 1:
                t = gradient_pos - idx
                c1 = gradient[idx]
                c2 = gradient[idx + 1]

                r = int(c1[0] + t * (c2[0] - c1[0]))
                g = int(c1[1] + t * (c2[1] - c1[1]))
                b = int(c1[2] + t * (c2[2] - c1[2]))

                colormap[i] = [r, g, b]
            else:
                colormap[i] = gradient[-1]

        return colormap

    def _update_frequency_axis(self):
        """Update frequency axis labels and mapping."""
        self.freq_labels = []

        if self.freq_scale == "log":
            # Logarithmic frequency points
            log_min = np.log10(self.freq_min)
            log_max = np.log10(self.freq_max)

            for i in range(10):  # 10 labels
                log_freq = log_min + (log_max - log_min) * i / 9
                freq = 10 ** log_freq

                if freq < 1000:
                    label = f"{int(freq)}Hz"
                else:
                    label = f"{freq/1000:.1f}kHz"

                y_pos = self.height - (i / 9) * self.height
                self.freq_labels.append((freq, label, y_pos))

        else:  # Linear
            for i in range(10):
                freq = self.freq_min + (self.freq_max - self.freq_min) * i / 9

                if freq < 1000:
                    label = f"{int(freq)}Hz"
                else:
                    label = f"{freq/1000:.1f}kHz"

                y_pos = self.height - (i / 9) * self.height
                self.freq_labels.append((freq, label, y_pos))

    def update(self, fft_data: np.ndarray, frequencies: np.ndarray):
        """Update spectrogram with new FFT data."""
        if fft_data is None or len(fft_data) == 0:
            return

        # Convert to dB
        magnitude_db = linear_to_db(np.abs(fft_data), self.db_floor)

        # Map to frequency range
        freq_indices = self._map_frequencies(frequencies)

        if freq_indices is None:
            return

        # Create column of pixels
        column = self._create_spectrogram_column(magnitude_db[freq_indices])

        # Add to history
        self.spectrogram_history.append(column)

        # Update display
        if self.display_mode == "waterfall":
            self._update_waterfall()
        elif self.display_mode == "static":
            self._update_static()
        elif self.display_mode == "3d":
            self._update_3d()

    def _map_frequencies(self, frequencies: np.ndarray) -> Optional[np.ndarray]:
        """Map FFT frequencies to display frequencies."""
        if len(frequencies) == 0:
            return None

        # Find indices within frequency range
        valid_mask = (frequencies >= self.freq_min) & (frequencies <= self.freq_max)
        valid_indices = np.where(valid_mask)[0]

        if len(valid_indices) == 0:
            return None

        # Resample to match display height
        if self.freq_scale == "log":
            # Logarithmic resampling
            log_freqs = np.log10(frequencies[valid_indices])
            log_min = np.log10(self.freq_min)
            log_max = np.log10(self.freq_max)

            # Create log-spaced bins
            log_bins = np.linspace(log_min, log_max, self.height)

            # Map to bins
            resampled_indices = []
            for i in range(len(log_bins) - 1):
                bin_mask = (log_freqs >= log_bins[i]) & (log_freqs < log_bins[i + 1])
                bin_indices = valid_indices[bin_mask]

                if len(bin_indices) > 0:
                    # Take average of bin
                    resampled_indices.append(int(np.mean(bin_indices)))
                else:
                    # Interpolate
                    if len(resampled_indices) > 0:
                        resampled_indices.append(resampled_indices[-1])
                    else:
                        resampled_indices.append(valid_indices[0])

            return np.array(resampled_indices)

        else:  # Linear
            # Linear resampling
            resampled_indices = np.linspace(
                valid_indices[0], valid_indices[-1], self.height
            ).astype(int)
            return resampled_indices

    def _create_spectrogram_column(self, magnitude_db: np.ndarray) -> np.ndarray:
        """Create a column of pixels from magnitude data."""
        # Normalize to 0-1 range
        normalized = (magnitude_db - self.db_floor) / self.db_range
        normalized = np.clip(normalized, 0, 1)

        # Map to colormap indices
        color_indices = (normalized * (len(self.colormap) - 1)).astype(int)

        # Create pixel column
        column = self.colormap[color_indices]

        return column

    def _update_waterfall(self):
        """Update waterfall display."""
        # Clear surface
        self.spectrogram_surface.fill(COLORS["BLACK"])

        # Draw history columns
        for i, column in enumerate(self.spectrogram_history):
            x = i

            # Draw column
            for y in range(self.height):
                if y < len(column):
                    color = column[self.height - 1 - y]  # Flip vertically
                    self.spectrogram_surface.set_at((x, y), color)

    def _update_static(self):
        """Update static spectrogram display."""
        # Similar to waterfall but doesn't scroll
        if len(self.spectrogram_history) == 0:
            return

        # Clear surface
        self.spectrogram_surface.fill(COLORS["BLACK"])

        # Compress history to fit display
        history_array = np.array(list(self.spectrogram_history))

        if len(history_array) > self.width:
            # Downsample
            indices = np.linspace(0, len(history_array) - 1, self.width).astype(int)
            display_data = history_array[indices]
        else:
            display_data = history_array

        # Draw compressed history
        for i, column in enumerate(display_data):
            x = int(i * self.width / len(display_data))

            for y in range(self.height):
                if y < len(column):
                    color = column[self.height - 1 - y]
                    self.spectrogram_surface.set_at((x, y), color)

    def _update_3d(self):
        """Update 3D spectrogram display (pseudo-3D)."""
        # Clear surface
        self.screen.fill(COLORS["BLACK"])

        if len(self.spectrogram_history) < 2:
            return

        # Create 3D effect with perspective
        perspective_factor = 0.5

        for i, column in enumerate(self.spectrogram_history):
            # Calculate perspective scaling
            depth = i / len(self.spectrogram_history)
            scale = 1 - depth * perspective_factor

            # Calculate position
            x = int(i + depth * self.width * 0.2)
            y_offset = int(depth * self.height * 0.1)

            # Draw column with scaling
            for y in range(int(self.height * scale)):
                source_y = int(y / scale)
                if source_y < len(column):
                    color = column[self.height - 1 - source_y]

                    # Apply depth shading
                    shade = 1 - depth * 0.5
                    color = tuple(int(c * shade) for c in color)

                    draw_y = y + y_offset
                    if 0 <= draw_y < self.height and x < self.width:
                        self.screen.set_at((x, draw_y), color)

    def render(self, screen: pygame.Surface):
        """Render panel to screen."""
        # Copy spectrogram surface to main surface
        self.screen.blit(self.spectrogram_surface, (0, 0))

        # Draw frequency axis
        self._draw_frequency_axis()

        # Draw time axis
        self._draw_time_axis()

        # Draw border
        pygame.draw.rect(
            self.screen, COLORS["PANEL_BORDER"], (0, 0, self.width, self.height), 1
        )

        # Blit to screen
        screen.blit(self.screen, (self.x, self.y))

    def _draw_frequency_axis(self):
        """Draw frequency axis labels."""
        font = pygame.font.Font(None, 12)

        for freq, label, y_pos in self.freq_labels:
            text = font.render(label, True, COLORS["TEXT_DIM"])
            text_rect = text.get_rect()
            text_rect.right = self.width - 5
            text_rect.centery = int(y_pos)

            self.screen.blit(text, text_rect)

            # Draw tick mark
            pygame.draw.line(
                self.screen,
                COLORS["GRID"],
                (self.width - 15, int(y_pos)),
                (self.width - 10, int(y_pos)),
                1,
            )

    def _draw_time_axis(self):
        """Draw time axis labels."""
        font = pygame.font.Font(None, 12)

        # Calculate time labels based on scroll speed and history
        time_per_pixel = self.time_window / self.width

        for i in range(5):  # 5 time markers
            x = int(i * self.width / 4)
            time_seconds = (self.width - x) * time_per_pixel

            if time_seconds < 1:
                label = f"{int(time_seconds * 1000)}ms"
            else:
                label = f"{time_seconds:.1f}s"

            text = font.render(label, True, COLORS["TEXT_DIM"])
            text_rect = text.get_rect()
            text_rect.centerx = x
            text_rect.bottom = self.height - 2

            self.screen.blit(text, text_rect)

    def set_color_map(self, color_map: str):
        """Set color map for spectrogram."""
        if color_map in GRADIENTS:
            self.color_map = color_map
            self.colormap = self._create_colormap()

    def set_frequency_range(self, freq_min: float, freq_max: float):
        """Set frequency range to display."""
        self.freq_min = max(1, freq_min)
        self.freq_max = min(22050, freq_max)
        self._update_frequency_axis()

    def set_dynamic_range(self, db_range: float, db_floor: float):
        """Set dynamic range for display."""
        self.db_range = max(20, min(120, db_range))
        self.db_floor = max(-120, min(-20, db_floor))

    def clear_history(self):
        """Clear spectrogram history."""
        self.spectrogram_history.clear()
        self.spectrogram_surface.fill(COLORS["BLACK"])
