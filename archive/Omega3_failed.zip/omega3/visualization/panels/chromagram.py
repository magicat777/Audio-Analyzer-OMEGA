"""
OMEGA-1 Chromagram visualization panel
"""

import colorsys
import time
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class ChromagramPanel:
    """Advanced chromagram visualization for note and chord detection"""

    def __init__(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        self.screen = surface
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)

        # Fonts
        self.font_small = pygame.font.Font(None, 16)
        self.font_medium = pygame.font.Font(None, 20)
        self.font_large = pygame.font.Font(None, 28)

        # Colors
        self.bg_color = (10, 12, 18)
        self.border_color = (40, 45, 55)
        self.text_color = (200, 200, 220)
        self.grid_color = (30, 35, 45)

        # Note colors (circle of fifths based)
        self.note_colors = self._generate_note_colors()

        # Chromagram data
        self.chroma_bins = 12  # 12 semitones
        self.note_names = [
            "C",
            "C#",
            "D",
            "D#",
            "E",
            "F",
            "F#",
            "G",
            "G#",
            "A",
            "A#",
            "B",
        ]
        self.chroma_history = []
        self.history_length = 100

        # Chord detection
        self.current_chord = None
        self.chord_confidence = 0
        self.chord_history = []
        self.chord_templates = self._generate_chord_templates()

        # Visualization modes
        self.view_modes = ["Circular", "Timeline", "3D Helix", "Tonnetz"]
        self.current_view = 0

        # Animation
        self.animation_phase = 0
        self.rotation_angle = 0
        self.last_update = time.time()

        # Key detection
        self.key_profiles = self._generate_key_profiles()
        self.detected_key = None
        self.key_confidence = 0

        # Tonnetz layout
        self.tonnetz_layout = self._generate_tonnetz_layout()

    def _generate_note_colors(self) -> List[Tuple[int, int, int]]:
        """Generate colors for each note using circle of fifths"""
        colors = []
        # Order by circle of fifths: C, G, D, A, E, B, F#, C#, G#, D#, A#, F
        fifths_order = [0, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10, 5]

        for i in range(12):
            # Map to hue on color wheel
            hue = fifths_order.index(i) / 12.0
            # High saturation and brightness for visibility
            rgb = colorsys.hsv_to_rgb(hue, 0.8, 0.9)
            colors.append(tuple(int(c * 255) for c in rgb))

        return colors

    def _generate_chord_templates(self) -> Dict[str, List[int]]:
        """Generate chord templates for detection"""
        templates = {
            # Major chords
            "Major": [1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0],
            "Major7": [1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1],
            "Maj7": [1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1],
            "6": [1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0],
            # Minor chords
            "Minor": [1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0],
            "Minor7": [1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0],
            "m7": [1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0],
            "m6": [1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0],
            # Dominant chords
            "7": [1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0],
            "9": [1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],
            "13": [1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0],
            # Other chords
            "Dim": [1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0],
            "Dim7": [1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0],
            "Aug": [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
            "Sus2": [1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0],
            "Sus4": [1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0],
        }
        return templates

    def _generate_key_profiles(self) -> Dict[str, List[float]]:
        """Generate key profiles for key detection"""
        # Krumhansl-Schmuckler key profiles
        major_profile = [
            6.35,
            2.23,
            3.48,
            2.33,
            4.38,
            4.09,
            2.52,
            5.19,
            2.39,
            3.66,
            2.29,
            2.88,
        ]
        minor_profile = [
            6.33,
            2.68,
            3.52,
            5.38,
            2.60,
            3.53,
            2.54,
            4.75,
            3.98,
            2.69,
            3.34,
            3.17,
        ]

        profiles = {}
        for i in range(12):
            # Major keys
            profiles[f"{self.note_names[i]} Major"] = np.roll(
                major_profile, -i
            ).tolist()
            # Minor keys
            profiles[f"{self.note_names[i]} Minor"] = np.roll(
                minor_profile, -i
            ).tolist()

        return profiles

    def _generate_tonnetz_layout(self) -> Dict[int, Tuple[int, int]]:
        """Generate Tonnetz (tone network) layout positions"""
        layout = {}
        # Simplified hexagonal Tonnetz layout
        positions = [
            (1, 0),
            (2, 0),
            (0, 1),
            (1, 1),
            (2, 1),
            (3, 1),
            (0, 2),
            (1, 2),
            (2, 2),
            (3, 2),
            (1, 3),
            (2, 3),
        ]

        # Map notes to positions (arranged by fifths and thirds)
        tonnetz_order = [0, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10, 5]
        for i, note in enumerate(tonnetz_order):
            layout[note] = positions[i]

        return layout

    def update(self, chroma_data: Dict[str, Any]):
        """Update chromagram data"""
        current_time = time.time()
        dt = current_time - self.last_update
        self.last_update = current_time

        # Update animation
        self.animation_phase += dt * 2
        self.rotation_angle += dt * 30  # 30 degrees per second

        # Update chroma vector
        if "chroma" in chroma_data:
            chroma = chroma_data["chroma"]
            self.chroma_history.append(chroma)

            if len(self.chroma_history) > self.history_length:
                self.chroma_history.pop(0)

            # Detect chord
            self._detect_chord(chroma)

            # Detect key
            self._detect_key(chroma)

        # Update chord history
        if "chord" in chroma_data:
            chord_info = chroma_data["chord"]
            self.current_chord = chord_info.get("name")
            self.chord_confidence = chord_info.get("confidence", 0)

            self.chord_history.append(self.current_chord)
            if len(self.chord_history) > 50:
                self.chord_history.pop(0)

    def _detect_chord(self, chroma: List[float]):
        """Detect chord from chroma vector"""
        if not chroma or len(chroma) != 12:
            return

        # Normalize chroma
        chroma_array = np.array(chroma)
        if np.sum(chroma_array) > 0:
            chroma_array = chroma_array / np.sum(chroma_array)

        best_match = None
        best_score = 0

        # Try all root positions
        for root in range(12):
            rotated_chroma = np.roll(chroma_array, -root)

            # Match against templates
            for chord_type, template in self.chord_templates.items():
                score = np.dot(rotated_chroma, template)

                if score > best_score:
                    best_score = score
                    best_match = (self.note_names[root], chord_type)

        if best_match and best_score > 0.7:
            self.current_chord = f"{best_match[0]} {best_match[1]}"
            self.chord_confidence = best_score

    def _detect_key(self, chroma: List[float]):
        """Detect musical key from chroma vector"""
        if not chroma or len(chroma) != 12:
            return

        # Average recent chroma vectors for stability
        if len(self.chroma_history) > 10:
            avg_chroma = np.mean(self.chroma_history[-10:], axis=0)
        else:
            avg_chroma = chroma

        # Normalize
        if np.sum(avg_chroma) > 0:
            avg_chroma = avg_chroma / np.sum(avg_chroma)

        best_key = None
        best_correlation = 0

        # Correlate with key profiles
        for key_name, profile in self.key_profiles.items():
            correlation = np.corrcoef(avg_chroma, profile)[0, 1]

            if correlation > best_correlation:
                best_correlation = correlation
                best_key = key_name

        if best_key and best_correlation > 0.8:
            self.detected_key = best_key
            self.key_confidence = best_correlation

    def draw(self, data=None):
        """Draw the chromagram panel"""
        # Clear background
        pygame.draw.rect(self.screen, self.bg_color, self.rect)
        pygame.draw.rect(self.screen, self.border_color, self.rect, 2)

        # Title
        title = self.font_large.render(
            f"CHROMAGRAM - {self.view_modes[self.current_view]}", True, self.text_color
        )
        title_rect = title.get_rect(centerx=self.x + self.width // 2, y=self.y + 5)
        self.screen.blit(title, title_rect)

        # Draw based on view mode
        content_y = self.y + 40
        content_height = self.height - 120

        if self.current_view == 0:  # Circular
            self._draw_circular_view(content_y, content_height)
        elif self.current_view == 1:  # Timeline
            self._draw_timeline_view(content_y, content_height)
        elif self.current_view == 2:  # 3D Helix
            self._draw_helix_view(content_y, content_height)
        elif self.current_view == 3:  # Tonnetz
            self._draw_tonnetz_view(content_y, content_height)

        # Draw chord and key info
        self._draw_harmonic_info(self.y + self.height - 70)

    def _draw_circular_view(self, y: int, height: int):
        """Draw circular chromagram visualization"""
        center_x = self.x + self.width // 2
        center_y = y + height // 2
        outer_radius = min(self.width, height) // 2 - 20
        inner_radius = outer_radius // 3

        # Draw background circles
        pygame.draw.circle(
            self.screen, self.grid_color, (center_x, center_y), outer_radius, 1
        )
        pygame.draw.circle(
            self.screen, self.grid_color, (center_x, center_y), inner_radius, 1
        )

        if self.chroma_history:
            current_chroma = self.chroma_history[-1]
            max_value = max(current_chroma) if max(current_chroma) > 0 else 1

            for i in range(12):
                # Calculate wedge position
                angle_start = -np.pi / 2 + (i * 2 * np.pi / 12) - np.pi / 12
                angle_end = angle_start + 2 * np.pi / 12

                # Chroma value
                value = current_chroma[i] / max_value

                if value > 0.01:
                    # Create wedge points
                    points = [(center_x, center_y)]

                    # Animated radius
                    animated_value = value * (
                        1 + 0.1 * np.sin(self.animation_phase + i)
                    )
                    radius = (
                        inner_radius + (outer_radius - inner_radius) * animated_value
                    )

                    # Generate arc points
                    for a in np.linspace(angle_start, angle_end, 10):
                        x = center_x + int(np.cos(a) * radius)
                        y = center_y + int(np.sin(a) * radius)
                        points.append((x, y))

                    # Draw filled wedge
                    if len(points) > 2:
                        color = self.note_colors[i]
                        alpha_color = tuple(int(c * value) for c in color)
                        pygame.draw.polygon(self.screen, alpha_color, points)

                # Draw note labels
                label_angle = -np.pi / 2 + (i * 2 * np.pi / 12)
                label_radius = outer_radius + 15
                label_x = center_x + int(np.cos(label_angle) * label_radius)
                label_y = center_y + int(np.sin(label_angle) * label_radius)

                # Highlight active notes
                is_active = value > 0.3
                label_color = self.note_colors[i] if is_active else (100, 100, 120)
                label = self.font_medium.render(self.note_names[i], True, label_color)
                label_rect = label.get_rect(center=(label_x, label_y))
                self.screen.blit(label, label_rect)

        # Draw current chord in center
        if self.current_chord and self.chord_confidence > 0.5:
            chord_surface = self.font_large.render(
                self.current_chord, True, (255, 200, 100)
            )
            chord_rect = chord_surface.get_rect(center=(center_x, center_y))
            self.screen.blit(chord_surface, chord_rect)

    def _draw_timeline_view(self, y: int, height: int):
        """Draw chromagram timeline/waterfall"""
        timeline_x = self.x + 10
        timeline_width = self.width - 20
        note_height = height // 12

        # Draw note labels
        for i in range(12):
            note_y = y + i * note_height

            # Note background
            bg_rect = pygame.Rect(timeline_x, note_y, timeline_width, note_height - 1)
            pygame.draw.rect(self.screen, (20, 22, 28), bg_rect)

            # Note label
            label = self.font_small.render(
                self.note_names[11 - i], True, self.note_colors[11 - i]
            )
            self.screen.blit(label, (timeline_x - 25, note_y + note_height // 2 - 8))

        # Draw chroma history
        if self.chroma_history:
            time_step = timeline_width / self.history_length

            for t, chroma in enumerate(self.chroma_history):
                x_pos = timeline_x + int(t * time_step)

                for i in range(12):
                    if chroma[i] > 0.01:
                        note_y = y + (11 - i) * note_height

                        # Intensity to alpha
                        intensity = min(chroma[i] * 2, 1.0)
                        color = tuple(int(c * intensity) for c in self.note_colors[i])

                        bar_rect = pygame.Rect(
                            x_pos, note_y + 1, max(1, int(time_step)), note_height - 2
                        )
                        pygame.draw.rect(self.screen, color, bar_rect)

        # Current time indicator
        current_x = timeline_x + timeline_width - 2
        pygame.draw.line(
            self.screen, (255, 255, 255), (current_x, y), (current_x, y + height), 2
        )

    def _draw_helix_view(self, y: int, height: int):
        """Draw 3D helix visualization"""
        center_x = self.x + self.width // 2
        center_y = y + height // 2

        if not self.chroma_history:
            return

        # Parameters for helix
        radius = min(self.width, height) // 3
        vertical_scale = height / (self.history_length * 0.3)

        # Draw helix
        for t in range(len(self.chroma_history)):
            chroma = self.chroma_history[t]

            # Time-based vertical position
            base_y = center_y + height // 2 - t * vertical_scale

            if base_y < y or base_y > y + height:
                continue

            for i in range(12):
                if chroma[i] > 0.01:
                    # Helix angle
                    angle = (
                        self.rotation_angle * np.pi / 180
                        + (i * 2 * np.pi / 12)
                        + (t * 0.1)
                    )

                    # 3D projection
                    z = np.cos(angle) * 0.5 + 0.5  # Depth factor
                    x = center_x + int(np.sin(angle) * radius * z)
                    y_pos = int(base_y - chroma[i] * 20 * z)

                    # Size based on depth
                    size = max(2, int(5 * z * chroma[i]))

                    # Color with depth shading
                    color = tuple(int(c * z * chroma[i]) for c in self.note_colors[i])

                    pygame.draw.circle(self.screen, color, (x, y_pos), size)

    def _draw_tonnetz_view(self, y: int, height: int):
        """Draw Tonnetz (tone network) visualization"""
        if not self.chroma_history:
            return

        current_chroma = self.chroma_history[-1]

        # Scale factor for layout
        scale_x = self.width / 5
        scale_y = height / 5
        offset_x = self.x + 40
        offset_y = y + 20

        # Draw connections between active notes
        active_notes = [(i, v) for i, v in enumerate(current_chroma) if v > 0.1]

        for i, (note1, value1) in enumerate(active_notes):
            pos1 = self.tonnetz_layout[note1]
            x1 = offset_x + int(pos1[0] * scale_x)
            y1 = offset_y + int(pos1[1] * scale_y)

            for note2, value2 in active_notes[i + 1:]:
                pos2 = self.tonnetz_layout[note2]
                x2 = offset_x + int(pos2[0] * scale_x)
                y2 = offset_y + int(pos2[1] * scale_y)

                # Check musical relationship
                interval = (note2 - note1) % 12

                # Different line styles for different intervals
                if interval == 7:  # Perfect fifth
                    color = (100, 200, 255)
                    width = 3
                elif interval == 4:  # Major third
                    color = (255, 200, 100)
                    width = 2
                elif interval == 3:  # Minor third
                    color = (200, 100, 255)
                    width = 2
                else:
                    continue

                # Draw connection with alpha based on strength
                alpha = int(min(value1, value2) * 255)
                pygame.draw.line(
                    self.screen, (*color, alpha), (x1, y1), (x2, y2), width
                )

        # Draw nodes
        for note in range(12):
            pos = self.tonnetz_layout[note]
            x = offset_x + int(pos[0] * scale_x)
            y = offset_y + int(pos[1] * scale_y)

            # Node size based on chroma value
            value = current_chroma[note]
            radius = int(10 + value * 20)

            # Draw node
            if value > 0.01:
                pygame.draw.circle(self.screen, self.note_colors[note], (x, y), radius)
                pygame.draw.circle(self.screen, (255, 255, 255), (x, y), radius, 1)
            else:
                pygame.draw.circle(self.screen, (50, 50, 60), (x, y), 10, 1)

            # Note label
            label = self.font_small.render(
                self.note_names[note],
                True,
                self.text_color if value > 0.1 else (100, 100, 120),
            )
            label_rect = label.get_rect(center=(x, y))
            self.screen.blit(label, label_rect)

    def _draw_harmonic_info(self, y: int):
        """Draw chord and key information"""
        info_rect = pygame.Rect(self.x + 5, y, self.width - 10, 60)
        pygame.draw.rect(self.screen, (20, 22, 28), info_rect)
        pygame.draw.rect(self.screen, self.border_color, info_rect, 1)

        info_x = self.x + 15

        # Current chord
        if self.current_chord and self.chord_confidence > 0.5:
            chord_text = f"Chord: {self.current_chord}"
            chord_color = (
                (255, 200, 100) if self.chord_confidence > 0.8 else (200, 180, 100)
            )
            chord_surface = self.font_medium.render(chord_text, True, chord_color)
            self.screen.blit(chord_surface, (info_x, y + 5))

            # Confidence bar
            conf_width = int(self.chord_confidence * 100)
            conf_rect = pygame.Rect(info_x + 200, y + 10, conf_width, 10)
            pygame.draw.rect(self.screen, chord_color, conf_rect)
        else:
            no_chord = self.font_medium.render(
                "No chord detected", True, (100, 100, 120)
            )
            self.screen.blit(no_chord, (info_x, y + 5))

        # Detected key
        if self.detected_key and self.key_confidence > 0.7:
            key_text = f"Key: {self.detected_key}"
            key_surface = self.font_medium.render(key_text, True, (150, 200, 255))
            self.screen.blit(key_surface, (info_x, y + 30))

            # Key confidence
            key_conf_text = f"({self.key_confidence * 100:.0f}%)"
            key_conf_surface = self.font_small.render(
                key_conf_text, True, (120, 150, 200)
            )
            self.screen.blit(key_conf_surface, (info_x + 150, y + 33))

        # Chord progression hint
        if len(self.chord_history) > 3:
            recent_chords = [c for c in self.chord_history[-4:] if c]
            if len(recent_chords) >= 2:
                prog_text = " → ".join(recent_chords[-2:])
                prog_surface = self.font_small.render(prog_text, True, (150, 150, 170))
                prog_rect = prog_surface.get_rect(
                    right=self.x + self.width - 15, y=y + 35
                )
                self.screen.blit(prog_surface, prog_rect)

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle input events"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_c:
                # Cycle through view modes
                self.current_view = (self.current_view + 1) % len(self.view_modes)
                return True
            elif event.key == pygame.K_r:
                # Reset data
                self.chroma_history.clear()
                self.chord_history.clear()
                self.current_chord = None
                self.detected_key = None
                return True

        return False
