"""
OMEGA-2 Genre classification and visualization panel
"""

import time
from collections import deque
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class GenrePanel:
    """Advanced genre classification and visualization panel"""

    def __init__(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        self.screen = surface
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)

        # Fonts
        self.font_small = pygame.font.Font(None, 18)
        self.font_medium = pygame.font.Font(None, 22)
        self.font_large = pygame.font.Font(None, 30)

        # Colors
        self.bg_color = (12, 14, 20)
        self.border_color = (35, 40, 50)
        self.text_color = (200, 200, 220)
        self.grid_color = (25, 30, 40)

        # Genre colors
        self.genre_colors = {
            "Electronic": (0, 255, 255),
            "Rock": (255, 100, 100),
            "Jazz": (255, 200, 100),
            "Classical": (200, 150, 255),
            "Hip-Hop": (150, 255, 100),
            "Pop": (255, 100, 200),
            "Metal": (200, 50, 50),
            "Folk": (150, 200, 100),
            "R&B": (200, 100, 255),
            "Country": (255, 180, 100),
            "Blues": (100, 150, 255),
            "Reggae": (100, 255, 150),
            "Latin": (255, 150, 50),
            "World": (150, 200, 200),
            "Ambient": (100, 200, 200),
            "Unknown": (150, 150, 150),
        }

        # Genre detection data
        self.current_genres = {}  # genre: confidence
        self.genre_history = deque(maxlen=100)
        self.genre_features = {}

        # Feature tracking
        self.tempo_history = deque(maxlen=50)
        self.energy_history = deque(maxlen=100)
        self.spectral_centroid_history = deque(maxlen=100)
        self.zero_crossing_history = deque(maxlen=100)

        # Visualization modes
        self.view_modes = ["Radar Chart", "Timeline", "Feature Space", "Genre Map"]
        self.current_view = 0

        # Animation
        self.animation_phase = 0
        self.particle_effects = []
        self.last_update = time.time()

        # Genre transition tracking
        self.dominant_genre = "Unknown"
        self.genre_stability = 0
        self.transition_history = []

        # Sub-genre detection
        self.sub_genres = {
            "Electronic": ["House", "Techno", "Drum & Bass", "Dubstep", "Trance"],
            "Rock": ["Classic Rock", "Alternative", "Indie", "Progressive", "Punk"],
            "Jazz": ["Smooth Jazz", "Bebop", "Fusion", "Swing", "Free Jazz"],
            "Classical": ["Baroque", "Romantic", "Modern", "Chamber", "Orchestral"],
        }

    def update(self, genre_data: Dict[str, Any]):
        """Update genre classification data"""
        current_time = time.time()
        dt = current_time - self.last_update
        self.last_update = current_time

        # Update animation
        self.animation_phase += dt * 2

        # Update particle effects
        self._update_particles(dt)

        # Process genre predictions
        if "genres" in genre_data:
            self.current_genres = genre_data["genres"]
            self.genre_history.append(self.current_genres.copy())

            # Update dominant genre
            if self.current_genres:
                top_genre = max(self.current_genres.items(), key=lambda x: x[1])
                if top_genre[0] == self.dominant_genre:
                    self.genre_stability = min(1.0, self.genre_stability + 0.1)
                else:
                    if self.genre_stability < 0.3:
                        # Genre transition
                        self._add_transition_effect(self.dominant_genre, top_genre[0])
                        self.dominant_genre = top_genre[0]
                    self.genre_stability = max(0, self.genre_stability - 0.2)

        # Update audio features
        if "features" in genre_data:
            features = genre_data["features"]
            self.genre_features = features

            if "tempo" in features:
                self.tempo_history.append(features["tempo"])
            if "energy" in features:
                self.energy_history.append(features["energy"])
            if "spectral_centroid" in features:
                self.spectral_centroid_history.append(features["spectral_centroid"])
            if "zero_crossing_rate" in features:
                self.zero_crossing_history.append(features["zero_crossing_rate"])

    def _update_particles(self, dt: float):
        """Update particle effects"""
        for particle in self.particle_effects[:]:
            particle["life"] -= dt
            particle["x"] += particle["vx"] * dt
            particle["y"] += particle["vy"] * dt
            particle["vy"] += 100 * dt  # Gravity

            if particle["life"] <= 0:
                self.particle_effects.remove(particle)

    def _add_transition_effect(self, from_genre: str, to_genre: str):
        """Add visual effect for genre transition"""
        # Create particle burst
        center_x = self.x + self.width // 2
        center_y = self.y + self.height // 2

        from_color = self.genre_colors.get(from_genre, (150, 150, 150))
        to_color = self.genre_colors.get(to_genre, (150, 150, 150))

        for i in range(20):
            angle = np.random.random() * 2 * np.pi
            speed = np.random.random() * 200 + 100

            particle = {
                "x": center_x,
                "y": center_y,
                "vx": np.cos(angle) * speed,
                "vy": np.sin(angle) * speed,
                "color": from_color if i < 10 else to_color,
                "life": 1.0,
            }
            self.particle_effects.append(particle)

        # Track transition
        self.transition_history.append(
            {"from": from_genre, "to": to_genre, "time": time.time()}
        )

    def draw(self, data=None):
        """Draw the genre panel"""
        # Clear background
        pygame.draw.rect(self.screen, self.bg_color, self.rect)
        pygame.draw.rect(self.screen, self.border_color, self.rect, 2)

        # Title with current dominant genre
        title_text = f"GENRE - {self.dominant_genre}"
        title_color = self.genre_colors.get(self.dominant_genre, self.text_color)
        title = self.font_large.render(title_text, True, title_color)
        title_rect = title.get_rect(centerx=self.x + self.width // 2, y=self.y + 5)
        self.screen.blit(title, title_rect)

        # Stability indicator
        stability_width = int(self.genre_stability * 100)
        stability_rect = pygame.Rect(
            self.x + self.width // 2 - 50, self.y + 35, stability_width, 3
        )
        pygame.draw.rect(self.screen, title_color, stability_rect)

        # Draw based on view mode
        content_y = self.y + 45
        content_height = self.height - 120

        if self.current_view == 0:  # Radar Chart
            self._draw_radar_view(content_y, content_height)
        elif self.current_view == 1:  # Timeline
            self._draw_timeline_view(content_y, content_height)
        elif self.current_view == 2:  # Feature Space
            self._draw_feature_space_view(content_y, content_height)
        elif self.current_view == 3:  # Genre Map
            self._draw_genre_map_view(content_y, content_height)

        # Draw feature indicators
        self._draw_feature_indicators(self.y + self.height - 65)

        # Draw particles
        self._draw_particles()

    def _draw_radar_view(self, y: int, height: int):
        """Draw radar chart of genre probabilities"""
        center_x = self.x + self.width // 2
        center_y = y + height // 2
        radius = min(self.width, height) // 2 - 30

        # Get top genres
        top_genres = sorted(
            self.current_genres.items(), key=lambda x: x[1], reverse=True
        )[:8]

        if not top_genres:
            return

        num_genres = len(top_genres)
        angle_step = 2 * np.pi / num_genres

        # Draw grid
        for i in range(5):
            grid_radius = radius * (i + 1) / 5
            pygame.draw.circle(
                self.screen, self.grid_color, (center_x, center_y), int(grid_radius), 1
            )

        # Draw axes and labels
        points = []
        for i, (genre, confidence) in enumerate(top_genres):
            angle = -np.pi / 2 + i * angle_step

            # Axis line
            x_end = center_x + int(np.cos(angle) * radius)
            y_end = center_y + int(np.sin(angle) * radius)
            pygame.draw.line(
                self.screen, self.grid_color, (center_x, center_y), (x_end, y_end), 1
            )

            # Genre label
            label_x = center_x + int(np.cos(angle) * (radius + 20))
            label_y = center_y + int(np.sin(angle) * (radius + 20))

            color = self.genre_colors.get(genre, self.text_color)
            label = self.font_small.render(genre, True, color)
            label_rect = label.get_rect(center=(label_x, label_y))
            self.screen.blit(label, label_rect)

            # Calculate point position
            point_radius = radius * confidence
            x = center_x + int(np.cos(angle) * point_radius)
            y = center_y + int(np.sin(angle) * point_radius)
            points.append((x, y))

        # Draw filled polygon
        if len(points) > 2:
            # Create semi-transparent surface
            poly_surface = pygame.Surface((self.width, height), pygame.SRCALPHA)

            # Animated fill
            alpha = int(100 + 50 * np.sin(self.animation_phase))
            fill_color = (
                *self.genre_colors.get(self.dominant_genre, (150, 150, 150)),
                alpha,
            )
            pygame.draw.polygon(poly_surface, fill_color, points)

            self.screen.blit(poly_surface, (self.x, y))

            # Draw outline
            pygame.draw.polygon(
                self.screen,
                self.genre_colors.get(self.dominant_genre, self.text_color),
                points,
                2,
            )

        # Draw confidence values
        for i, (genre, confidence) in enumerate(top_genres):
            angle = -np.pi / 2 + i * angle_step
            point_radius = radius * confidence
            x = center_x + int(np.cos(angle) * point_radius)
            y = center_y + int(np.sin(angle) * point_radius)

            # Draw point
            pygame.draw.circle(self.screen, (255, 255, 255), (x, y), 4)

            # Confidence text
            conf_text = f"{confidence * 100:.0f}%"
            conf_surface = self.font_small.render(conf_text, True, (200, 200, 220))
            conf_rect = conf_surface.get_rect(center=(x, y - 10))
            self.screen.blit(conf_surface, conf_rect)

    def _draw_timeline_view(self, y: int, height: int):
        """Draw genre evolution timeline"""
        timeline_x = self.x + 10
        timeline_width = self.width - 20

        # Background
        pygame.draw.rect(
            self.screen, (15, 17, 23), (timeline_x, y, timeline_width, height)
        )
        pygame.draw.rect(
            self.screen, self.grid_color, (timeline_x, y, timeline_width, height), 1
        )

        if not self.genre_history:
            return

        # Get unique genres from history
        all_genres = set()
        for genres_dict in self.genre_history:
            all_genres.update(genres_dict.keys())

        genre_list = sorted(list(all_genres))[:8]  # Limit to 8 genres
        if not genre_list:
            return

        # Draw stacked area chart
        time_step = timeline_width / len(self.genre_history)

        # Create layers for each genre
        for genre_idx, genre in enumerate(genre_list):
            points_upper = []
            points_lower = []

            for t, genres_dict in enumerate(self.genre_history):
                x = timeline_x + int(t * time_step)

                # Calculate cumulative height
                cumulative = 0
                for g in genre_list[:genre_idx]:
                    cumulative += genres_dict.get(g, 0)

                bottom_y = y + height - int(cumulative * height)
                top_y = (
                    y + height - int((cumulative + genres_dict.get(genre, 0)) * height)
                )

                points_upper.append((x, top_y))
                points_lower.insert(0, (x, bottom_y))

            # Draw filled area
            if points_upper and points_lower:
                all_points = points_upper + points_lower
                if len(all_points) > 2:
                    color = self.genre_colors.get(genre, (150, 150, 150))
                    alpha_color = (*color, 150)

                    # Create surface for transparency
                    area_surface = pygame.Surface(
                        (timeline_width, height), pygame.SRCALPHA
                    )
                    pygame.draw.polygon(
                        area_surface,
                        alpha_color,
                        [(p[0] - timeline_x, p[1] - y) for p in all_points],
                    )
                    self.screen.blit(area_surface, (timeline_x, y))

        # Draw genre labels
        label_y = y + height + 5
        label_x = timeline_x
        for genre in genre_list[:4]:  # Show top 4 genre labels
            color = self.genre_colors.get(genre, self.text_color)
            label = self.font_small.render(genre, True, color)
            self.screen.blit(label, (label_x, label_y))
            label_x += 100

        # Draw transitions
        for transition in self.transition_history[-5:]:  # Last 5 transitions
            age = time.time() - transition["time"]
            if age < 3:  # Show for 3 seconds
                alpha = int(255 * (1 - age / 3))
                trans_text = f"{transition['from']} → {transition['to']}"
                trans_surface = self.font_small.render(
                    trans_text, True, (*self.text_color, alpha)
                )
                self.screen.blit(trans_surface, (timeline_x + 10, y + 10))

    def _draw_feature_space_view(self, y: int, height: int):
        """Draw 2D feature space visualization"""
        space_x = self.x + 10
        space_width = self.width - 20

        # Background
        pygame.draw.rect(self.screen, (15, 17, 23), (space_x, y, space_width, height))
        pygame.draw.rect(
            self.screen, self.grid_color, (space_x, y, space_width, height), 1
        )

        # Axes labels
        x_label = self.font_small.render("Energy →", True, (150, 150, 170))
        self.screen.blit(x_label, (space_x + space_width // 2 - 30, y + height - 20))

        y_label = self.font_small.render("Tempo", True, (150, 150, 170))
        y_label = pygame.transform.rotate(y_label, 90)
        self.screen.blit(y_label, (space_x + 5, y + height // 2 - 20))

        # Plot genre regions
        if self.genre_features:
            # Current position based on features
            energy = self.genre_features.get("energy", 0.5)
            tempo = self.genre_features.get("tempo", 120)

            # Normalize tempo (60-200 BPM range)
            tempo_norm = (tempo - 60) / 140

            current_x = space_x + int(energy * space_width)
            current_y = y + height - int(tempo_norm * height)

            # Draw genre probability fields
            for genre, confidence in self.current_genres.items():
                if confidence > 0.1:
                    # Genre-specific position offsets (simplified clustering)
                    offsets = {
                        "Electronic": (0.7, 0.7),
                        "Rock": (0.6, 0.5),
                        "Jazz": (0.4, 0.4),
                        "Classical": (0.3, 0.3),
                        "Hip-Hop": (0.5, 0.6),
                        "Pop": (0.5, 0.5),
                    }

                    offset = offsets.get(genre, (0.5, 0.5))
                    genre_x = space_x + int(offset[0] * space_width)
                    genre_y = y + height - int(offset[1] * height)

                    # Draw influence circle
                    radius = int(confidence * 50)
                    color = self.genre_colors.get(genre, (150, 150, 150))
                    alpha_color = (*color, int(confidence * 100))

                    # Create gradient circle
                    for r in range(radius, 0, -5):
                        alpha = int(alpha_color[3] * (1 - r / radius))
                        pygame.draw.circle(
                            self.screen, (*color, alpha), (genre_x, genre_y), r
                        )

                    # Genre label
                    if confidence > 0.3:
                        label = self.font_small.render(genre, True, color)
                        label_rect = label.get_rect(center=(genre_x, genre_y))
                        self.screen.blit(label, label_rect)

            # Draw current position
            pygame.draw.circle(
                self.screen, (255, 255, 255), (current_x, current_y), 8, 2
            )
            pygame.draw.circle(
                self.screen,
                self.genre_colors.get(self.dominant_genre, (255, 255, 255)),
                (current_x, current_y),
                5,
            )

            # Feature values
            feature_text = f"E:{energy:.2f} T:{tempo:.0f}"
            feature_surface = self.font_small.render(
                feature_text, True, (200, 200, 220)
            )
            self.screen.blit(feature_surface, (current_x + 10, current_y - 20))

    def _draw_genre_map_view(self, y: int, height: int):
        """Draw genre relationship map"""
        map_x = self.x + 10
        map_width = self.width - 20

        # Create node positions using force-directed layout simulation
        nodes = {}
        for genre in self.genre_colors.keys():
            if genre != "Unknown":
                # Simple circular layout
                angle = (
                    list(self.genre_colors.keys()).index(genre)
                    * 2
                    * np.pi
                    / (len(self.genre_colors) - 1)
                )
                radius = min(map_width, height) // 3
                x = map_x + map_width // 2 + int(np.cos(angle) * radius)
                y_pos = y + height // 2 + int(np.sin(angle) * radius)
                nodes[genre] = (x, y_pos)

        # Draw connections based on genre similarity
        connections = [
            ("Rock", "Metal", 0.8),
            ("Rock", "Alternative", 0.7),
            ("Electronic", "Pop", 0.6),
            ("Jazz", "Blues", 0.8),
            ("Blues", "Rock", 0.6),
            ("Hip-Hop", "R&B", 0.7),
            ("Folk", "Country", 0.8),
            ("Classical", "Jazz", 0.4),
            ("Latin", "World", 0.6),
            ("Ambient", "Electronic", 0.7),
        ]

        # Draw connections
        for genre1, genre2, strength in connections:
            if genre1 in nodes and genre2 in nodes:
                pos1 = nodes[genre1]
                pos2 = nodes[genre2]

                # Connection line with alpha based on strength
                alpha = int(strength * 100)
                pygame.draw.line(
                    self.screen,
                    (*self.grid_color, alpha),
                    pos1,
                    pos2,
                    max(1, int(strength * 3)),
                )

        # Draw nodes
        for genre, pos in nodes.items():
            # Node size based on current confidence
            confidence = self.current_genres.get(genre, 0)
            base_size = 20
            size = int(base_size + confidence * 30)

            # Draw node
            color = self.genre_colors.get(genre, (150, 150, 150))

            if confidence > 0:
                # Active genre - draw with glow
                for r in range(size + 10, size, -2):
                    alpha = int(50 * (1 - (r - size) / 10))
                    pygame.draw.circle(self.screen, (*color, alpha), pos, r)

            pygame.draw.circle(self.screen, color, pos, size)
            pygame.draw.circle(self.screen, (255, 255, 255), pos, size, 2)

            # Genre label
            label = self.font_small.render(genre, True, self.text_color)
            label_rect = label.get_rect(center=(pos[0], pos[1] + size + 15))
            self.screen.blit(label, label_rect)

            # Confidence value
            if confidence > 0:
                conf_text = f"{confidence * 100:.0f}%"
                conf_surface = self.font_small.render(conf_text, True, (200, 200, 220))
                conf_rect = conf_surface.get_rect(center=pos)
                self.screen.blit(conf_surface, conf_rect)

    def _draw_feature_indicators(self, y: int):
        """Draw audio feature indicators"""
        indicators_rect = pygame.Rect(self.x + 5, y, self.width - 10, 55)
        pygame.draw.rect(self.screen, (20, 22, 28), indicators_rect)
        pygame.draw.rect(self.screen, self.border_color, indicators_rect, 1)

        x_offset = self.x + 15

        # Tempo indicator
        if self.tempo_history:
            tempo = self.tempo_history[-1]
            tempo_text = f"BPM: {tempo:.0f}"
            tempo_color = self._get_tempo_color(tempo)
            tempo_surface = self.font_medium.render(tempo_text, True, tempo_color)
            self.screen.blit(tempo_surface, (x_offset, y + 5))

            # Tempo visualization
            tempo_bar_width = int((tempo - 60) / 140 * 50)  # 60-200 BPM range
            tempo_bar = pygame.Rect(x_offset, y + 30, tempo_bar_width, 8)
            pygame.draw.rect(self.screen, tempo_color, tempo_bar)

        x_offset += 120

        # Energy indicator
        if self.energy_history:
            energy = self.energy_history[-1]
            energy_text = f"Energy: {energy * 100:.0f}%"
            energy_color = self._get_energy_color(energy)
            energy_surface = self.font_medium.render(energy_text, True, energy_color)
            self.screen.blit(energy_surface, (x_offset, y + 5))

            # Energy bar
            energy_bar_width = int(energy * 80)
            energy_bar = pygame.Rect(x_offset, y + 30, energy_bar_width, 8)
            pygame.draw.rect(self.screen, energy_color, energy_bar)

        x_offset += 150

        # Spectral centroid (brightness)
        if self.spectral_centroid_history:
            centroid = self.spectral_centroid_history[-1]
            brightness = min(centroid / 4000, 1.0)  # Normalize to 0-1
            bright_text = f"Brightness: {brightness * 100:.0f}%"
            bright_color = (255, int(255 * brightness), int(100 * brightness))
            bright_surface = self.font_medium.render(bright_text, True, bright_color)
            self.screen.blit(bright_surface, (x_offset, y + 5))

    def _draw_particles(self):
        """Draw particle effects"""
        for particle in self.particle_effects:
            alpha = int(255 * particle["life"])
            size = int(5 * particle["life"])

            if size > 0:
                pos = (int(particle["x"]), int(particle["y"]))
                color = (*particle["color"], alpha)
                pygame.draw.circle(self.screen, color, pos, size)

    def _get_tempo_color(self, tempo: float) -> Tuple[int, int, int]:
        """Get color based on tempo"""
        if tempo < 90:
            return (100, 100, 255)  # Slow - Blue
        elif tempo < 120:
            return (100, 255, 100)  # Medium - Green
        elif tempo < 140:
            return (255, 255, 100)  # Fast - Yellow
        else:
            return (255, 100, 100)  # Very fast - Red

    def _get_energy_color(self, energy: float) -> Tuple[int, int, int]:
        """Get color based on energy level"""
        # Gradient from blue (low) to red (high)
        r = int(255 * energy)
        g = int(255 * (1 - abs(energy - 0.5) * 2))
        b = int(255 * (1 - energy))
        return (r, g, b)

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle input events"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_g:
                # Cycle through view modes
                self.current_view = (self.current_view + 1) % len(self.view_modes)
                return True
            elif event.key == pygame.K_r:
                # Reset data
                self.genre_history.clear()
                self.tempo_history.clear()
                self.energy_history.clear()
                self.spectral_centroid_history.clear()
                self.current_genres.clear()
                self.dominant_genre = "Unknown"
                self.genre_stability = 0
                return True

        return False
