"""
Waveform visualization panel for OMEGA-3.
Displays audio waveform with various rendering modes.
"""

from collections import deque
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame

# Import fallbacks if relative imports fail
try:
    from ...utils.constants import COLORS
    from ...utils.math_utils import normalize
except ImportError:
    # Fallback definitions
    COLORS = {
        "PANEL_BG": (20, 20, 25),
        "GRID": (40, 40, 50),
        "GRID_MAJOR": (60, 60, 80),
        "WHITE": (255, 255, 255),
    }

    def normalize(x, a=0, b=1):
        return a + (b - a) * (x - np.min(x)) / (np.max(x) - np.min(x) + 1e-10)


class WaveformPanel:
    """Waveform visualization panel."""

    def __init__(self, x: int, y: int, width: int, height: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

        # Display settings
        self.display_mode = "oscilloscope"  # oscilloscope, rolling, dual, lissajous
        self.draw_mode = "lines"  # lines, dots, filled
        self.time_scale = 0.02  # seconds to display

        # Visual settings
        self.line_thickness = 2
        self.dot_size = 2
        self.fade_factor = 0.95
        self.glow_effect = True

        # Colors
        self.waveform_color = COLORS["ACCENT"]
        self.zero_line_color = COLORS["GRID_MAJOR"]
        self.grid_color = COLORS["GRID"]

        # Buffer for rolling display
        self.sample_rate = 48000
        self.buffer_size = int(self.sample_rate * self.time_scale)
        self.waveform_buffer = deque(maxlen=self.buffer_size)

        # Oscilloscope trigger
        self.trigger_mode = "auto"  # auto, normal, single
        self.trigger_level = 0.0
        self.trigger_slope = "rising"  # rising, falling
        self.triggered = False

        # Surface for rendering
        self.screen = pygame.Surface((width, height))
        self.trail_surface = pygame.Surface((width, height))
        self.trail_surface.set_alpha(255)

    def update(self, audio_data: np.ndarray, sample_rate: Optional[int] = None):
        """Update waveform display with new audio data."""
        if audio_data is None or len(audio_data) == 0:
            return

        if sample_rate:
            self.sample_rate = sample_rate
            self.buffer_size = int(self.sample_rate * self.time_scale)

        # Update buffer for rolling display
        if self.display_mode == "rolling":
            self.waveform_buffer.extend(audio_data)

        # Clear or fade surface
        if self.display_mode == "oscilloscope" and self.glow_effect:
            # Fade trail for glow effect
            fade_surface = pygame.Surface((self.width, self.height))
            fade_surface.set_alpha(int(255 * (1 - self.fade_factor)))
            fade_surface.fill(COLORS["PANEL_BG"])
            self.trail_surface.blit(fade_surface, (0, 0))
        else:
            self.screen.fill(COLORS["PANEL_BG"])

        # Draw based on display mode
        if self.display_mode == "oscilloscope":
            self._draw_oscilloscope(audio_data)
        elif self.display_mode == "rolling":
            self._draw_rolling()
        elif self.display_mode == "dual":
            self._draw_dual_channel(audio_data)
        elif self.display_mode == "lissajous":
            self._draw_lissajous(audio_data)

        # Draw grid and zero line
        self._draw_grid()
        self._draw_zero_line()

    def _draw_oscilloscope(self, audio_data: np.ndarray):
        """Draw oscilloscope-style waveform."""
        # Find trigger point if needed
        if self.trigger_mode != "auto":
            trigger_index = self._find_trigger_point(audio_data)
            if trigger_index is None:
                return
            audio_data = audio_data[trigger_index:]

        # Resample to fit display width
        if len(audio_data) > self.width:
            indices = np.linspace(0, len(audio_data) - 1, self.width).astype(int)
            display_data = audio_data[indices]
        else:
            display_data = audio_data

        # Draw waveform
        if self.draw_mode == "lines":
            self._draw_line_waveform(display_data)
        elif self.draw_mode == "dots":
            self._draw_dot_waveform(display_data)
        elif self.draw_mode == "filled":
            self._draw_filled_waveform(display_data)

    def _draw_rolling(self):
        """Draw rolling waveform display."""
        if len(self.waveform_buffer) < 2:
            return

        # Convert buffer to array
        buffer_array = np.array(self.waveform_buffer)

        # Resample to fit display
        if len(buffer_array) > self.width:
            indices = np.linspace(0, len(buffer_array) - 1, self.width).astype(int)
            display_data = buffer_array[indices]
        else:
            display_data = buffer_array

        # Draw waveform
        if self.draw_mode == "lines":
            self._draw_line_waveform(display_data)
        elif self.draw_mode == "dots":
            self._draw_dot_waveform(display_data)
        elif self.draw_mode == "filled":
            self._draw_filled_waveform(display_data)

    def _draw_dual_channel(self, audio_data: np.ndarray):
        """Draw dual channel (stereo) waveform."""
        if audio_data.ndim < 2:
            # Mono - duplicate for both channels
            left = right = audio_data
        else:
            left = audio_data[:, 0]
            right = audio_data[:, 1] if audio_data.shape[1] > 1 else left

        # Draw top half for left channel
        half_height = self.height // 2

        # Left channel
        self.screen.fill(COLORS["PANEL_BG"], (0, 0, self.width, half_height))
        self._draw_line_waveform(left, offset_y=0, height=half_height)

        # Right channel
        self.screen.fill(COLORS["PANEL_BG"], (0, half_height, self.width, half_height))
        self._draw_line_waveform(right, offset_y=half_height, height=half_height)

        # Separator line
        pygame.draw.line(
            self.screen,
            COLORS["GRID_MAJOR"],
            (0, half_height),
            (self.width, half_height),
            1,
        )

    def _draw_lissajous(self, audio_data: np.ndarray):
        """Draw Lissajous pattern (X-Y mode)."""
        if audio_data.ndim < 2:
            # Need stereo for Lissajous
            return

        left = audio_data[:, 0]
        right = audio_data[:, 1] if audio_data.shape[1] > 1 else left

        # Normalize data
        left = normalize(left, -1, 1)
        right = normalize(right, -1, 1)

        # Create points
        points = []
        num_points = min(len(left), len(right), 1000)  # Limit points for performance

        for i in range(0, num_points, max(1, num_points // 500)):
            x = int((right[i] + 1) * 0.5 * self.width)
            y = int((1 - left[i]) * 0.5 * self.height)
            points.append((x, y))

        # Draw pattern
        if len(points) > 1:
            if self.glow_effect:
                # Draw with glow
                for i in range(3):
                    alpha = 255 // (i + 1)
                    color = (*self.waveform_color, alpha)
                    thickness = self.line_thickness + i

                    # Create temporary surface for alpha
                    temp_surface = pygame.Surface(
                        (self.width, self.height), pygame.SRCALPHA
                    )
                    pygame.draw.lines(temp_surface, color, False, points, thickness)
                    self.trail_surface.blit(temp_surface, (0, 0))
            else:
                pygame.draw.lines(
                    self.screen, self.waveform_color, False, points, self.line_thickness
                )

    def _draw_line_waveform(
        self, data: np.ndarray, offset_y: int = 0, height: Optional[int] = None
    ):
        """Draw waveform as connected lines."""
        if height is None:
            height = self.height

        if len(data) < 2:
            return

        # Create points
        points = []
        for i, sample in enumerate(data):
            x = int(i * self.width / len(data))
            y = int(offset_y + height / 2 - sample * height / 2)
            points.append((x, y))

        # Draw waveform
        target_surface = self.trail_surface if self.glow_effect else self.screen

        if self.glow_effect:
            # Multi-pass for glow effect
            for i in range(3):
                alpha = 255 // (i + 1)
                thickness = self.line_thickness + i

                temp_surface = pygame.Surface(
                    (self.width, self.height), pygame.SRCALPHA
                )
                color = (*self.waveform_color, alpha)
                pygame.draw.lines(temp_surface, color, False, points, thickness)
                target_surface.blit(temp_surface, (0, 0))
        else:
            pygame.draw.lines(
                target_surface, self.waveform_color, False, points, self.line_thickness
            )

    def _draw_dot_waveform(self, data: np.ndarray):
        """Draw waveform as dots."""
        for i, sample in enumerate(data):
            x = int(i * self.width / len(data))
            y = int(self.height / 2 - sample * self.height / 2)

            target_surface = self.trail_surface if self.glow_effect else self.screen
            pygame.draw.circle(
                target_surface, self.waveform_color, (x, y), self.dot_size
            )

    def _draw_filled_waveform(self, data: np.ndarray):
        """Draw waveform as filled area."""
        if len(data) < 2:
            return

        # Create polygon points
        points_top = []
        points_bottom = []

        for i, sample in enumerate(data):
            x = int(i * self.width / len(data))
            y_top = int(self.height / 2 - abs(sample) * self.height / 2)
            y_bottom = int(self.height / 2 + abs(sample) * self.height / 2)

            points_top.append((x, y_top))
            points_bottom.append((x, y_bottom))

        # Combine points for filled polygon
        points = points_top + points_bottom[::-1]

        if len(points) > 2:
            target_surface = self.trail_surface if self.glow_effect else self.screen

            # Draw with transparency
            fill_color = (*self.waveform_color, 128)
            temp_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            pygame.draw.polygon(temp_surface, fill_color, points)
            target_surface.blit(temp_surface, (0, 0))

    def _find_trigger_point(self, audio_data: np.ndarray) -> Optional[int]:
        """Find trigger point in audio data."""
        if len(audio_data) < 10:
            return None

        for i in range(1, len(audio_data) - 1):
            if self.trigger_slope == "rising":
                if audio_data[i - 1] <= self.trigger_level < audio_data[i]:
                    return i
            else:  # falling
                if audio_data[i - 1] >= self.trigger_level > audio_data[i]:
                    return i

        return None if self.trigger_mode == "normal" else 0

    def _draw_grid(self):
        """Draw grid lines."""
        # Vertical grid lines
        for i in range(0, 11):
            x = int(i * self.width / 10)
            pygame.draw.line(self.screen, self.grid_color, (x, 0), (x, self.height), 1)

        # Horizontal grid lines
        for i in range(0, 9):
            y = int(i * self.height / 8)
            pygame.draw.line(self.screen, self.grid_color, (0, y), (self.width, y), 1)

    def _draw_zero_line(self):
        """Draw zero reference line."""
        y = self.height // 2
        pygame.draw.line(self.screen, self.zero_line_color, (0, y), (self.width, y), 1)

    def render(self, screen: pygame.Surface):
        """Render panel to screen."""
        # Combine surfaces if using glow effect
        if self.glow_effect:
            self.screen.blit(self.trail_surface, (0, 0))

        screen.blit(self.screen, (self.x, self.y))

    def set_time_scale(self, seconds: float):
        """Set time scale for display."""
        self.time_scale = max(0.001, min(1.0, seconds))
        self.buffer_size = int(self.sample_rate * self.time_scale)
        self.waveform_buffer = deque(maxlen=self.buffer_size)

    def set_trigger(self, level: float, slope: str = "rising"):
        """Set trigger parameters."""
        self.trigger_level = max(-1.0, min(1.0, level))
        self.trigger_slope = slope if slope in ["rising", "falling"] else "rising"
