"""
Audio metering panel for OMEGA-3.
Professional-grade audio level meters and indicators.
"""

from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame

# Import fallbacks if relative imports fail
try:
    from ...utils.constants import COLORS
    from ...utils.constants import METER_STANDARDS
    from ...utils.math_utils import linear_to_db
except ImportError:
    # Fallback definitions
    COLORS = {"PANEL_BG": (20, 20, 25), "GRID": (40, 40, 50), "WHITE": (255, 255, 255)}
    METER_STANDARDS = {"PEAK_HOLD_TIME": 2.0}

    def linear_to_db(x):
        return 20 * np.log10(x + 1e-10)


class MeterPanel:
    """Professional audio metering panel."""

    def __init__(self, x: int, y: int, width: int, height: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

        # Meter types to display
        self.show_peak = True
        self.show_rms = True
        self.show_lufs = True
        self.show_correlation = True

        # Meter settings
        self.meter_range = 60  # dB range
        self.reference_level = 0  # dBFS
        self.peak_hold_time = METER_STANDARDS["PEAK_HOLD_TIME"]

        # Meter values
        self.peak_left = -np.inf
        self.peak_right = -np.inf
        self.peak_hold_left = -np.inf
        self.peak_hold_right = -np.inf
        self.peak_hold_counter_left = 0
        self.peak_hold_counter_right = 0

        self.rms_left = -np.inf
        self.rms_right = -np.inf

        self.lufs_momentary = -np.inf
        self.lufs_short_term = -np.inf
        self.lufs_integrated = -np.inf

        self.correlation = 0.0

        # Visual settings
        self.meter_width = 30
        self.meter_spacing = 10
        self.scale_width = 40

        # Colors
        self.color_normal = COLORS["SUCCESS"]
        self.color_warning = COLORS["WARNING"]
        self.color_danger = COLORS["ERROR"]
        self.color_background = (40, 40, 45)

        # Surface for rendering
        self.screen = pygame.Surface((width, height))

    def update(self, metering_data: Dict[str, any]):
        """Update meter values from metering data."""
        if not metering_data:
            return

        # Update peak meters
        if "peak" in metering_data:
            peak_data = metering_data["peak"]
            self.peak_left = peak_data.get("peak_db", -np.inf)
            self.peak_right = self.peak_left  # Assume mono if not specified

            # Update peak hold
            if self.peak_left > self.peak_hold_left:
                self.peak_hold_left = self.peak_left
                self.peak_hold_counter_left = 0
            else:
                self.peak_hold_counter_left += 1
                if (
                    self.peak_hold_counter_left > self.peak_hold_time * 60
                ):  # 60 FPS assumed
                    self.peak_hold_left = self.peak_left

        # Update RMS meters
        if "rms" in metering_data:
            rms_data = metering_data["rms"]
            self.rms_left = rms_data.get("rms_db", -np.inf)
            self.rms_right = self.rms_left

        # Update LUFS meters
        if "lufs" in metering_data:
            lufs_data = metering_data["lufs"]
            self.lufs_momentary = lufs_data.get("momentary", -np.inf)
            self.lufs_short_term = lufs_data.get("short_term", -np.inf)
            self.lufs_integrated = lufs_data.get("integrated", -np.inf)

        # Update correlation meter
        if "correlation" in metering_data:
            corr_data = metering_data["correlation"]
            self.correlation = corr_data.get("correlation", 0.0)

    def render(self, screen: pygame.Surface):
        """Render meter panel to screen."""
        # Clear surface
        self.screen.fill(COLORS["PANEL_BG"])

        # Calculate meter positions
        current_x = self.scale_width

        # Draw scale
        self._draw_scale(5, 0, self.scale_width - 10, self.height)

        # Draw peak meters
        if self.show_peak:
            self._draw_stereo_meter(
                current_x,
                "PEAK",
                self.peak_left,
                self.peak_right,
                self.peak_hold_left,
                self.peak_hold_right,
            )
            current_x += self.meter_width * 2 + self.meter_spacing

        # Draw RMS meters
        if self.show_rms:
            self._draw_stereo_meter(current_x, "RMS", self.rms_left, self.rms_right)
            current_x += self.meter_width * 2 + self.meter_spacing

        # Draw LUFS meters
        if self.show_lufs:
            self._draw_lufs_meters(current_x)
            current_x += self.meter_width * 3 + self.meter_spacing * 2

        # Draw correlation meter
        if self.show_correlation:
            self._draw_correlation_meter(current_x)

        # Draw border
        pygame.draw.rect(
            self.screen, COLORS["PANEL_BORDER"], (0, 0, self.width, self.height), 1
        )

        # Blit to screen
        screen.blit(self.screen, (self.x, self.y))

    def _draw_scale(self, x: int, y: int, width: int, height: int):
        """Draw dB scale."""
        font = pygame.font.Font(None, 10)

        # Draw scale marks
        db_marks = [0, -6, -12, -18, -24, -30, -40, -50, -60]

        for db in db_marks:
            # Calculate position
            normalized = (self.reference_level - db) / self.meter_range
            mark_y = int(y + normalized * height)

            if 0 <= mark_y <= y + height:
                # Draw line
                pygame.draw.line(
                    self.screen,
                    COLORS["GRID"],
                    (x + width - 5, mark_y),
                    (x + width, mark_y),
                    1,
                )

                # Draw text
                text = font.render(f"{db}", True, COLORS["TEXT_DIM"])
                text_rect = text.get_rect()
                text_rect.right = x + width - 7
                text_rect.centery = mark_y

                self.screen.blit(text, text_rect)

    def _draw_stereo_meter(
        self,
        x: int,
        label: str,
        left_db: float,
        right_db: float,
        left_hold: Optional[float] = None,
        right_hold: Optional[float] = None,
    ):
        """Draw stereo meter pair."""
        # Draw label
        font = pygame.font.Font(None, 12)
        text = font.render(label, True, COLORS["TEXT"])
        text_rect = text.get_rect()
        text_rect.centerx = x + self.meter_width
        text_rect.bottom = self.height - 5
        self.screen.blit(text, text_rect)

        # Draw meters
        meter_height = self.height - 25

        # Left channel
        self._draw_single_meter(
            x, 5, self.meter_width - 2, meter_height, left_db, left_hold, "L"
        )

        # Right channel
        self._draw_single_meter(
            x + self.meter_width,
            5,
            self.meter_width - 2,
            meter_height,
            right_db,
            right_hold,
            "R",
        )

    def _draw_single_meter(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        value_db: float,
        hold_db: Optional[float],
        channel: str,
    ):
        """Draw single meter bar."""
        # Draw background
        pygame.draw.rect(self.screen, self.color_background, (x, y, width, height))

        # Calculate bar height
        if value_db > -np.inf:
            normalized = np.clip(
                (self.reference_level - value_db) / self.meter_range, 0, 1
            )
            bar_height = int((1 - normalized) * height)
            bar_y = y + height - bar_height

            # Determine color based on level
            if value_db > -3:
                color = self.color_danger
            elif value_db > -6:
                color = self.color_warning
            else:
                color = self.color_normal

            # Draw bar
            if bar_height > 0:
                pygame.draw.rect(
                    self.screen, color, (x + 2, bar_y, width - 4, bar_height)
                )

        # Draw peak hold
        if hold_db is not None and hold_db > -np.inf:
            hold_normalized = np.clip(
                (self.reference_level - hold_db) / self.meter_range, 0, 1
            )
            hold_y = y + int((1 - hold_normalized) * height)

            pygame.draw.line(
                self.screen,
                COLORS["WHITE"],
                (x + 2, hold_y),
                (x + width - 2, hold_y),
                2,
            )

        # Draw channel label
        font = pygame.font.Font(None, 10)
        text = font.render(channel, True, COLORS["TEXT_DIM"])
        text_rect = text.get_rect()
        text_rect.centerx = x + width // 2
        text_rect.top = y + 2
        self.screen.blit(text, text_rect)

        # Draw border
        pygame.draw.rect(self.screen, COLORS["GRID"], (x, y, width, height), 1)

    def _draw_lufs_meters(self, x: int):
        """Draw LUFS meters."""
        meter_width = self.meter_width - 5
        meter_height = self.height - 25

        # Labels
        labels = ["M", "S", "I"]
        values = [self.lufs_momentary, self.lufs_short_term, self.lufs_integrated]

        # Draw overall label
        font = pygame.font.Font(None, 12)
        text = font.render("LUFS", True, COLORS["TEXT"])
        text_rect = text.get_rect()
        text_rect.centerx = x + meter_width * 1.5 + 5
        text_rect.bottom = self.height - 5
        self.screen.blit(text, text_rect)

        # Draw individual meters
        for i, (label, value) in enumerate(zip(labels, values)):
            meter_x = x + i * (meter_width + 2)
            self._draw_single_meter(
                meter_x, 5, meter_width, meter_height, value, None, label
            )

    def _draw_correlation_meter(self, x: int):
        """Draw phase correlation meter."""
        meter_width = self.meter_width * 2
        meter_height = 30
        meter_y = self.height // 2 - meter_height // 2

        # Draw background
        pygame.draw.rect(
            self.screen, self.color_background, (x, meter_y, meter_width, meter_height)
        )

        # Draw scale marks
        for i, val in enumerate([-1, 0, 1]):
            mark_x = x + meter_width * (i / 2)
            pygame.draw.line(
                self.screen,
                COLORS["GRID"],
                (int(mark_x), meter_y),
                (int(mark_x), meter_y + meter_height),
                1,
            )

            # Label
            font = pygame.font.Font(None, 10)
            text = font.render(str(val), True, COLORS["TEXT_DIM"])
            text_rect = text.get_rect()
            text_rect.centerx = int(mark_x)
            text_rect.top = meter_y + meter_height + 2
            self.screen.blit(text, text_rect)

        # Draw correlation indicator
        indicator_x = x + meter_width * (self.correlation + 1) / 2

        # Color based on correlation
        if abs(self.correlation) > 0.8:
            color = self.color_normal
        elif abs(self.correlation) < 0.3:
            color = self.color_warning
        else:
            color = COLORS["ACCENT"]

        # Draw indicator line
        pygame.draw.line(
            self.screen,
            color,
            (int(indicator_x), meter_y + 2),
            (int(indicator_x), meter_y + meter_height - 2),
            3,
        )

        # Label
        font = pygame.font.Font(None, 12)
        text = font.render("CORR", True, COLORS["TEXT"])
        text_rect = text.get_rect()
        text_rect.centerx = x + meter_width // 2
        text_rect.bottom = meter_y - 2
        self.screen.blit(text, text_rect)

        # Border
        pygame.draw.rect(
            self.screen, COLORS["GRID"], (x, meter_y, meter_width, meter_height), 1
        )
