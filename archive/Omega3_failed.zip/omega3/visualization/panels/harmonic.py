"""
Harmonic analysis panel for frequency component visualization
"""

from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame

try:
    from .base_panel import AnalysisPanel
except ImportError:
    from base_panel import AnalysisPanel


class HarmonicPanel(AnalysisPanel):
    """Panel for harmonic analysis display"""

    def __init__(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        super().__init__(surface, x, y, width, height)

        # Enhanced colors for harmonic visualization
        self.fundamental_color = (255, 200, 100)
        self.harmonic_colors = [
            (100, 200, 255),  # 2nd harmonic
            (150, 255, 150),  # 3rd
            (255, 150, 200),  # 4th
            (200, 150, 255),  # 5th
            (255, 255, 150),  # 6th+
        ]

        # Visualization settings
        self.show_spectrum = True
        self.show_bars = True
        self.show_phase = False
        self.max_harmonics = 10

        # History for animation
        self.fundamental_history = []
        self.harmonic_history = []
        self.history_length = 50

    def draw(self, harmonic_data: Dict[str, Any]):
        """Draw harmonic analysis"""
        self.clear()
        self.draw_border()
        self.draw_title("Harmonic Analysis")

        y_offset = self.y + 35

        if not harmonic_data:
            no_data = self.font_small.render("No harmonic data", True, (100, 100, 120))
            self.screen.blit(no_data, (self.x + 10, y_offset))
            return

        # Update history
        if "fundamental_freq" in harmonic_data:
            self.fundamental_history.append(harmonic_data["fundamental_freq"])
            if len(self.fundamental_history) > self.history_length:
                self.fundamental_history.pop(0)

        # Draw fundamental frequency
        if "fundamental_freq" in harmonic_data:
            self._draw_fundamental_info(harmonic_data, y_offset)
            y_offset += 50

        # Draw harmonic spectrum visualization
        if self.show_spectrum and "harmonics" in harmonic_data:
            self._draw_harmonic_spectrum(harmonic_data, y_offset)
            y_offset += 100

        # Draw individual harmonics
        if "harmonics" in harmonic_data:
            self._draw_harmonic_details(harmonic_data, y_offset)
            y_offset = self.y + self.height - 80

        # Draw analysis metrics
        self._draw_analysis_metrics(harmonic_data, y_offset)

        # Draw chord info if present
        if "chord_info" in harmonic_data and harmonic_data["chord_info"]:
            self._draw_chord_info(harmonic_data["chord_info"])

    def _draw_fundamental_info(self, data: Dict[str, Any], y: int):
        """Draw fundamental frequency information"""
        fund_freq = data["fundamental_freq"]
        fund_note = data.get("fundamental_note", "N/A")
        cents = data.get("cents_offset", 0)

        # Main frequency display
        freq_text = f"{fund_freq:.1f} Hz"
        freq_surface = self.font_medium.render(freq_text, True, self.fundamental_color)
        self.screen.blit(freq_surface, (self.x + 10, y))

        # Note name
        note_text = f"{fund_note}"
        note_surface = self.font_medium.render(note_text, True, self.accent_color)
        self.screen.blit(note_surface, (self.x + 100, y))

        # Tuning offset with visual indicator
        cents_color = self._get_cents_color(cents)
        cents_text = f"{cents:+.1f}¢"
        cents_surface = self.font_small.render(cents_text, True, cents_color)
        self.screen.blit(cents_surface, (self.x + 160, y + 3))

        # Visual tuning meter
        self._draw_tuning_meter(self.x + 10, y + 25, 200, 15, cents)

    def _draw_tuning_meter(self, x: int, y: int, width: int, height: int, cents: float):
        """Draw a visual tuning meter"""
        # Background
        pygame.draw.rect(self.screen, (40, 40, 50), (x, y, width, height))
        pygame.draw.rect(self.screen, self.border_color, (x, y, width, height), 1)

        # Center line
        center_x = x + width // 2
        pygame.draw.line(
            self.screen, (100, 100, 120), (center_x, y), (center_x, y + height), 2
        )

        # Cents position (-50 to +50 range)
        normalized = np.clip(cents / 50.0, -1, 1)
        pos_x = center_x + int(normalized * (width // 2 - 10))

        # Indicator
        color = self._get_cents_color(cents)
        pygame.draw.circle(self.screen, color, (pos_x, y + height // 2), 5)

        # Scale marks
        for mark_cents in [-50, -25, 0, 25, 50]:
            mark_x = center_x + int((mark_cents / 50.0) * (width // 2 - 10))
            pygame.draw.line(
                self.screen,
                (70, 70, 80),
                (mark_x, y + height - 3),
                (mark_x, y + height),
                1,
            )

    def _get_cents_color(self, cents: float) -> Tuple[int, int, int]:
        """Get color based on cents offset"""
        abs_cents = abs(cents)
        if abs_cents < 5:
            return (100, 255, 100)  # Green - in tune
        elif abs_cents < 10:
            return (255, 255, 100)  # Yellow - slightly off
        else:
            return (255, 100, 100)  # Red - out of tune

    def _draw_harmonic_spectrum(self, data: Dict[str, Any], y: int):
        """Draw harmonic spectrum visualization"""
        harmonics = data.get("harmonics", [])[: self.max_harmonics]
        if not harmonics:
            return

        spectrum_height = 80
        spectrum_width = self.width - 20
        x_start = self.x + 10

        # Background
        pygame.draw.rect(
            self.screen, (25, 25, 35), (x_start, y, spectrum_width, spectrum_height)
        )
        pygame.draw.rect(
            self.screen,
            self.border_color,
            (x_start, y, spectrum_width, spectrum_height),
            1,
        )

        # Find max magnitude for normalization
        fund_mag = data.get("fundamental_mag", 1.0)
        max_mag = max([h["magnitude"] for h in harmonics] + [fund_mag])

        if max_mag > 0:
            # Draw fundamental
            bar_width = spectrum_width // (len(harmonics) + 2)
            x_pos = x_start + bar_width // 2

            # Fundamental bar
            fund_height = int((fund_mag / max_mag) * (spectrum_height - 10))
            if fund_height > 0:
                fund_rect = pygame.Rect(
                    x_pos - bar_width // 3,
                    y + spectrum_height - fund_height - 5,
                    bar_width // 1.5,
                    fund_height,
                )
                pygame.draw.rect(self.screen, self.fundamental_color, fund_rect)

                # Label
                label = self.font_small.render("F", True, self.text_color)
                label_rect = label.get_rect(centerx=x_pos, y=y + spectrum_height + 2)
                self.screen.blit(label, label_rect)

            # Draw harmonics
            for i, harmonic in enumerate(harmonics):
                x_pos += bar_width
                h_height = int(
                    (harmonic["magnitude"] / max_mag) * (spectrum_height - 10)
                )

                if h_height > 0:
                    color_idx = min(i, len(self.harmonic_colors) - 1)
                    color = self.harmonic_colors[color_idx]

                    h_rect = pygame.Rect(
                        x_pos - bar_width // 3,
                        y + spectrum_height - h_height - 5,
                        bar_width // 1.5,
                        h_height,
                    )
                    pygame.draw.rect(self.screen, color, h_rect)

                    # Label
                    label = self.font_small.render(
                        str(harmonic["number"]), True, self.text_color
                    )
                    label_rect = label.get_rect(
                        centerx=x_pos, y=y + spectrum_height + 2
                    )
                    self.screen.blit(label, label_rect)

    def _draw_harmonic_details(self, data: Dict[str, Any], y: int):
        """Draw detailed harmonic information"""
        harmonics = data.get("harmonics", [])[:5]  # Show first 5

        for i, h in enumerate(harmonics):
            # Harmonic number and frequency
            h_text = f"H{h['number']}: {h['frequency']:.1f}Hz"
            color_idx = min(i, len(self.harmonic_colors) - 1)
            h_surface = self.font_small.render(
                h_text, True, self.harmonic_colors[color_idx]
            )
            self.screen.blit(h_surface, (self.x + 10, y))

            # Note name if available
            if "note" in h:
                note_text = f"({h['note']})"
                note_surface = self.font_small.render(note_text, True, (150, 150, 170))
                self.screen.blit(note_surface, (self.x + 130, y))

            # Magnitude bar
            if "fundamental_mag" in data and data["fundamental_mag"] > 0:
                relative_mag = h["magnitude"] / data["fundamental_mag"]
                bar_width = int(relative_mag * 60)
                bar_rect = pygame.Rect(self.x + 190, y + 5, bar_width, 8)
                pygame.draw.rect(self.screen, self.harmonic_colors[color_idx], bar_rect)

                # Percentage
                pct_text = f"{relative_mag * 100:.0f}%"
                pct_surface = self.font_small.render(pct_text, True, (120, 120, 140))
                self.screen.blit(pct_surface, (self.x + 255, y))

            y += 20

    def _draw_analysis_metrics(self, data: Dict[str, Any], y: int):
        """Draw harmonic analysis metrics"""
        # THD
        if "thd_percent" in data:
            thd = data["thd_percent"]
            thd_color = self._get_thd_color(thd)
            thd_text = f"THD: {thd:.1f}%"
            thd_surface = self.font_small.render(thd_text, True, thd_color)
            self.screen.blit(thd_surface, (self.x + 10, y))

            # THD bar
            thd_width = int(min(thd * 2, 100))
            bar_rect = pygame.Rect(self.x + 80, y + 5, thd_width, 8)
            pygame.draw.rect(self.screen, thd_color, bar_rect)

        # Inharmonicity
        if "inharmonicity" in data:
            inh = data["inharmonicity"]
            inh_text = f"Inharmonicity: {inh:.3f}"
            color = (150, 150, 170) if inh < 0.01 else (255, 200, 100)
            inh_surface = self.font_small.render(inh_text, True, color)
            self.screen.blit(inh_surface, (self.x + 10, y + 20))

        # Spectral centroid
        if "spectral_centroid" in data:
            sc = data["spectral_centroid"]
            sc_text = f"Centroid: {sc:.0f}Hz"
            sc_surface = self.font_small.render(sc_text, True, (150, 150, 170))
            self.screen.blit(sc_surface, (self.x + 10, y + 40))

    def _get_thd_color(self, thd: float) -> Tuple[int, int, int]:
        """Get color based on THD value"""
        if thd < 1:
            return (100, 255, 100)  # Excellent
        elif thd < 5:
            return (200, 255, 100)  # Good
        elif thd < 10:
            return (255, 255, 100)  # Acceptable
        else:
            return (255, 150, 100)  # High distortion

    def _draw_chord_info(self, chord_info: Dict[str, Any]):
        """Draw chord detection information"""
        y = self.y + self.height - 60

        # Chord background
        chord_bg = pygame.Rect(self.x + 5, y - 5, self.width - 10, 50)
        pygame.draw.rect(self.screen, (40, 45, 55), chord_bg)
        pygame.draw.rect(self.screen, self.accent_color, chord_bg, 2)

        # Chord name
        chord_text = f"{chord_info['root_note']} {chord_info['chord_type']}"
        chord_surface = self.font_medium.render(chord_text, True, (255, 200, 100))
        chord_rect = chord_surface.get_rect(centerx=self.x + self.width // 2, y=y)
        self.screen.blit(chord_surface, chord_rect)

        # Confidence
        if "confidence" in chord_info:
            conf_text = f"Confidence: {chord_info['confidence'] * 100:.0f}%"
            conf_surface = self.font_small.render(conf_text, True, (150, 150, 170))
            conf_rect = conf_surface.get_rect(
                centerx=self.x + self.width // 2, y=y + 25
            )
            self.screen.blit(conf_surface, conf_rect)

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle input events"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_h:
                # Toggle spectrum display
                self.show_spectrum = not self.show_spectrum
                return True
            elif event.key == pygame.K_b:
                # Toggle bar display
                self.show_bars = not self.show_bars
                return True
            elif event.key == pygame.K_p:
                # Toggle phase display
                self.show_phase = not self.show_phase
                return True

        return False
