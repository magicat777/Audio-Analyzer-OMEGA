"""
Professional meters panel with VU, PPM, and loudness meters
"""

import time
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class MetersPanel:
    """Professional audio meters display"""

    def __init__(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        self.screen = surface
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)

        # Fonts
        self.font_small = pygame.font.Font(None, 16)
        self.font_medium = pygame.font.Font(None, 20)
        self.font_large = pygame.font.Font(None, 24)

        # Colors
        self.bg_color = (20, 22, 28)
        self.border_color = (50, 55, 65)
        self.text_color = (200, 200, 220)
        self.grid_color = (40, 45, 55)

        # Meter colors
        self.meter_green = (50, 255, 50)
        self.meter_yellow = (255, 255, 50)
        self.meter_red = (255, 50, 50)

        # Meter settings
        self.meter_types = ["VU", "PPM", "RMS", "Peak"]
        self.current_meter = 0

        # Meter state
        self.vu_value = 0.0
        self.vu_peak = 0.0
        self.ppm_value = 0.0
        self.ppm_peak = 0.0
        self.rms_value = 0.0
        self.peak_value = 0.0
        self.lufs_value = -60.0
        self.lufs_integrated = -60.0

        # Peak hold
        self.peak_hold_time = 2.0  # seconds
        self.peak_hold_values = {}
        self.peak_hold_times = {}

        # History for meters
        self.history_length = 100
        self.vu_history = []
        self.rms_history = []
        self.peak_history = []

        # Meter ballistics
        self.vu_attack = 0.3  # 300ms rise time
        self.vu_release = 0.3  # 300ms fall time
        self.ppm_attack = 0.005  # 5ms rise time
        self.ppm_release = 1.5  # 1.5s fall time

        # Initialize time tracking
        self.last_update = time.time()

    def update(self, audio_data: np.ndarray, sample_rate: int = 44100):
        """Update meter values from audio data"""
        if len(audio_data) == 0:
            return

        current_time = time.time()
        dt = current_time - self.last_update
        self.last_update = current_time

        # Calculate instantaneous values
        peak = np.max(np.abs(audio_data))
        rms = np.sqrt(np.mean(audio_data ** 2))

        # VU meter (average responding)
        target_vu = self._db_to_linear(self._linear_to_db(rms) + 3.0)  # VU calibration
        if target_vu > self.vu_value:
            self.vu_value += (target_vu - self.vu_value) * min(1.0, dt / self.vu_attack)
        else:
            self.vu_value += (target_vu - self.vu_value) * min(
                1.0, dt / self.vu_release
            )

        # PPM (peak program meter)
        if peak > self.ppm_value:
            self.ppm_value += (peak - self.ppm_value) * min(1.0, dt / self.ppm_attack)
        else:
            self.ppm_value += (peak - self.ppm_value) * min(1.0, dt / self.ppm_release)

        # Update other values
        self.rms_value = rms
        self.peak_value = peak

        # Update peak holds
        self._update_peak_hold("vu", self.vu_value, current_time)
        self._update_peak_hold("ppm", self.ppm_value, current_time)
        self._update_peak_hold("peak", peak, current_time)

        # Update history
        self.vu_history.append(self.vu_value)
        self.rms_history.append(rms)
        self.peak_history.append(peak)

        # Trim history
        if len(self.vu_history) > self.history_length:
            self.vu_history.pop(0)
        if len(self.rms_history) > self.history_length:
            self.rms_history.pop(0)
        if len(self.peak_history) > self.history_length:
            self.peak_history.pop(0)

    def _update_peak_hold(self, meter_name: str, value: float, current_time: float):
        """Update peak hold for a meter"""
        if (
            meter_name not in self.peak_hold_values
            or value > self.peak_hold_values[meter_name]
        ):
            self.peak_hold_values[meter_name] = value
            self.peak_hold_times[meter_name] = current_time
        elif current_time - self.peak_hold_times[meter_name] > self.peak_hold_time:
            # Reset peak hold
            self.peak_hold_values[meter_name] = value
            self.peak_hold_times[meter_name] = current_time

    def _linear_to_db(self, value: float) -> float:
        """Convert linear value to dB"""
        if value <= 0:
            return -96.0
        return 20.0 * np.log10(value)

    def _db_to_linear(self, db: float) -> float:
        """Convert dB to linear value"""
        return 10.0 ** (db / 20.0)

    def draw(self, data: Dict[str, Any] = None):
        """Draw the meters panel"""
        # Clear background
        pygame.draw.rect(self.screen, self.bg_color, self.rect)
        pygame.draw.rect(self.screen, self.border_color, self.rect, 2)

        # Title
        title = self.font_large.render("METERS", True, self.text_color)
        title_rect = title.get_rect(centerx=self.x + self.width // 2, y=self.y + 5)
        self.screen.blit(title, title_rect)

        # Draw meters based on layout
        meter_y = self.y + 35
        meter_height = (self.height - 45) // 3

        # VU Meter
        self._draw_meter(
            "VU",
            self.vu_value,
            self.x + 10,
            meter_y,
            self.width - 20,
            meter_height - 10,
            meter_type="vu",
            peak_hold=self.peak_hold_values.get("vu", 0),
        )
        meter_y += meter_height

        # PPM Meter
        self._draw_meter(
            "PPM",
            self.ppm_value,
            self.x + 10,
            meter_y,
            self.width - 20,
            meter_height - 10,
            meter_type="ppm",
            peak_hold=self.peak_hold_values.get("ppm", 0),
        )
        meter_y += meter_height

        # RMS/Peak Meter
        self._draw_meter(
            "RMS/Peak",
            self.rms_value,
            self.x + 10,
            meter_y,
            self.width - 20,
            meter_height - 10,
            meter_type="rms",
            peak_value=self.peak_value,
            peak_hold=self.peak_hold_values.get("peak", 0),
        )

    def _draw_meter(
        self,
        name: str,
        value: float,
        x: int,
        y: int,
        width: int,
        height: int,
        meter_type: str = "vu",
        peak_value: Optional[float] = None,
        peak_hold: float = 0,
    ):
        """Draw an individual meter"""
        # Background
        meter_rect = pygame.Rect(x, y, width, height)
        pygame.draw.rect(self.screen, (15, 17, 22), meter_rect)
        pygame.draw.rect(self.screen, self.grid_color, meter_rect, 1)

        # Label
        label = self.font_medium.render(name, True, self.text_color)
        self.screen.blit(label, (x + 5, y + 2))

        # Meter area
        meter_x = x + 5
        meter_y = y + 25
        meter_width = width - 10
        meter_height = height - 30

        # Draw scale
        self._draw_meter_scale(meter_x, meter_y, meter_width, meter_height, meter_type)

        # Draw meter bar
        db_value = self._linear_to_db(value)
        if meter_type == "vu":
            # VU scale: -20 to +3 dB
            normalized = (db_value + 20) / 23.0
        elif meter_type == "ppm":
            # PPM scale: -40 to +5 dB
            normalized = (db_value + 40) / 45.0
        else:
            # RMS/Peak scale: -60 to 0 dB
            normalized = (db_value + 60) / 60.0

        normalized = np.clip(normalized, 0, 1)

        # Draw main bar
        bar_width = int(normalized * meter_width)
        if bar_width > 0:
            # Color coding
            if db_value > -3:
                color = self.meter_red
            elif db_value > -10:
                color = self.meter_yellow
            else:
                color = self.meter_green

            bar_rect = pygame.Rect(meter_x, meter_y + 2, bar_width, meter_height - 4)
            pygame.draw.rect(self.screen, color, bar_rect)

        # Draw peak indicator if provided
        if peak_value is not None:
            peak_db = self._linear_to_db(peak_value)
            if meter_type == "rms":
                peak_normalized = (peak_db + 60) / 60.0
            else:
                peak_normalized = normalized  # Use same scale

            peak_normalized = np.clip(peak_normalized, 0, 1)
            peak_x = meter_x + int(peak_normalized * meter_width)
            pygame.draw.line(
                self.screen,
                (255, 255, 255),
                (peak_x, meter_y),
                (peak_x, meter_y + meter_height),
                2,
            )

        # Draw peak hold
        if peak_hold > 0:
            hold_db = self._linear_to_db(peak_hold)
            if meter_type == "vu":
                hold_normalized = (hold_db + 20) / 23.0
            elif meter_type == "ppm":
                hold_normalized = (hold_db + 40) / 45.0
            else:
                hold_normalized = (hold_db + 60) / 60.0

            hold_normalized = np.clip(hold_normalized, 0, 1)
            hold_x = meter_x + int(hold_normalized * meter_width)
            pygame.draw.line(
                self.screen,
                (255, 200, 100),
                (hold_x, meter_y - 2),
                (hold_x, meter_y + meter_height + 2),
                1,
            )

    def _draw_meter_scale(
        self, x: int, y: int, width: int, height: int, meter_type: str
    ):
        """Draw meter scale markings"""
        # Scale markings based on meter type
        if meter_type == "vu":
            # VU scale: -20 to +3 dB
            marks = [-20, -10, -7, -5, -3, 0, 1, 2, 3]
            range_db = 23.0
            offset_db = 20.0
        elif meter_type == "ppm":
            # PPM scale: -40 to +5 dB
            marks = [-40, -30, -20, -10, -5, 0, 5]
            range_db = 45.0
            offset_db = 40.0
        else:
            # RMS/Peak scale: -60 to 0 dB
            marks = [-60, -50, -40, -30, -20, -10, -6, -3, 0]
            range_db = 60.0
            offset_db = 60.0

        # Draw scale marks
        for mark in marks:
            normalized = (mark + offset_db) / range_db
            mark_x = x + int(normalized * width)

            # Draw tick
            pygame.draw.line(
                self.screen, self.grid_color, (mark_x, y - 5), (mark_x, y), 1
            )

            # Draw label for major marks
            if mark % 10 == 0 or mark == -3 or mark == 3:
                label = self.font_small.render(str(mark), True, (150, 150, 170))
                label_rect = label.get_rect(centerx=mark_x, y=y - 18)
                self.screen.blit(label, label_rect)

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle input events"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_m:
                # Cycle through meter types
                self.current_meter = (self.current_meter + 1) % len(self.meter_types)
                return True
            elif event.key == pygame.K_r:
                # Reset peak holds
                self.peak_hold_values.clear()
                self.peak_hold_times.clear()
                return True

        return False
