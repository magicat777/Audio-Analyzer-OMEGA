"""
VU meter display panel with classic analog-style meters
"""

import math
import time
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class VUMetersPanel:
    """Classic VU meter visualization panel"""

    def __init__(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        self.screen = surface
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)

        # Fonts
        self.font_tiny = pygame.font.Font(None, 14)
        self.font_small = pygame.font.Font(None, 18)
        self.font_medium = pygame.font.Font(None, 22)
        self.font_large = pygame.font.Font(None, 28)

        # Colors
        self.bg_color = (25, 25, 30)
        self.border_color = (60, 65, 75)
        self.text_color = (200, 200, 220)
        self.meter_bg_color = (40, 40, 45)

        # VU meter colors
        self.scale_color = (180, 180, 200)
        self.needle_color = (255, 100, 100)
        self.peak_color = (255, 200, 100)

        # Meter zones
        self.green_zone = (-20, -7)
        self.yellow_zone = (-7, 0)
        self.red_zone = (0, 3)

        # Meter configuration
        self.num_meters = 2  # Stereo
        self.meter_range = (-20, 3)  # dB range
        self.meter_angle_range = (-45, 45)  # degrees

        # Meter state
        self.left_value = -60.0
        self.right_value = -60.0
        self.left_peak = -60.0
        self.right_peak = -60.0
        self.mono_value = -60.0

        # Meter dynamics
        self.ballistics = {
            "attack": 0.3,  # 300ms rise time (VU standard)
            "release": 0.3,  # 300ms fall time
            "peak_hold": 2.0,  # 2 second peak hold
        }

        # Peak hold tracking
        self.left_peak_time = 0
        self.right_peak_time = 0

        # Needle animation
        self.left_needle_angle = -45
        self.right_needle_angle = -45
        self.left_needle_velocity = 0
        self.right_needle_velocity = 0
        self.needle_damping = 0.85

        # Display modes
        self.display_modes = ["Classic VU", "PPM", "BBC", "Nordic"]
        self.current_mode = 0

        # Correlation meter
        self.correlation_value = 0
        self.correlation_history = []

        # Animation
        self.last_update = time.time()
        self.lamp_glow = 0
        self.lamp_phase = 0

    def update(self, audio_data: Dict[str, Any]):
        """Update VU meter values"""
        current_time = time.time()
        dt = current_time - self.last_update
        self.last_update = current_time

        # Update lamp animation
        self.lamp_phase += dt * 2
        self.lamp_glow = 0.7 + 0.3 * np.sin(self.lamp_phase)

        # Get audio levels
        if "left_level" in audio_data and "right_level" in audio_data:
            target_left = self._linear_to_db(audio_data["left_level"])
            target_right = self._linear_to_db(audio_data["right_level"])

            # Apply ballistics
            self._update_meter_value("left", target_left, dt)
            self._update_meter_value("right", target_right, dt)

            # Update mono
            self.mono_value = self._linear_to_db(
                (audio_data["left_level"] + audio_data["right_level"]) / 2
            )

            # Update correlation
            if "correlation" in audio_data:
                self.correlation_value = audio_data["correlation"]
                self.correlation_history.append(self.correlation_value)
                if len(self.correlation_history) > 100:
                    self.correlation_history.pop(0)

        # Update needle physics
        self._update_needle_physics(dt)

    def _update_meter_value(self, channel: str, target_db: float, dt: float):
        """Update meter value with proper ballistics"""
        if channel == "left":
            current = self.left_value
            peak = self.left_peak
            peak_time = self.left_peak_time
        else:
            current = self.right_value
            peak = self.right_peak
            peak_time = self.right_peak_time

        # Apply VU ballistics
        if target_db > current:
            # Attack (rise)
            rate = dt / self.ballistics["attack"]
            new_value = current + (target_db - current) * min(1.0, rate)
        else:
            # Release (fall)
            rate = dt / self.ballistics["release"]
            new_value = current + (target_db - current) * min(1.0, rate)

        # Update peak
        if new_value > peak or time.time() - peak_time > self.ballistics["peak_hold"]:
            peak = new_value
            peak_time = time.time()

        # Store values
        if channel == "left":
            self.left_value = new_value
            self.left_peak = peak
            self.left_peak_time = peak_time
        else:
            self.right_value = new_value
            self.right_peak = peak
            self.right_peak_time = peak_time

    def _update_needle_physics(self, dt: float):
        """Update needle physics simulation"""
        # Left needle
        target_angle = self._db_to_angle(self.left_value)
        angle_diff = target_angle - self.left_needle_angle
        self.left_needle_velocity += angle_diff * 0.2
        self.left_needle_velocity *= self.needle_damping
        self.left_needle_angle += self.left_needle_velocity * dt * 60

        # Right needle
        target_angle = self._db_to_angle(self.right_value)
        angle_diff = target_angle - self.right_needle_angle
        self.right_needle_velocity += angle_diff * 0.2
        self.right_needle_velocity *= self.needle_damping
        self.right_needle_angle += self.right_needle_velocity * dt * 60

    def _linear_to_db(self, value: float) -> float:
        """Convert linear value to dB"""
        if value <= 0:
            return -60.0
        return 20.0 * np.log10(value)

    def _db_to_angle(self, db: float) -> float:
        """Convert dB value to needle angle"""
        # Clamp to meter range
        db = np.clip(db, self.meter_range[0], self.meter_range[1])

        # Normalize to 0-1
        normalized = (db - self.meter_range[0]) / (
            self.meter_range[1] - self.meter_range[0]
        )

        # Convert to angle
        angle = self.meter_angle_range[0] + normalized * (
            self.meter_angle_range[1] - self.meter_angle_range[0]
        )
        return angle

    def draw(self, data=None):
        """Draw the VU meters panel"""
        # Clear background with vintage color
        pygame.draw.rect(self.screen, self.bg_color, self.rect)

        # Draw decorative border
        self._draw_vintage_border()

        # Title with mode
        title_text = f"VU METERS - {self.display_modes[self.current_mode]}"
        title = self.font_large.render(title_text, True, self.text_color)
        title_rect = title.get_rect(centerx=self.x + self.width // 2, y=self.y + 10)
        self.screen.blit(title, title_rect)

        # Calculate meter positions
        meter_width = (self.width - 60) // 2
        meter_height = self.height - 180
        left_meter_x = self.x + 20
        right_meter_x = self.x + self.width // 2 + 10
        meter_y = self.y + 50

        # Draw meters
        self._draw_vu_meter(
            "LEFT",
            self.left_value,
            self.left_peak,
            self.left_needle_angle,
            left_meter_x,
            meter_y,
            meter_width,
            meter_height,
        )

        self._draw_vu_meter(
            "RIGHT",
            self.right_value,
            self.right_peak,
            self.right_needle_angle,
            right_meter_x,
            meter_y,
            meter_width,
            meter_height,
        )

        # Draw correlation meter
        self._draw_correlation_meter(self.y + self.height - 110)

        # Draw level indicators
        self._draw_level_indicators(self.y + self.height - 50)

    def _draw_vintage_border(self):
        """Draw vintage-style decorative border"""
        # Outer border
        pygame.draw.rect(self.screen, self.border_color, self.rect, 3)

        # Inner border
        inner_rect = pygame.Rect(
            self.x + 5, self.y + 5, self.width - 10, self.height - 10
        )
        pygame.draw.rect(self.screen, (50, 55, 65), inner_rect, 1)

        # Corner decorations
        corner_size = 20
        corners = [
            (self.x, self.y),
            (self.x + self.width - corner_size, self.y),
            (self.x, self.y + self.height - corner_size),
            (self.x + self.width - corner_size, self.y + self.height - corner_size),
        ]

        for cx, cy in corners:
            # Decorative corner lines
            pygame.draw.lines(
                self.screen,
                (100, 105, 115),
                False,
                [(cx + corner_size, cy), (cx, cy), (cx, cy + corner_size)],
                2,
            )

    def _draw_vu_meter(
        self,
        label: str,
        value: float,
        peak: float,
        needle_angle: float,
        x: int,
        y: int,
        width: int,
        height: int,
    ):
        """Draw a single VU meter"""
        center_x = x + width // 2
        center_y = y + height - 30
        radius = min(width, height) - 40

        # Meter background
        meter_rect = pygame.Rect(x, y, width, height)
        pygame.draw.rect(self.screen, self.meter_bg_color, meter_rect)
        pygame.draw.rect(self.screen, self.border_color, meter_rect, 2)

        # Draw meter face
        pygame.draw.circle(self.screen, (35, 35, 40), (center_x, center_y), radius)
        pygame.draw.circle(
            self.screen, self.border_color, (center_x, center_y), radius, 2
        )

        # Draw scale arc
        start_angle = math.radians(180 + self.meter_angle_range[0])
        end_angle = math.radians(180 + self.meter_angle_range[1])

        # Scale markings
        db_marks = [-20, -10, -7, -5, -3, -1, 0, 1, 2, 3]
        for db in db_marks:
            angle = math.radians(180 + self._db_to_angle(db))

            # Tick marks
            inner_r = radius - 10
            outer_r = radius - 5 if db % 10 == 0 else radius - 7

            x1 = center_x + int(math.cos(angle) * inner_r)
            y1 = center_y + int(math.sin(angle) * inner_r)
            x2 = center_x + int(math.cos(angle) * outer_r)
            y2 = center_y + int(math.sin(angle) * outer_r)

            # Color based on zone
            if db <= self.green_zone[1]:
                color = (100, 200, 100)
            elif db <= self.yellow_zone[1]:
                color = (255, 255, 100)
            else:
                color = (255, 100, 100)

            pygame.draw.line(self.screen, color, (x1, y1), (x2, y2), 2)

            # Scale numbers
            if db % 5 == 0 or db == -7 or db == 3:
                text = str(db) if db <= 0 else f"+{db}"
                label_surface = self.font_tiny.render(text, True, self.scale_color)
                label_x = center_x + int(math.cos(angle) * (radius - 20))
                label_y = center_y + int(math.sin(angle) * (radius - 20))
                label_rect = label_surface.get_rect(center=(label_x, label_y))
                self.screen.blit(label_surface, label_rect)

        # Draw colored zones
        self._draw_meter_zones(center_x, center_y, radius)

        # Draw needle
        needle_angle_rad = math.radians(180 + needle_angle)
        needle_length = radius - 25
        needle_x = center_x + int(math.cos(needle_angle_rad) * needle_length)
        needle_y = center_y + int(math.sin(needle_angle_rad) * needle_length)

        # Needle shadow
        shadow_x = needle_x + 2
        shadow_y = needle_y + 2
        pygame.draw.line(
            self.screen,
            (20, 20, 25),
            (center_x + 2, center_y + 2),
            (shadow_x, shadow_y),
            3,
        )

        # Main needle
        pygame.draw.line(
            self.screen,
            self.needle_color,
            (center_x, center_y),
            (needle_x, needle_y),
            3,
        )

        # Needle pivot
        pygame.draw.circle(self.screen, (80, 80, 90), (center_x, center_y), 8)
        pygame.draw.circle(self.screen, (60, 60, 70), (center_x, center_y), 5)

        # Peak indicator
        if peak > self.meter_range[0]:
            peak_angle_rad = math.radians(180 + self._db_to_angle(peak))
            peak_x = center_x + int(math.cos(peak_angle_rad) * (radius - 35))
            peak_y = center_y + int(math.sin(peak_angle_rad) * (radius - 35))
            pygame.draw.circle(self.screen, self.peak_color, (peak_x, peak_y), 3)

        # Channel label
        label_surface = self.font_medium.render(label, True, self.text_color)
        label_rect = label_surface.get_rect(centerx=center_x, y=y + 5)
        self.screen.blit(label_surface, label_rect)

        # VU label at bottom
        vu_label = self.font_small.render("VU", True, (150, 150, 170))
        vu_rect = vu_label.get_rect(centerx=center_x, y=center_y + 15)
        self.screen.blit(vu_label, vu_rect)

        # Current value display
        value_text = f"{value:.1f} dB"
        value_surface = self.font_small.render(value_text, True, self.text_color)
        value_rect = value_surface.get_rect(centerx=center_x, y=y + height - 20)
        self.screen.blit(value_surface, value_rect)

    def _draw_meter_zones(self, center_x: int, center_y: int, radius: int):
        """Draw colored zones on meter"""
        # Create arc segments for each zone
        arc_width = 15
        arc_radius = radius - 30

        # Green zone
        green_start = math.radians(180 + self._db_to_angle(self.green_zone[0]))
        green_end = math.radians(180 + self._db_to_angle(self.green_zone[1]))
        self._draw_arc_segment(
            center_x,
            center_y,
            arc_radius,
            arc_width,
            green_start,
            green_end,
            (50, 150, 50, 100),
        )

        # Yellow zone
        yellow_start = math.radians(180 + self._db_to_angle(self.yellow_zone[0]))
        yellow_end = math.radians(180 + self._db_to_angle(self.yellow_zone[1]))
        self._draw_arc_segment(
            center_x,
            center_y,
            arc_radius,
            arc_width,
            yellow_start,
            yellow_end,
            (200, 200, 50, 100),
        )

        # Red zone
        red_start = math.radians(180 + self._db_to_angle(self.red_zone[0]))
        red_end = math.radians(180 + self._db_to_angle(self.red_zone[1]))
        self._draw_arc_segment(
            center_x,
            center_y,
            arc_radius,
            arc_width,
            red_start,
            red_end,
            (200, 50, 50, 100),
        )

    def _draw_arc_segment(
        self,
        cx: int,
        cy: int,
        radius: int,
        width: int,
        start_angle: float,
        end_angle: float,
        color: Tuple[int, int, int, int],
    ):
        """Draw an arc segment with transparency"""
        # Create points for the arc
        num_points = 20
        points = []

        for i in range(num_points + 1):
            angle = start_angle + (end_angle - start_angle) * i / num_points

            # Outer edge
            x_out = cx + int(math.cos(angle) * radius)
            y_out = cy + int(math.sin(angle) * radius)
            points.append((x_out, y_out))

        # Inner edge (reverse order)
        for i in range(num_points, -1, -1):
            angle = start_angle + (end_angle - start_angle) * i / num_points

            # Inner edge
            x_in = cx + int(math.cos(angle) * (radius - width))
            y_in = cy + int(math.sin(angle) * (radius - width))
            points.append((x_in, y_in))

        # Draw filled polygon with transparency
        if len(points) > 2:
            # Create surface for transparency
            arc_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            pygame.draw.polygon(arc_surface, color, points)
            self.screen.blit(arc_surface, (self.x, self.y))

    def _draw_correlation_meter(self, y: int):
        """Draw stereo correlation meter"""
        meter_x = self.x + 40
        meter_width = self.width - 80
        meter_height = 40

        # Background
        meter_rect = pygame.Rect(meter_x, y, meter_width, meter_height)
        pygame.draw.rect(self.screen, self.meter_bg_color, meter_rect)
        pygame.draw.rect(self.screen, self.border_color, meter_rect, 2)

        # Title
        title = self.font_small.render("STEREO CORRELATION", True, self.text_color)
        title_rect = title.get_rect(centerx=self.x + self.width // 2, y=y - 20)
        self.screen.blit(title, title_rect)

        # Scale markings
        marks = [-1, -0.5, 0, 0.5, 1]
        for mark in marks:
            x_pos = meter_x + int((mark + 1) / 2 * meter_width)
            pygame.draw.line(
                self.screen, self.scale_color, (x_pos, y), (x_pos, y + 10), 1
            )

            # Labels
            label_text = "L" if mark == -1 else "R" if mark == 1 else str(mark)
            label = self.font_tiny.render(label_text, True, self.scale_color)
            label_rect = label.get_rect(centerx=x_pos, y=y + meter_height - 15)
            self.screen.blit(label, label_rect)

        # Draw correlation history
        if self.correlation_history:
            points = []
            for i, corr in enumerate(self.correlation_history):
                x_pos = meter_x + int(i * meter_width / len(self.correlation_history))
                y_pos = y + meter_height // 2 - int(corr * meter_height // 2)
                points.append((x_pos, y_pos))

            if len(points) > 1:
                pygame.draw.lines(self.screen, (100, 200, 255), False, points, 1)

        # Current value indicator
        if self.correlation_value is not None:
            x_pos = meter_x + int((self.correlation_value + 1) / 2 * meter_width)
            pygame.draw.line(
                self.screen, (255, 255, 100), (x_pos, y), (x_pos, y + meter_height), 2
            )

            # Value text
            value_text = f"{self.correlation_value:.2f}"
            value_surface = self.font_small.render(value_text, True, (255, 255, 100))
            value_rect = value_surface.get_rect(centerx=x_pos, y=y - 35)
            self.screen.blit(value_surface, value_rect)

    def _draw_level_indicators(self, y: int):
        """Draw digital level readouts"""
        # Background
        ind_rect = pygame.Rect(self.x + 20, y, self.width - 40, 40)
        pygame.draw.rect(self.screen, (30, 30, 35), ind_rect)
        pygame.draw.rect(self.screen, self.border_color, ind_rect, 1)

        # Calculate positions
        section_width = (self.width - 40) // 3

        # Left channel
        left_text = f"L: {self.left_value:.1f}dB"
        left_color = self._get_level_color(self.left_value)
        left_surface = self.font_medium.render(left_text, True, left_color)
        left_rect = left_surface.get_rect(
            center=(self.x + 20 + section_width // 2, y + 20)
        )
        self.screen.blit(left_surface, left_rect)

        # Mono/Sum
        mono_text = f"M: {self.mono_value:.1f}dB"
        mono_color = self._get_level_color(self.mono_value)
        mono_surface = self.font_medium.render(mono_text, True, mono_color)
        mono_rect = mono_surface.get_rect(center=(self.x + self.width // 2, y + 20))
        self.screen.blit(mono_surface, mono_rect)

        # Right channel
        right_text = f"R: {self.right_value:.1f}dB"
        right_color = self._get_level_color(self.right_value)
        right_surface = self.font_medium.render(right_text, True, right_color)
        right_rect = right_surface.get_rect(
            center=(self.x + self.width - 20 - section_width // 2, y + 20)
        )
        self.screen.blit(right_surface, right_rect)

    def _get_level_color(self, db: float) -> Tuple[int, int, int]:
        """Get color based on dB level"""
        if db <= self.green_zone[1]:
            return (100, 200, 100)
        elif db <= self.yellow_zone[1]:
            return (255, 255, 100)
        else:
            return (255, 100, 100)

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle input events"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_v:
                # Cycle through display modes
                self.current_mode = (self.current_mode + 1) % len(self.display_modes)

                # Adjust ballistics for different modes
                if self.display_modes[self.current_mode] == "PPM":
                    self.ballistics["attack"] = 0.005
                    self.ballistics["release"] = 1.5
                elif self.display_modes[self.current_mode] == "BBC":
                    self.ballistics["attack"] = 0.01
                    self.ballistics["release"] = 2.8
                else:  # VU or Nordic
                    self.ballistics["attack"] = 0.3
                    self.ballistics["release"] = 0.3

                return True

            elif event.key == pygame.K_r:
                # Reset peaks
                self.left_peak = -60.0
                self.right_peak = -60.0
                self.left_peak_time = 0
                self.right_peak_time = 0
                return True

        return False
