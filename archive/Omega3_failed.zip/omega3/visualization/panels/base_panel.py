"""
Base panel class for OMEGA-3 visualization panels
"""

from abc import ABC
from abc import abstractmethod
from typing import Any
from typing import Dict
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class AnalysisPanel(ABC):
    """Base class for all analysis panels"""

    def __init__(self, screen: pygame.Surface, x: int, y: int, width: int, height: int):
        self.screen = screen
        self.rect = pygame.Rect(x, y, width, height)
        self.x = x
        self.y = y
        self.width = width
        self.height = height

        # Colors
        self.bg_color = (15, 15, 25)
        self.border_color = (60, 60, 80)
        self.text_color = (200, 200, 220)
        self.accent_color = (100, 150, 255)

        # Fonts
        self.font_small = pygame.font.Font(None, 20)
        self.font_medium = pygame.font.Font(None, 24)
        self.font_large = pygame.font.Font(None, 32)

    @abstractmethod
    def draw(self, data: Dict[str, Any]):
        """Draw the panel with given data"""
        pass

    def draw_background(self, title: str = ""):
        """Draw panel background and border"""
        # Background
        pygame.draw.rect(self.screen, self.bg_color, self.rect)
        pygame.draw.rect(self.screen, self.border_color, self.rect, 2)

        # Title
        if title:
            title_surface = self.font_medium.render(title, True, self.text_color)
            title_rect = title_surface.get_rect(
                centerx=self.x + self.width // 2, y=self.y + 5
            )
            self.screen.blit(title_surface, title_rect)

    def draw_text(
        self,
        text: str,
        x: int,
        y: int,
        color: Optional[Tuple[int, int, int]] = None,
        font=None,
    ):
        """Draw text at position"""
        if color is None:
            color = self.text_color
        if font is None:
            font = self.font_small

        text_surface = font.render(text, True, color)
        self.screen.blit(text_surface, (self.x + x, self.y + y))

    def draw_bar(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        value: float,
        color: Optional[Tuple[int, int, int]] = None,
    ):
        """Draw a value bar"""
        if color is None:
            color = self.accent_color

        # Background
        bg_rect = pygame.Rect(self.x + x, self.y + y, width, height)
        pygame.draw.rect(self.screen, (30, 30, 40), bg_rect)
        pygame.draw.rect(self.screen, self.border_color, bg_rect, 1)

        # Value bar
        if value > 0:
            bar_height = int(height * min(value, 1.0))
            bar_rect = pygame.Rect(
                self.x + x, self.y + y + height - bar_height, width, bar_height
            )
            pygame.draw.rect(self.screen, color, bar_rect)

    def draw_line_graph(
        self,
        data: np.ndarray,
        x: int,
        y: int,
        width: int,
        height: int,
        color: Optional[Tuple[int, int, int]] = None,
    ):
        """Draw a line graph"""
        if color is None:
            color = self.accent_color

        if len(data) < 2:
            return

        # Background
        bg_rect = pygame.Rect(self.x + x, self.y + y, width, height)
        pygame.draw.rect(self.screen, (20, 20, 30), bg_rect)
        pygame.draw.rect(self.screen, self.border_color, bg_rect, 1)

        # Scale data
        if np.max(data) > 0:
            normalized_data = data / np.max(data)
        else:
            normalized_data = data

        # Draw lines
        points = []
        for i, value in enumerate(normalized_data):
            px = self.x + x + int(i * width / len(data))
            py = self.y + y + height - int(value * height)
            points.append((px, py))

        if len(points) > 1:
            pygame.draw.lines(self.screen, color, False, points, 2)

    def clear(self):
        """Clear the panel background"""
        pygame.draw.rect(self.screen, self.bg_color, self.rect)

    def draw_border(self, color: Optional[Tuple[int, int, int]] = None):
        """Draw panel border"""
        border_color = color if color else self.border_color
        pygame.draw.rect(self.screen, border_color, self.rect, 2)

    def draw_title(self, title: str, color: Optional[Tuple[int, int, int]] = None):
        """Draw panel title"""
        title_color = color if color else self.text_color
        title_surface = self.font_medium.render(title, True, title_color)
        title_rect = title_surface.get_rect(
            centerx=self.x + self.width // 2, y=self.y + 5
        )
        self.screen.blit(title_surface, title_rect)
