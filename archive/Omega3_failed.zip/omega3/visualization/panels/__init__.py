"""
Visualization panels for OMEGA-3.
Professional audio analysis display panels
"""

from .bass_detail import BassDetailPanel
from .chromagram import ChromagramPanel
from .drum_panel import DrumPanel
from .genre import GenrePanel
from .harmonic import HarmonicPanel
from .meter_panel import MeterPanel
from .meters import MetersPanel
from .pitch import PitchPanel
from .spectrogram_panel import SpectrogramPanel
from .spectrum_panel import SpectrumPanel
from .technical import TechnicalPanel
from .voice import VoicePanel
from .vu_meters import VUMetersPanel
from .waveform_panel import WaveformPanel

__all__ = [
    "SpectrumPanel",
    "WaveformPanel",
    "SpectrogramPanel",
    "MeterPanel",
    "HarmonicPanel",
    "VoicePanel",
    "PitchPanel",
    "ChromagramPanel",
    "GenrePanel",
    "BassDetailPanel",
    "VUMetersPanel",
    "TechnicalPanel",
    "MetersPanel",
    "DrumPanel",
]
