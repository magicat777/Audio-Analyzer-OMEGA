"""
Bass detail zoom window for low frequency analysis
"""

import time
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class BassDetailPanel:
    """Detailed bass frequency analysis panel"""

    def __init__(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        self.screen = surface
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)

        # Fonts
        self.font_small = pygame.font.Font(None, 16)
        self.font_medium = pygame.font.Font(None, 20)
        self.font_large = pygame.font.Font(None, 26)

        # Colors
        self.bg_color = (10, 12, 18)
        self.border_color = (40, 45, 55)
        self.text_color = (200, 200, 220)
        self.grid_color = (25, 30, 40)

        # Bass frequency colors (gradient from deep to mid bass)
        self.bass_colors = [
            (50, 0, 100),  # Sub-bass (20-60 Hz) - Deep purple
            (100, 0, 150),  # Bass (60-250 Hz) - Purple
            (150, 50, 200),  # Low-mid (250-500 Hz) - Light purple
            (200, 100, 255),  # Mid (500-2k Hz) - Lavender
        ]

        # Frequency ranges
        self.frequency_ranges = {
            "Sub-bass": (20, 60),
            "Bass": (60, 250),
            "Low-mid": (250, 500),
            "Mid": (500, 2000),
        }

        # Analysis data
        self.spectrum_data = None
        self.bass_peaks = []
        self.bass_energy_history = []
        self.sub_bass_history = []
        self.bass_note_history = []
        self.history_length = 200

        # Visualization settings
        self.zoom_level = 1.0
        self.frequency_offset = 0
        self.max_frequency = 500  # Focus on bass frequencies
        self.show_harmonics = True
        self.show_notes = True
        self.show_phase = False

        # Peak detection
        self.peak_hold_time = 2.0
        self.peak_holds = {}
        self.peak_timestamps = {}

        # Animation
        self.animation_phase = 0
        self.waveform_offset = 0
        self.last_update = time.time()

        # Bass enhancement detection
        self.bass_boost_detected = False
        self.resonance_peaks = []

    def update(self, audio_data: Dict[str, Any]):
        """Update bass analysis data"""
        current_time = time.time()
        dt = current_time - self.last_update
        self.last_update = current_time

        # Update animation
        self.animation_phase += dt * 3
        self.waveform_offset += dt * 50

        # Update spectrum data
        if "spectrum" in audio_data:
            self.spectrum_data = audio_data["spectrum"]
            self._analyze_bass_content()

        # Update bass energy
        if "bass_energy" in audio_data:
            bass_energy = audio_data["bass_energy"]
            self.bass_energy_history.append(bass_energy)
            if len(self.bass_energy_history) > self.history_length:
                self.bass_energy_history.pop(0)

        # Update sub-bass
        if "sub_bass_energy" in audio_data:
            sub_bass = audio_data["sub_bass_energy"]
            self.sub_bass_history.append(sub_bass)
            if len(self.sub_bass_history) > self.history_length:
                self.sub_bass_history.pop(0)

        # Detect bass notes
        if "bass_note" in audio_data:
            note = audio_data["bass_note"]
            self.bass_note_history.append(note)
            if len(self.bass_note_history) > 50:
                self.bass_note_history.pop(0)

    def _analyze_bass_content(self):
        """Analyze bass frequency content"""
        if not self.spectrum_data:
            return

        freqs = self.spectrum_data.get("frequencies", [])
        magnitudes = self.spectrum_data.get("magnitudes", [])

        if not freqs or not magnitudes:
            return

        # Find peaks in bass region
        self.bass_peaks = []
        self.resonance_peaks = []

        # Focus on bass frequencies
        bass_mask = (freqs >= 20) & (freqs <= self.max_frequency)
        bass_freqs = freqs[bass_mask]
        bass_mags = magnitudes[bass_mask]

        if len(bass_mags) > 0:
            # Find local maxima
            for i in range(1, len(bass_mags) - 1):
                if bass_mags[i] > bass_mags[i - 1] and bass_mags[i] > bass_mags[i + 1]:
                    if bass_mags[i] > np.mean(bass_mags) * 1.5:
                        peak_freq = bass_freqs[i]
                        peak_mag = bass_mags[i]
                        self.bass_peaks.append(
                            {
                                "frequency": peak_freq,
                                "magnitude": peak_mag,
                                "note": self._freq_to_note(peak_freq),
                            }
                        )

                        # Check for resonance
                        if peak_mag > np.mean(bass_mags) * 3:
                            self.resonance_peaks.append(peak_freq)

            # Update peak holds
            for peak in self.bass_peaks:
                freq = peak["frequency"]
                mag = peak["magnitude"]

                if freq not in self.peak_holds or mag > self.peak_holds[freq]:
                    self.peak_holds[freq] = mag
                    self.peak_timestamps[freq] = time.time()

            # Clean old peak holds
            current_time = time.time()
            for freq in list(self.peak_holds.keys()):
                if current_time - self.peak_timestamps[freq] > self.peak_hold_time:
                    del self.peak_holds[freq]
                    del self.peak_timestamps[freq]

            # Detect bass boost
            avg_bass = np.mean(bass_mags)
            if len(magnitudes) > len(bass_mags):
                avg_total = np.mean(magnitudes)
                self.bass_boost_detected = avg_bass > avg_total * 2

    def _freq_to_note(self, freq: float) -> str:
        """Convert frequency to musical note"""
        if freq <= 0:
            return ""

        A4 = 440.0
        notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

        # Calculate semitones from A4
        semitones = 12 * np.log2(freq / A4)

        # Find octave and note
        octave = int(4 + (semitones + 9) / 12)
        note_index = int(round(semitones + 9)) % 12

        return f"{notes[note_index]}{octave}"

    def draw(self, data=None):
        """Draw the bass detail panel"""
        # Clear background
        pygame.draw.rect(self.screen, self.bg_color, self.rect)
        pygame.draw.rect(self.screen, self.border_color, self.rect, 2)

        # Title
        title = self.font_large.render("BASS DETAIL", True, self.text_color)
        title_rect = title.get_rect(centerx=self.x + self.width // 2, y=self.y + 5)
        self.screen.blit(title, title_rect)

        # Bass boost indicator
        if self.bass_boost_detected:
            boost_text = "BASS BOOST"
            boost_color = (255, 100, 100)
            boost_surface = self.font_small.render(boost_text, True, boost_color)
            self.screen.blit(boost_surface, (self.x + self.width - 80, self.y + 10))

        # Main visualization area
        viz_y = self.y + 35
        viz_height = self.height - 100

        # Draw spectrum
        self._draw_bass_spectrum(viz_y, viz_height)

        # Draw frequency ranges
        self._draw_frequency_ranges(viz_y, viz_height)

        # Draw bass energy timeline
        self._draw_energy_timeline(self.y + self.height - 60)

        # Draw current bass info
        self._draw_bass_info(self.x + self.width - 200, viz_y)

    def _draw_bass_spectrum(self, y: int, height: int):
        """Draw detailed bass spectrum"""
        spec_x = self.x + 60
        spec_width = self.width - 80

        # Background
        pygame.draw.rect(self.screen, (15, 17, 23), (spec_x, y, spec_width, height))
        pygame.draw.rect(
            self.screen, self.grid_color, (spec_x, y, spec_width, height), 1
        )

        if not self.spectrum_data:
            return

        freqs = self.spectrum_data.get("frequencies", [])
        magnitudes = self.spectrum_data.get("magnitudes", [])

        if not freqs or not magnitudes:
            return

        # Focus on bass frequencies
        bass_mask = (freqs >= 20) & (freqs <= self.max_frequency)
        bass_freqs = freqs[bass_mask]
        bass_mags = magnitudes[bass_mask]

        if len(bass_mags) == 0:
            return

        # Normalize magnitudes
        max_mag = np.max(bass_mags) if np.max(bass_mags) > 0 else 1

        # Draw frequency grid
        for freq in [30, 60, 100, 200, 300, 400, 500]:
            if freq <= self.max_frequency:
                x_pos = spec_x + int(
                    (freq - 20) / (self.max_frequency - 20) * spec_width
                )
                pygame.draw.line(
                    self.screen, self.grid_color, (x_pos, y), (x_pos, y + height), 1
                )

                # Frequency label
                label = self.font_small.render(f"{freq}Hz", True, (100, 100, 120))
                label_rect = label.get_rect(centerx=x_pos, y=y + height + 2)
                self.screen.blit(label, label_rect)

        # Draw magnitude lines
        for db in [-60, -40, -20, 0]:
            y_pos = y + int((1 - (db + 60) / 60) * height)
            pygame.draw.line(
                self.screen,
                self.grid_color,
                (spec_x, y_pos),
                (spec_x + spec_width, y_pos),
                1,
            )

            # dB label
            label = self.font_small.render(f"{db}dB", True, (100, 100, 120))
            self.screen.blit(label, (spec_x - 35, y_pos - 8))

        # Draw spectrum curve with gradient fill
        points = []
        for i, (freq, mag) in enumerate(zip(bass_freqs, bass_mags)):
            x_pos = spec_x + int((freq - 20) / (self.max_frequency - 20) * spec_width)

            # Convert to dB
            db = 20 * np.log10(mag / max_mag + 1e-10)
            normalized = (db + 60) / 60  # -60dB to 0dB range
            normalized = np.clip(normalized, 0, 1)

            y_pos = y + int((1 - normalized) * height)
            points.append((x_pos, y_pos))

        if len(points) > 1:
            # Draw filled area with gradient
            bottom_points = [(p[0], y + height) for p in points]
            all_points = points + bottom_points[::-1]

            # Create gradient surface
            gradient_surface = pygame.Surface((spec_width, height), pygame.SRCALPHA)

            # Draw gradient fill
            for i in range(len(points) - 1):
                x1, y1 = points[i]
                x2, y2 = points[i + 1]

                # Determine color based on frequency
                freq = bass_freqs[i]
                if freq < 60:
                    color = self.bass_colors[0]  # Sub-bass
                elif freq < 250:
                    color = self.bass_colors[1]  # Bass
                elif freq < 500:
                    color = self.bass_colors[2]  # Low-mid
                else:
                    color = self.bass_colors[3]  # Mid

                # Draw vertical lines for fill
                for x in range(int(x1 - spec_x), int(x2 - spec_x)):
                    t = (x - (x1 - spec_x)) / max(1, (x2 - x1))
                    y_interp = y1 + t * (y2 - y1)

                    for y_fill in range(int(y_interp - y), int(height)):
                        alpha = int(150 * (1 - y_fill / height))
                        gradient_surface.set_at((x, y_fill), (*color, alpha))

            self.screen.blit(gradient_surface, (spec_x, y))

            # Draw spectrum line
            pygame.draw.lines(self.screen, (255, 255, 255), False, points, 2)

        # Draw peaks
        for peak in self.bass_peaks:
            freq = peak["frequency"]
            mag = peak["magnitude"]
            note = peak["note"]

            x_pos = spec_x + int((freq - 20) / (self.max_frequency - 20) * spec_width)

            # Peak indicator
            pygame.draw.line(
                self.screen, (255, 200, 100), (x_pos, y), (x_pos, y + height), 1
            )

            # Note label
            if self.show_notes and note:
                note_surface = self.font_small.render(note, True, (255, 200, 100))
                note_rect = note_surface.get_rect(centerx=x_pos, y=y - 15)
                self.screen.blit(note_surface, note_rect)

        # Draw resonance warnings
        for res_freq in self.resonance_peaks:
            x_pos = spec_x + int(
                (res_freq - 20) / (self.max_frequency - 20) * spec_width
            )

            # Resonance indicator (pulsing)
            pulse = int(5 + 3 * np.sin(self.animation_phase))
            pygame.draw.circle(self.screen, (255, 100, 100), (x_pos, y + 20), pulse)

    def _draw_frequency_ranges(self, y: int, height: int):
        """Draw frequency range indicators"""
        range_x = self.x + 10
        range_width = 40

        for name, (min_freq, max_freq) in self.frequency_ranges.items():
            # Calculate vertical position
            y_start = (
                y + height - int((max_freq - 20) / (self.max_frequency - 20) * height)
            )
            y_end = (
                y + height - int((min_freq - 20) / (self.max_frequency - 20) * height)
            )

            if y_start < y:
                y_start = y
            if y_end > y + height:
                y_end = y + height

            range_height = y_end - y_start

            if range_height > 5:
                # Get color for range
                color_idx = list(self.frequency_ranges.keys()).index(name)
                color = self.bass_colors[color_idx % len(self.bass_colors)]

                # Draw range bar
                range_rect = pygame.Rect(range_x, y_start, range_width, range_height)
                pygame.draw.rect(self.screen, (*color, 100), range_rect)
                pygame.draw.rect(self.screen, color, range_rect, 1)

                # Range label (rotated)
                if range_height > 30:
                    label = self.font_small.render(name, True, self.text_color)
                    label = pygame.transform.rotate(label, 90)
                    label_rect = label.get_rect(
                        center=(range_x + range_width // 2, y_start + range_height // 2)
                    )
                    self.screen.blit(label, label_rect)

    def _draw_energy_timeline(self, y: int):
        """Draw bass energy timeline"""
        timeline_height = 50
        timeline_x = self.x + 60
        timeline_width = self.width - 80

        # Background
        pygame.draw.rect(
            self.screen, (15, 17, 23), (timeline_x, y, timeline_width, timeline_height)
        )
        pygame.draw.rect(
            self.screen,
            self.grid_color,
            (timeline_x, y, timeline_width, timeline_height),
            1,
        )

        # Labels
        bass_label = self.font_small.render("Bass", True, self.bass_colors[1])
        self.screen.blit(bass_label, (timeline_x - 35, y + 5))

        sub_label = self.font_small.render("Sub", True, self.bass_colors[0])
        self.screen.blit(sub_label, (timeline_x - 35, y + 25))

        # Draw energy histories
        if self.bass_energy_history:
            # Bass energy
            points = []
            for i, energy in enumerate(self.bass_energy_history):
                x_pos = timeline_x + int(i * timeline_width / self.history_length)
                y_pos = y + 20 - int(energy * 15)
                points.append((x_pos, y_pos))

            if len(points) > 1:
                pygame.draw.lines(self.screen, self.bass_colors[1], False, points, 2)

        if self.sub_bass_history:
            # Sub-bass energy
            points = []
            for i, energy in enumerate(self.sub_bass_history):
                x_pos = timeline_x + int(i * timeline_width / self.history_length)
                y_pos = y + 40 - int(energy * 15)
                points.append((x_pos, y_pos))

            if len(points) > 1:
                pygame.draw.lines(self.screen, self.bass_colors[0], False, points, 2)

    def _draw_bass_info(self, x: int, y: int):
        """Draw current bass information"""
        info_width = 180
        info_height = 150

        # Background
        info_rect = pygame.Rect(x, y, info_width, info_height)
        pygame.draw.rect(self.screen, (20, 22, 28), info_rect)
        pygame.draw.rect(self.screen, self.grid_color, info_rect, 1)

        # Title
        title = self.font_medium.render("Bass Analysis", True, self.text_color)
        self.screen.blit(title, (x + 5, y + 5))

        y_offset = y + 30

        # Current bass note
        if self.bass_note_history:
            current_note = self.bass_note_history[-1]
            if current_note:
                note_text = f"Note: {current_note}"
                note_surface = self.font_small.render(note_text, True, (255, 200, 100))
                self.screen.blit(note_surface, (x + 5, y_offset))
                y_offset += 20

        # Bass peaks
        if self.bass_peaks:
            peaks_text = f"Peaks: {len(self.bass_peaks)}"
            peaks_surface = self.font_small.render(peaks_text, True, (200, 200, 220))
            self.screen.blit(peaks_surface, (x + 5, y_offset))
            y_offset += 20

            # Show top peak
            top_peak = max(self.bass_peaks, key=lambda p: p["magnitude"])
            peak_text = f"Main: {top_peak['frequency']:.1f}Hz"
            peak_surface = self.font_small.render(peak_text, True, (150, 200, 255))
            self.screen.blit(peak_surface, (x + 5, y_offset))
            y_offset += 20

        # Energy levels
        if self.bass_energy_history:
            bass_energy = self.bass_energy_history[-1]
            energy_text = f"Bass Energy: {bass_energy * 100:.0f}%"
            energy_color = self._get_energy_color(bass_energy)
            energy_surface = self.font_small.render(energy_text, True, energy_color)
            self.screen.blit(energy_surface, (x + 5, y_offset))
            y_offset += 20

        if self.sub_bass_history:
            sub_energy = self.sub_bass_history[-1]
            sub_text = f"Sub Energy: {sub_energy * 100:.0f}%"
            sub_color = self._get_energy_color(sub_energy)
            sub_surface = self.font_small.render(sub_text, True, sub_color)
            self.screen.blit(sub_surface, (x + 5, y_offset))
            y_offset += 20

        # Resonance warning
        if self.resonance_peaks:
            res_text = "⚠ Resonance Detected"
            res_color = (
                (255, 100, 100)
                if int(self.animation_phase) % 2 == 0
                else (255, 150, 150)
            )
            res_surface = self.font_small.render(res_text, True, res_color)
            self.screen.blit(res_surface, (x + 5, y_offset))

    def _get_energy_color(self, energy: float) -> Tuple[int, int, int]:
        """Get color based on energy level"""
        if energy < 0.3:
            return (100, 100, 255)  # Low - Blue
        elif energy < 0.6:
            return (100, 255, 100)  # Medium - Green
        elif energy < 0.8:
            return (255, 255, 100)  # High - Yellow
        else:
            return (255, 100, 100)  # Very high - Red

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle input events"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_PLUS or event.key == pygame.K_EQUALS:
                # Zoom in
                self.zoom_level = min(4.0, self.zoom_level * 1.2)
                self.max_frequency = 500 / self.zoom_level
                return True
            elif event.key == pygame.K_MINUS:
                # Zoom out
                self.zoom_level = max(0.5, self.zoom_level / 1.2)
                self.max_frequency = 500 / self.zoom_level
                return True
            elif event.key == pygame.K_h:
                # Toggle harmonics
                self.show_harmonics = not self.show_harmonics
                return True
            elif event.key == pygame.K_n:
                # Toggle notes
                self.show_notes = not self.show_notes
                return True

        return False
