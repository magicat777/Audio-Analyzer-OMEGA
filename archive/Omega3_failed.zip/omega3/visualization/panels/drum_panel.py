"""
Drum detection and analysis panel for OMEGA-3
"""

import time
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame

try:
    from .base_panel import AnalysisPanel
except ImportError:
    from base_panel import AnalysisPanel


class DrumPanel(AnalysisPanel):
    """Panel for drum detection and analysis"""

    def __init__(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        super().__init__(surface, x, y, width, height)

        # Enhanced colors for drum visualization
        self.kick_color = (255, 100, 100)
        self.snare_color = (100, 255, 100)
        self.hihat_color = (100, 100, 255)
        self.crash_color = (255, 255, 100)
        self.tom_color = (255, 100, 255)

        # Drum kit colors
        self.drum_colors = {
            "kick": self.kick_color,
            "snare": self.snare_color,
            "hihat": self.hihat_color,
            "crash": self.crash_color,
            "tom": self.tom_color,
            "ride": (100, 255, 255),
            "open_hihat": (150, 150, 255),
            "rimshot": (255, 150, 100),
        }

        # Detection history
        self.detection_history = []
        self.history_length = 100

        # Current detections
        self.current_detections = {}
        self.detection_confidence = {}

        # Tempo and rhythm
        self.tempo = 0
        self.beat_phase = 0
        self.rhythm_pattern = []

        # Animation
        self.hit_animations = {}
        self.last_update = time.time()

        # Visualization modes
        self.view_modes = ["Kit View", "Timeline", "Pattern", "Frequency"]
        self.current_view = 0

    def draw(self, drum_data: Dict[str, Any]):
        """Draw drum analysis"""
        self.draw_background("Drum Detection")

        current_time = time.time()
        dt = current_time - self.last_update
        self.last_update = current_time

        y_offset = self.y + 35

        if not drum_data:
            no_data = self.font_small.render("No drum data", True, (100, 100, 120))
            self.screen.blit(no_data, (self.x + 10, y_offset))
            return

        # Update detections
        self._update_detections(drum_data, dt)

        # Draw based on current view
        if self.current_view == 0:  # Kit View
            self._draw_kit_view(y_offset)
        elif self.current_view == 1:  # Timeline
            self._draw_timeline_view(y_offset)
        elif self.current_view == 2:  # Pattern
            self._draw_pattern_view(y_offset)
        elif self.current_view == 3:  # Frequency
            self._draw_frequency_view(y_offset)

        # Draw tempo info
        self._draw_tempo_info(self.y + self.height - 60)

    def _update_detections(self, data: Dict[str, Any], dt: float):
        """Update drum detection data"""
        # Update current detections
        if "detections" in data:
            self.current_detections = data["detections"]

            # Add to history
            self.detection_history.append(self.current_detections.copy())
            if len(self.detection_history) > self.history_length:
                self.detection_history.pop(0)

        # Update confidence
        if "confidence" in data:
            self.detection_confidence = data["confidence"]

        # Update tempo
        if "tempo" in data:
            self.tempo = data["tempo"]

        if "beat_phase" in data:
            self.beat_phase = data["beat_phase"]

        # Update hit animations
        for drum, detected in self.current_detections.items():
            if detected:
                self.hit_animations[drum] = 1.0

        # Decay animations
        for drum in list(self.hit_animations.keys()):
            self.hit_animations[drum] -= dt * 3
            if self.hit_animations[drum] <= 0:
                del self.hit_animations[drum]

    def _draw_kit_view(self, y: int):
        """Draw drum kit visualization"""
        kit_width = self.width - 20
        kit_height = self.height - 100
        kit_x = self.x + 10

        # Background
        pygame.draw.rect(self.screen, (20, 20, 30), (kit_x, y, kit_width, kit_height))
        pygame.draw.rect(
            self.screen, self.border_color, (kit_x, y, kit_width, kit_height), 1
        )

        # Drum positions (simplified drum kit layout)
        drum_positions = {
            "kick": (kit_x + kit_width // 2, y + kit_height - 40),
            "snare": (kit_x + kit_width // 2 + 60, y + kit_height // 2),
            "hihat": (kit_x + kit_width // 2 - 60, y + kit_height // 2 - 40),
            "crash": (kit_x + kit_width // 2 - 100, y + 40),
            "ride": (kit_x + kit_width // 2 + 100, y + 40),
            "tom": (kit_x + kit_width // 2, y + 60),
        }

        # Draw drums
        for drum, (x_pos, y_pos) in drum_positions.items():
            # Base drum size
            base_size = 25

            # Animation scaling
            if drum in self.hit_animations:
                scale = 1 + self.hit_animations[drum] * 0.5
                size = int(base_size * scale)
                alpha = int(255 * self.hit_animations[drum])
            else:
                size = base_size
                alpha = 100

            # Drum color
            color = self.drum_colors.get(drum, (150, 150, 150))

            # Draw drum
            if drum in self.current_detections and self.current_detections[drum]:
                # Active state
                pygame.draw.circle(self.screen, color, (x_pos, y_pos), size)
                pygame.draw.circle(
                    self.screen, (255, 255, 255), (x_pos, y_pos), size, 2
                )
            else:
                # Inactive state
                faded_color = tuple(c // 3 for c in color)
                pygame.draw.circle(self.screen, faded_color, (x_pos, y_pos), size)
                pygame.draw.circle(
                    self.screen, self.border_color, (x_pos, y_pos), size, 1
                )

            # Drum label
            label = self.font_small.render(drum.upper(), True, self.text_color)
            label_rect = label.get_rect(center=(x_pos, y_pos + size + 15))
            self.screen.blit(label, label_rect)

            # Confidence if available
            if drum in self.detection_confidence:
                conf = self.detection_confidence[drum]
                conf_text = f"{conf * 100:.0f}%"
                conf_surface = self.font_small.render(conf_text, True, (150, 150, 170))
                conf_rect = conf_surface.get_rect(center=(x_pos, y_pos + size + 30))
                self.screen.blit(conf_surface, conf_rect)

    def _draw_timeline_view(self, y: int):
        """Draw drum detection timeline"""
        timeline_x = self.x + 10
        timeline_width = self.width - 20
        timeline_height = self.height - 100

        # Background
        pygame.draw.rect(
            self.screen, (20, 20, 30), (timeline_x, y, timeline_width, timeline_height)
        )
        pygame.draw.rect(
            self.screen,
            self.border_color,
            (timeline_x, y, timeline_width, timeline_height),
            1,
        )

        if not self.detection_history:
            return

        # Drum types to show
        drum_types = ["kick", "snare", "hihat", "crash", "tom"]
        drum_height = timeline_height // len(drum_types)

        # Draw drum lanes
        for i, drum in enumerate(drum_types):
            lane_y = y + i * drum_height

            # Lane background
            if i % 2 == 0:
                pygame.draw.rect(
                    self.screen,
                    (25, 25, 35),
                    (timeline_x, lane_y, timeline_width, drum_height),
                )

            # Lane label
            color = self.drum_colors.get(drum, (150, 150, 150))
            label = self.font_small.render(drum.upper(), True, color)
            self.screen.blit(label, (timeline_x - 50, lane_y + drum_height // 2 - 8))

            # Draw hits
            for t, detections in enumerate(self.detection_history):
                if drum in detections and detections[drum]:
                    x_pos = timeline_x + int(t * timeline_width / self.history_length)
                    hit_rect = pygame.Rect(
                        x_pos,
                        lane_y + 5,
                        max(2, timeline_width // self.history_length),
                        drum_height - 10,
                    )
                    pygame.draw.rect(self.screen, color, hit_rect)

        # Current time indicator
        current_x = timeline_x + timeline_width - 2
        pygame.draw.line(
            self.screen,
            (255, 255, 255),
            (current_x, y),
            (current_x, y + timeline_height),
            2,
        )

    def _draw_pattern_view(self, y: int):
        """Draw rhythm pattern analysis"""
        pattern_x = self.x + 10
        pattern_width = self.width - 20
        pattern_height = self.height - 100

        # Background
        pygame.draw.rect(
            self.screen, (20, 20, 30), (pattern_x, y, pattern_width, pattern_height)
        )
        pygame.draw.rect(
            self.screen,
            self.border_color,
            (pattern_x, y, pattern_width, pattern_height),
            1,
        )

        # Draw beat grid (16 beats)
        beats = 16
        beat_width = pattern_width // beats

        # Grid lines
        for i in range(beats + 1):
            x_pos = pattern_x + i * beat_width
            line_color = (60, 60, 80) if i % 4 == 0 else (40, 40, 50)
            pygame.draw.line(
                self.screen, line_color, (x_pos, y), (x_pos, y + pattern_height), 1
            )

        # Beat numbers
        for i in range(0, beats, 4):
            beat_num = (i // 4) + 1
            x_pos = pattern_x + i * beat_width + beat_width // 2
            beat_label = self.font_small.render(str(beat_num), True, (100, 100, 120))
            beat_rect = beat_label.get_rect(center=(x_pos, y - 15))
            self.screen.blit(beat_label, beat_rect)

        # Draw pattern for main drums
        main_drums = ["kick", "snare", "hihat"]
        for i, drum in enumerate(main_drums):
            lane_y = y + 20 + i * 40

            # Drum label
            color = self.drum_colors.get(drum, (150, 150, 150))
            label = self.font_small.render(drum.upper(), True, color)
            self.screen.blit(label, (pattern_x - 50, lane_y))

            # Pattern dots
            for beat in range(beats):
                x_pos = pattern_x + beat * beat_width + beat_width // 2

                # Check if this beat should have this drum (simplified pattern)
                has_hit = False
                if len(self.detection_history) > beat:
                    idx = -(beats - beat)
                    if idx < 0 and -idx <= len(self.detection_history):
                        has_hit = self.detection_history[idx].get(drum, False)

                if has_hit:
                    pygame.draw.circle(self.screen, color, (x_pos, lane_y + 10), 8)
                else:
                    pygame.draw.circle(
                        self.screen, (50, 50, 60), (x_pos, lane_y + 10), 5, 1
                    )

        # Beat phase indicator
        if self.beat_phase >= 0:
            phase_x = pattern_x + int(self.beat_phase * pattern_width)
            pygame.draw.line(
                self.screen,
                (255, 200, 100),
                (phase_x, y),
                (phase_x, y + pattern_height),
                3,
            )

    def _draw_frequency_view(self, y: int):
        """Draw frequency-based drum analysis"""
        freq_x = self.x + 10
        freq_width = self.width - 20
        freq_height = self.height - 100

        # Background
        pygame.draw.rect(
            self.screen, (20, 20, 30), (freq_x, y, freq_width, freq_height)
        )
        pygame.draw.rect(
            self.screen, self.border_color, (freq_x, y, freq_width, freq_height), 1
        )

        # Frequency ranges for different drums
        freq_ranges = {
            "kick": (20, 120, "Kick (20-120Hz)"),
            "snare": (150, 300, "Snare (150-300Hz)"),
            "hihat": (8000, 16000, "Hi-Hat (8-16kHz)"),
            "tom": (80, 200, "Toms (80-200Hz)"),
        }

        # Draw frequency bands
        band_height = freq_height // len(freq_ranges)

        for i, (drum, (min_freq, max_freq, label)) in enumerate(freq_ranges.items()):
            band_y = y + i * band_height

            # Band background
            if i % 2 == 0:
                pygame.draw.rect(
                    self.screen, (25, 25, 35), (freq_x, band_y, freq_width, band_height)
                )

            # Band label
            color = self.drum_colors.get(drum, (150, 150, 150))
            label_surface = self.font_small.render(label, True, color)
            self.screen.blit(label_surface, (freq_x + 5, band_y + 5))

            # Activity indicator
            if drum in self.current_detections and self.current_detections[drum]:
                # Active band visualization
                bar_width = int(freq_width * 0.8)
                bar_height = band_height - 10
                bar_rect = pygame.Rect(
                    freq_x + 5, band_y + 25, bar_width, bar_height - 20
                )

                # Animated fill
                if drum in self.hit_animations:
                    fill_width = int(bar_width * self.hit_animations[drum])
                    fill_rect = pygame.Rect(
                        freq_x + 5, band_y + 25, fill_width, bar_height - 20
                    )
                    pygame.draw.rect(self.screen, color, fill_rect)

                pygame.draw.rect(self.screen, color, bar_rect, 1)

    def _draw_tempo_info(self, y: int):
        """Draw tempo and rhythm information"""
        info_rect = pygame.Rect(self.x + 5, y, self.width - 10, 50)
        pygame.draw.rect(self.screen, (25, 27, 33), info_rect)
        pygame.draw.rect(self.screen, self.border_color, info_rect, 1)

        info_x = self.x + 15

        # Tempo
        if self.tempo > 0:
            tempo_text = f"Tempo: {self.tempo:.1f} BPM"
            tempo_surface = self.font_medium.render(tempo_text, True, self.accent_color)
            self.screen.blit(tempo_surface, (info_x, y + 5))
        else:
            no_tempo = self.font_medium.render(
                "No tempo detected", True, (100, 100, 120)
            )
            self.screen.blit(no_tempo, (info_x, y + 5))

        # Beat phase indicator
        if self.beat_phase >= 0:
            phase_text = f"Beat Phase: {self.beat_phase:.2f}"
            phase_surface = self.font_small.render(phase_text, True, (150, 150, 170))
            self.screen.blit(phase_surface, (info_x, y + 25))

            # Visual beat indicator
            beat_x = info_x + 200
            beat_size = 15
            beat_alpha = int(255 * (1 - abs(self.beat_phase - 0.5) * 2))
            beat_color = (*self.accent_color, beat_alpha)
            pygame.draw.circle(self.screen, beat_color, (beat_x, y + 25), beat_size)

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle input events"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_d:
                # Cycle through view modes
                self.current_view = (self.current_view + 1) % len(self.view_modes)
                return True
            elif event.key == pygame.K_r:
                # Reset history
                self.detection_history.clear()
                self.hit_animations.clear()
                return True

        return False
