"""
Technical overlay panel with advanced audio analysis metrics
"""

import time
from collections import deque
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class TechnicalPanel:
    """Technical analysis overlay with detailed metrics"""

    def __init__(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        self.screen = surface
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)

        # Fonts
        self.font_mono_tiny = pygame.font.Font(None, 12)
        self.font_mono_small = pygame.font.Font(None, 14)
        self.font_mono_medium = pygame.font.Font(None, 16)
        self.font_title = pygame.font.Font(None, 24)

        # Colors
        self.bg_color = (10, 10, 15, 200)  # Semi-transparent
        self.border_color = (30, 35, 45)
        self.text_color = (180, 180, 200)
        self.header_color = (100, 200, 255)
        self.data_color = (200, 255, 200)
        self.warning_color = (255, 200, 100)
        self.error_color = (255, 100, 100)

        # Data sections
        self.sections = {
            "Audio Info": {
                "Sample Rate": "N/A",
                "Bit Depth": "N/A",
                "Channels": "N/A",
                "Buffer Size": "N/A",
                "Latency": "N/A",
            },
            "Signal Analysis": {
                "RMS Level": "N/A",
                "Peak Level": "N/A",
                "Crest Factor": "N/A",
                "Dynamic Range": "N/A",
                "LUFS-I": "N/A",
                "LUFS-S": "N/A",
                "True Peak": "N/A",
            },
            "Frequency Analysis": {
                "Spectral Centroid": "N/A",
                "Spectral Spread": "N/A",
                "Spectral Flux": "N/A",
                "Spectral Rolloff": "N/A",
                "Zero Crossing Rate": "N/A",
                "Spectral Flatness": "N/A",
            },
            "Time Domain": {
                "Tempo": "N/A",
                "Beat Phase": "N/A",
                "Onset Rate": "N/A",
                "Transient Density": "N/A",
            },
            "Psychoacoustic": {
                "Loudness": "N/A",
                "Sharpness": "N/A",
                "Roughness": "N/A",
                "Tonality": "N/A",
            },
            "Performance": {
                "CPU Usage": "N/A",
                "Frame Rate": "N/A",
                "Processing Time": "N/A",
                "Buffer Underruns": "0",
            },
        }

        # History tracking
        self.cpu_history = deque(maxlen=100)
        self.fps_history = deque(maxlen=100)
        self.latency_history = deque(maxlen=100)

        # Update tracking
        self.last_update = time.time()
        self.frame_count = 0
        self.update_interval = 0.1  # Update display every 100ms
        self.last_display_update = 0

        # Alert system
        self.alerts = []
        self.max_alerts = 5

        # Visualization modes
        self.compact_mode = False
        self.show_graphs = True
        self.show_alerts = True

    def update(self, technical_data: Dict[str, Any]):
        """Update technical analysis data"""
        current_time = time.time()
        self.frame_count += 1

        # Update display at interval
        if current_time - self.last_display_update >= self.update_interval:
            # Calculate FPS
            fps = self.frame_count / (current_time - self.last_display_update)
            self.fps_history.append(fps)
            self.frame_count = 0
            self.last_display_update = current_time

            # Update sections
            self._update_audio_info(technical_data)
            self._update_signal_analysis(technical_data)
            self._update_frequency_analysis(technical_data)
            self._update_time_domain(technical_data)
            self._update_psychoacoustic(technical_data)
            self._update_performance(technical_data, fps)

            # Check for alerts
            self._check_alerts(technical_data)

    def _update_audio_info(self, data: Dict[str, Any]):
        """Update audio information section"""
        if "sample_rate" in data:
            self.sections["Audio Info"]["Sample Rate"] = f"{data['sample_rate']} Hz"
        if "bit_depth" in data:
            self.sections["Audio Info"]["Bit Depth"] = f"{data['bit_depth']} bit"
        if "channels" in data:
            self.sections["Audio Info"]["Channels"] = str(data["channels"])
        if "buffer_size" in data:
            self.sections["Audio Info"]["Buffer Size"] = str(data["buffer_size"])
        if "latency" in data:
            latency_ms = data["latency"] * 1000
            self.sections["Audio Info"]["Latency"] = f"{latency_ms:.1f} ms"
            self.latency_history.append(latency_ms)

    def _update_signal_analysis(self, data: Dict[str, Any]):
        """Update signal analysis section"""
        if "rms_level" in data:
            rms_db = 20 * np.log10(data["rms_level"] + 1e-10)
            self.sections["Signal Analysis"]["RMS Level"] = f"{rms_db:.1f} dB"
        if "peak_level" in data:
            peak_db = 20 * np.log10(data["peak_level"] + 1e-10)
            self.sections["Signal Analysis"]["Peak Level"] = f"{peak_db:.1f} dB"
        if "crest_factor" in data:
            self.sections["Signal Analysis"][
                "Crest Factor"
            ] = f"{data['crest_factor']:.1f} dB"
        if "dynamic_range" in data:
            self.sections["Signal Analysis"][
                "Dynamic Range"
            ] = f"{data['dynamic_range']:.1f} dB"
        if "lufs_integrated" in data:
            self.sections["Signal Analysis"][
                "LUFS-I"
            ] = f"{data['lufs_integrated']:.1f} LUFS"
        if "lufs_short" in data:
            self.sections["Signal Analysis"][
                "LUFS-S"
            ] = f"{data['lufs_short']:.1f} LUFS"
        if "true_peak" in data:
            tp_db = 20 * np.log10(data["true_peak"] + 1e-10)
            self.sections["Signal Analysis"]["True Peak"] = f"{tp_db:.1f} dBTP"

    def _update_frequency_analysis(self, data: Dict[str, Any]):
        """Update frequency analysis section"""
        if "spectral_centroid" in data:
            self.sections["Frequency Analysis"][
                "Spectral Centroid"
            ] = f"{data['spectral_centroid']:.0f} Hz"
        if "spectral_spread" in data:
            self.sections["Frequency Analysis"][
                "Spectral Spread"
            ] = f"{data['spectral_spread']:.0f} Hz"
        if "spectral_flux" in data:
            self.sections["Frequency Analysis"][
                "Spectral Flux"
            ] = f"{data['spectral_flux']:.3f}"
        if "spectral_rolloff" in data:
            self.sections["Frequency Analysis"][
                "Spectral Rolloff"
            ] = f"{data['spectral_rolloff']:.0f} Hz"
        if "zero_crossing_rate" in data:
            self.sections["Frequency Analysis"][
                "Zero Crossing Rate"
            ] = f"{data['zero_crossing_rate']:.0f} Hz"
        if "spectral_flatness" in data:
            self.sections["Frequency Analysis"][
                "Spectral Flatness"
            ] = f"{data['spectral_flatness']:.3f}"

    def _update_time_domain(self, data: Dict[str, Any]):
        """Update time domain analysis section"""
        if "tempo" in data:
            self.sections["Time Domain"]["Tempo"] = f"{data['tempo']:.1f} BPM"
        if "beat_phase" in data:
            self.sections["Time Domain"]["Beat Phase"] = f"{data['beat_phase']:.2f}"
        if "onset_rate" in data:
            self.sections["Time Domain"]["Onset Rate"] = f"{data['onset_rate']:.1f} Hz"
        if "transient_density" in data:
            self.sections["Time Domain"][
                "Transient Density"
            ] = f"{data['transient_density']:.2f}"

    def _update_psychoacoustic(self, data: Dict[str, Any]):
        """Update psychoacoustic analysis section"""
        if "loudness" in data:
            self.sections["Psychoacoustic"][
                "Loudness"
            ] = f"{data['loudness']:.1f} sones"
        if "sharpness" in data:
            self.sections["Psychoacoustic"][
                "Sharpness"
            ] = f"{data['sharpness']:.2f} acum"
        if "roughness" in data:
            self.sections["Psychoacoustic"][
                "Roughness"
            ] = f"{data['roughness']:.2f} asper"
        if "tonality" in data:
            self.sections["Psychoacoustic"]["Tonality"] = f"{data['tonality']:.2f}"

    def _update_performance(self, data: Dict[str, Any], fps: float):
        """Update performance metrics section"""
        if "cpu_usage" in data:
            cpu = data["cpu_usage"]
            self.sections["Performance"]["CPU Usage"] = f"{cpu:.1f}%"
            self.cpu_history.append(cpu)

        self.sections["Performance"]["Frame Rate"] = f"{fps:.1f} FPS"

        if "processing_time" in data:
            proc_ms = data["processing_time"] * 1000
            self.sections["Performance"]["Processing Time"] = f"{proc_ms:.2f} ms"

        if "buffer_underruns" in data:
            self.sections["Performance"]["Buffer Underruns"] = str(
                data["buffer_underruns"]
            )

    def _check_alerts(self, data: Dict[str, Any]):
        """Check for conditions that warrant alerts"""
        current_time = time.time()

        # CPU usage alert
        if "cpu_usage" in data and data["cpu_usage"] > 80:
            self._add_alert("High CPU Usage", f"{data['cpu_usage']:.1f}%", "warning")

        # Latency alert
        if "latency" in data and data["latency"] > 0.02:  # 20ms
            self._add_alert("High Latency", f"{data['latency']*1000:.1f}ms", "warning")

        # Clipping alert
        if "peak_level" in data and data["peak_level"] > 0.99:
            self._add_alert("Clipping Detected", "Peak > -0.1dB", "error")

        # Buffer underrun alert
        if "buffer_underruns" in data and data["buffer_underruns"] > 0:
            self._add_alert(
                "Buffer Underrun", f"{data['buffer_underruns']} drops", "error"
            )

    def _add_alert(self, title: str, message: str, severity: str = "info"):
        """Add an alert to the display"""
        alert = {
            "title": title,
            "message": message,
            "severity": severity,
            "time": time.time(),
        }

        # Check if similar alert exists
        for existing in self.alerts:
            if existing["title"] == title:
                existing["time"] = time.time()
                existing["message"] = message
                return

        self.alerts.append(alert)

        # Keep only recent alerts
        if len(self.alerts) > self.max_alerts:
            self.alerts.pop(0)

    def draw(self, data=None):
        """Draw the technical overlay panel"""
        # Semi-transparent background
        overlay_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay_surface.fill(self.bg_color)
        self.screen.blit(overlay_surface, (self.x, self.y))

        # Border
        pygame.draw.rect(self.screen, self.border_color, self.rect, 2)

        # Title
        title = self.font_title.render("TECHNICAL ANALYSIS", True, self.header_color)
        title_rect = title.get_rect(centerx=self.x + self.width // 2, y=self.y + 5)
        self.screen.blit(title, title_rect)

        if self.compact_mode:
            self._draw_compact_view()
        else:
            self._draw_full_view()

        # Draw alerts
        if self.show_alerts and self.alerts:
            self._draw_alerts()

    def _draw_full_view(self):
        """Draw full technical information"""
        y_offset = self.y + 35
        section_width = (self.width - 30) // 3

        # Draw sections in columns
        col = 0
        for section_name, section_data in self.sections.items():
            x_offset = self.x + 10 + col * section_width

            # Section header
            header = self.font_mono_medium.render(section_name, True, self.header_color)
            self.screen.blit(header, (x_offset, y_offset))

            # Section data
            item_y = y_offset + 20
            for key, value in section_data.items():
                # Key
                key_text = f"{key}:"
                key_surface = self.font_mono_small.render(
                    key_text, True, self.text_color
                )
                self.screen.blit(key_surface, (x_offset, item_y))

                # Value
                value_color = self._get_value_color(key, value)
                value_surface = self.font_mono_small.render(value, True, value_color)
                value_rect = value_surface.get_rect(
                    right=x_offset + section_width - 10, y=item_y
                )
                self.screen.blit(value_surface, value_rect)

                item_y += 18

            # Move to next column or row
            col += 1
            if col >= 3:
                col = 0
                y_offset = item_y + 10

        # Draw mini graphs
        if self.show_graphs:
            self._draw_performance_graphs(self.y + self.height - 100)

    def _draw_compact_view(self):
        """Draw compact technical information"""
        y_offset = self.y + 35

        # Show only critical metrics
        critical_metrics = [
            ("CPU", self.sections["Performance"]["CPU Usage"]),
            ("FPS", self.sections["Performance"]["Frame Rate"]),
            ("Latency", self.sections["Audio Info"]["Latency"]),
            ("Peak", self.sections["Signal Analysis"]["Peak Level"]),
            ("LUFS-S", self.sections["Signal Analysis"]["LUFS-S"]),
            ("Tempo", self.sections["Time Domain"]["Tempo"]),
        ]

        # Draw in two columns
        for i, (label, value) in enumerate(critical_metrics):
            col = i % 2
            row = i // 2

            x_offset = self.x + 10 + col * (self.width // 2)
            y_pos = y_offset + row * 20

            # Label
            label_surface = self.font_mono_medium.render(
                f"{label}:", True, self.text_color
            )
            self.screen.blit(label_surface, (x_offset, y_pos))

            # Value
            value_color = self._get_value_color(label, value)
            value_surface = self.font_mono_medium.render(value, True, value_color)
            value_rect = value_surface.get_rect(
                right=x_offset + self.width // 2 - 20, y=y_pos
            )
            self.screen.blit(value_surface, value_rect)

    def _draw_performance_graphs(self, y: int):
        """Draw mini performance graphs"""
        graph_height = 80
        graph_width = (self.width - 40) // 3

        # CPU graph
        self._draw_mini_graph(
            self.cpu_history,
            "CPU %",
            self.x + 10,
            y,
            graph_width,
            graph_height,
            max_value=100,
            warning_threshold=80,
        )

        # FPS graph
        self._draw_mini_graph(
            self.fps_history,
            "FPS",
            self.x + 20 + graph_width,
            y,
            graph_width,
            graph_height,
            max_value=120,
            warning_threshold=30,
            invert_warning=True,
        )

        # Latency graph
        self._draw_mini_graph(
            self.latency_history,
            "Latency ms",
            self.x + 30 + graph_width * 2,
            y,
            graph_width,
            graph_height,
            max_value=50,
            warning_threshold=20,
        )

    def _draw_mini_graph(
        self,
        data: deque,
        label: str,
        x: int,
        y: int,
        width: int,
        height: int,
        max_value: float = 100,
        warning_threshold: float = 80,
        invert_warning: bool = False,
    ):
        """Draw a mini graph"""
        # Background
        graph_rect = pygame.Rect(x, y, width, height)
        pygame.draw.rect(self.screen, (20, 20, 25), graph_rect)
        pygame.draw.rect(self.screen, self.border_color, graph_rect, 1)

        # Label
        label_surface = self.font_mono_tiny.render(label, True, self.text_color)
        self.screen.blit(label_surface, (x + 2, y + 2))

        if not data:
            return

        # Draw data
        points = []
        for i, value in enumerate(data):
            x_pos = x + int(i * width / len(data))
            y_pos = y + height - int(value / max_value * (height - 15))
            points.append((x_pos, y_pos))

        if len(points) > 1:
            # Determine color based on latest value
            latest = data[-1]
            if invert_warning:
                color = (
                    self.warning_color
                    if latest < warning_threshold
                    else self.data_color
                )
            else:
                color = (
                    self.warning_color
                    if latest > warning_threshold
                    else self.data_color
                )

            pygame.draw.lines(self.screen, color, False, points, 1)

        # Current value
        if data:
            value_text = f"{data[-1]:.1f}"
            value_color = self._get_graph_value_color(
                data[-1], warning_threshold, invert_warning
            )
            value_surface = self.font_mono_small.render(value_text, True, value_color)
            value_rect = value_surface.get_rect(right=x + width - 2, y=y + 15)
            self.screen.blit(value_surface, value_rect)

    def _draw_alerts(self):
        """Draw alert messages"""
        alert_y = self.y + 50
        alert_x = self.x + self.width - 250

        current_time = time.time()

        for alert in self.alerts[::-1]:  # Show newest first
            age = current_time - alert["time"]
            if age > 5:  # Fade out after 5 seconds
                continue

            # Alert background
            alert_rect = pygame.Rect(alert_x, alert_y, 240, 30)

            # Color based on severity
            if alert["severity"] == "error":
                bg_color = (*self.error_color, 50)
                text_color = self.error_color
            elif alert["severity"] == "warning":
                bg_color = (*self.warning_color, 50)
                text_color = self.warning_color
            else:
                bg_color = (*self.data_color, 50)
                text_color = self.data_color

            # Draw alert
            alert_surface = pygame.Surface((240, 30), pygame.SRCALPHA)
            alert_surface.fill(bg_color)
            self.screen.blit(alert_surface, (alert_x, alert_y))
            pygame.draw.rect(self.screen, text_color, alert_rect, 1)

            # Alert text
            title_surface = self.font_mono_small.render(
                alert["title"], True, text_color
            )
            self.screen.blit(title_surface, (alert_x + 5, alert_y + 2))

            message_surface = self.font_mono_tiny.render(
                alert["message"], True, text_color
            )
            self.screen.blit(message_surface, (alert_x + 5, alert_y + 15))

            alert_y += 35

    def _get_value_color(self, key: str, value: str) -> Tuple[int, int, int]:
        """Get color for a value based on its key and content"""
        if value == "N/A":
            return (100, 100, 120)

        # Check for warning conditions
        if "CPU" in key and value != "N/A":
            try:
                cpu = float(value.replace("%", ""))
                if cpu > 80:
                    return self.error_color
                elif cpu > 60:
                    return self.warning_color
            except BaseException:
                pass

        if "Peak" in key and "dB" in value:
            try:
                peak = float(value.replace("dB", "").replace("dBTP", ""))
                if peak > -0.1:
                    return self.error_color
                elif peak > -3:
                    return self.warning_color
            except BaseException:
                pass

        if "Latency" in key and "ms" in value:
            try:
                latency = float(value.replace("ms", ""))
                if latency > 20:
                    return self.warning_color
            except BaseException:
                pass

        if "Underruns" in key and value != "0":
            return self.error_color

        return self.data_color

    def _get_graph_value_color(
        self, value: float, threshold: float, invert: bool = False
    ) -> Tuple[int, int, int]:
        """Get color for graph value"""
        if invert:
            return self.warning_color if value < threshold else self.data_color
        else:
            return self.warning_color if value > threshold else self.data_color

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle input events"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_t:
                # Toggle compact mode
                self.compact_mode = not self.compact_mode
                return True
            elif event.key == pygame.K_g:
                # Toggle graphs
                self.show_graphs = not self.show_graphs
                return True
            elif event.key == pygame.K_a:
                # Toggle alerts
                self.show_alerts = not self.show_alerts
                return True
            elif event.key == pygame.K_c:
                # Clear alerts
                self.alerts.clear()
                return True

        return False
