"""
Voice detection and analysis panel
"""

import time
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame

try:
    from .base_panel import AnalysisPanel
except ImportError:
    from base_panel import AnalysisPanel


class VoicePanel(AnalysisPanel):
    """Panel for voice analysis display"""

    def __init__(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        super().__init__(surface, x, y, width, height)

        # Enhanced colors for voice visualization
        self.voice_active_color = (100, 255, 150)
        self.voice_inactive_color = (100, 100, 120)
        self.male_color = (100, 150, 255)
        self.female_color = (255, 150, 200)
        self.formant_colors = [
            (255, 100, 100),  # F1 - Red
            (100, 255, 100),  # F2 - Green
            (100, 100, 255),  # F3 - Blue
            (255, 255, 100),  # F4 - Yellow
        ]

        # Voice detection history
        self.detection_history = []
        self.pitch_history = []
        self.formant_history = {"F1": [], "F2": [], "F3": []}
        self.history_length = 100

        # Visualization settings
        self.show_formant_plot = True
        self.show_pitch_track = True
        self.show_vowel_space = True

        # Animation
        self.voice_activity_alpha = 0
        self.last_detection_time = 0

        # Vowel space reference points
        self.vowel_references = {
            "i": {"F1": 300, "F2": 2200},  # "ee" as in "beat"
            "e": {"F1": 400, "F2": 2000},  # "ay" as in "bait"
            "a": {"F1": 700, "F2": 1200},  # "ah" as in "bot"
            "o": {"F1": 500, "F2": 900},  # "oh" as in "boat"
            "u": {"F1": 300, "F2": 800},  # "oo" as in "boot"
        }

    def draw(self, voice_data: Dict[str, Any]):
        """Draw voice analysis"""
        self.clear()
        self.draw_border()
        self.draw_title("Voice Analysis")

        y_offset = self.y + 35

        if not voice_data:
            no_data = self.font_small.render("No voice data", True, (100, 100, 120))
            self.screen.blit(no_data, (self.x + 10, y_offset))
            return

        # Update detection history
        detected = voice_data.get("voice_detected", False)
        self.detection_history.append(1 if detected else 0)
        if len(self.detection_history) > self.history_length:
            self.detection_history.pop(0)

        # Update animation
        if detected:
            self.voice_activity_alpha = min(255, self.voice_activity_alpha + 20)
            self.last_detection_time = time.time()
        else:
            self.voice_activity_alpha = max(0, self.voice_activity_alpha - 10)

        # Draw voice detection status with animation
        self._draw_detection_status(voice_data, y_offset)
        y_offset += 40

        # Draw confidence meter
        if "confidence" in voice_data:
            self._draw_confidence_meter(voice_data["confidence"], y_offset)
            y_offset += 30

        # Draw voice characteristics
        self._draw_voice_characteristics(voice_data, y_offset)
        y_offset += 60

        # Draw pitch tracking if available
        if self.show_pitch_track and "pitch_hz" in voice_data:
            self._draw_pitch_track(voice_data, y_offset)
            y_offset += 60

        # Draw formant visualization
        if "formants" in voice_data and voice_data["formants"]:
            if self.show_formant_plot:
                self._draw_formant_plot(voice_data["formants"], y_offset)
                y_offset += 80

            # Draw vowel space if enabled
            if self.show_vowel_space:
                self._draw_vowel_space(voice_data["formants"])

        # Draw activity timeline
        self._draw_activity_timeline(self.y + self.height - 30)

    def _draw_detection_status(self, data: Dict[str, Any], y: int):
        """Draw voice detection status with animation"""
        detected = data.get("voice_detected", False)

        # Activity indicator background
        indicator_rect = pygame.Rect(self.x + 10, y, self.width - 20, 30)

        # Animated background color
        if self.voice_activity_alpha > 0:
            alpha_color = tuple(
                c * self.voice_activity_alpha // 255 for c in self.voice_active_color
            )
            overlay = pygame.Surface((indicator_rect.width, indicator_rect.height))
            overlay.set_alpha(self.voice_activity_alpha // 3)
            overlay.fill(alpha_color)
            self.screen.blit(overlay, indicator_rect)

        pygame.draw.rect(self.screen, self.border_color, indicator_rect, 2)

        # Status text
        status_text = "VOICE DETECTED" if detected else "No Voice"
        status_color = (
            self.voice_active_color if detected else self.voice_inactive_color
        )
        status_surface = self.font_medium.render(status_text, True, status_color)
        status_rect = status_surface.get_rect(center=(self.x + self.width // 2, y + 15))
        self.screen.blit(status_surface, status_rect)

    def _draw_confidence_meter(self, confidence: float, y: int):
        """Draw confidence meter with gradient"""
        meter_width = self.width - 40
        meter_height = 20
        meter_x = self.x + 20

        # Background
        pygame.draw.rect(
            self.screen, (40, 40, 50), (meter_x, y, meter_width, meter_height)
        )
        pygame.draw.rect(
            self.screen, self.border_color, (meter_x, y, meter_width, meter_height), 1
        )

        # Confidence bar with gradient
        bar_width = int(confidence * meter_width)
        if bar_width > 0:
            # Create gradient effect
            for i in range(bar_width):
                gradient = i / meter_width
                if confidence > 0.8:
                    color = self.voice_active_color
                elif confidence > 0.5:
                    color = (255, 255, 100)
                else:
                    color = (255, 150, 100)

                # Fade color based on position
                faded_color = tuple(int(c * (0.7 + 0.3 * gradient)) for c in color)
                pygame.draw.line(
                    self.screen,
                    faded_color,
                    (meter_x + i, y + 2),
                    (meter_x + i, y + meter_height - 2),
                )

        # Confidence text
        conf_text = f"{confidence * 100:.0f}%"
        conf_surface = self.font_small.render(conf_text, True, self.text_color)
        conf_rect = conf_surface.get_rect(center=(meter_x + meter_width // 2, y + 10))
        self.screen.blit(conf_surface, conf_rect)

    def _draw_voice_characteristics(self, data: Dict[str, Any], y: int):
        """Draw voice type and gender information"""
        char_x = self.x + 10

        # Voice type
        if "voice_type" in data and data["voice_type"]:
            type_text = f"Type: {data['voice_type'].title()}"
            type_color = self.accent_color
            if data["voice_type"] == "singing":
                type_color = (255, 200, 100)
            elif data["voice_type"] == "shouting":
                type_color = (255, 100, 100)

            type_surface = self.font_small.render(type_text, True, type_color)
            self.screen.blit(type_surface, (char_x, y))

        # Gender with visual indicator
        if "gender" in data and data["gender"]:
            gender = data["gender"]
            gender_color = (
                self.male_color if gender.lower() == "male" else self.female_color
            )

            # Gender icon/indicator
            icon_rect = pygame.Rect(char_x + 100, y, 15, 15)
            pygame.draw.circle(self.screen, gender_color, icon_rect.center, 7)

            gender_text = gender.title()
            gender_surface = self.font_small.render(gender_text, True, gender_color)
            self.screen.blit(gender_surface, (char_x + 120, y))

        # Additional characteristics
        if "emotion" in data and data["emotion"]:
            emotion_text = f"Emotion: {data['emotion']}"
            emotion_surface = self.font_small.render(
                emotion_text, True, (200, 150, 255)
            )
            self.screen.blit(emotion_surface, (char_x, y + 20))

    def _draw_pitch_track(self, data: Dict[str, Any], y: int):
        """Draw pitch tracking visualization"""
        pitch_hz = data.get("pitch_hz", 0)
        if pitch_hz <= 0:
            return

        # Update pitch history
        self.pitch_history.append(pitch_hz)
        if len(self.pitch_history) > self.history_length:
            self.pitch_history.pop(0)

        track_height = 50
        track_width = self.width - 20
        track_x = self.x + 10

        # Background
        pygame.draw.rect(
            self.screen, (25, 25, 35), (track_x, y, track_width, track_height)
        )
        pygame.draw.rect(
            self.screen, self.border_color, (track_x, y, track_width, track_height), 1
        )

        # Draw pitch history
        if len(self.pitch_history) > 1:
            # Find min/max for scaling
            min_pitch = min(self.pitch_history)
            max_pitch = max(self.pitch_history)
            pitch_range = max_pitch - min_pitch

            if pitch_range > 0:
                points = []
                for i, pitch in enumerate(self.pitch_history):
                    x_pos = track_x + int(i * track_width / self.history_length)
                    y_pos = (
                        y
                        + track_height
                        - int((pitch - min_pitch) / pitch_range * (track_height - 10))
                        - 5
                    )
                    points.append((x_pos, y_pos))

                # Draw pitch line
                if len(points) > 1:
                    pygame.draw.lines(self.screen, self.accent_color, False, points, 2)

                # Current pitch indicator
                current_y = points[-1][1]
                pygame.draw.circle(
                    self.screen,
                    (255, 200, 100),
                    (track_x + track_width - 5, current_y),
                    4,
                )

        # Pitch label
        pitch_text = f"Pitch: {pitch_hz:.1f} Hz"
        if "pitch_note" in data:
            pitch_text += f" ({data['pitch_note']})"
        pitch_surface = self.font_small.render(pitch_text, True, self.text_color)
        self.screen.blit(pitch_surface, (track_x, y - 15))

    def _draw_formant_plot(self, formants: Dict[str, Any], y: int):
        """Draw formant frequency plot"""
        plot_height = 70
        plot_width = self.width - 20
        plot_x = self.x + 10

        # Background
        pygame.draw.rect(
            self.screen, (25, 25, 35), (plot_x, y, plot_width, plot_height)
        )
        pygame.draw.rect(
            self.screen, self.border_color, (plot_x, y, plot_width, plot_height), 1
        )

        # Title
        title = self.font_small.render("Formants", True, self.text_color)
        self.screen.blit(title, (plot_x + 5, y - 15))

        # Draw formant bars
        formant_names = ["F1", "F2", "F3", "F4"]
        bar_width = plot_width // (len(formant_names) + 1)

        for i, f_name in enumerate(formant_names):
            if f_name in formants:
                f_data = formants[f_name]
                freq = f_data["frequency"]

                # Scale frequency (0-4000 Hz range)
                normalized = min(freq / 4000, 1.0)
                bar_height = int(normalized * (plot_height - 10))

                x_pos = plot_x + (i + 1) * bar_width - bar_width // 3
                y_pos = y + plot_height - bar_height - 5

                # Draw bar
                bar_rect = pygame.Rect(x_pos, y_pos, bar_width // 2, bar_height)
                color = self.formant_colors[i % len(self.formant_colors)]
                pygame.draw.rect(self.screen, color, bar_rect)

                # Frequency label
                freq_text = f"{freq:.0f}"
                freq_surface = self.font_small.render(freq_text, True, (150, 150, 170))
                freq_rect = freq_surface.get_rect(
                    centerx=x_pos + bar_width // 4, y=y_pos - 10
                )
                self.screen.blit(freq_surface, freq_rect)

                # Formant label
                label = self.font_small.render(f_name, True, self.text_color)
                label_rect = label.get_rect(
                    centerx=x_pos + bar_width // 4, y=y + plot_height + 2
                )
                self.screen.blit(label, label_rect)

    def _draw_vowel_space(self, formants: Dict[str, Any]):
        """Draw F1-F2 vowel space plot"""
        if "F1" not in formants or "F2" not in formants:
            return

        # Vowel space position (bottom right corner)
        vs_size = 100
        vs_x = self.x + self.width - vs_size - 10
        vs_y = self.y + self.height - vs_size - 40

        # Background
        pygame.draw.rect(self.screen, (20, 20, 30), (vs_x, vs_y, vs_size, vs_size))
        pygame.draw.rect(
            self.screen, self.border_color, (vs_x, vs_y, vs_size, vs_size), 1
        )

        # Title
        title = self.font_small.render("Vowel Space", True, (150, 150, 170))
        title_rect = title.get_rect(centerx=vs_x + vs_size // 2, y=vs_y - 15)
        self.screen.blit(title, title_rect)

        # Draw reference vowels
        for vowel, refs in self.vowel_references.items():
            # Scale to plot (F1: 200-800Hz, F2: 600-2400Hz)
            x = vs_x + int((refs["F2"] - 600) / 1800 * vs_size)
            y = vs_y + vs_size - int((refs["F1"] - 200) / 600 * vs_size)

            # Draw reference point
            pygame.draw.circle(self.screen, (100, 100, 120), (x, y), 3)

            # Vowel label
            v_surface = self.font_small.render(vowel, True, (150, 150, 170))
            v_rect = v_surface.get_rect(center=(x, y - 8))
            self.screen.blit(v_surface, v_rect)

        # Draw current formant position
        f1 = formants["F1"]["frequency"]
        f2 = formants["F2"]["frequency"]

        # Scale to plot
        current_x = vs_x + int((f2 - 600) / 1800 * vs_size)
        current_y = vs_y + vs_size - int((f1 - 200) / 600 * vs_size)

        # Ensure within bounds
        current_x = max(vs_x, min(vs_x + vs_size, current_x))
        current_y = max(vs_y, min(vs_y + vs_size, current_y))

        # Draw current position
        pygame.draw.circle(self.screen, (255, 200, 100), (current_x, current_y), 5)
        pygame.draw.circle(self.screen, (255, 255, 255), (current_x, current_y), 5, 1)

    def _draw_activity_timeline(self, y: int):
        """Draw voice activity timeline"""
        timeline_width = self.width - 20
        timeline_x = self.x + 10
        timeline_height = 20

        # Background
        pygame.draw.rect(
            self.screen, (30, 30, 40), (timeline_x, y, timeline_width, timeline_height)
        )
        pygame.draw.rect(
            self.screen,
            self.border_color,
            (timeline_x, y, timeline_width, timeline_height),
            1,
        )

        # Draw activity history
        if self.detection_history:
            bar_width = timeline_width / len(self.detection_history)
            for i, detected in enumerate(self.detection_history):
                if detected:
                    x_pos = timeline_x + int(i * bar_width)
                    bar_rect = pygame.Rect(
                        x_pos, y + 2, max(1, int(bar_width)), timeline_height - 4
                    )
                    # Fade older detections
                    alpha = int(255 * (i / len(self.detection_history)))
                    color = tuple(c * alpha // 255 for c in self.voice_active_color)
                    pygame.draw.rect(self.screen, color, bar_rect)

        # Timeline label
        label = self.font_small.render("Activity", True, (120, 120, 140))
        self.screen.blit(label, (timeline_x - 50, y + 3))

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle input events"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_f:
                # Toggle formant plot
                self.show_formant_plot = not self.show_formant_plot
                return True
            elif event.key == pygame.K_p:
                # Toggle pitch track
                self.show_pitch_track = not self.show_pitch_track
                return True
            elif event.key == pygame.K_v:
                # Toggle vowel space
                self.show_vowel_space = not self.show_vowel_space
                return True

        return False
