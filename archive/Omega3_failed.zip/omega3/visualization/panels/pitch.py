"""
OMEGA pitch detection and visualization panel
"""

import time
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class PitchPanel:
    """Advanced pitch detection and visualization panel"""

    def __init__(
        self, surface: pygame.Surface, x: int, y: int, width: int, height: int
    ):
        self.screen = surface
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)

        # Fonts
        self.font_small = pygame.font.Font(None, 18)
        self.font_medium = pygame.font.Font(None, 24)
        self.font_large = pygame.font.Font(None, 32)

        # Colors
        self.bg_color = (15, 17, 23)
        self.border_color = (45, 50, 60)
        self.text_color = (200, 200, 220)
        self.grid_color = (35, 40, 50)
        self.accent_color = (100, 200, 255)

        # Pitch colors
        self.pitch_gradient = [
            (100, 100, 255),  # Low pitches - Blue
            (100, 255, 255),  # Mid-low - Cyan
            (100, 255, 100),  # Mid - Green
            (255, 255, 100),  # Mid-high - Yellow
            (255, 100, 100),  # High - Red
        ]

        # Pitch tracking
        self.pitch_history = []
        self.confidence_history = []
        self.note_history = []
        self.history_length = 200
        self.pitch_range = (50, 2000)  # Hz range for display

        # Multi-pitch detection
        self.multi_pitches = []
        self.max_simultaneous_pitches = 5

        # Note detection
        self.current_note = None
        self.note_stability_counter = 0
        self.stable_note_threshold = 10  # frames

        # Visualization modes
        self.view_modes = ["Timeline", "Spiral", "Piano Roll", "3D Spectrum"]
        self.current_view = 0

        # Piano visualization
        self.octave_range = (2, 7)  # C2 to C7
        self.piano_keys = self._generate_piano_keys()

        # Animation
        self.animation_phase = 0
        self.last_update = time.time()

        # Pitch statistics
        self.pitch_stats = {
            "min": float("inf"),
            "max": float("-inf"),
            "average": 0,
            "median": 0,
            "vibrato_rate": 0,
            "vibrato_extent": 0,
        }

    def _generate_piano_keys(self) -> List[Dict[str, Any]]:
        """Generate piano key positions and notes"""
        keys = []
        notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

        for octave in range(self.octave_range[0], self.octave_range[1] + 1):
            for i, note in enumerate(notes):
                is_black = "#" in note
                frequency = 440.0 * (2.0 ** ((octave - 4) + (i - 9) / 12.0))
                keys.append(
                    {
                        "note": f"{note}{octave}",
                        "frequency": frequency,
                        "is_black": is_black,
                        "midi_number": octave * 12 + i,
                    }
                )

        return keys

    def update(self, pitch_data: Dict[str, Any]):
        """Update pitch tracking data"""
        current_time = time.time()
        dt = current_time - self.last_update
        self.last_update = current_time

        # Update animation
        self.animation_phase += dt * 2  # 2 Hz animation

        # Main pitch tracking
        if "pitch_hz" in pitch_data and pitch_data["pitch_hz"] > 0:
            pitch = pitch_data["pitch_hz"]
            confidence = pitch_data.get("confidence", 0)

            self.pitch_history.append(pitch)
            self.confidence_history.append(confidence)

            # Note detection
            if "note" in pitch_data:
                note = pitch_data["note"]
                self.note_history.append(note)

                # Check note stability
                if self.current_note == note:
                    self.note_stability_counter += 1
                else:
                    self.current_note = note
                    self.note_stability_counter = 1

            # Trim history
            if len(self.pitch_history) > self.history_length:
                self.pitch_history.pop(0)
                self.confidence_history.pop(0)
                if self.note_history:
                    self.note_history.pop(0)

        # Multi-pitch detection
        if "multi_pitches" in pitch_data:
            self.multi_pitches = pitch_data["multi_pitches"][
                : self.max_simultaneous_pitches
            ]

        # Update statistics
        self._update_pitch_statistics()

        # Detect vibrato
        if len(self.pitch_history) > 20:
            self._detect_vibrato()

    def _update_pitch_statistics(self):
        """Calculate pitch statistics"""
        if len(self.pitch_history) > 0:
            self.pitch_stats["min"] = min(self.pitch_history)
            self.pitch_stats["max"] = max(self.pitch_history)
            self.pitch_stats["average"] = np.mean(self.pitch_history)
            self.pitch_stats["median"] = np.median(self.pitch_history)

    def _detect_vibrato(self):
        """Detect vibrato in pitch history"""
        if len(self.pitch_history) < 50:
            return

        # Get recent pitch history
        recent_pitches = self.pitch_history[-50:]

        # Detrend the pitch data
        mean_pitch = np.mean(recent_pitches)
        detrended = [p - mean_pitch for p in recent_pitches]

        # Simple zero-crossing detection for vibrato rate
        zero_crossings = 0
        for i in range(1, len(detrended)):
            if detrended[i - 1] * detrended[i] < 0:
                zero_crossings += 1

        # Estimate vibrato rate (Hz)
        sample_duration = 50 / 30.0  # Assuming 30 FPS
        self.pitch_stats["vibrato_rate"] = zero_crossings / (2 * sample_duration)

        # Vibrato extent (cents)
        if mean_pitch > 0:
            pitch_std = np.std(recent_pitches)
            self.pitch_stats["vibrato_extent"] = 1200 * np.log2(
                1 + pitch_std / mean_pitch
            )

    def draw(self, data=None):
        """Draw the pitch panel"""
        # Clear background
        pygame.draw.rect(self.screen, self.bg_color, self.rect)
        pygame.draw.rect(self.screen, self.border_color, self.rect, 2)

        # Title with current view mode
        title_text = f"PITCH - {self.view_modes[self.current_view]}"
        title = self.font_large.render(title_text, True, self.text_color)
        title_rect = title.get_rect(centerx=self.x + self.width // 2, y=self.y + 5)
        self.screen.blit(title, title_rect)

        # Draw based on current view mode
        content_y = self.y + 40
        content_height = self.height - 120

        if self.current_view == 0:  # Timeline
            self._draw_timeline_view(content_y, content_height)
        elif self.current_view == 1:  # Spiral
            self._draw_spiral_view(content_y, content_height)
        elif self.current_view == 2:  # Piano Roll
            self._draw_piano_roll_view(content_y, content_height)
        elif self.current_view == 3:  # 3D Spectrum
            self._draw_3d_spectrum_view(content_y, content_height)

        # Draw current pitch info
        self._draw_current_pitch_info(self.y + self.height - 70)

        # Draw statistics
        self._draw_pitch_statistics(self.x + self.width - 150, self.y + 40)

    def _draw_timeline_view(self, y: int, height: int):
        """Draw pitch timeline visualization"""
        timeline_x = self.x + 10
        timeline_width = self.width - 20

        # Background
        pygame.draw.rect(
            self.screen, (20, 22, 28), (timeline_x, y, timeline_width, height)
        )
        pygame.draw.rect(
            self.screen, self.grid_color, (timeline_x, y, timeline_width, height), 1
        )

        if len(self.pitch_history) < 2:
            return

        # Draw grid lines
        for i in range(5):
            grid_y = y + int(i * height / 4)
            pygame.draw.line(
                self.screen,
                self.grid_color,
                (timeline_x, grid_y),
                (timeline_x + timeline_width, grid_y),
                1,
            )

            # Frequency labels
            freq = self.pitch_range[1] - (
                i * (self.pitch_range[1] - self.pitch_range[0]) / 4
            )
            label = self.font_small.render(f"{freq:.0f}Hz", True, (100, 100, 120))
            self.screen.blit(label, (timeline_x + 5, grid_y + 2))

        # Draw pitch line with confidence-based thickness
        points = []
        for i, pitch in enumerate(self.pitch_history):
            x_pos = timeline_x + int(i * timeline_width / self.history_length)

            # Logarithmic scale for pitch
            if pitch > 0:
                log_pitch = np.log2(pitch / self.pitch_range[0])
                log_range = np.log2(self.pitch_range[1] / self.pitch_range[0])
                normalized = log_pitch / log_range
                normalized = np.clip(normalized, 0, 1)
                y_pos = y + height - int(normalized * height)
                points.append((x_pos, y_pos))

        if points:
            # Draw main pitch line
            pygame.draw.lines(self.screen, self.accent_color, False, points, 2)

            # Draw confidence shading
            for i in range(len(points) - 1):
                if i < len(self.confidence_history):
                    conf = self.confidence_history[i]
                    if conf > 0.5:
                        alpha = int(conf * 100)
                        pygame.draw.line(
                            self.screen,
                            (*self.accent_color, alpha),
                            points[i],
                            points[i + 1],
                            3,
                        )

            # Current pitch indicator
            pygame.draw.circle(self.screen, (255, 200, 100), points[-1], 4)

        # Draw multi-pitch indicators
        if self.multi_pitches:
            for mp in self.multi_pitches:
                if mp["frequency"] > 0:
                    log_pitch = np.log2(mp["frequency"] / self.pitch_range[0])
                    log_range = np.log2(self.pitch_range[1] / self.pitch_range[0])
                    normalized = np.clip(log_pitch / log_range, 0, 1)
                    mp_y = y + height - int(normalized * height)

                    # Draw secondary pitch marker
                    pygame.draw.circle(
                        self.screen,
                        (150, 150, 255),
                        (timeline_x + timeline_width - 10, mp_y),
                        3,
                    )

    def _draw_spiral_view(self, y: int, height: int):
        """Draw pitch in spiral/helix visualization"""
        center_x = self.x + self.width // 2
        center_y = y + height // 2
        max_radius = min(self.width, height) // 2 - 20

        # Background circle
        pygame.draw.circle(
            self.screen, self.grid_color, (center_x, center_y), max_radius, 1
        )

        # Draw octave circles
        for octave in range(3, 7):
            radius = int(max_radius * (octave - 2) / 5)
            pygame.draw.circle(
                self.screen, (40, 40, 50), (center_x, center_y), radius, 1
            )

            # Octave label
            label = self.font_small.render(f"C{octave}", True, (100, 100, 120))
            self.screen.blit(label, (center_x + radius + 5, center_y - 10))

        # Draw note positions
        notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        for i, note in enumerate(notes):
            angle = -np.pi / 2 + (i / 12) * 2 * np.pi  # Start from top

            # Draw note lines
            x1 = center_x + int(np.cos(angle) * 20)
            y1 = center_y + int(np.sin(angle) * 20)
            x2 = center_x + int(np.cos(angle) * max_radius)
            y2 = center_y + int(np.sin(angle) * max_radius)

            is_black_key = "#" in note
            color = (60, 60, 70) if is_black_key else (80, 80, 90)
            pygame.draw.line(self.screen, color, (x1, y1), (x2, y2), 1)

            # Note labels
            if not is_black_key:
                label_x = center_x + int(np.cos(angle) * (max_radius + 15))
                label_y = center_y + int(np.sin(angle) * (max_radius + 15))
                label = self.font_small.render(note, True, (120, 120, 140))
                label_rect = label.get_rect(center=(label_x, label_y))
                self.screen.blit(label, label_rect)

        # Draw pitch history as spiral
        if self.pitch_history:
            points = []
            for i, pitch in enumerate(self.pitch_history[-100:]):  # Last 100 points
                if pitch > 0:
                    # Calculate position on spiral
                    note_pos = 12 * np.log2(pitch / 261.63)  # Position relative to C4
                    octave = int(note_pos // 12) + 4
                    note_angle = -np.pi / 2 + (note_pos % 12) / 12 * 2 * np.pi

                    # Radius based on octave
                    radius = max_radius * (octave - 2) / 5
                    radius = np.clip(radius, 20, max_radius)

                    x = center_x + int(np.cos(note_angle) * radius)
                    y = center_y + int(np.sin(note_angle) * radius)
                    points.append((x, y))

            if len(points) > 1:
                # Draw pitch trail
                for i in range(len(points) - 1):
                    alpha = int(255 * (i / len(points)))
                    color = self._get_pitch_color(
                        self.pitch_history[-(len(points) - i)]
                    )
                    pygame.draw.line(self.screen, color, points[i], points[i + 1], 2)

                # Current position
                pygame.draw.circle(self.screen, (255, 200, 100), points[-1], 5)

    def _draw_piano_roll_view(self, y: int, height: int):
        """Draw piano roll visualization"""
        roll_x = self.x + 10
        roll_width = self.width - 20

        # Calculate key dimensions
        white_key_count = sum(1 for k in self.piano_keys if not k["is_black"])
        key_width = roll_width // white_key_count
        key_height = height

        # Draw piano keys
        white_x = roll_x
        for key in self.piano_keys:
            if not key["is_black"]:
                # White key
                key_rect = pygame.Rect(white_x, y, key_width - 1, key_height)

                # Check if this key is active
                is_active = False
                if self.current_note and self.note_stability_counter > 3:
                    if key["note"] == self.current_note:
                        is_active = True

                color = (200, 200, 220) if not is_active else (255, 200, 100)
                pygame.draw.rect(self.screen, color, key_rect)
                pygame.draw.rect(self.screen, self.border_color, key_rect, 1)

                white_x += key_width

        # Draw black keys
        white_x = roll_x
        white_index = 0
        for key in self.piano_keys:
            if not key["is_black"]:
                white_index += 1
            else:
                # Black key position
                black_x = roll_x + (white_index - 0.65) * key_width
                black_width = int(key_width * 0.6)
                black_height = int(key_height * 0.6)

                key_rect = pygame.Rect(int(black_x), y, black_width, black_height)

                # Check if active
                is_active = False
                if self.current_note and self.note_stability_counter > 3:
                    if key["note"] == self.current_note:
                        is_active = True

                color = (40, 40, 50) if not is_active else (255, 150, 50)
                pygame.draw.rect(self.screen, color, key_rect)

        # Draw note history
        if self.note_history:
            history_y = y + key_height - 30
            bar_height = 20
            bar_width = roll_width // len(self.note_history)

            for i, note in enumerate(self.note_history):
                if note:
                    # Find key for this note
                    for key in self.piano_keys:
                        if key["note"] == note:
                            # Draw activity bar
                            bar_x = roll_x + i * bar_width
                            alpha = int(255 * (i / len(self.note_history)))
                            color = tuple(c * alpha // 255 for c in (100, 200, 255))
                            bar_rect = pygame.Rect(
                                bar_x, history_y, bar_width - 1, bar_height
                            )
                            pygame.draw.rect(self.screen, color, bar_rect)
                            break

    def _draw_3d_spectrum_view(self, y: int, height: int):
        """Draw 3D spectrum waterfall view"""
        spec_x = self.x + 10
        spec_width = self.width - 20
        spec_height = height

        # Create waterfall effect
        time_steps = 50
        freq_bins = 40

        # Background
        pygame.draw.rect(
            self.screen, (10, 10, 15), (spec_x, y, spec_width, spec_height)
        )

        # Generate spectrum data from pitch history
        if len(self.pitch_history) > time_steps:
            for t in range(time_steps):
                idx = -time_steps + t
                if idx < -len(self.pitch_history):
                    continue

                pitch = self.pitch_history[idx]
                if pitch <= 0:
                    continue

                # Create pseudo-spectrum around the pitch
                for f in range(freq_bins):
                    freq = self.pitch_range[0] * (
                        self.pitch_range[1] / self.pitch_range[0]
                    ) ** (f / freq_bins)

                    # Gaussian-like response around the pitch
                    distance = abs(np.log2(freq / pitch))
                    intensity = np.exp(-distance * 10) if distance < 0.5 else 0

                    if intensity > 0.01:
                        # 3D projection
                        x_pos = spec_x + int(f * spec_width / freq_bins)
                        y_pos = y + int(t * spec_height / time_steps)

                        # Add perspective
                        perspective = 1 - (t / time_steps) * 0.3
                        x_pos = int(
                            spec_x
                            + spec_width // 2
                            + (x_pos - spec_x - spec_width // 2) * perspective
                        )

                        # Color based on intensity and age
                        age_factor = t / time_steps
                        color_intensity = int(intensity * 255 * age_factor)
                        color = self._get_pitch_color(pitch, color_intensity)

                        # Draw pixel
                        pixel_size = max(1, int(3 * perspective))
                        pygame.draw.rect(
                            self.screen, color, (x_pos, y_pos, pixel_size, pixel_size)
                        )

    def _draw_current_pitch_info(self, y: int):
        """Draw current pitch information"""
        info_x = self.x + 10

        # Background
        info_rect = pygame.Rect(self.x + 5, y, self.width - 10, 60)
        pygame.draw.rect(self.screen, (25, 27, 33), info_rect)
        pygame.draw.rect(self.screen, self.border_color, info_rect, 1)

        if self.pitch_history and self.pitch_history[-1] > 0:
            current_pitch = self.pitch_history[-1]

            # Pitch frequency
            pitch_text = f"{current_pitch:.1f} Hz"
            pitch_surface = self.font_large.render(pitch_text, True, self.accent_color)
            self.screen.blit(pitch_surface, (info_x + 10, y + 5))

            # Note name
            if self.current_note:
                note_color = (
                    (255, 200, 100)
                    if self.note_stability_counter > 5
                    else (200, 200, 220)
                )
                note_surface = self.font_medium.render(
                    self.current_note, True, note_color
                )
                self.screen.blit(note_surface, (info_x + 150, y + 10))

                # Cents offset
                if self.note_history:
                    # Calculate cents offset from perfect pitch
                    note_freq = next(
                        (
                            k["frequency"]
                            for k in self.piano_keys
                            if k["note"] == self.current_note
                        ),
                        0,
                    )
                    if note_freq > 0:
                        cents = 1200 * np.log2(current_pitch / note_freq)
                        cents_color = (
                            (100, 255, 100) if abs(cents) < 10 else (255, 150, 100)
                        )
                        cents_text = f"{cents:+.0f}¢"
                        cents_surface = self.font_small.render(
                            cents_text, True, cents_color
                        )
                        self.screen.blit(cents_surface, (info_x + 220, y + 15))

            # Confidence bar
            if self.confidence_history:
                conf = self.confidence_history[-1]
                conf_width = int(conf * 100)
                conf_rect = pygame.Rect(info_x + 10, y + 40, conf_width, 10)
                conf_color = (100, 255, 100) if conf > 0.8 else (255, 200, 100)
                pygame.draw.rect(self.screen, conf_color, conf_rect)

                conf_text = f"Confidence: {conf * 100:.0f}%"
                conf_surface = self.font_small.render(conf_text, True, (150, 150, 170))
                self.screen.blit(conf_surface, (info_x + 120, y + 40))
        else:
            no_pitch = self.font_medium.render(
                "No pitch detected", True, (100, 100, 120)
            )
            self.screen.blit(no_pitch, (info_x + 10, y + 20))

    def _draw_pitch_statistics(self, x: int, y: int):
        """Draw pitch statistics panel"""
        stats_width = 140
        stats_height = 150

        # Background
        stats_rect = pygame.Rect(x, y, stats_width, stats_height)
        pygame.draw.rect(self.screen, (20, 22, 28), stats_rect)
        pygame.draw.rect(self.screen, self.grid_color, stats_rect, 1)

        # Title
        title = self.font_small.render("Statistics", True, self.text_color)
        self.screen.blit(title, (x + 5, y + 5))

        y_offset = y + 25

        # Display stats
        if len(self.pitch_history) > 0:
            stats_items = [
                ("Min", f"{self.pitch_stats['min']:.1f} Hz"),
                ("Max", f"{self.pitch_stats['max']:.1f} Hz"),
                ("Avg", f"{self.pitch_stats['average']:.1f} Hz"),
                ("Med", f"{self.pitch_stats['median']:.1f} Hz"),
            ]

            for label, value in stats_items:
                label_surf = self.font_small.render(label + ":", True, (120, 120, 140))
                value_surf = self.font_small.render(value, True, (180, 180, 200))
                self.screen.blit(label_surf, (x + 5, y_offset))
                self.screen.blit(value_surf, (x + 40, y_offset))
                y_offset += 18

            # Vibrato info
            if self.pitch_stats["vibrato_rate"] > 0.5:
                vib_text = f"Vibrato: {self.pitch_stats['vibrato_rate']:.1f} Hz"
                vib_surf = self.font_small.render(vib_text, True, (255, 200, 100))
                self.screen.blit(vib_surf, (x + 5, y_offset))

                y_offset += 18
                extent_text = f"Extent: {self.pitch_stats['vibrato_extent']:.0f}¢"
                extent_surf = self.font_small.render(extent_text, True, (200, 180, 100))
                self.screen.blit(extent_surf, (x + 5, y_offset))

    def _get_pitch_color(
        self, pitch: float, intensity: int = 255
    ) -> Tuple[int, int, int]:
        """Get color based on pitch frequency"""
        if pitch <= 0:
            return (100, 100, 100)

        # Map pitch to color gradient
        log_pitch = np.log2(pitch / 100)  # Normalize to 100 Hz base
        gradient_pos = (log_pitch / 4) % 1  # 4 octave cycle

        # Interpolate between gradient colors
        idx = int(gradient_pos * (len(self.pitch_gradient) - 1))
        frac = gradient_pos * (len(self.pitch_gradient) - 1) - idx

        if idx < len(self.pitch_gradient) - 1:
            color1 = self.pitch_gradient[idx]
            color2 = self.pitch_gradient[idx + 1]
            color = tuple(
                int(c1 * (1 - frac) + c2 * frac) for c1, c2 in zip(color1, color2)
            )
        else:
            color = self.pitch_gradient[-1]

        # Apply intensity
        return tuple(int(c * intensity / 255) for c in color)

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle input events"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_TAB:
                # Cycle through view modes
                self.current_view = (self.current_view + 1) % len(self.view_modes)
                return True
            elif event.key == pygame.K_r:
                # Reset statistics
                self.pitch_history.clear()
                self.confidence_history.clear()
                self.note_history.clear()
                self.pitch_stats = {
                    "min": float("inf"),
                    "max": float("-inf"),
                    "average": 0,
                    "median": 0,
                    "vibrato_rate": 0,
                    "vibrato_extent": 0,
                }
                return True

        return False
