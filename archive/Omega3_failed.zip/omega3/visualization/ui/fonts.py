"""
Font management for visualization UI
"""

import os
from typing import Dict
from typing import Optional
from typing import Tuple

import pygame


class FontManager:
    """Manages fonts for the visualization interface"""

    def __init__(self):
        pygame.font.init()

        # Font paths
        self.system_fonts = {
            "arial": "Arial",
            "helvetica": "Helvetica",
            "verdana": "Verdana",
            "tahoma": "Tahoma",
            "trebuchet": "Trebuchet MS",
            "georgia": "Georgia",
            "times": "Times New Roman",
            "courier": "Courier New",
            "monaco": "Monaco",
            "consolas": "Consolas",
            "dejavu_sans": "DejaVu Sans",
            "dejavu_mono": "DejaVu Sans Mono",
            "liberation_sans": "Liberation Sans",
            "liberation_mono": "Liberation Mono",
            "ubuntu": "Ubuntu",
            "ubuntu_mono": "Ubuntu Mono",
        }

        # Font categories
        self.font_categories = {
            "display": ["Arial", "Helvetica", "Ubuntu"],
            "ui": ["Verdana", "Tahoma", "DejaVu Sans"],
            "mono": ["Consolas", "Monaco", "DejaVu Sans Mono", "Ubuntu Mono"],
            "serif": ["Georgia", "Times New Roman"],
        }

        # Font sizes
        self.sizes = {
            "tiny": 12,
            "small": 14,
            "medium": 16,
            "large": 20,
            "xlarge": 24,
            "huge": 32,
            "giant": 48,
        }

        # Font cache
        self.font_cache: Dict[str, pygame.font.Font] = {}

        # Default fonts
        self.default_font_name = None
        self.mono_font_name = None

        # Initialize default fonts
        self._initialize_defaults()

    def _initialize_defaults(self):
        """Initialize default fonts"""
        # Find available fonts
        available_fonts = pygame.font.get_fonts()

        # Set default display font
        for font in ["ubuntu", "dejavu_sans", "arial", "helvetica"]:
            if font in available_fonts:
                self.default_font_name = self.system_fonts.get(font, font)
                break

        # Set default monospace font
        for font in ["ubuntu_mono", "dejavu_mono", "consolas", "monaco", "courier"]:
            if font in available_fonts:
                self.mono_font_name = self.system_fonts.get(font, font)
                break

        # Fallback to pygame default
        if not self.default_font_name:
            self.default_font_name = pygame.font.get_default_font()
        if not self.mono_font_name:
            self.mono_font_name = pygame.font.get_default_font()

    def get_font(
        self,
        size: int,
        font_name: Optional[str] = None,
        bold: bool = False,
        italic: bool = False,
    ) -> pygame.font.Font:
        """Get a font with caching"""
        # Use default if no font specified
        if font_name is None:
            font_name = self.default_font_name

        # Create cache key
        cache_key = f"{font_name}_{size}_{bold}_{italic}"

        # Check cache
        if cache_key in self.font_cache:
            return self.font_cache[cache_key]

        # Create font
        try:
            # Try to load as system font
            font = pygame.font.SysFont(font_name, size, bold, italic)
        except BaseException:
            # Try to load from file
            if os.path.exists(font_name):
                font = pygame.font.Font(font_name, size)
            else:
                # Fallback to default
                font = pygame.font.Font(None, size)

        # Cache and return
        self.font_cache[cache_key] = font
        return font

    def get_display_font(
        self, size_name: str = "medium", bold: bool = False
    ) -> pygame.font.Font:
        """Get display font by size name"""
        size = self.sizes.get(size_name, self.sizes["medium"])
        return self.get_font(size, self.default_font_name, bold)

    def get_mono_font(
        self, size_name: str = "medium", bold: bool = False
    ) -> pygame.font.Font:
        """Get monospace font by size name"""
        size = self.sizes.get(size_name, self.sizes["medium"])
        return self.get_font(size, self.mono_font_name, bold)

    def get_ui_font(self, size_name: str = "medium") -> pygame.font.Font:
        """Get UI font optimized for interface elements"""
        size = self.sizes.get(size_name, self.sizes["medium"])

        # Try to use a good UI font
        for font in ["verdana", "tahoma", "dejavu_sans"]:
            if font in pygame.font.get_fonts():
                return self.get_font(size, self.system_fonts.get(font, font))

        return self.get_font(size)

    def render_text(
        self,
        text: str,
        font: pygame.font.Font,
        color: Tuple[int, int, int],
        antialias: bool = True,
    ) -> pygame.Surface:
        """Render text with the given font"""
        return font.render(text, antialias, color)

    def render_text_with_shadow(
        self,
        text: str,
        font: pygame.font.Font,
        color: Tuple[int, int, int],
        shadow_color: Tuple[int, int, int] = (0, 0, 0),
        shadow_offset: Tuple[int, int] = (2, 2),
        antialias: bool = True,
    ) -> pygame.Surface:
        """Render text with shadow effect"""
        # Render shadow
        shadow = font.render(text, antialias, shadow_color)

        # Render main text
        main = font.render(text, antialias, color)

        # Create surface to hold both
        width = main.get_width() + abs(shadow_offset[0])
        height = main.get_height() + abs(shadow_offset[1])
        surface = pygame.Surface((width, height), pygame.SRCALPHA)

        # Blit shadow and text
        shadow_pos = (max(0, shadow_offset[0]), max(0, shadow_offset[1]))
        main_pos = (max(0, -shadow_offset[0]), max(0, -shadow_offset[1]))

        surface.blit(shadow, shadow_pos)
        surface.blit(main, main_pos)

        return surface

    def render_text_with_outline(
        self,
        text: str,
        font: pygame.font.Font,
        color: Tuple[int, int, int],
        outline_color: Tuple[int, int, int] = (0, 0, 0),
        outline_width: int = 2,
        antialias: bool = True,
    ) -> pygame.Surface:
        """Render text with outline effect"""
        # Render main text
        main = font.render(text, antialias, color)

        # Create surface with space for outline
        width = main.get_width() + outline_width * 2
        height = main.get_height() + outline_width * 2
        surface = pygame.Surface((width, height), pygame.SRCALPHA)

        # Render outline by drawing text in multiple positions
        outline = font.render(text, antialias, outline_color)
        for dx in range(-outline_width, outline_width + 1):
            for dy in range(-outline_width, outline_width + 1):
                if dx != 0 or dy != 0:
                    surface.blit(outline, (outline_width + dx, outline_width + dy))

        # Draw main text on top
        surface.blit(main, (outline_width, outline_width))

        return surface

    def get_text_size(self, text: str, font: pygame.font.Font) -> Tuple[int, int]:
        """Get the size of rendered text"""
        return font.size(text)

    def wrap_text(self, text: str, font: pygame.font.Font, max_width: int) -> list:
        """Wrap text to fit within max_width"""
        words = text.split(" ")
        lines = []
        current_line = []

        for word in words:
            test_line = " ".join(current_line + [word])
            width, _ = font.size(test_line)

            if width <= max_width:
                current_line.append(word)
            else:
                if current_line:
                    lines.append(" ".join(current_line))
                    current_line = [word]
                else:
                    # Word is too long, split it
                    lines.append(word)
                    current_line = []

        if current_line:
            lines.append(" ".join(current_line))

        return lines

    def render_multiline_text(
        self,
        lines: list,
        font: pygame.font.Font,
        color: Tuple[int, int, int],
        line_spacing: int = 2,
        align: str = "left",
        antialias: bool = True,
    ) -> pygame.Surface:
        """Render multiple lines of text"""
        if not lines:
            return pygame.Surface((0, 0))

        # Calculate total size
        line_surfaces = []
        max_width = 0
        total_height = 0

        for line in lines:
            surface = font.render(line, antialias, color)
            line_surfaces.append(surface)
            max_width = max(max_width, surface.get_width())
            total_height += surface.get_height() + line_spacing

        total_height -= line_spacing  # Remove last spacing

        # Create combined surface
        combined = pygame.Surface((max_width, total_height), pygame.SRCALPHA)

        # Blit lines
        y = 0
        for surface in line_surfaces:
            if align == "center":
                x = (max_width - surface.get_width()) // 2
            elif align == "right":
                x = max_width - surface.get_width()
            else:  # left
                x = 0

            combined.blit(surface, (x, y))
            y += surface.get_height() + line_spacing

        return combined

    def clear_cache(self):
        """Clear the font cache"""
        self.font_cache.clear()

    def get_available_fonts(self) -> list:
        """Get list of available system fonts"""
        return sorted(pygame.font.get_fonts())

    def font_exists(self, font_name: str) -> bool:
        """Check if a font exists on the system"""
        return font_name.lower() in pygame.font.get_fonts()


# Global font manager instance
font_manager = FontManager()
