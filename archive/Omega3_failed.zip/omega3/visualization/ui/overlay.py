"""
Overlay UI elements for OMEGA-3.
HUD and information overlays for the visualizer.
"""

from datetime import datetime
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame

from ...utils.constants import COLORS
from ...utils.constants import INFO_MESSAGES


class Overlay:
    """Base class for overlay elements."""

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.visible = True
        self.opacity = 255

    def update(self, data: Dict[str, Any]):
        """Update overlay with new data."""
        pass

    def render(self, surface: pygame.Surface):
        """Render overlay to surface."""
        pass


class InfoOverlay(Overlay):
    """Information display overlay."""

    def __init__(self, x: int, y: int, width: int = 300):
        super().__init__(x, y)
        self.width = width
        self.padding = 10

        # Data to display
        self.fps = 0
        self.latency = 0
        self.cpu_usage = 0
        self.sample_rate = 48000
        self.buffer_size = 2048
        self.fft_size = 4096

        # Visual settings
        self.background_color = (*COLORS["PANEL_BG"], 200)
        self.text_color = COLORS["TEXT"]
        self.header_color = COLORS["ACCENT"]

        # Font
        self.font = pygame.font.Font(None, 12)
        self.header_font = pygame.font.Font(None, 14)

    def update(self, data: Dict[str, Any]):
        """Update info display data."""
        self.fps = data.get("fps", self.fps)
        self.latency = data.get("latency", self.latency)
        self.cpu_usage = data.get("cpu_usage", self.cpu_usage)
        self.sample_rate = data.get("sample_rate", self.sample_rate)
        self.buffer_size = data.get("buffer_size", self.buffer_size)
        self.fft_size = data.get("fft_size", self.fft_size)

    def render(self, surface: pygame.Surface):
        if not self.visible:
            return

        # Create info lines
        lines = [
            ("OMEGA-3 Audio Visualizer", self.header_font, self.header_color),
            ("", self.font, self.text_color),  # Spacer
            (f"FPS: {self.fps:.1f}", self.font, self.text_color),
            (f"Latency: {self.latency:.1f}ms", self.font, self.text_color),
            (f"CPU: {self.cpu_usage:.1f}%", self.font, self.text_color),
            ("", self.font, self.text_color),  # Spacer
            (
                f"Sample Rate: {self.sample_rate/1000:.0f}kHz",
                self.font,
                self.text_color,
            ),
            (f"Buffer Size: {self.buffer_size}", self.font, self.text_color),
            (f"FFT Size: {self.fft_size}", self.font, self.text_color),
        ]

        # Calculate height
        line_height = 16
        height = len(lines) * line_height + 2 * self.padding

        # Create surface with alpha
        info_surface = pygame.Surface((self.width, height), pygame.SRCALPHA)

        # Draw background
        pygame.draw.rect(
            info_surface, self.background_color, (0, 0, self.width, height)
        )
        pygame.draw.rect(
            info_surface, COLORS["PANEL_BORDER"], (0, 0, self.width, height), 1
        )

        # Draw text
        y = self.padding
        for text, font, color in lines:
            if text:  # Skip empty lines
                text_surface = font.render(text, True, color)
                info_surface.blit(text_surface, (self.padding, y))
            y += line_height

        # Apply opacity
        info_surface.set_alpha(self.opacity)

        # Blit to main surface
        surface.blit(info_surface, (self.x, self.y))


class SpectrumInfoOverlay(Overlay):
    """Spectrum-specific information overlay."""

    def __init__(self, x: int, y: int):
        super().__init__(x, y)

        # Data
        self.peak_frequency = 0
        self.peak_note = ""
        self.peak_magnitude = -np.inf
        self.dominant_frequencies = []

        # Visual settings
        self.background_color = (*COLORS["PANEL_BG"], 180)
        self.text_color = COLORS["TEXT"]
        self.highlight_color = COLORS["ACCENT"]

        # Font
        self.font = pygame.font.Font(None, 14)
        self.small_font = pygame.font.Font(None, 12)

    def update(self, data: Dict[str, Any]):
        """Update spectrum info."""
        self.peak_frequency = data.get("peak_frequency", self.peak_frequency)
        self.peak_note = data.get("peak_note", self.peak_note)
        self.peak_magnitude = data.get("peak_magnitude", self.peak_magnitude)
        self.dominant_frequencies = data.get(
            "dominant_frequencies", self.dominant_frequencies
        )[:5]

    def render(self, surface: pygame.Surface):
        if not self.visible:
            return

        # Create content
        lines = []

        # Peak frequency
        if self.peak_frequency > 0:
            freq_text = (
                f"{self.peak_frequency:.1f}Hz"
                if self.peak_frequency < 1000
                else f"{self.peak_frequency/1000:.2f}kHz"
            )
            mag_text = f"{self.peak_magnitude:.1f}dB"
            lines.append(
                (
                    f"Peak: {freq_text} {self.peak_note} ({mag_text})",
                    self.font,
                    self.highlight_color,
                )
            )

        # Dominant frequencies
        if self.dominant_frequencies:
            lines.append(("Dominant:", self.small_font, self.text_color))
            for freq, mag in self.dominant_frequencies:
                freq_text = f"{freq:.0f}Hz" if freq < 1000 else f"{freq/1000:.1f}kHz"
                lines.append(
                    (f"  {freq_text}: {mag:.1f}dB", self.small_font, self.text_color)
                )

        if not lines:
            return

        # Calculate size
        padding = 8
        line_height = 14
        width = 200
        height = len(lines) * line_height + 2 * padding

        # Create surface
        info_surface = pygame.Surface((width, height), pygame.SRCALPHA)

        # Draw background
        pygame.draw.rect(info_surface, self.background_color, (0, 0, width, height))
        pygame.draw.rect(info_surface, COLORS["PANEL_BORDER"], (0, 0, width, height), 1)

        # Draw text
        y = padding
        for text, font, color in lines:
            text_surface = font.render(text, True, color)
            info_surface.blit(text_surface, (padding, y))
            y += line_height

        # Apply opacity
        info_surface.set_alpha(self.opacity)

        # Blit to main surface
        surface.blit(info_surface, (self.x, self.y))


class NotificationOverlay(Overlay):
    """Notification/message overlay."""

    def __init__(self, x: int, y: int):
        super().__init__(x, y)

        # Message queue
        self.messages = []  # List of (message, timestamp, duration, type)
        self.max_messages = 5

        # Visual settings
        self.message_height = 30
        self.message_spacing = 5
        self.fade_time = 0.5  # seconds

        # Colors by type
        self.colors = {
            "info": COLORS["ACCENT"],
            "success": COLORS["SUCCESS"],
            "warning": COLORS["WARNING"],
            "error": COLORS["ERROR"],
        }

        # Font
        self.font = pygame.font.Font(None, 14)

    def add_message(self, message: str, duration: float = 3.0, msg_type: str = "info"):
        """Add a notification message."""
        timestamp = datetime.now()
        self.messages.append((message, timestamp, duration, msg_type))

        # Limit message count
        if len(self.messages) > self.max_messages:
            self.messages.pop(0)

    def update(self, data: Dict[str, Any]):
        """Update and remove expired messages."""
        current_time = datetime.now()

        # Remove expired messages
        self.messages = [
            (msg, ts, dur, typ)
            for msg, ts, dur, typ in self.messages
            if (current_time - ts).total_seconds() < dur
        ]

    def render(self, surface: pygame.Surface):
        if not self.visible or not self.messages:
            return

        current_time = datetime.now()
        y_offset = 0

        for message, timestamp, duration, msg_type in self.messages:
            # Calculate age and opacity
            age = (current_time - timestamp).total_seconds()

            if age < self.fade_time:
                # Fade in
                opacity = int(255 * (age / self.fade_time))
            elif age > duration - self.fade_time:
                # Fade out
                remaining = duration - age
                opacity = int(255 * (remaining / self.fade_time))
            else:
                # Full opacity
                opacity = 255

            # Get color
            color = self.colors.get(msg_type, COLORS["TEXT"])

            # Create message surface
            text_surface = self.font.render(message, True, color)
            text_rect = text_surface.get_rect()

            # Background
            padding = 10
            bg_width = text_rect.width + 2 * padding
            bg_height = self.message_height

            msg_surface = pygame.Surface((bg_width, bg_height), pygame.SRCALPHA)

            # Draw background
            bg_color = (*COLORS["PANEL_BG"], int(200 * opacity / 255))
            pygame.draw.rect(msg_surface, bg_color, (0, 0, bg_width, bg_height))
            pygame.draw.rect(
                msg_surface, (*color, opacity), (0, 0, bg_width, bg_height), 2
            )

            # Draw text
            text_surface.set_alpha(opacity)
            msg_surface.blit(
                text_surface, (padding, (bg_height - text_rect.height) // 2)
            )

            # Blit to main surface
            surface.blit(msg_surface, (self.x, self.y + y_offset))

            y_offset += bg_height + self.message_spacing


class GridOverlay(Overlay):
    """Grid overlay for alignment and measurement."""

    def __init__(self, width: int, height: int):
        super().__init__(0, 0)
        self.width = width
        self.height = height

        # Grid settings
        self.grid_size = 50
        self.major_grid_interval = 5

        # Colors
        self.color_minor = (*COLORS["GRID"], 50)
        self.color_major = (*COLORS["GRID_MAJOR"], 100)

    def render(self, surface: pygame.Surface):
        if not self.visible:
            return

        # Create grid surface
        grid_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)

        # Draw vertical lines
        for x in range(0, self.width, self.grid_size):
            is_major = (x // self.grid_size) % self.major_grid_interval == 0
            color = self.color_major if is_major else self.color_minor
            width = 2 if is_major else 1
            pygame.draw.line(grid_surface, color, (x, 0), (x, self.height), width)

        # Draw horizontal lines
        for y in range(0, self.height, self.grid_size):
            is_major = (y // self.grid_size) % self.major_grid_interval == 0
            color = self.color_major if is_major else self.color_minor
            width = 2 if is_major else 1
            pygame.draw.line(grid_surface, color, (0, y), (self.width, y), width)

        # Apply opacity
        grid_surface.set_alpha(self.opacity)

        # Blit to main surface
        surface.blit(grid_surface, (0, 0))
