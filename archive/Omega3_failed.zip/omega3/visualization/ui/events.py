"""
Event handling for visualization UI
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any
from typing import Callable
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import pygame


class EventType(Enum):
    """Custom event types for visualization"""

    PANEL_RESIZE = "panel_resize"
    PANEL_MOVE = "panel_move"
    PANEL_CLOSE = "panel_close"
    PANEL_FOCUS = "panel_focus"
    LAYOUT_CHANGE = "layout_change"
    COLOR_SCHEME_CHANGE = "color_scheme_change"
    VIEW_MODE_CHANGE = "view_mode_change"
    AUDIO_EVENT = "audio_event"
    PERFORMANCE_WARNING = "performance_warning"


@dataclass
class VisualizationEvent:
    """Custom event for visualization system"""

    type: EventType
    data: Dict[str, Any]
    timestamp: float


class EventHandler:
    """Centralized event handling for visualization"""

    def __init__(self):
        # Event listeners
        self.listeners: Dict[EventType, List[Callable]] = {
            event_type: [] for event_type in EventType
        }

        # Keyboard shortcuts
        self.shortcuts: Dict[
            Tuple[int, int], Callable
        ] = {}  # (key, modifiers): callback

        # Mouse state
        self.mouse_state = {
            "position": (0, 0),
            "buttons": [False, False, False],  # Left, Middle, Right
            "dragging": False,
            "drag_start": None,
            "drag_target": None,
            "hover_target": None,
        }

        # Keyboard state
        self.keyboard_state = {
            "modifiers": {"shift": False, "ctrl": False, "alt": False, "meta": False},
            "pressed_keys": set(),
        }

        # Double-click detection
        self.double_click_time = 0.5  # seconds
        self.last_click_time = 0
        self.last_click_pos = (0, 0)

        # Event queue for custom events
        self.event_queue: List[VisualizationEvent] = []

        # Initialize default shortcuts
        self._init_default_shortcuts()

    def _init_default_shortcuts(self):
        """Initialize default keyboard shortcuts"""
        # Panel shortcuts
        self.register_shortcut(pygame.K_F11, 0, self._toggle_fullscreen)
        self.register_shortcut(pygame.K_TAB, 0, self._cycle_panels)
        self.register_shortcut(pygame.K_ESCAPE, 0, self._close_focused_panel)

        # Layout shortcuts
        self.register_shortcut(
            pygame.K_1, pygame.KMOD_CTRL, lambda: self._change_layout("omega")
        )
        self.register_shortcut(
            pygame.K_2, pygame.KMOD_CTRL, lambda: self._change_layout("grid")
        )
        self.register_shortcut(
            pygame.K_3, pygame.KMOD_CTRL, lambda: self._change_layout("horizontal")
        )
        self.register_shortcut(
            pygame.K_4, pygame.KMOD_CTRL, lambda: self._change_layout("vertical")
        )

        # View shortcuts
        self.register_shortcut(pygame.K_w, 0, lambda: self._toggle_panel("waveform"))
        self.register_shortcut(pygame.K_s, 0, lambda: self._toggle_panel("spectrum"))
        self.register_shortcut(pygame.K_g, 0, lambda: self._toggle_panel("spectrogram"))
        self.register_shortcut(pygame.K_m, 0, lambda: self._toggle_panel("meters"))
        self.register_shortcut(pygame.K_v, 0, lambda: self._toggle_panel("voice"))
        self.register_shortcut(pygame.K_h, 0, lambda: self._toggle_panel("harmonic"))

        # Help
        self.register_shortcut(pygame.K_F1, 0, self._show_help)

    def register_listener(self, event_type: EventType, callback: Callable):
        """Register an event listener"""
        if event_type in self.listeners:
            self.listeners[event_type].append(callback)

    def unregister_listener(self, event_type: EventType, callback: Callable):
        """Unregister an event listener"""
        if event_type in self.listeners and callback in self.listeners[event_type]:
            self.listeners[event_type].remove(callback)

    def register_shortcut(self, key: int, modifiers: int, callback: Callable):
        """Register a keyboard shortcut"""
        self.shortcuts[(key, modifiers)] = callback

    def emit_event(self, event_type: EventType, data: Dict[str, Any]):
        """Emit a custom event"""
        event = VisualizationEvent(
            type=event_type, data=data, timestamp=pygame.time.get_ticks() / 1000.0
        )
        self.event_queue.append(event)

    def process_event(self, event: pygame.event.Event) -> bool:
        """Process a pygame event"""
        handled = False

        if event.type == pygame.QUIT:
            return False  # Let main loop handle quit

        elif event.type == pygame.KEYDOWN:
            handled = self._handle_keydown(event)

        elif event.type == pygame.KEYUP:
            handled = self._handle_keyup(event)

        elif event.type == pygame.MOUSEBUTTONDOWN:
            handled = self._handle_mousedown(event)

        elif event.type == pygame.MOUSEBUTTONUP:
            handled = self._handle_mouseup(event)

        elif event.type == pygame.MOUSEMOTION:
            handled = self._handle_mousemotion(event)

        elif event.type == pygame.MOUSEWHEEL:
            handled = self._handle_mousewheel(event)

        return handled

    def process_custom_events(self):
        """Process queued custom events"""
        while self.event_queue:
            event = self.event_queue.pop(0)

            # Call listeners
            if event.type in self.listeners:
                for listener in self.listeners[event.type]:
                    try:
                        listener(event)
                    except Exception as e:
                        print(f"Error in event listener: {e}")

    def _handle_keydown(self, event: pygame.event.Event) -> bool:
        """Handle key press events"""
        # Update keyboard state
        self.keyboard_state["pressed_keys"].add(event.key)
        self._update_modifiers(event)

        # Check shortcuts
        modifiers = 0
        if self.keyboard_state["modifiers"]["shift"]:
            modifiers |= pygame.KMOD_SHIFT
        if self.keyboard_state["modifiers"]["ctrl"]:
            modifiers |= pygame.KMOD_CTRL
        if self.keyboard_state["modifiers"]["alt"]:
            modifiers |= pygame.KMOD_ALT
        if self.keyboard_state["modifiers"]["meta"]:
            modifiers |= pygame.KMOD_META

        shortcut_key = (event.key, modifiers)
        if shortcut_key in self.shortcuts:
            self.shortcuts[shortcut_key]()
            return True

        return False

    def _handle_keyup(self, event: pygame.event.Event) -> bool:
        """Handle key release events"""
        self.keyboard_state["pressed_keys"].discard(event.key)
        self._update_modifiers(event)
        return False

    def _handle_mousedown(self, event: pygame.event.Event) -> bool:
        """Handle mouse button press"""
        if event.button <= 3:
            self.mouse_state["buttons"][event.button - 1] = True

        # Check for double-click
        current_time = pygame.time.get_ticks() / 1000.0
        if (
            current_time - self.last_click_time < self.double_click_time
            and self._distance(event.pos, self.last_click_pos) < 5
        ):
            # Double click detected
            self.emit_event(
                EventType.PANEL_FOCUS, {"position": event.pos, "double_click": True}
            )

        self.last_click_time = current_time
        self.last_click_pos = event.pos

        # Start drag
        if event.button == 1:  # Left click
            self.mouse_state["dragging"] = True
            self.mouse_state["drag_start"] = event.pos

        return False

    def _handle_mouseup(self, event: pygame.event.Event) -> bool:
        """Handle mouse button release"""
        if event.button <= 3:
            self.mouse_state["buttons"][event.button - 1] = False

        # End drag
        if event.button == 1 and self.mouse_state["dragging"]:
            self.mouse_state["dragging"] = False

            if self.mouse_state["drag_target"]:
                # Emit drag end event
                self.emit_event(
                    EventType.PANEL_MOVE,
                    {
                        "panel": self.mouse_state["drag_target"],
                        "start": self.mouse_state["drag_start"],
                        "end": event.pos,
                    },
                )
                self.mouse_state["drag_target"] = None

        return False

    def _handle_mousemotion(self, event: pygame.event.Event) -> bool:
        """Handle mouse motion"""
        self.mouse_state["position"] = event.pos

        if self.mouse_state["dragging"] and self.mouse_state["drag_target"]:
            # Emit drag update event
            self.emit_event(
                EventType.PANEL_MOVE,
                {
                    "panel": self.mouse_state["drag_target"],
                    "position": event.pos,
                    "dragging": True,
                },
            )

        return False

    def _handle_mousewheel(self, event: pygame.event.Event) -> bool:
        """Handle mouse wheel events"""
        # Could be used for zooming or scrolling
        return False

    def _update_modifiers(self, event: pygame.event.Event):
        """Update modifier key state"""
        mods = pygame.key.get_mods()
        self.keyboard_state["modifiers"]["shift"] = bool(mods & pygame.KMOD_SHIFT)
        self.keyboard_state["modifiers"]["ctrl"] = bool(mods & pygame.KMOD_CTRL)
        self.keyboard_state["modifiers"]["alt"] = bool(mods & pygame.KMOD_ALT)
        self.keyboard_state["modifiers"]["meta"] = bool(mods & pygame.KMOD_META)

    def _distance(self, pos1: Tuple[int, int], pos2: Tuple[int, int]) -> float:
        """Calculate distance between two points"""
        dx = pos1[0] - pos2[0]
        dy = pos1[1] - pos2[1]
        return (dx * dx + dy * dy) ** 0.5

    # Default shortcut callbacks
    def _toggle_fullscreen(self):
        """Toggle fullscreen mode"""
        # This would be implemented by the main application
        pass

    def _cycle_panels(self):
        """Cycle through panels"""
        self.emit_event(EventType.PANEL_FOCUS, {"action": "cycle"})

    def _close_focused_panel(self):
        """Close the focused panel"""
        self.emit_event(EventType.PANEL_CLOSE, {"panel": "focused"})

    def _change_layout(self, layout_name: str):
        """Change to a specific layout"""
        self.emit_event(EventType.LAYOUT_CHANGE, {"layout": layout_name})

    def _toggle_panel(self, panel_name: str):
        """Toggle panel visibility"""
        self.emit_event(EventType.PANEL_FOCUS, {"panel": panel_name, "toggle": True})

    def _show_help(self):
        """Show help/shortcuts"""
        # This would be implemented by the main application
        pass

    def get_mouse_position(self) -> Tuple[int, int]:
        """Get current mouse position"""
        return self.mouse_state["position"]

    def is_key_pressed(self, key: int) -> bool:
        """Check if a key is currently pressed"""
        return key in self.keyboard_state["pressed_keys"]

    def is_modifier_pressed(self, modifier: str) -> bool:
        """Check if a modifier key is pressed"""
        return self.keyboard_state["modifiers"].get(modifier, False)

    def is_dragging(self) -> bool:
        """Check if currently dragging"""
        return self.mouse_state["dragging"]

    def set_drag_target(self, target: Any):
        """Set the current drag target"""
        self.mouse_state["drag_target"] = target

    def set_hover_target(self, target: Any):
        """Set the current hover target"""
        old_target = self.mouse_state["hover_target"]
        self.mouse_state["hover_target"] = target

        # Emit hover events
        if old_target != target:
            if old_target:
                self.emit_event(
                    EventType.PANEL_FOCUS, {"panel": old_target, "hover": False}
                )
            if target:
                self.emit_event(EventType.PANEL_FOCUS, {"panel": target, "hover": True})


# Global event handler instance
event_handler = EventHandler()
