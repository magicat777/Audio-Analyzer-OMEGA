"""
UI layout manager for organizing visualization panels
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import pygame


class LayoutType(Enum):
    """Available layout types"""

    GRID = "grid"
    HORIZONTAL = "horizontal"
    VERTICAL = "vertical"
    CUSTOM = "custom"
    OMEGA = "omega"


@dataclass
class PanelConfig:
    """Configuration for a panel"""

    name: str
    x: int
    y: int
    width: int
    height: int
    visible: bool = True
    resizable: bool = True
    min_width: int = 200
    min_height: int = 150


class LayoutManager:
    """Manages the layout of visualization panels"""

    def __init__(self, screen_width: int, screen_height: int):
        self.screen_width = screen_width
        self.screen_height = screen_height

        # Panel configurations
        self.panels: Dict[str, PanelConfig] = {}
        self.active_panels: List[str] = []

        # Layout settings
        self.current_layout = LayoutType.OMEGA
        self.margin = 5
        self.panel_spacing = 10

        # Predefined layouts
        self.layouts = {
            LayoutType.OMEGA: self._create_omega_layout,
            LayoutType.GRID: self._create_grid_layout,
            LayoutType.HORIZONTAL: self._create_horizontal_layout,
            LayoutType.VERTICAL: self._create_vertical_layout,
            LayoutType.CUSTOM: self._create_custom_layout,
        }

        # Panel groups for organization
        self.panel_groups = {
            "primary": ["spectrum", "waveform", "spectrogram"],
            "analysis": ["harmonic", "pitch", "chromagram"],
            "detection": ["voice", "drum", "genre"],
            "meters": ["vu_meters", "meters", "technical"],
            "detail": ["bass_detail", "meter_panel"],
        }

        # Initialize with default layout
        self.initialize_default_panels()
        self.apply_layout(LayoutType.OMEGA)

    def initialize_default_panels(self):
        """Initialize default panel configurations"""
        # Primary visualization panels
        self.register_panel("spectrum", 0, 0, 800, 400, resizable=True)
        self.register_panel("waveform", 0, 0, 800, 200, resizable=True)
        self.register_panel("spectrogram", 0, 0, 800, 300, resizable=True)

        # Analysis panels
        self.register_panel("harmonic", 0, 0, 400, 300, resizable=True)
        self.register_panel("pitch", 0, 0, 600, 400, resizable=True)
        self.register_panel("chromagram", 0, 0, 500, 350, resizable=True)

        # Detection panels
        self.register_panel("voice", 0, 0, 400, 350, resizable=True)
        self.register_panel("drum", 0, 0, 400, 300, resizable=True)
        self.register_panel("genre", 0, 0, 600, 400, resizable=True)

        # Meter panels
        self.register_panel("vu_meters", 0, 0, 600, 300, resizable=True)
        self.register_panel("meters", 0, 0, 400, 400, resizable=True)
        self.register_panel("technical", 0, 0, 800, 600, resizable=True)

        # Detail panels
        self.register_panel("bass_detail", 0, 0, 500, 300, resizable=True)
        self.register_panel("meter_panel", 0, 0, 300, 200, resizable=True)

    def register_panel(
        self,
        name: str,
        x: int,
        y: int,
        width: int,
        height: int,
        visible: bool = True,
        resizable: bool = True,
        min_width: int = 200,
        min_height: int = 150,
    ):
        """Register a new panel"""
        self.panels[name] = PanelConfig(
            name=name,
            x=x,
            y=y,
            width=width,
            height=height,
            visible=visible,
            resizable=resizable,
            min_width=min_width,
            min_height=min_height,
        )

    def apply_layout(self, layout_type: LayoutType):
        """Apply a predefined layout"""
        self.current_layout = layout_type

        if layout_type in self.layouts:
            self.layouts[layout_type]()

        # Update active panels list
        self.active_panels = [
            name for name, config in self.panels.items() if config.visible
        ]

    def _create_omega_layout(self):
        """Create the OMEGA professional layout"""
        # Clear visibility
        for panel in self.panels.values():
            panel.visible = False

        # Main spectrum display (top center)
        self._position_panel(
            "spectrum",
            self.margin,
            self.margin,
            self.screen_width - 2 * self.margin,
            self.screen_height // 3,
        )

        # Left column (voice, harmonic)
        left_width = self.screen_width // 4
        left_x = self.margin
        y_offset = self.screen_height // 3 + self.panel_spacing

        self._position_panel(
            "voice", left_x, y_offset, left_width - self.margin, self.screen_height // 3
        )

        self._position_panel(
            "harmonic",
            left_x,
            y_offset + self.screen_height // 3 + self.panel_spacing,
            left_width - self.margin,
            self.screen_height // 3 - self.margin,
        )

        # Center column (waveform, pitch)
        center_width = self.screen_width // 2
        center_x = left_width + self.panel_spacing

        self._position_panel(
            "waveform",
            center_x,
            y_offset,
            center_width - self.panel_spacing,
            self.screen_height // 6,
        )

        self._position_panel(
            "pitch",
            center_x,
            y_offset + self.screen_height // 6 + self.panel_spacing,
            center_width - self.panel_spacing,
            self.screen_height // 3,
        )

        # Right column (meters, technical overlay)
        right_width = self.screen_width // 4
        right_x = self.screen_width - right_width

        self._position_panel(
            "meters",
            right_x,
            y_offset,
            right_width - self.margin,
            self.screen_height // 3,
        )

        self._position_panel(
            "vu_meters",
            right_x,
            y_offset + self.screen_height // 3 + self.panel_spacing,
            right_width - self.margin,
            self.screen_height // 3 - self.margin,
        )

        # Bottom row (chromagram, genre, bass_detail)
        bottom_y = y_offset + self.screen_height // 3 + self.panel_spacing
        bottom_width = (center_width - 2 * self.panel_spacing) // 3

        self._position_panel(
            "chromagram",
            center_x,
            bottom_y,
            bottom_width,
            self.screen_height // 3 - self.margin,
        )

        self._position_panel(
            "genre",
            center_x + bottom_width + self.panel_spacing,
            bottom_y,
            bottom_width,
            self.screen_height // 3 - self.margin,
        )

        self._position_panel(
            "bass_detail",
            center_x + 2 * (bottom_width + self.panel_spacing),
            bottom_y,
            bottom_width,
            self.screen_height // 3 - self.margin,
        )

    def _create_grid_layout(self):
        """Create a grid layout"""
        # Show primary panels in a grid
        panels_to_show = [
            "spectrum",
            "waveform",
            "spectrogram",
            "harmonic",
            "voice",
            "meters",
        ]

        # Clear visibility
        for panel in self.panels.values():
            panel.visible = False

        # Calculate grid dimensions
        cols = 3
        rows = 2
        panel_width = (self.screen_width - (cols + 1) * self.panel_spacing) // cols
        panel_height = (self.screen_height - (rows + 1) * self.panel_spacing) // rows

        # Position panels
        for i, panel_name in enumerate(panels_to_show):
            if i < cols * rows:
                col = i % cols
                row = i // cols

                x = self.panel_spacing + col * (panel_width + self.panel_spacing)
                y = self.panel_spacing + row * (panel_height + self.panel_spacing)

                self._position_panel(panel_name, x, y, panel_width, panel_height)

    def _create_horizontal_layout(self):
        """Create a horizontal layout"""
        panels_to_show = ["waveform", "spectrum", "spectrogram"]

        # Clear visibility
        for panel in self.panels.values():
            panel.visible = False

        # Calculate dimensions
        panel_height = self.screen_height - 2 * self.margin
        panel_width = (
            self.screen_width - (len(panels_to_show) + 1) * self.panel_spacing
        ) // len(panels_to_show)

        # Position panels
        for i, panel_name in enumerate(panels_to_show):
            x = self.panel_spacing + i * (panel_width + self.panel_spacing)
            self._position_panel(panel_name, x, self.margin, panel_width, panel_height)

    def _create_vertical_layout(self):
        """Create a vertical layout"""
        panels_to_show = ["spectrum", "waveform", "meters"]

        # Clear visibility
        for panel in self.panels.values():
            panel.visible = False

        # Calculate dimensions
        panel_width = self.screen_width - 2 * self.margin
        panel_height = (
            self.screen_height - (len(panels_to_show) + 1) * self.panel_spacing
        ) // len(panels_to_show)

        # Position panels
        for i, panel_name in enumerate(panels_to_show):
            y = self.panel_spacing + i * (panel_height + self.panel_spacing)
            self._position_panel(panel_name, self.margin, y, panel_width, panel_height)

    def _create_custom_layout(self):
        """Create a custom layout (can be modified by user)"""
        # For now, just show all panels in their current positions
        for panel in self.panels.values():
            panel.visible = True

    def _position_panel(self, name: str, x: int, y: int, width: int, height: int):
        """Position a panel and make it visible"""
        if name in self.panels:
            panel = self.panels[name]
            panel.x = x
            panel.y = y
            panel.width = max(width, panel.min_width)
            panel.height = max(height, panel.min_height)
            panel.visible = True

    def toggle_panel(self, panel_name: str):
        """Toggle panel visibility"""
        if panel_name in self.panels:
            self.panels[panel_name].visible = not self.panels[panel_name].visible
            self._update_active_panels()

    def show_panel_group(self, group_name: str):
        """Show all panels in a group"""
        if group_name in self.panel_groups:
            for panel_name in self.panel_groups[group_name]:
                if panel_name in self.panels:
                    self.panels[panel_name].visible = True
            self._update_active_panels()

    def hide_panel_group(self, group_name: str):
        """Hide all panels in a group"""
        if group_name in self.panel_groups:
            for panel_name in self.panel_groups[group_name]:
                if panel_name in self.panels:
                    self.panels[panel_name].visible = False
            self._update_active_panels()

    def _update_active_panels(self):
        """Update the list of active panels"""
        self.active_panels = [
            name for name, config in self.panels.items() if config.visible
        ]

    def get_panel_rect(self, panel_name: str) -> Optional[pygame.Rect]:
        """Get the rectangle for a panel"""
        if panel_name in self.panels and self.panels[panel_name].visible:
            panel = self.panels[panel_name]
            return pygame.Rect(panel.x, panel.y, panel.width, panel.height)
        return None

    def resize_panel(self, panel_name: str, width: int, height: int):
        """Resize a panel"""
        if panel_name in self.panels:
            panel = self.panels[panel_name]
            if panel.resizable:
                panel.width = max(width, panel.min_width)
                panel.height = max(height, panel.min_height)

    def move_panel(self, panel_name: str, x: int, y: int):
        """Move a panel to a new position"""
        if panel_name in self.panels:
            panel = self.panels[panel_name]
            panel.x = max(0, min(x, self.screen_width - panel.width))
            panel.y = max(0, min(y, self.screen_height - panel.height))

    def handle_resize(self, new_width: int, new_height: int):
        """Handle screen resize"""
        # Calculate scale factors
        scale_x = new_width / self.screen_width
        scale_y = new_height / self.screen_height

        # Update screen dimensions
        self.screen_width = new_width
        self.screen_height = new_height

        # Reapply current layout
        self.apply_layout(self.current_layout)

    def save_layout(self, filename: str):
        """Save current layout to file"""
        import json

        layout_data = {
            "screen_width": self.screen_width,
            "screen_height": self.screen_height,
            "current_layout": self.current_layout.value,
            "panels": {},
        }

        for name, panel in self.panels.items():
            layout_data["panels"][name] = {
                "x": panel.x,
                "y": panel.y,
                "width": panel.width,
                "height": panel.height,
                "visible": panel.visible,
            }

        with open(filename, "w") as f:
            json.dump(layout_data, f, indent=2)

    def load_layout(self, filename: str):
        """Load layout from file"""
        import json

        try:
            with open(filename, "r") as f:
                layout_data = json.load(f)

            # Apply panel positions
            for name, data in layout_data["panels"].items():
                if name in self.panels:
                    panel = self.panels[name]
                    panel.x = data["x"]
                    panel.y = data["y"]
                    panel.width = data["width"]
                    panel.height = data["height"]
                    panel.visible = data["visible"]

            self._update_active_panels()
            self.current_layout = LayoutType.CUSTOM

        except Exception as e:
            print(f"Error loading layout: {e}")

    def get_layout_info(self) -> Dict[str, Any]:
        """Get information about current layout"""
        return {
            "type": self.current_layout.value,
            "active_panels": self.active_panels,
            "total_panels": len(self.panels),
            "visible_panels": len(self.active_panels),
            "screen_size": (self.screen_width, self.screen_height),
        }
