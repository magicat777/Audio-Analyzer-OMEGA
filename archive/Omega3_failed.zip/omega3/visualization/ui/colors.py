"""
Color schemes and gradients for visualization
"""

import colorsys
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame


class ColorScheme:
    """Base class for color schemes"""

    def __init__(self, name: str):
        self.name = name

        # Base colors
        self.background = (10, 12, 18)
        self.foreground = (200, 200, 220)
        self.accent = (100, 200, 255)
        self.warning = (255, 200, 100)
        self.error = (255, 100, 100)
        self.success = (100, 255, 100)

        # UI colors
        self.panel_bg = (20, 22, 28)
        self.panel_border = (50, 55, 65)
        self.grid = (35, 40, 50)
        self.text = (180, 180, 200)
        self.text_dim = (120, 120, 140)

        # Visualization colors
        self.spectrum_gradient = []
        self.waveform_color = (100, 200, 255)
        self.peak_color = (255, 200, 100)
        self.rms_color = (100, 255, 100)


class OmegaColorScheme(ColorScheme):
    """OMEGA professional color scheme"""

    def __init__(self):
        super().__init__("OMEGA")

        # Deep space theme
        self.background = (5, 7, 12)
        self.panel_bg = (15, 17, 23)
        self.panel_border = (45, 50, 60)
        self.grid = (25, 30, 40)

        # Neon accents
        self.accent = (0, 255, 255)  # Cyan
        self.warning = (255, 100, 255)  # Magenta
        self.error = (255, 50, 100)
        self.success = (50, 255, 200)

        # Text
        self.text = (200, 200, 220)
        self.text_dim = (100, 100, 120)

        # Spectrum gradient (thermal-inspired)
        self.spectrum_gradient = self._create_thermal_gradient()

        # Waveform colors
        self.waveform_color = (100, 200, 255)
        self.waveform_fill = (50, 100, 150, 100)

        # Level colors
        self.level_low = (50, 100, 255)
        self.level_mid = (50, 255, 100)
        self.level_high = (255, 255, 50)
        self.level_peak = (255, 50, 50)

    def _create_thermal_gradient(self) -> List[Tuple[int, int, int]]:
        """Create thermal-style gradient for spectrum"""
        gradient = []
        steps = 256

        for i in range(steps):
            t = i / steps

            if t < 0.25:
                # Black to blue
                r, g, b = 0, 0, int(t * 4 * 255)
            elif t < 0.5:
                # Blue to cyan
                r, g, b = 0, int((t - 0.25) * 4 * 255), 255
            elif t < 0.75:
                # Cyan to yellow
                r, g, b = int((t - 0.5) * 4 * 255), 255, 255 - int((t - 0.5) * 4 * 255)
            else:
                # Yellow to white
                r, g, b = 255, 255, int((t - 0.75) * 4 * 255)

            gradient.append((r, g, b))

        return gradient


class CyberpunkColorScheme(ColorScheme):
    """Cyberpunk-inspired color scheme"""

    def __init__(self):
        super().__init__("Cyberpunk")

        self.background = (10, 0, 20)
        self.panel_bg = (20, 10, 30)
        self.panel_border = (80, 40, 100)
        self.grid = (40, 20, 50)

        self.accent = (255, 0, 255)  # Magenta
        self.warning = (255, 255, 0)
        self.error = (255, 0, 100)
        self.success = (0, 255, 200)

        self.spectrum_gradient = self._create_neon_gradient()
        self.waveform_color = (255, 0, 200)

    def _create_neon_gradient(self) -> List[Tuple[int, int, int]]:
        """Create neon gradient"""
        gradient = []
        for i in range(256):
            t = i / 256
            # Magenta to cyan
            r = int(255 * (1 - t))
            g = int(255 * t)
            b = 255
            gradient.append((r, g, b))
        return gradient


class MatrixColorScheme(ColorScheme):
    """Matrix-inspired green color scheme"""

    def __init__(self):
        super().__init__("Matrix")

        self.background = (0, 5, 0)
        self.panel_bg = (0, 15, 0)
        self.panel_border = (0, 80, 0)
        self.grid = (0, 40, 0)

        self.accent = (0, 255, 0)
        self.warning = (200, 255, 0)
        self.error = (255, 200, 0)
        self.success = (100, 255, 100)

        self.text = (150, 255, 150)
        self.text_dim = (50, 150, 50)

        self.spectrum_gradient = self._create_matrix_gradient()
        self.waveform_color = (0, 255, 0)

    def _create_matrix_gradient(self) -> List[Tuple[int, int, int]]:
        """Create matrix green gradient"""
        gradient = []
        for i in range(256):
            intensity = i / 256
            r = int(50 * intensity)
            g = int(255 * intensity)
            b = int(50 * intensity)
            gradient.append((r, g, b))
        return gradient


class ColorManager:
    """Manages color schemes and color utilities"""

    def __init__(self):
        self.schemes = {
            "OMEGA": OmegaColorScheme(),
            "Cyberpunk": CyberpunkColorScheme(),
            "Matrix": MatrixColorScheme(),
        }

        self.current_scheme_name = "OMEGA"
        self.current_scheme = self.schemes[self.current_scheme_name]

        # Gradient cache
        self.gradient_cache: Dict[str, List[Tuple[int, int, int]]] = {}

    def set_scheme(self, scheme_name: str):
        """Set the current color scheme"""
        if scheme_name in self.schemes:
            self.current_scheme_name = scheme_name
            self.current_scheme = self.schemes[scheme_name]
            self.gradient_cache.clear()  # Clear cache when changing schemes

    def get_scheme(self) -> ColorScheme:
        """Get current color scheme"""
        return self.current_scheme

    def create_gradient(
        self,
        start_color: Tuple[int, int, int],
        end_color: Tuple[int, int, int],
        steps: int = 256,
    ) -> List[Tuple[int, int, int]]:
        """Create a gradient between two colors"""
        cache_key = f"{start_color}_{end_color}_{steps}"

        if cache_key in self.gradient_cache:
            return self.gradient_cache[cache_key]

        gradient = []
        for i in range(steps):
            t = i / (steps - 1)
            r = int(start_color[0] * (1 - t) + end_color[0] * t)
            g = int(start_color[1] * (1 - t) + end_color[1] * t)
            b = int(start_color[2] * (1 - t) + end_color[2] * t)
            gradient.append((r, g, b))

        self.gradient_cache[cache_key] = gradient
        return gradient

    def create_rainbow_gradient(self, steps: int = 256) -> List[Tuple[int, int, int]]:
        """Create a rainbow gradient"""
        cache_key = f"rainbow_{steps}"

        if cache_key in self.gradient_cache:
            return self.gradient_cache[cache_key]

        gradient = []
        for i in range(steps):
            hue = i / steps
            rgb = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
            gradient.append(tuple(int(c * 255) for c in rgb))

        self.gradient_cache[cache_key] = gradient
        return gradient

    def create_heat_gradient(self, steps: int = 256) -> List[Tuple[int, int, int]]:
        """Create a heat map gradient"""
        cache_key = f"heat_{steps}"

        if cache_key in self.gradient_cache:
            return self.gradient_cache[cache_key]

        gradient = []
        for i in range(steps):
            t = i / steps

            if t < 0.33:
                # Black to red
                r = int(t * 3 * 255)
                g, b = 0, 0
            elif t < 0.66:
                # Red to yellow
                r = 255
                g = int((t - 0.33) * 3 * 255)
                b = 0
            else:
                # Yellow to white
                r, g = 255, 255
                b = int((t - 0.66) * 3 * 255)

            gradient.append((r, g, b))

        self.gradient_cache[cache_key] = gradient
        return gradient

    def get_db_color(self, db_value: float) -> Tuple[int, int, int]:
        """Get color based on dB level"""
        if db_value < -40:
            return self.current_scheme.level_low
        elif db_value < -20:
            # Interpolate between low and mid
            t = (db_value + 40) / 20
            return self._interpolate_color(
                self.current_scheme.level_low, self.current_scheme.level_mid, t
            )
        elif db_value < -6:
            # Interpolate between mid and high
            t = (db_value + 20) / 14
            return self._interpolate_color(
                self.current_scheme.level_mid, self.current_scheme.level_high, t
            )
        else:
            # Interpolate between high and peak
            t = min((db_value + 6) / 6, 1.0)
            return self._interpolate_color(
                self.current_scheme.level_high, self.current_scheme.level_peak, t
            )

    def get_frequency_color(
        self,
        frequency: float,
        spectrum_gradient: Optional[List[Tuple[int, int, int]]] = None,
    ) -> Tuple[int, int, int]:
        """Get color based on frequency"""
        if spectrum_gradient is None:
            spectrum_gradient = self.current_scheme.spectrum_gradient

        if not spectrum_gradient:
            return self.current_scheme.accent

        # Map frequency to gradient (20Hz to 20kHz)
        if frequency <= 20:
            return spectrum_gradient[0]
        elif frequency >= 20000:
            return spectrum_gradient[-1]
        else:
            # Logarithmic mapping
            log_freq = np.log10(frequency / 20)
            log_max = np.log10(20000 / 20)
            index = int((log_freq / log_max) * (len(spectrum_gradient) - 1))
            return spectrum_gradient[index]

    def _interpolate_color(
        self, color1: Tuple[int, int, int], color2: Tuple[int, int, int], t: float
    ) -> Tuple[int, int, int]:
        """Interpolate between two colors"""
        t = np.clip(t, 0, 1)
        r = int(color1[0] * (1 - t) + color2[0] * t)
        g = int(color1[1] * (1 - t) + color2[1] * t)
        b = int(color1[2] * (1 - t) + color2[2] * t)
        return (r, g, b)

    def apply_alpha(
        self, color: Tuple[int, int, int], alpha: float
    ) -> Tuple[int, int, int, int]:
        """Apply alpha to a color"""
        alpha = int(np.clip(alpha * 255, 0, 255))
        return (*color, alpha)

    def brighten(
        self, color: Tuple[int, int, int], factor: float = 1.2
    ) -> Tuple[int, int, int]:
        """Brighten a color"""
        return tuple(min(int(c * factor), 255) for c in color)

    def darken(
        self, color: Tuple[int, int, int], factor: float = 0.8
    ) -> Tuple[int, int, int]:
        """Darken a color"""
        return tuple(int(c * factor) for c in color)

    def get_contrasting_color(
        self, background: Tuple[int, int, int]
    ) -> Tuple[int, int, int]:
        """Get a contrasting color for text on background"""
        # Calculate luminance
        luminance = (
            0.299 * background[0] + 0.587 * background[1] + 0.114 * background[2]
        ) / 255

        # Return white or black based on luminance
        return (255, 255, 255) if luminance < 0.5 else (0, 0, 0)

    def create_surface_with_gradient(
        self,
        width: int,
        height: int,
        gradient: List[Tuple[int, int, int]],
        direction: str = "horizontal",
    ) -> pygame.Surface:
        """Create a surface filled with gradient"""
        surface = pygame.Surface((width, height))

        if direction == "horizontal":
            for x in range(width):
                color_index = int((x / width) * len(gradient))
                color_index = min(color_index, len(gradient) - 1)
                pygame.draw.line(surface, gradient[color_index], (x, 0), (x, height))
        else:  # vertical
            for y in range(height):
                color_index = int((y / height) * len(gradient))
                color_index = min(color_index, len(gradient) - 1)
                pygame.draw.line(surface, gradient[color_index], (0, y), (width, y))

        return surface


# Global color manager instance
color_manager = ColorManager()
