"""
UI control elements for OMEGA-3.
Interactive controls for the visualizer interface.
"""

from typing import Any
from typing import Callable
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import pygame

from ...utils.constants import COLORS


class UIControl:
    """Base class for UI controls."""

    def __init__(self, x: int, y: int, width: int, height: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)

        self.visible = True
        self.enabled = True
        self.hovered = False
        self.pressed = False

        self.on_change = None

    def handle_event(self, event: pygame.event.Event) -> bool:
        """Handle pygame event. Returns True if event was consumed."""
        if not self.visible or not self.enabled:
            return False

        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)

        return False

    def update(self):
        """Update control state."""
        pass

    def render(self, surface: pygame.Surface):
        """Render control to surface."""
        pass

    def set_callback(self, callback: Callable):
        """Set change callback."""
        self.on_change = callback


class Button(UIControl):
    """Clickable button control."""

    def __init__(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        text: str = "",
        icon: Optional[pygame.Surface] = None,
    ):
        super().__init__(x, y, width, height)
        self.text = text
        self.icon = icon

        # Colors
        self.color_normal = COLORS["PANEL_BG"]
        self.color_hover = (60, 60, 70)
        self.color_pressed = (80, 80, 90)
        self.color_text = COLORS["TEXT"]
        self.color_border = COLORS["PANEL_BORDER"]

        # Font
        self.font = pygame.font.Font(None, 14)

    def handle_event(self, event: pygame.event.Event) -> bool:
        if not super().handle_event(event):
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and self.hovered:
                    self.pressed = True
                    return True

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1 and self.pressed:
                    self.pressed = False
                    if self.hovered and self.on_change:
                        self.on_change()
                    return True

        return False

    def render(self, surface: pygame.Surface):
        if not self.visible:
            return

        # Determine color
        if self.pressed and self.hovered:
            color = self.color_pressed
        elif self.hovered and self.enabled:
            color = self.color_hover
        else:
            color = self.color_normal

        # Draw button
        pygame.draw.rect(surface, color, self.rect)
        pygame.draw.rect(surface, self.color_border, self.rect, 1)

        # Draw content
        if self.icon:
            icon_rect = self.icon.get_rect()
            icon_rect.center = self.rect.center
            surface.blit(self.icon, icon_rect)

        if self.text:
            text_color = self.color_text if self.enabled else COLORS["TEXT_DIM"]
            text_surface = self.font.render(self.text, True, text_color)
            text_rect = text_surface.get_rect()
            text_rect.center = self.rect.center
            surface.blit(text_surface, text_rect)


class Slider(UIControl):
    """Horizontal or vertical slider control."""

    def __init__(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        min_value: float = 0.0,
        max_value: float = 1.0,
        value: float = 0.5,
        orientation: str = "horizontal",
    ):
        super().__init__(x, y, width, height)
        self.min_value = min_value
        self.max_value = max_value
        self.value = value
        self.orientation = orientation

        # Visual settings
        self.track_thickness = 4
        self.handle_size = 16

        # Colors
        self.color_track = (60, 60, 70)
        self.color_fill = COLORS["ACCENT"]
        self.color_handle = COLORS["TEXT"]
        self.color_handle_hover = COLORS["WHITE"]

        # State
        self.dragging = False

    def handle_event(self, event: pygame.event.Event) -> bool:
        if not super().handle_event(event):
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and self.hovered:
                    self.dragging = True
                    self._update_value_from_mouse(event.pos)
                    return True

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1 and self.dragging:
                    self.dragging = False
                    return True

            elif event.type == pygame.MOUSEMOTION:
                if self.dragging:
                    self._update_value_from_mouse(event.pos)
                    return True

        return False

    def _update_value_from_mouse(self, mouse_pos: Tuple[int, int]):
        """Update value based on mouse position."""
        if self.orientation == "horizontal":
            relative_x = mouse_pos[0] - self.x
            normalized = np.clip(relative_x / self.width, 0, 1)
        else:  # vertical
            relative_y = mouse_pos[1] - self.y
            normalized = 1 - np.clip(relative_y / self.height, 0, 1)

        self.value = self.min_value + normalized * (self.max_value - self.min_value)

        if self.on_change:
            self.on_change(self.value)

    def render(self, surface: pygame.Surface):
        if not self.visible:
            return

        # Calculate positions
        normalized = (self.value - self.min_value) / (self.max_value - self.min_value)

        if self.orientation == "horizontal":
            # Draw track
            track_y = self.y + self.height // 2 - self.track_thickness // 2
            pygame.draw.rect(
                surface,
                self.color_track,
                (self.x, track_y, self.width, self.track_thickness),
            )

            # Draw fill
            fill_width = int(normalized * self.width)
            pygame.draw.rect(
                surface,
                self.color_fill,
                (self.x, track_y, fill_width, self.track_thickness),
            )

            # Draw handle
            handle_x = self.x + int(normalized * self.width)
            handle_y = self.y + self.height // 2
            handle_color = (
                self.color_handle_hover
                if (self.hovered or self.dragging)
                else self.color_handle
            )
            pygame.draw.circle(
                surface, handle_color, (handle_x, handle_y), self.handle_size // 2
            )

        else:  # vertical
            # Draw track
            track_x = self.x + self.width // 2 - self.track_thickness // 2
            pygame.draw.rect(
                surface,
                self.color_track,
                (track_x, self.y, self.track_thickness, self.height),
            )

            # Draw fill
            fill_height = int(normalized * self.height)
            fill_y = self.y + self.height - fill_height
            pygame.draw.rect(
                surface,
                self.color_fill,
                (track_x, fill_y, self.track_thickness, fill_height),
            )

            # Draw handle
            handle_x = self.x + self.width // 2
            handle_y = self.y + int((1 - normalized) * self.height)
            handle_color = (
                self.color_handle_hover
                if (self.hovered or self.dragging)
                else self.color_handle
            )
            pygame.draw.circle(
                surface, handle_color, (handle_x, handle_y), self.handle_size // 2
            )

    def set_value(self, value: float):
        """Set slider value."""
        self.value = np.clip(value, self.min_value, self.max_value)


class Knob(UIControl):
    """Rotary knob control."""

    def __init__(
        self,
        x: int,
        y: int,
        size: int,
        min_value: float = 0.0,
        max_value: float = 1.0,
        value: float = 0.5,
    ):
        super().__init__(x, y, size, size)
        self.size = size
        self.min_value = min_value
        self.max_value = max_value
        self.value = value

        # Visual settings
        self.start_angle = 225  # degrees
        self.end_angle = -45  # degrees
        self.notch_length = 8

        # Colors
        self.color_body = (60, 60, 70)
        self.color_notch = COLORS["ACCENT"]
        self.color_track = (40, 40, 45)
        self.color_fill = COLORS["ACCENT"]

        # State
        self.dragging = False
        self.drag_start_y = 0
        self.drag_start_value = 0

    def handle_event(self, event: pygame.event.Event) -> bool:
        if not super().handle_event(event):
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and self.hovered:
                    self.dragging = True
                    self.drag_start_y = event.pos[1]
                    self.drag_start_value = self.value
                    return True

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1 and self.dragging:
                    self.dragging = False
                    return True

            elif event.type == pygame.MOUSEMOTION:
                if self.dragging:
                    # Vertical mouse movement controls knob
                    delta_y = self.drag_start_y - event.pos[1]
                    delta_normalized = delta_y / 100.0  # Sensitivity

                    new_normalized = (self.drag_start_value - self.min_value) / (
                        self.max_value - self.min_value
                    )
                    new_normalized = np.clip(new_normalized + delta_normalized, 0, 1)

                    self.value = self.min_value + new_normalized * (
                        self.max_value - self.min_value
                    )

                    if self.on_change:
                        self.on_change(self.value)

                    return True

        return False

    def render(self, surface: pygame.Surface):
        if not self.visible:
            return

        center_x = self.x + self.size // 2
        center_y = self.y + self.size // 2
        radius = self.size // 2 - 2

        # Draw track arc
        # Note: pygame doesn't have arc drawing, so we approximate with lines

        # Draw body
        pygame.draw.circle(surface, self.color_body, (center_x, center_y), radius)
        pygame.draw.circle(surface, self.color_track, (center_x, center_y), radius, 2)

        # Calculate notch angle
        normalized = (self.value - self.min_value) / (self.max_value - self.min_value)
        angle_range = self.end_angle - self.start_angle
        if angle_range < 0:
            angle_range += 360
        current_angle = self.start_angle + normalized * angle_range

        # Convert to radians
        angle_rad = np.radians(current_angle)

        # Draw notch
        notch_inner_x = center_x + int((radius - self.notch_length) * np.cos(angle_rad))
        notch_inner_y = center_y + int((radius - self.notch_length) * np.sin(angle_rad))
        notch_outer_x = center_x + int(radius * np.cos(angle_rad))
        notch_outer_y = center_y + int(radius * np.sin(angle_rad))

        pygame.draw.line(
            surface,
            self.color_notch,
            (notch_inner_x, notch_inner_y),
            (notch_outer_x, notch_outer_y),
            3,
        )


class ToggleButton(UIControl):
    """Toggle/checkbox button control."""

    def __init__(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        text: str = "",
        checked: bool = False,
    ):
        super().__init__(x, y, width, height)
        self.text = text
        self.checked = checked

        # Visual settings
        self.checkbox_size = min(height - 4, 16)

        # Colors
        self.color_unchecked = (60, 60, 70)
        self.color_checked = COLORS["ACCENT"]
        self.color_text = COLORS["TEXT"]
        self.color_border = COLORS["PANEL_BORDER"]

        # Font
        self.font = pygame.font.Font(None, 14)

    def handle_event(self, event: pygame.event.Event) -> bool:
        if not super().handle_event(event):
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and self.hovered:
                    self.checked = not self.checked
                    if self.on_change:
                        self.on_change(self.checked)
                    return True

        return False

    def render(self, surface: pygame.Surface):
        if not self.visible:
            return

        # Draw checkbox
        checkbox_x = self.x + 2
        checkbox_y = self.y + (self.height - self.checkbox_size) // 2
        checkbox_rect = pygame.Rect(
            checkbox_x, checkbox_y, self.checkbox_size, self.checkbox_size
        )

        if self.checked:
            pygame.draw.rect(surface, self.color_checked, checkbox_rect)
            # Draw checkmark
            pygame.draw.lines(
                surface,
                COLORS["WHITE"],
                False,
                [
                    (checkbox_x + 3, checkbox_y + self.checkbox_size // 2),
                    (
                        checkbox_x + self.checkbox_size // 3,
                        checkbox_y + self.checkbox_size - 3,
                    ),
                    (checkbox_x + self.checkbox_size - 3, checkbox_y + 3),
                ],
                2,
            )
        else:
            pygame.draw.rect(surface, self.color_unchecked, checkbox_rect)

        pygame.draw.rect(surface, self.color_border, checkbox_rect, 1)

        # Draw text
        if self.text:
            text_color = self.color_text if self.enabled else COLORS["TEXT_DIM"]
            text_surface = self.font.render(self.text, True, text_color)
            text_rect = text_surface.get_rect()
            text_rect.left = checkbox_x + self.checkbox_size + 6
            text_rect.centery = self.y + self.height // 2
            surface.blit(text_surface, text_rect)
