"""
Ring buffer for efficient audio data management
"""

from typing import Optional

import numpy as np


class RingBuffer:
    """Thread-safe ring buffer for audio data"""

    def __init__(self, size: int, dtype=np.float32):
        self.size = size
        self.dtype = dtype
        self.buffer = np.zeros(size, dtype=dtype)
        self.write_pos = 0
        self.read_pos = 0
        self.available = 0

    def write(self, data: np.ndarray) -> int:
        """
        Write data to buffer

        Returns:
            Number of samples written
        """
        data_len = len(data)
        space = self.size - self.available

        if data_len > space:
            # Buffer overflow - only write what fits
            data = data[:space]
            data_len = space

        # Write in two parts if wrapping
        end_pos = self.write_pos + data_len

        if end_pos <= self.size:
            # No wrap
            self.buffer[self.write_pos: end_pos] = data
        else:
            # Wrap around
            first_part = self.size - self.write_pos
            self.buffer[self.write_pos:] = data[:first_part]
            self.buffer[: data_len - first_part] = data[first_part:]

        self.write_pos = end_pos % self.size
        self.available += data_len

        return data_len

    def read(self, count: int) -> Optional[np.ndarray]:
        """
        Read data from buffer

        Returns:
            Audio data or None if not enough available
        """
        if count > self.available:
            return None

        result = np.zeros(count, dtype=self.dtype)
        end_pos = self.read_pos + count

        if end_pos <= self.size:
            # No wrap
            result[:] = self.buffer[self.read_pos: end_pos]
        else:
            # Wrap around
            first_part = self.size - self.read_pos
            result[:first_part] = self.buffer[self.read_pos:]
            result[first_part:] = self.buffer[: count - first_part]

        self.read_pos = end_pos % self.size
        self.available -= count

        return result

    def peek(self, count: int, offset: int = 0) -> Optional[np.ndarray]:
        """
        Peek at data without removing it

        Args:
            count: Number of samples to peek
            offset: Offset from read position

        Returns:
            Audio data or None if not enough available
        """
        if offset + count > self.available:
            return None

        result = np.zeros(count, dtype=self.dtype)
        start_pos = (self.read_pos + offset) % self.size
        end_pos = start_pos + count

        if end_pos <= self.size:
            # No wrap
            result[:] = self.buffer[start_pos:end_pos]
        else:
            # Wrap around
            first_part = self.size - start_pos
            result[:first_part] = self.buffer[start_pos:]
            result[first_part:] = self.buffer[: count - first_part]

        return result

    def clear(self):
        """Clear the buffer"""
        self.write_pos = 0
        self.read_pos = 0
        self.available = 0
        self.buffer.fill(0)

    def get_available(self) -> int:
        """Get number of available samples"""
        return self.available

    def get_space(self) -> int:
        """Get available space in buffer"""
        return self.size - self.available
