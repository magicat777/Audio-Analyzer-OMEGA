"""
PipeWire audio capture implementation
"""

import select
import subprocess
import threading
import time
from typing import Callable
from typing import Optional

import numpy as np

from ..config import CHUNK_SIZE
from ..config import SAMPLE_RATE
from .buffers import RingBuffer


class PipeWireMonitorCapture:
    """Capture audio from PipeWire monitor sources"""

    def __init__(
        self,
        source_name: Optional[str] = None,
        source_index: Optional[int] = None,
        interactive: bool = False,
        sample_rate: int = SAMPLE_RATE,
        chunk_size: int = CHUNK_SIZE,
    ):
        self.source_name = source_name
        self.source_index = source_index
        self.interactive = interactive
        self.sample_rate = sample_rate
        self.chunk_size = chunk_size
        self.process = None
        self.capture_thread = None
        self.running = False

        # Ring buffer for captured audio
        buffer_size = sample_rate * 2  # 2 seconds
        self.audio_buffer = RingBuffer(buffer_size)

        # Callback for new audio data
        self.audio_callback: Optional[Callable] = None

        # Performance tracking
        self.dropped_frames = 0
        self.total_frames = 0

    def get_monitor_sources(self) -> list:
        """Get available PipeWire monitor sources"""
        try:
            # Try pactl first (more compatible)
            result = subprocess.run(
                ["pactl", "list", "sources", "short"],
                capture_output=True,
                text=True,
                check=True,
            )

            sources = []
            for line in result.stdout.strip().split("\n"):
                if "monitor" in line:
                    parts = line.split("\t")
                    if len(parts) >= 2:
                        source_id = parts[0]
                        source_name = parts[1]
                        sources.append((source_id, source_name))

            if sources:
                return sources

            # Fallback to pw-cli if pactl fails
            result = subprocess.run(
                ["pw-cli", "dump", "short", "Node"],
                capture_output=True,
                text=True,
                check=True,
            )

            for line in result.stdout.splitlines():
                if ".monitor" in line:
                    parts = line.split()
                    if len(parts) >= 3:
                        node_id = parts[0]
                        node_name = parts[2]
                        sources.append((node_id, node_name))

            return sources
        except Exception as e:
            print(f"Error getting monitor sources: {e}")
            return []

    def select_monitor_source(
        self, source_index: Optional[int] = None, interactive: bool = False
    ) -> Optional[str]:
        """Select a monitor source by index, interactively, or automatically"""
        sources = self.get_monitor_sources()

        if not sources:
            print("❌ No monitor sources found!")
            return None

        # Display available sources
        print("\n🔊 Available Monitor Sources:")
        print("=" * 50)
        for idx, (source_id, source_name) in enumerate(sources):
            print(f"{idx}: {source_name}")
        print("=" * 50)

        # Select by index if provided
        if source_index is not None:
            if 0 <= source_index < len(sources):
                selected = sources[source_index][1]
                print(f"🎯 Selected source {source_index}: {selected}")
                return selected
            else:
                print(
                    f"❌ Invalid source index {source_index}. Available: 0-{len(sources)-1}"
                )
                return None

        # Interactive selection
        if interactive:
            try:
                choice = input(
                    f"\nSelect source (0-{len(sources)-1}) or press Enter for auto-select: "
                ).strip()
                if choice == "":
                    # Auto-select with intelligent prioritization
                    selected = self._auto_select_best_source(sources)
                    return selected
                else:
                    idx = int(choice)
                    if 0 <= idx < len(sources):
                        selected = sources[idx][1]
                        print(f"🎯 Selected source {idx}: {selected}")
                        return selected
                    else:
                        print(f"❌ Invalid choice {idx}. Using auto-select.")
                        selected = self._auto_select_best_source(sources)
                        return selected
            except (ValueError, KeyboardInterrupt):
                print("Using auto-select.")
                selected = self._auto_select_best_source(sources)
                return selected

        # Auto-select with intelligent device prioritization
        selected = self._auto_select_best_source(sources)
        print(f"🎯 Auto-selected: {selected}")
        return selected

    def _get_system_default_sink(self) -> Optional[str]:
        """Get the system's default audio sink"""
        try:
            # Get system default sink
            result = subprocess.run(
                ["pactl", "get-default-sink"],
                capture_output=True,
                text=True,
                check=True,
            )
            default_sink = result.stdout.strip()
            print(f"🖱️ System default sink: {default_sink}")
            return default_sink
        except Exception as e:
            print(f"⚠️ Could not get system default sink: {e}")
            return None

    def _auto_select_best_source(self, sources: list) -> str:
        """
        Automatically select the best audio source by using the system default.
        
        This method queries the system's default audio sink and finds its monitor
        source, ensuring OMEGA-3 uses whatever audio device the user has configured
        as their system default (e.g., Focusrite, system speakers, etc.)
        """
        if not sources:
            return ""
        
        print("\n🎧 Looking for system default audio device...")
        
        # Try to get system default sink and find its monitor
        default_sink = self._get_system_default_sink()
        if default_sink:
            # Look for the monitor of the default sink
            monitor_name = f"{default_sink}.monitor"
            for source_id, source_name in sources:
                if monitor_name in source_name:
                    print(f"✅ Found system default monitor: {source_name}")
                    return source_name
            
            # If exact monitor not found, try partial match
            for source_id, source_name in sources:
                if default_sink.replace("alsa_output.", "").split(".")[0] in source_name:
                    print(f"✅ Found system default device monitor: {source_name}")
                    return source_name
        
        # Fallback: use first available
        print("🔍 System default not found, using first available source")
        selected = sources[0][1]
        print(f"📱 Selected: {selected}")
        return selected

    def select_by_index(self, index: int) -> Optional[str]:
        """Select a monitor source by its index number"""
        return self.select_monitor_source(source_index=index)

    def start_capture(self) -> bool:
        """Start audio capture"""
        if self.running:
            return True

        # Select source if not specified
        if not self.source_name:
            self.source_name = self.select_monitor_source(
                source_index=self.source_index, interactive=self.interactive
            )
            if not self.source_name:
                return False

        print(f"\n🎵 Starting audio capture:")
        print(f"   Source: {self.source_name}")
        print(f"   Sample Rate: {self.sample_rate}Hz")

        # Build parec command
        cmd = [
            "parec",
            "--format=float32le",
            "--channels=2",
            f"--rate={self.sample_rate}",
            "--latency-msec=10",
            "--process-time-msec=10",
            "-d",
            self.source_name,
        ]

        try:
            print("🔧 Executing parec command...")
            self.process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0
            )
            print("✅ parec process started successfully")

            self.running = True
            print("🧵 Starting capture thread...")
            self.capture_thread = threading.Thread(target=self._capture_worker)
            self.capture_thread.daemon = True
            self.capture_thread.start()
            print("✅ Capture thread started")

            # Give thread a moment to initialize
            time.sleep(0.1)
            print("🎤 Audio capture fully initialized")
            return True

        except Exception as e:
            print(f"❌ Failed to start capture: {e}")
            return False

    def stop_capture(self):
        """Stop audio capture"""
        self.running = False

        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None

        if self.capture_thread:
            self.capture_thread.join(timeout=2.0)
            self.capture_thread = None

    def _capture_worker(self):
        """Worker thread for audio capture"""
        print("🎬 Capture worker thread started")
        bytes_per_sample = 4  # float32
        bytes_per_frame = bytes_per_sample * 2  # stereo
        chunk_bytes = self.chunk_size * bytes_per_frame
        print(f"📊 Capture parameters: chunk_size={self.chunk_size}, chunk_bytes={chunk_bytes}")

        while self.running and self.process:
            try:
                # Check if data is available with timeout
                ready, _, _ = select.select([self.process.stdout], [], [], 0.1)
                
                if not ready:
                    # No data available, send zeros to keep the analyzer running
                    zero_data = np.zeros(self.chunk_size, dtype=np.float32)
                    written = self.audio_buffer.write(zero_data)
                    if self.audio_callback:
                        self.audio_callback(zero_data)
                    continue
                
                # Read raw audio data 
                raw_data = self.process.stdout.read(chunk_bytes)

                if not raw_data:
                    print("⚠️ No audio data received - process may have ended")
                    break

                # Convert to numpy array
                audio_data = np.frombuffer(raw_data, dtype=np.float32)

                # Reshape to stereo
                if len(audio_data) >= 2:
                    audio_data = audio_data.reshape(-1, 2)

                    # Mix to mono
                    mono_data = np.mean(audio_data, axis=1)

                    # Write to buffer
                    written = self.audio_buffer.write(mono_data)

                    if written < len(mono_data):
                        self.dropped_frames += len(mono_data) - written

                    self.total_frames += len(mono_data)

                    # Notify callback if set
                    if self.audio_callback:
                        self.audio_callback(mono_data)

            except Exception as e:
                if self.running:
                    print(f"Capture error: {e}")
                break

    def get_audio_data(self, count: Optional[int] = None) -> Optional[np.ndarray]:
        """
        Get audio data from buffer

        Args:
            count: Number of samples to get (default: chunk_size)

        Returns:
            Audio data or None if not enough available
        """
        if count is None:
            count = self.chunk_size

        return self.audio_buffer.read(count)

    def get_buffer_status(self) -> dict:
        """Get buffer status information"""
        return {
            "available": self.audio_buffer.get_available(),
            "capacity": self.audio_buffer.size,
            "dropped_frames": self.dropped_frames,
            "total_frames": self.total_frames,
            "drop_rate": self.dropped_frames / max(1, self.total_frames),
        }

    def set_audio_callback(self, callback: Callable):
        """Set callback for new audio data"""
        self.audio_callback = callback
