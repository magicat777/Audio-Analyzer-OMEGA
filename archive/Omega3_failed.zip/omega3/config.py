"""
Configuration constants for OMEGA-3 analyzer
"""

# Audio configuration
SAMPLE_RATE = 48000
CHUNK_SIZE = 512  # 10.7ms latency
FFT_SIZE_BASE = 4096  # 85ms window
MAX_FREQ = 20000
NYQUIST = SAMPLE_RATE / 2

# Display configuration
BARS_DEFAULT = 1024
BARS_MAX = 1536
DEFAULT_WIDTH = 2200
DEFAULT_HEIGHT = 1200

# Performance configuration
TARGET_FPS = 60
THREAD_POOL_SIZE = 4
MAX_PROCESSING_TIME_MS = 50.0  # More lenient timeout for complex analyzers

# Analysis configuration
BASS_DETAIL_BARS = 64
BASS_FREQ_MIN = 20
BASS_FREQ_MAX = 200

# Multi-resolution FFT configs
FFT_CONFIGS = [
    {
        "range": (20, 200),
        "fft_size": 4096,
        "hop_size": 1024,
        "weight": 1.5,
    },  # Bass
    {
        "range": (200, 1000),
        "fft_size": 2048,
        "hop_size": 512,
        "weight": 1.2,
    },  # Low-mids
    {
        "range": (1000, 5000),
        "fft_size": 1024,
        "hop_size": 256,
        "weight": 1.0,
    },  # Mids
    {
        "range": (5000, 20000),
        "fft_size": 1024,
        "hop_size": 256,
        "weight": 1.5,
    },  # Highs
]

# VU Meter configuration
VU_INTEGRATION_TIME = 0.3  # 300ms standard
VU_REFERENCE_LEVEL = 0.1  # -20 dBFS = 0 VU
VU_DAMPING = 0.85

# LUFS metering
LUFS_SHORT_TERM_WINDOW = 3.0  # seconds
LUFS_INTEGRATED_WINDOW = 30.0  # seconds
TARGET_LUFS = -16.0

# Performance thresholds
PERFORMANCE_MODE_THRESHOLD_MS = 30.0
QUALITY_MODE_THRESHOLD_MS = 25.0
MODE_SWITCH_HOLD_TIME = 10.0  # seconds
