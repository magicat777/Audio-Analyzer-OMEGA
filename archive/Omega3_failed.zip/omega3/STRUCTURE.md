# OMEGA-3 Professional Audio Analyzer - Project Structure

## Overview
OMEGA-3 is a modular, high-performance audio visualization system with industry-standard analysis capabilities.

## Directory Structure

```
omega3/
├── analyzers/              # Audio analysis modules
│   ├── base.py            # Base analyzer interface
│   ├── voice_detection.py # Voice/speech analysis
│   ├── pitch_detection.py # OMEGA pitch detection (cepstral)
│   ├── harmonic.py        # Harmonic analysis and instrument ID
│   ├── drum_detection.py  # Beat and rhythm analysis
│   ├── chromagram.py      # OMEGA-1 key detection
│   ├── genre.py           # OMEGA-2 genre classification
│   ├── room_modes.py      # Room acoustics analysis
│   ├── transients.py      # Attack/dynamics analysis
│   └── metering.py        # Professional LUFS/True Peak
│
├── audio/                  # Audio capture and management
│   ├── capture.py         # PipeWire audio capture
│   ├── buffers.py         # Ring buffers and audio data management
│   └── sources.py         # Audio source selection and management
│
├── processing/            # Signal processing modules
│   ├── fft.py            # Multi-resolution FFT processing
│   ├── spectrum.py       # Spectrum processing with perceptual mapping
│   ├── frequency_mapping.py # Perceptual frequency distribution
│   ├── smoothing.py      # Spectrum smoothing algorithms
│   ├── compensation.py   # Frequency response correction
│   ├── filters.py        # Audio filters and windowing
│   └── threading.py      # Thread pool for parallel processing
│
├── utils/                 # Utility modules
│   ├── math_utils.py     # Mathematical utilities
│   ├── performance.py    # Performance monitoring
│   ├── threading_utils.py # Thread-safe utilities
│   └── constants.py      # Shared constants
│
├── visualization/         # Visualization modules
│   ├── main_display.py   # Main spectrum visualization
│   │
│   ├── panels/           # Analysis display panels
│   │   ├── meters.py     # Professional meters panel
│   │   ├── harmonic.py   # Harmonic analysis panel
│   │   ├── voice.py      # Voice detection panel
│   │   ├── pitch.py      # OMEGA pitch panel
│   │   ├── chromagram.py # OMEGA-1 chromagram panel
│   │   ├── genre.py      # OMEGA-2 genre panel
│   │   ├── bass_detail.py # Bass zoom window
│   │   ├── vu_meters.py  # VU meter display
│   │   └── technical.py  # Technical overlay
│   │
│   ├── ui/              # User interface components
│   │   ├── layout.py    # UI layout manager
│   │   ├── colors.py    # Color schemes and gradients
│   │   ├── fonts.py     # Font management
│   │   └── events.py    # Event handling
│   │
│   └── effects/         # Visual effects
│       ├── peak_hold.py # Peak hold visualization
│       ├── reactivity.py # Beat/voice reactive effects
│       └── overlays.py  # Grid, scale, formants
│
├── config.py            # Configuration constants
└── main.py             # Main application entry point
```

## Module Descriptions

### Analyzers
- **base.py**: Abstract base class for all analyzers
- **voice_detection.py**: Industry-standard voice detection algorithms
- **pitch_detection.py**: Multiple pitch detection methods (cepstral, autocorrelation)
- **harmonic.py**: Harmonic content analysis for instrument identification
- **drum_detection.py**: Beat detection and rhythm analysis
- **chromagram.py**: Chromatic feature extraction for key/chord detection
- **genre.py**: Machine learning-based genre classification
- **room_modes.py**: Room acoustics and resonant frequency analysis
- **transients.py**: Attack detection and dynamics analysis
- **metering.py**: Professional metering (LUFS, True Peak, K-weighting)

### Audio
- **capture.py**: PipeWire audio capture with low latency
- **buffers.py**: Efficient ring buffer implementation
- **sources.py**: Audio source management and routing

### Processing
- **fft.py**: Multi-resolution FFT with GPU acceleration option
- **spectrum.py**: Main spectrum processor with perceptual mapping
- **frequency_mapping.py**: Frequency scaling utilities
- **smoothing.py**: Various smoothing algorithms
- **compensation.py**: Frequency response correction curves
- **filters.py**: Digital filter implementations
- **threading.py**: Thread pool for parallel analysis

### Visualization
- **main_display.py**: Core spectrum renderer
- **panels/**: Individual analysis panels
- **ui/**: UI management and theming
- **effects/**: Visual enhancement effects

## Key Features
- Multi-resolution FFT for enhanced bass detail
- Industry-standard perceptual frequency mapping
- Professional metering and analysis
- Modular architecture for easy extension
- Thread pool for parallel processing
- GPU acceleration support
- Multiple visualization modes
- Real-time performance optimization