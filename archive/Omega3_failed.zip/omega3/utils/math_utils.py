"""
Mathematical utilities for OMEGA-3.
Common mathematical functions and helpers.
"""

from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import numpy as np


def db_to_linear(db: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
    """Convert decibels to linear scale."""
    return 10 ** (db / 20)


def linear_to_db(
    linear: Union[float, np.ndarray], min_db: float = -120.0
) -> Union[float, np.ndarray]:
    """Convert linear scale to decibels."""
    db = 20 * np.log10(np.maximum(linear, 10 ** (min_db / 20)))
    return np.maximum(db, min_db)


def normalize(
    data: np.ndarray, min_val: float = 0.0, max_val: float = 1.0
) -> np.ndarray:
    """Normalize array to specified range."""
    data_min = np.min(data)
    data_max = np.max(data)

    if data_max - data_min > 0:
        normalized = (data - data_min) / (data_max - data_min)
        return normalized * (max_val - min_val) + min_val
    else:
        return np.full_like(data, min_val)


def rms(data: np.ndarray, axis: Optional[int] = None) -> Union[float, np.ndarray]:
    """Calculate root mean square."""
    return np.sqrt(np.mean(data ** 2, axis=axis))


def peak_to_rms(data: np.ndarray) -> float:
    """Calculate peak to RMS ratio (crest factor)."""
    peak = np.max(np.abs(data))
    rms_val = rms(data)

    if rms_val > 0:
        return peak / rms_val
    else:
        return 0.0


def apply_window(data: np.ndarray, window_type: str = "hann") -> np.ndarray:
    """Apply window function to data."""
    n = len(data)

    if window_type == "hann" or window_type == "hanning":
        window = np.hanning(n)
    elif window_type == "hamming":
        window = np.hamming(n)
    elif window_type == "blackman":
        window = np.blackman(n)
    elif window_type == "bartlett":
        window = np.bartlett(n)
    elif window_type == "kaiser":
        window = np.kaiser(n, 8)
    elif window_type == "tukey":
        window = tukey(n, 0.5)
    elif window_type == "rectangular" or window_type == "none":
        window = np.ones(n)
    else:
        # Default to Hann
        window = np.hanning(n)

    return data * window


def tukey(n: int, alpha: float = 0.5) -> np.ndarray:
    """Generate Tukey (tapered cosine) window."""
    if alpha <= 0:
        return np.ones(n)
    elif alpha >= 1:
        return np.hanning(n)

    x = np.arange(n)
    width = int(alpha * n / 2)

    window = np.ones(n)

    # Left taper
    left = 0.5 * (1 + np.cos(np.pi * (2 * x[:width] / (alpha * n) - 1)))
    window[:width] = left

    # Right taper
    right = 0.5 * (1 + np.cos(np.pi * (2 * x[-width:] / (alpha * n) - 2 / alpha + 1)))
    window[-width:] = right

    return window


def next_power_of_two(n: int) -> int:
    """Find next power of two greater than or equal to n."""
    return 1 << (n - 1).bit_length()


def is_power_of_two(n: int) -> bool:
    """Check if n is a power of two."""
    return n > 0 and (n & (n - 1)) == 0


def frequency_to_mel(frequency: float) -> float:
    """Convert frequency to mel scale."""
    return 2595 * np.log10(1 + frequency / 700)


def mel_to_frequency(mel: float) -> float:
    """Convert mel scale to frequency."""
    return 700 * (10 ** (mel / 2595) - 1)


def frequency_to_bark(frequency: float) -> float:
    """Convert frequency to Bark scale."""
    return 13 * np.arctan(0.00076 * frequency) + 3.5 * np.arctan(
        (frequency / 7500) ** 2
    )


def frequency_to_erb(frequency: float) -> float:
    """Convert frequency to ERB (Equivalent Rectangular Bandwidth) scale."""
    return 21.4 * np.log10(1 + 0.00437 * frequency)


def note_to_frequency(note: str, octave: int = 4, a4: float = 440.0) -> float:
    """Convert musical note to frequency."""
    notes = {
        "C": -9,
        "C#": -8,
        "Db": -8,
        "D": -7,
        "D#": -6,
        "Eb": -6,
        "E": -5,
        "F": -4,
        "F#": -3,
        "Gb": -3,
        "G": -2,
        "G#": -1,
        "Ab": -1,
        "A": 0,
        "A#": 1,
        "Bb": 1,
        "B": 2,
    }

    if note.upper() not in notes:
        raise ValueError(f"Unknown note: {note}")

    semitones_from_a4 = notes[note.upper()] + (octave - 4) * 12
    return a4 * (2 ** (semitones_from_a4 / 12))


def frequency_to_note(frequency: float, a4: float = 440.0) -> Tuple[str, int, float]:
    """
    Convert frequency to musical note.

    Returns:
        Tuple of (note, octave, cents_offset)
    """
    if frequency <= 0:
        return ("", 0, 0.0)

    notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

    # Calculate semitones from A4
    semitones_from_a4 = 12 * np.log2(frequency / a4)

    # Round to nearest semitone
    nearest_semitone = round(semitones_from_a4)
    cents_offset = (semitones_from_a4 - nearest_semitone) * 100

    # Calculate note and octave
    note_index = (nearest_semitone + 9) % 12  # A is 9 semitones above C
    octave = 4 + (nearest_semitone + 9) // 12

    return (notes[note_index], octave, cents_offset)


def interpolate_linear(x: np.ndarray, xp: np.ndarray, fp: np.ndarray) -> np.ndarray:
    """Linear interpolation (wrapper around np.interp for consistency)."""
    return np.interp(x, xp, fp)


def interpolate_log(x: np.ndarray, xp: np.ndarray, fp: np.ndarray) -> np.ndarray:
    """Logarithmic interpolation."""
    log_x = np.log10(np.maximum(x, 1e-10))
    log_xp = np.log10(np.maximum(xp, 1e-10))
    return np.interp(log_x, log_xp, fp)


def smooth_exponential(
    current: np.ndarray,
    target: np.ndarray,
    alpha: float,
    rising_alpha: Optional[float] = None,
) -> np.ndarray:
    """
    Exponential smoothing with optional different rising rate.

    Args:
        current: Current values
        target: Target values
        alpha: Smoothing factor (0-1)
        rising_alpha: Optional different alpha for rising values

    Returns:
        Smoothed values
    """
    if rising_alpha is None:
        return current + alpha * (target - current)
    else:
        result = np.zeros_like(current)
        rising = target > current
        result[rising] = current[rising] + rising_alpha * (
            target[rising] - current[rising]
        )
        result[~rising] = current[~rising] + alpha * (
            target[~rising] - current[~rising]
        )
        return result


def calculate_centroid(data: np.ndarray, weights: Optional[np.ndarray] = None) -> float:
    """Calculate weighted centroid of data."""
    if weights is None:
        weights = np.ones_like(data)

    indices = np.arange(len(data))
    total_weight = np.sum(weights * data)

    if total_weight > 0:
        return np.sum(indices * weights * data) / total_weight
    else:
        return 0.0


def calculate_spread(
    data: np.ndarray, centroid: float, weights: Optional[np.ndarray] = None
) -> float:
    """Calculate spread around centroid."""
    if weights is None:
        weights = np.ones_like(data)

    indices = np.arange(len(data))
    total_weight = np.sum(weights * data)

    if total_weight > 0:
        variance = np.sum(weights * data * (indices - centroid) ** 2) / total_weight
        return np.sqrt(variance)
    else:
        return 0.0


def circular_mean(angles: np.ndarray, weights: Optional[np.ndarray] = None) -> float:
    """Calculate circular mean of angles in radians."""
    if weights is None:
        weights = np.ones_like(angles)

    mean_sin = np.average(np.sin(angles), weights=weights)
    mean_cos = np.average(np.cos(angles), weights=weights)

    return np.arctan2(mean_sin, mean_cos)


def circular_variance(
    angles: np.ndarray, weights: Optional[np.ndarray] = None
) -> float:
    """Calculate circular variance of angles in radians."""
    if weights is None:
        weights = np.ones_like(angles)

    mean_angle = circular_mean(angles, weights)

    # Calculate mean resultant length
    R = np.average(np.cos(angles - mean_angle), weights=weights)

    # Circular variance
    return 1 - R


def wrap_phase(phase: np.ndarray) -> np.ndarray:
    """Wrap phase to [-π, π] range."""
    return np.angle(np.exp(1j * phase))


def unwrap_phase(phase: np.ndarray, axis: int = -1) -> np.ndarray:
    """Unwrap phase by removing 2π jumps."""
    return np.unwrap(phase, axis=axis)


def calculate_instantaneous_frequency(
    phase: np.ndarray, sample_rate: int, hop_length: int = 1
) -> np.ndarray:
    """Calculate instantaneous frequency from phase."""
    # Phase difference
    phase_diff = np.diff(phase, axis=-1)

    # Wrap phase difference
    phase_diff = wrap_phase(phase_diff)

    # Convert to frequency
    inst_freq = phase_diff * sample_rate / (2 * np.pi * hop_length)

    return inst_freq


def soft_clip(data: np.ndarray, threshold: float = 0.9) -> np.ndarray:
    """Apply soft clipping to prevent harsh distortion."""
    # Symmetric soft clipping using tanh
    scaled = data / threshold
    clipped = threshold * np.tanh(scaled)

    return clipped


def hard_clip(
    data: np.ndarray, min_val: float = -1.0, max_val: float = 1.0
) -> np.ndarray:
    """Apply hard clipping to specified range."""
    return np.clip(data, min_val, max_val)


def crossfade(
    data1: np.ndarray, data2: np.ndarray, position: float, curve: str = "linear"
) -> np.ndarray:
    """
    Crossfade between two arrays.

    Args:
        data1: First array
        data2: Second array
        position: Crossfade position (0 = all data1, 1 = all data2)
        curve: Crossfade curve type ("linear", "equal_power", "sigmoid")

    Returns:
        Crossfaded array
    """
    position = np.clip(position, 0.0, 1.0)

    if curve == "linear":
        alpha1 = 1 - position
        alpha2 = position
    elif curve == "equal_power":
        # Equal power crossfade
        alpha1 = np.cos(position * np.pi / 2)
        alpha2 = np.sin(position * np.pi / 2)
    elif curve == "sigmoid":
        # S-curve crossfade
        t = position
        alpha2 = t * t * (3 - 2 * t)
        alpha1 = 1 - alpha2
    else:
        # Default to linear
        alpha1 = 1 - position
        alpha2 = position

    return alpha1 * data1 + alpha2 * data2
