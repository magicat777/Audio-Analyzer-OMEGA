"""
Performance monitoring utilities
"""

import time
from collections import deque
from typing import Dict
from typing import Optional


class PerformanceMonitor:
    """Monitor application performance metrics"""

    def __init__(self, history_size: int = 100):
        self.history_size = history_size
        self.frame_times = deque(maxlen=history_size)
        self.component_times: Dict[str, deque] = {}
        self.start_times: Dict[str, float] = {}

    def add_frame_time(self, frame_time_ms: float):
        """Add a frame processing time"""
        self.frame_times.append(frame_time_ms)

    def start_timing(self, component: str):
        """Start timing a component"""
        self.start_times[component] = time.perf_counter()

    def end_timing(self, component: str):
        """End timing a component"""
        if component in self.start_times:
            elapsed = (time.perf_counter() - self.start_times[component]) * 1000

            if component not in self.component_times:
                self.component_times[component] = deque(maxlen=self.history_size)

            self.component_times[component].append(elapsed)
            del self.start_times[component]

    def get_average_latency(self) -> float:
        """Get average frame processing time in ms"""
        if not self.frame_times:
            return 0.0
        return sum(self.frame_times) / len(self.frame_times)

    def get_max_latency(self) -> float:
        """Get maximum frame processing time in ms"""
        if not self.frame_times:
            return 0.0
        return max(self.frame_times)

    def get_component_stats(self) -> Dict[str, Dict[str, float]]:
        """Get statistics for all components"""
        stats = {}

        for component, times in self.component_times.items():
            if times:
                stats[component] = {
                    "average": sum(times) / len(times),
                    "max": max(times),
                    "min": min(times),
                    "current": times[-1] if times else 0.0,
                }

        return stats

    def get_fps(self) -> float:
        """Calculate current FPS based on frame times"""
        if not self.frame_times or len(self.frame_times) < 2:
            return 0.0

        avg_frame_time = self.get_average_latency()
        if avg_frame_time > 0:
            return 1000.0 / avg_frame_time
        return 0.0
