"""
Constants and configuration values for OMEGA-3.
Central location for all constant values used throughout the system.
"""

from typing import Dict
from typing import List
from typing import Tuple

import numpy as np

# Audio Constants
SAMPLE_RATES = [44100, 48000, 88200, 96000, 176400, 192000]
DEFAULT_SAMPLE_RATE = 48000
DEFAULT_BUFFER_SIZE = 2048
DEFAULT_CHANNELS = 2

# FFT Constants
FFT_SIZES = [512, 1024, 2048, 4096, 8192, 16384, 32768]
DEFAULT_FFT_SIZE = 4096
FFT_WINDOW_TYPES = ["hann", "hamming", "blackman", "bartlett", "kaiser", "tukey"]
DEFAULT_WINDOW_TYPE = "hann"

# Frequency Constants
MIN_FREQUENCY = 20.0  # Hz
MAX_FREQUENCY = 20000.0  # Hz
NYQUIST_RATIO = 0.5

# Musical Constants
A4_FREQUENCY = 440.0  # Hz
NOTES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
OCTAVE_RANGE = (0, 9)

# Visualization Constants
DEFAULT_FPS = 60
MAX_FPS = 144
DEFAULT_BARS = 64
MAX_BARS = 256
DEFAULT_WIDTH = 1920
DEFAULT_HEIGHT = 1080

# Color Constants
COLORS = {
    # Basic colors
    "BLACK": (0, 0, 0),
    "WHITE": (255, 255, 255),
    "RED": (255, 0, 0),
    "GREEN": (0, 255, 0),
    "BLUE": (0, 0, 255),
    "YELLOW": (255, 255, 0),
    "CYAN": (0, 255, 255),
    "MAGENTA": (255, 0, 255),
    # Theme colors
    "BACKGROUND": (10, 10, 10),
    "FOREGROUND": (200, 200, 200),
    "ACCENT": (0, 162, 255),
    "WARNING": (255, 162, 0),
    "ERROR": (255, 0, 100),
    "SUCCESS": (0, 255, 100),
    # Spectrum colors
    "BASS": (255, 0, 100),
    "LOW_MID": (255, 100, 0),
    "MID": (255, 255, 0),
    "HIGH_MID": (0, 255, 100),
    "TREBLE": (0, 100, 255),
    # UI colors
    "PANEL_BG": (20, 20, 25),
    "PANEL_BORDER": (60, 60, 70),
    "TEXT": (200, 200, 210),
    "TEXT_DIM": (120, 120, 130),
    "GRID": (40, 40, 45),
    "GRID_MAJOR": (60, 60, 65),
}

# Gradient presets
GRADIENTS = {
    "SPECTRUM": [
        (255, 0, 100),  # Red
        (255, 100, 0),  # Orange
        (255, 255, 0),  # Yellow
        (0, 255, 100),  # Green
        (0, 100, 255),  # Blue
        (100, 0, 255),  # Purple
    ],
    "FIRE": [
        (0, 0, 0),  # Black
        (100, 0, 0),  # Dark red
        (255, 0, 0),  # Red
        (255, 100, 0),  # Orange
        (255, 200, 0),  # Yellow-orange
        (255, 255, 100),  # Yellow-white
    ],
    "ICE": [
        (0, 0, 50),  # Dark blue
        (0, 50, 100),  # Blue
        (0, 100, 200),  # Light blue
        (100, 200, 255),  # Cyan
        (200, 255, 255),  # Light cyan
        (255, 255, 255),  # White
    ],
    "PLASMA": [
        (50, 0, 100),  # Purple
        (100, 0, 150),  # Violet
        (150, 0, 100),  # Magenta
        (200, 50, 50),  # Red
        (255, 100, 0),  # Orange
        (255, 200, 0),  # Yellow
    ],
}

# Frequency band definitions
FREQUENCY_BANDS = {
    "SUB_BASS": (20, 60),
    "BASS": (60, 250),
    "LOW_MID": (250, 500),
    "MID": (500, 2000),
    "HIGH_MID": (2000, 4000),
    "PRESENCE": (4000, 8000),
    "BRILLIANCE": (8000, 20000),
}

# Musical frequency ranges
INSTRUMENT_RANGES = {
    "BASS": (40, 400),
    "KICK": (40, 100),
    "SNARE": (200, 500),
    "VOCALS": (80, 1100),
    "GUITAR": (80, 1200),
    "PIANO": (27.5, 4186),
    "VIOLIN": (196, 3136),
    "CYMBALS": (300, 20000),
}

# Analysis parameters
ONSET_DETECTION_THRESHOLD = 0.3
PITCH_DETECTION_THRESHOLD = 0.5
BEAT_DETECTION_WINDOW = 0.5  # seconds
TRANSIENT_THRESHOLD = 3.0  # standard deviations

# Performance thresholds
MAX_LATENCY_MS = 20
TARGET_LATENCY_MS = 10
MIN_UPDATE_INTERVAL_MS = 16  # ~60 FPS
BUFFER_UNDERRUN_THRESHOLD = 0.1

# Smoothing parameters
DEFAULT_ATTACK_TIME = 0.01  # seconds
DEFAULT_DECAY_TIME = 0.1  # seconds
DEFAULT_SMOOTHING_ALPHA = 0.3

# Metering standards
METER_STANDARDS = {
    "PEAK_HOLD_TIME": 2.0,  # seconds
    "VU_INTEGRATION": 0.3,  # seconds
    "RMS_WINDOW": 0.3,  # seconds
    "LUFS_MOMENTARY": 0.4,  # seconds
    "LUFS_SHORT_TERM": 3.0,  # seconds
    "LUFS_GATE_THRESHOLD": -70,  # LUFS
}

# Keyboard shortcuts
KEYBOARD_SHORTCUTS = {
    "QUIT": ["q", "escape"],
    "FULLSCREEN": ["f", "f11"],
    "PAUSE": ["space", "p"],
    "RESET": ["r"],
    "SAVE": ["s"],
    "LOAD": ["l"],
    "HELP": ["h", "?"],
    "DEBUG": ["d"],
    "SCREENSHOT": ["print_screen", "f12"],
    # View controls
    "VIEW_SPECTRUM": ["1"],
    "VIEW_WAVEFORM": ["2"],
    "VIEW_SPECTROGRAM": ["3"],
    "VIEW_PHASE": ["4"],
    "VIEW_3D": ["5"],
    # Audio controls
    "GAIN_UP": ["+", "="],
    "GAIN_DOWN": ["-", "_"],
    "MUTE": ["m"],
    # Analysis controls
    "FFT_SIZE_UP": ["]"],
    "FFT_SIZE_DOWN": ["["],
    "BARS_UP": ["."],
    "BARS_DOWN": [","],
    # Effect controls
    "EFFECT_NEXT": ["e"],
    "EFFECT_PREV": ["shift+e"],
    "EFFECT_TOGGLE": ["x"],
}

# Mathematical constants
TWO_PI = 2 * np.pi
PI = np.pi
SQRT_2 = np.sqrt(2)
LOG_10 = np.log(10)
DB_REFERENCE = 20 / LOG_10

# Unit conversions
MS_TO_SAMPLES = DEFAULT_SAMPLE_RATE / 1000
SAMPLES_TO_MS = 1000 / DEFAULT_SAMPLE_RATE
HZ_TO_RADIANS = TWO_PI / DEFAULT_SAMPLE_RATE
RADIANS_TO_HZ = DEFAULT_SAMPLE_RATE / TWO_PI

# File formats
SUPPORTED_AUDIO_FORMATS = [".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"]
SUPPORTED_IMAGE_FORMATS = [".png", ".jpg", ".jpeg", ".bmp"]
SUPPORTED_DATA_FORMATS = [".json", ".csv", ".npy", ".npz"]

# Network constants
DEFAULT_OSC_PORT = 7770
DEFAULT_WEBSOCKET_PORT = 8080
DEFAULT_HTTP_PORT = 8000
MAX_NETWORK_CLIENTS = 10

# Plugin constants
PLUGIN_API_VERSION = "1.0.0"
PLUGIN_DIRECTORY = "plugins"
PLUGIN_CONFIG_FILE = "plugin.json"

# Preset categories
PRESET_CATEGORIES = [
    "Factory",
    "User",
    "Electronic",
    "Acoustic",
    "Experimental",
    "Utility",
]

# Error messages
ERROR_MESSAGES = {
    "AUDIO_INIT": "Failed to initialize audio system",
    "FFT_SIZE": "Invalid FFT size - must be power of 2",
    "SAMPLE_RATE": "Unsupported sample rate",
    "FILE_NOT_FOUND": "File not found",
    "INVALID_FORMAT": "Invalid file format",
    "BUFFER_OVERFLOW": "Audio buffer overflow",
    "BUFFER_UNDERFLOW": "Audio buffer underflow",
    "NETWORK_ERROR": "Network connection error",
    "PLUGIN_ERROR": "Plugin loading error",
}

# Info messages
INFO_MESSAGES = {
    "STARTUP": "OMEGA-3 Audio Visualizer",
    "VERSION": "Version 3.0.0",
    "READY": "System ready",
    "LOADING": "Loading...",
    "SAVING": "Saving...",
    "PROCESSING": "Processing audio...",
}

# OpenGL constants
GL_VERSION_MAJOR = 3
GL_VERSION_MINOR = 3
GL_MULTISAMPLE_SAMPLES = 4
GL_DEPTH_SIZE = 24
GL_STENCIL_SIZE = 8

# Thread pool sizes
AUDIO_THREAD_PRIORITY = 10
RENDER_THREAD_PRIORITY = 8
ANALYSIS_THREAD_PRIORITY = 5
UI_THREAD_PRIORITY = 3

# Cache sizes
SPECTRUM_CACHE_SIZE = 100
WAVEFORM_CACHE_SIZE = 50
FFT_CACHE_SIZE = 10
TEXTURE_CACHE_SIZE = 20

# Limits
MAX_RECORDING_DURATION = 3600  # 1 hour in seconds
MAX_BUFFER_DURATION = 10  # seconds
MAX_UNDO_LEVELS = 50
MAX_RECENT_FILES = 10
