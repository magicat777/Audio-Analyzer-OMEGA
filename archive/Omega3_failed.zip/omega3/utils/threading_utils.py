"""
Threading utilities for OMEGA-3.
Provides thread-safe operations and performance optimization.
"""

import multiprocessing as mp
import queue
import threading
import time
from collections import deque
from contextlib import contextmanager
from typing import Any
from typing import Callable
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np


class ThreadSafeValue:
    """Thread-safe wrapper for a single value."""

    def __init__(self, initial_value: Any = None):
        self._value = initial_value
        self._lock = threading.RLock()

    def get(self) -> Any:
        """Get the current value."""
        with self._lock:
            return self._value

    def set(self, value: Any):
        """Set a new value."""
        with self._lock:
            self._value = value

    def update(self, func: Callable[[Any], Any]) -> Any:
        """Update value using a function."""
        with self._lock:
            self._value = func(self._value)
            return self._value

    @contextmanager
    def locked(self):
        """Context manager for locked access."""
        self._lock.acquire()
        try:
            yield self._value
        finally:
            self._lock.release()


class ThreadSafeBuffer:
    """Thread-safe circular buffer."""

    def __init__(self, maxsize: int):
        self.maxsize = maxsize
        self._buffer = deque(maxlen=maxsize)
        self._lock = threading.RLock()

    def append(self, item: Any):
        """Append item to buffer."""
        with self._lock:
            self._buffer.append(item)

    def extend(self, items: List[Any]):
        """Extend buffer with multiple items."""
        with self._lock:
            self._buffer.extend(items)

    def get_all(self) -> List[Any]:
        """Get all items in buffer."""
        with self._lock:
            return list(self._buffer)

    def get_latest(self, n: int) -> List[Any]:
        """Get latest n items."""
        with self._lock:
            return list(self._buffer)[-n:]

    def clear(self):
        """Clear the buffer."""
        with self._lock:
            self._buffer.clear()

    def __len__(self) -> int:
        with self._lock:
            return len(self._buffer)


class ThreadSafeDict:
    """Thread-safe dictionary wrapper."""

    def __init__(self):
        self._dict = {}
        self._lock = threading.RLock()

    def get(self, key: Any, default: Any = None) -> Any:
        """Get value for key."""
        with self._lock:
            return self._dict.get(key, default)

    def set(self, key: Any, value: Any):
        """Set value for key."""
        with self._lock:
            self._dict[key] = value

    def update(self, other: Dict[Any, Any]):
        """Update from another dictionary."""
        with self._lock:
            self._dict.update(other)

    def pop(self, key: Any, default: Any = None) -> Any:
        """Remove and return value for key."""
        with self._lock:
            return self._dict.pop(key, default)

    def keys(self) -> List[Any]:
        """Get all keys."""
        with self._lock:
            return list(self._dict.keys())

    def values(self) -> List[Any]:
        """Get all values."""
        with self._lock:
            return list(self._dict.values())

    def items(self) -> List[Tuple[Any, Any]]:
        """Get all items."""
        with self._lock:
            return list(self._dict.items())

    def clear(self):
        """Clear the dictionary."""
        with self._lock:
            self._dict.clear()

    @contextmanager
    def locked(self):
        """Context manager for locked access."""
        self._lock.acquire()
        try:
            yield self._dict
        finally:
            self._lock.release()


class WorkerThread(threading.Thread):
    """Base class for worker threads."""

    def __init__(self, name: str = None):
        super().__init__(name=name)
        self.daemon = True
        self._stop_event = threading.Event()
        self._pause_event = threading.Event()
        self._pause_event.set()  # Start unpaused

    def stop(self):
        """Signal thread to stop."""
        self._stop_event.set()

    def pause(self):
        """Pause thread execution."""
        self._pause_event.clear()

    def resume(self):
        """Resume thread execution."""
        self._pause_event.set()

    def is_running(self) -> bool:
        """Check if thread should continue running."""
        return not self._stop_event.is_set()

    def wait_if_paused(self):
        """Wait if thread is paused."""
        self._pause_event.wait()

    def run(self):
        """Override this method in subclasses."""
        raise NotImplementedError


class ProcessingWorker(WorkerThread):
    """Worker thread for audio processing tasks."""

    def __init__(
        self,
        name: str,
        input_queue: queue.Queue,
        output_queue: queue.Queue,
        process_func: Callable[[Any], Any],
    ):
        super().__init__(name)
        self.input_queue = input_queue
        self.output_queue = output_queue
        self.process_func = process_func
        self.processed_count = 0

    def run(self):
        """Process items from input queue."""
        while self.is_running():
            self.wait_if_paused()

            try:
                # Get item with timeout
                item = self.input_queue.get(timeout=0.1)

                # Process item
                result = self.process_func(item)

                # Put result
                self.output_queue.put(result)
                self.processed_count += 1

                # Mark task done
                self.input_queue.task_done()

            except queue.Empty:
                continue
            except Exception as e:
                print(f"Error in {self.name}: {e}")


class ThreadPool:
    """Simple thread pool for parallel processing."""

    def __init__(self, num_threads: int = None):
        if num_threads is None:
            num_threads = mp.cpu_count()

        self.num_threads = num_threads
        self.input_queue = queue.Queue()
        self.output_queue = queue.Queue()
        self.workers = []
        self._started = False

    def start(self, process_func: Callable[[Any], Any]):
        """Start worker threads."""
        if self._started:
            return

        for i in range(self.num_threads):
            worker = ProcessingWorker(
                f"Worker-{i}", self.input_queue, self.output_queue, process_func
            )
            worker.start()
            self.workers.append(worker)

        self._started = True

    def submit(self, item: Any):
        """Submit item for processing."""
        self.input_queue.put(item)

    def get_result(self, timeout: Optional[float] = None) -> Any:
        """Get a processed result."""
        return self.output_queue.get(timeout=timeout)

    def get_all_results(self) -> List[Any]:
        """Get all available results."""
        results = []
        while not self.output_queue.empty():
            try:
                results.append(self.output_queue.get_nowait())
            except queue.Empty:
                break
        return results

    def wait_completion(self):
        """Wait for all tasks to complete."""
        self.input_queue.join()

    def stop(self):
        """Stop all worker threads."""
        for worker in self.workers:
            worker.stop()

        for worker in self.workers:
            worker.join(timeout=1.0)

        self.workers.clear()
        self._started = False


class RateLimiter:
    """Rate limiter for controlling update frequency."""

    def __init__(self, max_rate: float):
        self.max_rate = max_rate
        self.min_interval = 1.0 / max_rate if max_rate > 0 else 0
        self.last_time = 0
        self._lock = threading.Lock()

    def should_update(self) -> bool:
        """Check if update should happen based on rate limit."""
        with self._lock:
            current_time = time.time()
            if current_time - self.last_time >= self.min_interval:
                self.last_time = current_time
                return True
            return False

    def wait_if_needed(self):
        """Wait if necessary to maintain rate limit."""
        with self._lock:
            current_time = time.time()
            time_since_last = current_time - self.last_time
            if time_since_last < self.min_interval:
                time.sleep(self.min_interval - time_since_last)
            self.last_time = time.time()


class PerformanceMonitor:
    """Monitor performance metrics for threads."""

    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        self.metrics = ThreadSafeDict()
        self._timers = ThreadSafeDict()

    @contextmanager
    def measure(self, name: str):
        """Context manager to measure execution time."""
        start_time = time.perf_counter()
        yield
        elapsed = time.perf_counter() - start_time

        # Update metrics
        if name not in self.metrics.get("timings", {}):
            self.metrics.set(f"timings.{name}", deque(maxlen=self.window_size))

        with self.metrics.locked() as metrics:
            if "timings" not in metrics:
                metrics["timings"] = {}
            if name not in metrics["timings"]:
                metrics["timings"][name] = deque(maxlen=self.window_size)
            metrics["timings"][name].append(elapsed)

    def get_average(self, name: str) -> float:
        """Get average time for a measurement."""
        with self.metrics.locked() as metrics:
            timings = metrics.get("timings", {}).get(name, [])
            if timings:
                return sum(timings) / len(timings)
            return 0.0

    def get_stats(self, name: str) -> Dict[str, float]:
        """Get statistics for a measurement."""
        with self.metrics.locked() as metrics:
            timings = metrics.get("timings", {}).get(name, [])
            if not timings:
                return {"avg": 0.0, "min": 0.0, "max": 0.0, "count": 0}

            timings_list = list(timings)
            return {
                "avg": sum(timings_list) / len(timings_list),
                "min": min(timings_list),
                "max": max(timings_list),
                "count": len(timings_list),
            }

    def get_all_stats(self) -> Dict[str, Dict[str, float]]:
        """Get statistics for all measurements."""
        with self.metrics.locked() as metrics:
            all_stats = {}
            for name in metrics.get("timings", {}).keys():
                all_stats[name] = self.get_stats(name)
            return all_stats


class DataExchanger:
    """Thread-safe data exchange between threads."""

    def __init__(self):
        self._data = {}
        self._locks = {}
        self._events = {}

    def set_data(self, key: str, data: Any):
        """Set data for a key."""
        if key not in self._locks:
            self._locks[key] = threading.RLock()
            self._events[key] = threading.Event()

        with self._locks[key]:
            self._data[key] = data
            self._events[key].set()

    def get_data(self, key: str, timeout: Optional[float] = None) -> Optional[Any]:
        """Get data for a key."""
        if key not in self._events:
            return None

        if self._events[key].wait(timeout):
            with self._locks[key]:
                return self._data.get(key)
        return None

    def wait_for_data(self, key: str, timeout: Optional[float] = None) -> bool:
        """Wait for data to be available."""
        if key not in self._events:
            self._events[key] = threading.Event()
        return self._events[key].wait(timeout)

    def clear_data(self, key: str):
        """Clear data for a key."""
        if key in self._locks:
            with self._locks[key]:
                self._data.pop(key, None)
                self._events[key].clear()


def parallel_process(
    func: Callable[[Any], Any], items: List[Any], num_threads: Optional[int] = None
) -> List[Any]:
    """Process items in parallel using thread pool."""
    pool = ThreadPool(num_threads)
    pool.start(func)

    # Submit all items
    for item in items:
        pool.submit(item)

    # Wait for completion
    pool.wait_completion()

    # Get results
    results = pool.get_all_results()

    # Stop pool
    pool.stop()

    return results


def chunked_parallel_process(
    func: Callable[[np.ndarray], np.ndarray],
    data: np.ndarray,
    chunk_size: Optional[int] = None,
    num_threads: Optional[int] = None,
) -> np.ndarray:
    """Process numpy array in parallel chunks."""
    if num_threads is None:
        num_threads = mp.cpu_count()

    if chunk_size is None:
        chunk_size = max(1, len(data) // (num_threads * 4))

    # Split data into chunks
    chunks = []
    for i in range(0, len(data), chunk_size):
        chunks.append(data[i: i + chunk_size])

    # Process chunks in parallel
    processed_chunks = parallel_process(func, chunks, num_threads)

    # Combine results
    return np.concatenate(processed_chunks)
