"""
Voice Detection Wrapper
Wraps the industry voice detection module
"""

import os
import sys
import time
from typing import Dict
from typing import Optional

import numpy as np

from .base import AnalyzerResult
from .base import BaseAnalyzer

# Add path for industry voice detection module
sys.path.append(
    os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        "..",
        "voice_detection",
    )
)

try:
    from industry_voice_detection import IndustryVoiceDetector

    VOICE_DETECTION_AVAILABLE = True
except ImportError:
    VOICE_DETECTION_AVAILABLE = False
    print("Warning: Industry voice detection module not available")


class VoiceAnalyzer(BaseAnalyzer):
    """Voice detection and analysis wrapper"""

    def __init__(self, sample_rate: int = 48000):
        super().__init__(sample_rate, "VoiceAnalyzer")

        self.detector = None
        if VOICE_DETECTION_AVAILABLE:
            try:
                self.detector = IndustryVoiceDetector(sample_rate)
            except Exception as e:
                print(f"Failed to initialize voice detector: {e}")
                self.detector = None

        # Formant frequency ranges
        self.formant_ranges = {
            "F1": (200, 1000),  # First formant
            "F2": (700, 3000),  # Second formant
            "F3": (1500, 4000),  # Third formant
            "F4": (2500, 5000),  # Fourth formant
        }

        # Voice classification
        self.voice_types = {
            "bass": {"F1": (200, 400), "F2": (700, 1200)},
            "baritone": {"F1": (300, 500), "F2": (800, 1400)},
            "tenor": {"F1": (350, 600), "F2": (900, 1600)},
            "alto": {"F1": (400, 700), "F2": (1000, 1800)},
            "soprano": {"F1": (450, 800), "F2": (1100, 2000)},
        }

    def analyze_formants(
        self, fft_data: np.ndarray, freqs: np.ndarray
    ) -> Dict[str, float]:
        """Extract formant frequencies from spectrum"""
        formants = {}

        # Find peaks that could be formants
        from scipy import signal

        prominence = np.max(fft_data) * 0.1
        peaks, properties = signal.find_peaks(
            fft_data, prominence=prominence, distance=20
        )

        if len(peaks) == 0:
            return formants

        # Match peaks to formant ranges
        for formant_name, (low, high) in self.formant_ranges.items():
            for peak_idx in peaks:
                if peak_idx < len(freqs):
                    peak_freq = freqs[peak_idx]
                    if low <= peak_freq <= high:
                        if (
                            formant_name not in formants
                            or fft_data[peak_idx] > formants[formant_name]["magnitude"]
                        ):
                            formants[formant_name] = {
                                "frequency": peak_freq,
                                "magnitude": fft_data[peak_idx],
                            }

        return formants

    def classify_voice_type(self, formants: Dict[str, dict]) -> Optional[str]:
        """Classify voice type based on formants"""
        if "F1" not in formants or "F2" not in formants:
            return None

        f1_freq = formants["F1"]["frequency"]
        f2_freq = formants["F2"]["frequency"]

        best_match = None
        best_score = float("inf")

        for voice_type, ranges in self.voice_types.items():
            f1_range = ranges["F1"]
            f2_range = ranges["F2"]

            # Calculate distance from range centers
            f1_center = (f1_range[0] + f1_range[1]) / 2
            f2_center = (f2_range[0] + f2_range[1]) / 2

            distance = np.sqrt((f1_freq - f1_center) ** 2 + (f2_freq - f2_center) ** 2)

            if distance < best_score:
                best_score = distance
                best_match = voice_type

        return best_match

    def analyze_pitch_stability(self, audio_data: np.ndarray) -> float:
        """Analyze pitch stability using autocorrelation"""
        # Simple autocorrelation-based pitch detection
        autocorr = np.correlate(audio_data, audio_data, mode="full")
        autocorr = autocorr[len(autocorr) // 2 :]

        # Find first peak after zero lag
        min_period = int(self.sample_rate / 500)  # 500 Hz max
        max_period = int(self.sample_rate / 50)  # 50 Hz min

        if max_period < len(autocorr):
            autocorr_slice = autocorr[min_period:max_period]
            if len(autocorr_slice) > 0:
                peak_idx = np.argmax(autocorr_slice) + min_period

                # Measure stability by correlation strength
                if autocorr[0] > 0:
                    stability = autocorr[peak_idx] / autocorr[0]
                    return float(np.clip(stability, 0, 1))

        return 0.0

    def process(
        self, audio_data: np.ndarray, fft_data: Optional[np.ndarray] = None
    ) -> AnalyzerResult:
        """Process audio for voice detection"""
        try:
            # Input validation
            if audio_data is None:
                raise ValueError("audio_data cannot be None")
            if not isinstance(audio_data, np.ndarray):
                raise ValueError(f"audio_data must be numpy array, got {type(audio_data)}")
            if audio_data.size == 0:
                raise ValueError("audio_data cannot be empty")
            if fft_data is not None and not isinstance(fft_data, np.ndarray):
                raise ValueError(f"fft_data must be numpy array or None, got {type(fft_data)}")
            if fft_data is not None and fft_data.size == 0:
                raise ValueError("fft_data cannot be empty")
            result_data = {
                "voice_detected": False,
                "confidence": 0.0,
                "formants": {},
                "voice_type": None,
                "pitch_stability": 0.0,
                "gender": None,
                "pitch_hz": 0.0,
            }

            # Use industry voice detector if available
            if self.detector and VOICE_DETECTION_AVAILABLE:
                try:
                    voice_result = self.detector.detect_voice_realtime(audio_data)
                    if voice_result:
                        result_data.update(
                            {
                                "voice_detected": voice_result.get(
                                    "voice_detected", False
                                ),
                                "confidence": voice_result.get("confidence", 0.0),
                                "gender": voice_result.get("gender", None),
                                "pitch_hz": voice_result.get("pitch", 0.0),
                            }
                        )
                except Exception as e:
                    print(f"Voice detection error: {e}")

            # Additional analysis if FFT data available
            if fft_data is not None and len(fft_data) > 0:
                # Generate frequency bins matching FFT data length
                fft_size = 2 * (len(fft_data) - 1)
                freqs = np.fft.rfftfreq(fft_size, 1 / self.sample_rate)

                # Analyze formants
                formants = self.analyze_formants(fft_data, freqs)
                result_data["formants"] = formants

                # Classify voice type
                voice_type = self.classify_voice_type(formants)
                if voice_type:
                    result_data["voice_type"] = voice_type

            # Analyze pitch stability
            stability = self.analyze_pitch_stability(audio_data)
            result_data["pitch_stability"] = stability

            # Simple voice detection fallback if industry detector not available
            if not self.detector:
                # Basic energy-based detection in voice frequency range
                if fft_data is not None:
                    voice_band_energy = np.sum(fft_data[10:200])  # 100Hz - 2kHz approx
                    total_energy = np.sum(fft_data) + 1e-6
                    voice_ratio = voice_band_energy / total_energy

                    result_data["voice_detected"] = (
                        voice_ratio > 0.3 and stability > 0.5
                    )
                    result_data["confidence"] = voice_ratio * stability

            return AnalyzerResult(result_data, time.time(), 0.0)
        except Exception as e:
            print(f"VoiceAnalyzer error: {e}")
            return AnalyzerResult(
                {
                    "voice_detected": False,
                    "confidence": 0.0,
                    "formants": {},
                    "voice_type": None,
                    "pitch_stability": 0.0,
                    "gender": None,
                    "pitch_hz": 0.0,
                },
                time.time(),
                0.0,
            )
