"""
Chromagram analyzer for OMEGA-3.
Extracts pitch class profiles for harmonic analysis and chord detection.
"""

from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np

from .base import BaseAnalyzer


class ChromagramAnalyzer(BaseAnalyzer):
    """Chromagram extraction and analysis."""

    def __init__(
        self, sample_rate: int = 48000, n_chroma: int = 12, hop_length: int = 512
    ):
        super().__init__(sample_rate)
        self.n_chroma = n_chroma
        self.hop_length = hop_length
        self.reference_frequency = 440.0  # A4
        self.n_octaves = 7
        self.fmin = 32.70  # C1

        # Chord templates
        self.chord_templates = self._create_chord_templates()

        # Initialize filterbank
        self.filterbank = self._create_filterbank()

    def analyze(self, audio_data: np.ndarray) -> Dict[str, any]:
        """
        Extract chromagram features from audio.

        Returns:
            Dict containing:
            - chroma: 12-element array of pitch class energies
            - chord: Detected chord name
            - chord_confidence: Confidence score for chord detection
            - key: Estimated musical key
            - pitch_classes: Dominant pitch classes
        """
        # Compute chromagram
        chroma = self._compute_chromagram(audio_data)

        # Normalize chroma vector
        chroma_norm = chroma / (np.max(chroma) + 1e-10)

        # Detect chord
        chord, chord_confidence = self._detect_chord(chroma_norm)

        # Estimate key
        key = self._estimate_key(chroma_norm)

        # Find dominant pitch classes
        pitch_classes = self._get_dominant_pitch_classes(chroma_norm)

        return {
            "chroma": chroma_norm.tolist(),
            "chord": chord,
            "chord_confidence": chord_confidence,
            "key": key,
            "pitch_classes": pitch_classes,
            "energy_distribution": self._calculate_energy_distribution(chroma_norm),
        }

    def _compute_chromagram(self, audio_data: np.ndarray) -> np.ndarray:
        """Compute chromagram using constant-Q transform approach."""
        # Compute FFT
        fft = np.fft.rfft(audio_data)
        magnitude = np.abs(fft)
        freqs = np.fft.rfftfreq(len(audio_data), 1 / self.sample_rate)

        # Initialize chroma vector
        chroma = np.zeros(self.n_chroma)

        # Map frequency bins to pitch classes
        for i, freq in enumerate(freqs):
            if freq > 0 and freq < self.sample_rate / 2:
                pitch_class = self._frequency_to_pitch_class(freq)
                if pitch_class is not None:
                    chroma[pitch_class] += magnitude[i]

        return chroma

    def _create_filterbank(self) -> np.ndarray:
        """Create a filterbank for chromagram extraction."""
        # Stub implementation for constant-Q filterbank
        n_bins = self.n_octaves * self.n_chroma
        filterbank = np.zeros((n_bins, self.sample_rate // 2))

        for i in range(n_bins):
            center_freq = self.fmin * (2 ** (i / self.n_chroma))
            # Create triangular filter centered at center_freq
            # This is a simplified version

        return filterbank

    def _frequency_to_pitch_class(self, frequency: float) -> Optional[int]:
        """Convert frequency to pitch class (0-11)."""
        if frequency <= 0:
            return None

        # Calculate semitones from C0
        C0 = 16.35  # Hz
        semitones = 12 * np.log2(frequency / C0)

        # Get pitch class (0 = C, 1 = C#, ..., 11 = B)
        pitch_class = int(round(semitones)) % 12

        return pitch_class

    def _create_chord_templates(self) -> Dict[str, np.ndarray]:
        """Create chord templates for matching."""
        templates = {}

        # Major chords
        major_intervals = [0, 4, 7]  # Root, major third, fifth
        # Minor chords
        minor_intervals = [0, 3, 7]  # Root, minor third, fifth
        # Diminished
        dim_intervals = [0, 3, 6]
        # Augmented
        aug_intervals = [0, 4, 8]
        # Dominant 7th
        dom7_intervals = [0, 4, 7, 10]
        # Major 7th
        maj7_intervals = [0, 4, 7, 11]
        # Minor 7th
        min7_intervals = [0, 3, 7, 10]

        note_names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

        for i, root in enumerate(note_names):
            # Major
            templates[f"{root}"] = self._create_chord_vector(i, major_intervals)
            # Minor
            templates[f"{root}m"] = self._create_chord_vector(i, minor_intervals)
            # Diminished
            templates[f"{root}dim"] = self._create_chord_vector(i, dim_intervals)
            # Augmented
            templates[f"{root}aug"] = self._create_chord_vector(i, aug_intervals)
            # 7th chords
            templates[f"{root}7"] = self._create_chord_vector(i, dom7_intervals)
            templates[f"{root}maj7"] = self._create_chord_vector(i, maj7_intervals)
            templates[f"{root}m7"] = self._create_chord_vector(i, min7_intervals)

        return templates

    def _create_chord_vector(self, root: int, intervals: List[int]) -> np.ndarray:
        """Create a chord template vector."""
        vector = np.zeros(self.n_chroma)
        for interval in intervals:
            pitch_class = (root + interval) % self.n_chroma
            vector[pitch_class] = 1.0
        return vector / np.linalg.norm(vector)

    def _detect_chord(self, chroma: np.ndarray) -> Tuple[str, float]:
        """Detect chord from chromagram."""
        best_chord = "N/A"
        best_score = 0.0

        # Normalize input chroma
        if np.sum(chroma) > 0:
            chroma_norm = chroma / np.linalg.norm(chroma)
        else:
            return best_chord, best_score

        # Compare with chord templates
        for chord_name, template in self.chord_templates.items():
            # Cosine similarity
            score = np.dot(chroma_norm, template)
            if score > best_score:
                best_score = score
                best_chord = chord_name

        return best_chord, best_score

    def _estimate_key(self, chroma: np.ndarray) -> str:
        """Estimate musical key from chromagram."""
        # Krumhansl-Schmuckler key profiles
        major_profile = np.array(
            [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
        )
        minor_profile = np.array(
            [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]
        )

        note_names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

        best_key = "C"
        best_correlation = 0.0

        for i in range(12):
            # Rotate chroma to align with key
            rotated_chroma = np.roll(chroma, -i)

            # Correlate with major profile
            major_corr = np.corrcoef(rotated_chroma, major_profile)[0, 1]
            if major_corr > best_correlation:
                best_correlation = major_corr
                best_key = f"{note_names[i]} major"

            # Correlate with minor profile
            minor_corr = np.corrcoef(rotated_chroma, minor_profile)[0, 1]
            if minor_corr > best_correlation:
                best_correlation = minor_corr
                best_key = f"{note_names[i]} minor"

        return best_key

    def _get_dominant_pitch_classes(
        self, chroma: np.ndarray, threshold: float = 0.5
    ) -> List[str]:
        """Get dominant pitch classes from chromagram."""
        note_names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        dominant_classes = []

        for i, value in enumerate(chroma):
            if value >= threshold:
                dominant_classes.append(
                    {"note": note_names[i], "strength": float(value)}
                )

        # Sort by strength
        dominant_classes.sort(key=lambda x: x["strength"], reverse=True)

        return dominant_classes

    def _calculate_energy_distribution(self, chroma: np.ndarray) -> Dict[str, float]:
        """Calculate energy distribution metrics."""
        total_energy = np.sum(chroma)
        if total_energy == 0:
            return {"entropy": 0.0, "concentration": 0.0, "spread": 0.0}

        # Normalize to probability distribution
        prob_dist = chroma / total_energy

        # Calculate entropy
        entropy = -np.sum(prob_dist * np.log2(prob_dist + 1e-10))

        # Calculate concentration (how concentrated energy is in few pitch classes)
        sorted_chroma = np.sort(chroma)[::-1]
        concentration = np.sum(sorted_chroma[:3]) / total_energy

        # Calculate spread (circular variance)
        angles = np.linspace(0, 2 * np.pi, self.n_chroma, endpoint=False)
        mean_angle = np.angle(np.sum(chroma * np.exp(1j * angles)))
        spread = 1 - np.abs(
            np.sum(chroma * np.exp(1j * (angles - mean_angle))) / total_energy
        )

        return {
            "entropy": float(entropy),
            "concentration": float(concentration),
            "spread": float(spread),
        }
