"""
Pitch detection analyzer for OMEGA-3.
Implements multiple pitch detection algorithms for accurate frequency estimation.
"""

from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np

from .base import BaseAnalyzer


class PitchDetectionMethod:
    """Available pitch detection methods."""

    AUTOCORRELATION = "autocorrelation"
    YIN = "yin"
    HARMONIC_PRODUCT_SPECTRUM = "hps"
    CEPSTRUM = "cepstrum"
    ZERO_CROSSING = "zero_crossing"


class PitchDetector(BaseAnalyzer):
    """Advanced pitch detection analyzer."""

    def __init__(
        self, sample_rate: int = 48000, method: str = PitchDetectionMethod.YIN
    ):
        super().__init__(sample_rate)
        self.method = method
        self.min_frequency = 50.0  # Hz
        self.max_frequency = 2000.0  # Hz
        self.confidence_threshold = 0.8
        self.pitch_history: List[float] = []
        self.history_size = 10

    def analyze(self, audio_data: np.ndarray) -> Dict[str, any]:
        """
        Analyze audio data for pitch.

        Returns:
            Dict containing:
            - pitch: Detected pitch in Hz
            - confidence: Confidence score (0-1)
            - note: Musical note name
            - cents: Cents offset from nearest note
            - harmonics: List of harmonic frequencies
        """
        if self.method == PitchDetectionMethod.YIN:
            pitch, confidence = self._yin_pitch_detection(audio_data)
        elif self.method == PitchDetectionMethod.AUTOCORRELATION:
            pitch, confidence = self._autocorrelation_pitch_detection(audio_data)
        elif self.method == PitchDetectionMethod.HARMONIC_PRODUCT_SPECTRUM:
            pitch, confidence = self._hps_pitch_detection(audio_data)
        else:
            pitch, confidence = 0.0, 0.0

        # Update history
        if pitch > 0:
            self.pitch_history.append(pitch)
            if len(self.pitch_history) > self.history_size:
                self.pitch_history.pop(0)

        # Get musical note information
        note_info = self._frequency_to_note(pitch) if pitch > 0 else None

        # Detect harmonics
        harmonics = self._detect_harmonics(audio_data, pitch) if pitch > 0 else []

        return {
            "pitch": pitch,
            "confidence": confidence,
            "note": note_info["note"] if note_info else None,
            "octave": note_info["octave"] if note_info else None,
            "cents": note_info["cents"] if note_info else None,
            "harmonics": harmonics,
            "method": self.method,
        }

    def _yin_pitch_detection(self, audio_data: np.ndarray) -> Tuple[float, float]:
        """YIN algorithm for pitch detection."""
        # Stub implementation
        window_size = len(audio_data)
        difference = np.zeros(window_size // 2)

        # Calculate difference function
        for tau in range(1, window_size // 2):
            for i in range(window_size - tau):
                difference[tau] += (audio_data[i] - audio_data[i + tau]) ** 2

        # Normalize difference function
        cumulative_mean = np.zeros_like(difference)
        cumulative_mean[0] = 1
        for tau in range(1, len(difference)):
            cumulative_mean[tau] = difference[tau] / (
                (1 / tau) * np.sum(difference[1: tau + 1])
            )

        # Find the first minimum
        tau = np.argmin(cumulative_mean[1:]) + 1

        # Parabolic interpolation for refined pitch
        if tau > 0 and tau < len(cumulative_mean) - 1:
            x0 = cumulative_mean[tau - 1]
            x1 = cumulative_mean[tau]
            x2 = cumulative_mean[tau + 1]

            a = (x0 - 2 * x1 + x2) / 2
            b = (x2 - x0) / 2

            if a != 0:
                x_offset = -b / (2 * a)
                tau = tau + x_offset

        pitch = self.sample_rate / tau if tau > 0 else 0
        confidence = 1 - cumulative_mean[int(tau)] if tau < len(cumulative_mean) else 0

        return pitch, confidence

    def _autocorrelation_pitch_detection(
        self, audio_data: np.ndarray
    ) -> Tuple[float, float]:
        """Autocorrelation-based pitch detection."""
        # Stub implementation
        autocorr = np.correlate(audio_data, audio_data, mode="full")
        autocorr = autocorr[len(autocorr) // 2:]

        # Find peaks
        min_period = int(self.sample_rate / self.max_frequency)
        max_period = int(self.sample_rate / self.min_frequency)

        if max_period < len(autocorr):
            peak_idx = np.argmax(autocorr[min_period:max_period]) + min_period
            pitch = self.sample_rate / peak_idx
            confidence = autocorr[peak_idx] / autocorr[0]
        else:
            pitch, confidence = 0.0, 0.0

        return pitch, confidence

    def _hps_pitch_detection(self, audio_data: np.ndarray) -> Tuple[float, float]:
        """Harmonic Product Spectrum pitch detection."""
        # Stub implementation
        fft = np.fft.rfft(audio_data)
        magnitude = np.abs(fft)

        # Downsample and multiply
        hps = magnitude.copy()
        for h in range(2, 6):  # Check up to 5th harmonic
            decimated = magnitude[::h]
            hps[: len(decimated)] *= decimated

        # Find peak
        freq_bins = np.fft.rfftfreq(len(audio_data), 1 / self.sample_rate)
        min_bin = int(self.min_frequency * len(audio_data) / self.sample_rate)
        max_bin = int(self.max_frequency * len(audio_data) / self.sample_rate)

        if max_bin < len(hps):
            peak_bin = np.argmax(hps[min_bin:max_bin]) + min_bin
            pitch = freq_bins[peak_bin]
            confidence = hps[peak_bin] / np.max(hps)
        else:
            pitch, confidence = 0.0, 0.0

        return pitch, confidence

    def _frequency_to_note(self, frequency: float) -> Dict[str, any]:
        """Convert frequency to musical note."""
        if frequency <= 0:
            return None

        A4 = 440.0
        notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

        # Calculate semitones from A4
        semitones = 12 * np.log2(frequency / A4)

        # Find nearest note
        nearest_semitone = round(semitones)
        cents = (semitones - nearest_semitone) * 100

        # Calculate note and octave
        note_index = (nearest_semitone + 9) % 12  # A is 9 semitones above C
        octave = 4 + (nearest_semitone + 9) // 12

        return {
            "note": notes[note_index],
            "octave": octave,
            "cents": cents,
            "frequency": frequency,
        }

    def _detect_harmonics(
        self, audio_data: np.ndarray, fundamental: float, max_harmonics: int = 5
    ) -> List[float]:
        """Detect harmonic frequencies."""
        if fundamental <= 0:
            return []

        harmonics = []
        fft = np.fft.rfft(audio_data)
        magnitude = np.abs(fft)
        freq_bins = np.fft.rfftfreq(len(audio_data), 1 / self.sample_rate)

        for h in range(1, max_harmonics + 1):
            target_freq = fundamental * h
            if target_freq > self.sample_rate / 2:
                break

            # Find peak near expected harmonic
            target_bin = int(target_freq * len(audio_data) / self.sample_rate)
            search_range = int(0.1 * target_bin)  # 10% tolerance

            start_bin = max(0, target_bin - search_range)
            end_bin = min(len(magnitude), target_bin + search_range)

            if end_bin > start_bin:
                peak_bin = np.argmax(magnitude[start_bin:end_bin]) + start_bin
                harmonics.append(freq_bins[peak_bin])

        return harmonics

    def get_pitch_stability(self) -> float:
        """Calculate pitch stability score based on history."""
        if len(self.pitch_history) < 2:
            return 1.0

        # Calculate standard deviation of pitch history
        std_dev = np.std(self.pitch_history)
        mean_pitch = np.mean(self.pitch_history)

        if mean_pitch > 0:
            variation = std_dev / mean_pitch
            stability = max(0, 1 - variation)
        else:
            stability = 0.0

        return stability
