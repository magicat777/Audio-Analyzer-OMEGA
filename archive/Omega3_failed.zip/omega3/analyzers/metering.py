"""
Professional audio metering for OMEGA-3.
Implements various meter types and loudness standards.
"""

from collections import deque
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np

from .base import BaseAnalyzer


class MeteringStandard:
    """Audio metering standards."""

    EBU_R128 = "ebu_r128"
    ITU_BS1770 = "itu_bs1770"
    ATSC_A85 = "atsc_a85"
    VU = "vu"
    PPM = "ppm"
    RMS = "rms"
    PEAK = "peak"
    TRUE_PEAK = "true_peak"


class ProfessionalMeter(BaseAnalyzer):
    """Professional audio metering with multiple standards."""

    def __init__(self, sample_rate: int = 48000):
        super().__init__(sample_rate)

        # Meter parameters
        self.meter_types = [
            MeteringStandard.PEAK,
            MeteringStandard.RMS,
            MeteringStandard.VU,
            MeteringStandard.EBU_R128,
        ]

        # Time constants
        self.peak_hold_time = 2.0  # seconds
        self.rms_window = 0.3  # 300ms RMS window
        self.vu_integration = 0.3  # 300ms VU integration

        # EBU R128 / ITU-BS.1770 parameters
        self.momentary_window = 0.4  # 400ms
        self.short_term_window = 3.0  # 3 seconds
        self.integrated_gate_threshold = -70.0  # LUFS
        self.relative_gate_threshold = -10.0  # LU below ungated

        # K-weighting filter coefficients (ITU-BS.1770)
        self._init_k_weighting_filter()

        # History buffers
        self.peak_history = deque(maxlen=int(self.peak_hold_time * sample_rate))
        self.rms_buffer = deque(maxlen=int(self.rms_window * sample_rate))
        self.momentary_buffer = deque(maxlen=int(self.momentary_window * sample_rate))
        self.short_term_buffer = deque(maxlen=int(self.short_term_window * sample_rate))
        self.integrated_blocks = []

        # Peak hold values
        self.peak_hold = 0.0
        self.peak_hold_samples = 0

        # True peak oversampling
        self.oversample_factor = 4

    def analyze(self, audio_data: np.ndarray) -> Dict[str, any]:
        """
        Perform comprehensive audio metering.

        Returns:
            Dict containing:
            - peak: Peak level measurements
            - rms: RMS level measurements
            - vu: VU meter reading
            - lufs: EBU R128 loudness measurements
            - dynamic_range: Dynamic range metrics
            - correlation: Phase correlation meter
            - spectrum_balance: Frequency balance analysis
        """
        # Update buffers
        self._update_buffers(audio_data)

        # Peak measurements
        peak_metrics = self._measure_peak_levels(audio_data)

        # RMS measurements
        rms_metrics = self._measure_rms_levels(audio_data)

        # VU meter
        vu_reading = self._calculate_vu_meter(audio_data)

        # EBU R128 loudness
        loudness_metrics = self._measure_loudness(audio_data)

        # Dynamic range
        dynamic_range = self._calculate_dynamic_range(audio_data)

        # Phase correlation (for stereo)
        correlation = self._calculate_correlation(audio_data)

        # Spectrum balance
        spectrum_balance = self._analyze_spectrum_balance(audio_data)

        # Crest factor
        crest_factor = self._calculate_crest_factor(
            peak_metrics["peak"], rms_metrics["rms"]
        )

        return {
            "peak": peak_metrics,
            "rms": rms_metrics,
            "vu": vu_reading,
            "lufs": loudness_metrics,
            "dynamic_range": dynamic_range,
            "correlation": correlation,
            "spectrum_balance": spectrum_balance,
            "crest_factor": crest_factor,
            "headroom": self._calculate_headroom(peak_metrics["peak"]),
            "clipping": self._detect_clipping(audio_data),
        }

    def _init_k_weighting_filter(self):
        """Initialize K-weighting filter for loudness measurement."""
        # Pre-filter (high-pass)
        # H1(z) = 1 - 0.95 * z^-1
        self.pre_b = np.array([1.0, -0.95])
        self.pre_a = np.array([1.0, -0.95])

        # RLB filter (high-shelf)
        # Approximation for 48kHz sample rate
        f0 = 1681.81
        Q = 0.7071
        K = np.tan(np.pi * f0 / self.sample_rate)

        Vh = 10 ** (3.999843853973347 / 20)  # ~1.584893192
        Vb = Vh ** 0.4996667

        a0 = 1 + K / Q + K * K
        self.rlb_b = np.array(
            [
                (Vh + Vb * K / Q + K * K) / a0,
                2 * (K * K - Vh) / a0,
                (Vh - Vb * K / Q + K * K) / a0,
            ]
        )
        self.rlb_a = np.array([1.0, 2 * (K * K - 1) / a0, (1 - K / Q + K * K) / a0])

        # Filter states
        self.pre_state = np.zeros(2)
        self.rlb_state = np.zeros(2)

    def _update_buffers(self, audio_data: np.ndarray):
        """Update all measurement buffers."""
        # Convert to mono if stereo
        if audio_data.ndim > 1:
            mono = np.mean(audio_data, axis=1)
        else:
            mono = audio_data

        # Update various buffers
        self.rms_buffer.extend(mono)
        self.momentary_buffer.extend(mono)
        self.short_term_buffer.extend(mono)

        # K-weighted samples for loudness
        k_weighted = self._apply_k_weighting(mono)

        # Store blocks for integrated measurement
        block_size = int(0.1 * self.sample_rate)  # 100ms blocks
        for i in range(0, len(k_weighted), block_size):
            block = k_weighted[i: i + block_size]
            if len(block) == block_size:
                block_power = np.mean(block ** 2)
                self.integrated_blocks.append(block_power)

    def _apply_k_weighting(self, audio_data: np.ndarray) -> np.ndarray:
        """Apply K-weighting filter for loudness measurement."""
        # Pre-filter
        filtered = audio_data.copy()

        # Apply high-pass pre-filter
        for i in range(len(filtered)):
            if i > 0:
                filtered[i] = audio_data[i] - 0.95 * audio_data[i - 1]

        # Apply RLB high-shelf filter
        # Simplified implementation - in practice use scipy.signal.lfilter
        output = np.zeros_like(filtered)
        for i in range(len(filtered)):
            if i >= 2:
                output[i] = (
                    self.rlb_b[0] * filtered[i]
                    + self.rlb_b[1] * filtered[i - 1]
                    + self.rlb_b[2] * filtered[i - 2]
                    - self.rlb_a[1] * output[i - 1]
                    - self.rlb_a[2] * output[i - 2]
                )
            elif i == 1:
                output[i] = (
                    self.rlb_b[0] * filtered[i] + self.rlb_b[1] * filtered[i - 1]
                )
            else:
                output[i] = self.rlb_b[0] * filtered[i]

        return output

    def _measure_peak_levels(self, audio_data: np.ndarray) -> Dict[str, float]:
        """Measure various peak levels."""
        # Sample peak
        peak = np.max(np.abs(audio_data))

        # True peak (oversampled)
        true_peak = self._calculate_true_peak(audio_data)

        # Peak hold
        self.peak_history.append(peak)
        if peak > self.peak_hold:
            self.peak_hold = peak
            self.peak_hold_samples = 0
        else:
            self.peak_hold_samples += len(audio_data)
            if self.peak_hold_samples > self.peak_hold_time * self.sample_rate:
                self.peak_hold = np.max(self.peak_history) if self.peak_history else 0.0

        # Convert to dB
        peak_db = 20 * np.log10(peak + 1e-10)
        true_peak_db = 20 * np.log10(true_peak + 1e-10)
        peak_hold_db = 20 * np.log10(self.peak_hold + 1e-10)

        return {
            "peak": float(peak),
            "peak_db": float(peak_db),
            "true_peak": float(true_peak),
            "true_peak_db": float(true_peak_db),
            "peak_hold": float(self.peak_hold),
            "peak_hold_db": float(peak_hold_db),
        }

    def _calculate_true_peak(self, audio_data: np.ndarray) -> float:
        """Calculate true peak using oversampling."""
        # Simple linear interpolation oversampling
        oversampled = np.zeros(len(audio_data) * self.oversample_factor)

        for i in range(len(audio_data) - 1):
            for j in range(self.oversample_factor):
                alpha = j / self.oversample_factor
                idx = i * self.oversample_factor + j
                oversampled[idx] = (1 - alpha) * audio_data[i] + alpha * audio_data[
                    i + 1
                ]

        return np.max(np.abs(oversampled))

    def _measure_rms_levels(self, audio_data: np.ndarray) -> Dict[str, float]:
        """Measure RMS levels."""
        # Instantaneous RMS
        instant_rms = np.sqrt(np.mean(audio_data ** 2))

        # Windowed RMS
        if len(self.rms_buffer) > 0:
            windowed_rms = np.sqrt(np.mean(np.array(self.rms_buffer) ** 2))
        else:
            windowed_rms = instant_rms

        # Convert to dB
        instant_rms_db = 20 * np.log10(instant_rms + 1e-10)
        windowed_rms_db = 20 * np.log10(windowed_rms + 1e-10)

        return {
            "rms": float(windowed_rms),
            "rms_db": float(windowed_rms_db),
            "instant_rms": float(instant_rms),
            "instant_rms_db": float(instant_rms_db),
        }

    def _calculate_vu_meter(self, audio_data: np.ndarray) -> Dict[str, float]:
        """Calculate VU meter reading."""
        # VU meter has specific ballistics
        # Rise time: 300ms to 99% of steady state
        # Fall time: 300ms

        # Simple approximation using exponential smoothing
        target = np.sqrt(np.mean(audio_data ** 2))

        if not hasattr(self, "vu_level"):
            self.vu_level = 0.0

        # Time constant for 300ms at current sample rate
        alpha = 1 - np.exp(-1 / (0.3 * self.sample_rate / len(audio_data)))

        # Smooth towards target
        self.vu_level = alpha * target + (1 - alpha) * self.vu_level

        # VU is calibrated to 0 VU = +4 dBu = 1.228 Vrms
        # Assuming digital full scale = 0 dBFS
        vu_db = 20 * np.log10(self.vu_level + 1e-10) + 4

        return {"vu": float(self.vu_level), "vu_db": float(vu_db)}

    def _measure_loudness(self, audio_data: np.ndarray) -> Dict[str, float]:
        """Measure loudness according to EBU R128 / ITU-BS.1770."""
        # Momentary loudness (400ms)
        if len(self.momentary_buffer) >= int(
            self.momentary_window * self.sample_rate * 0.75
        ):
            momentary_samples = np.array(self.momentary_buffer)
            k_weighted = self._apply_k_weighting(momentary_samples)
            momentary_power = np.mean(k_weighted ** 2)
            momentary_lufs = -0.691 + 10 * np.log10(momentary_power + 1e-10)
        else:
            momentary_lufs = -70.0

        # Short-term loudness (3s)
        if len(self.short_term_buffer) >= int(
            self.short_term_window * self.sample_rate * 0.75
        ):
            short_term_samples = np.array(self.short_term_buffer)
            k_weighted = self._apply_k_weighting(short_term_samples)
            short_term_power = np.mean(k_weighted ** 2)
            short_term_lufs = -0.691 + 10 * np.log10(short_term_power + 1e-10)
        else:
            short_term_lufs = -70.0

        # Integrated loudness (gated)
        integrated_lufs = self._calculate_integrated_loudness()

        # Loudness range
        loudness_range = self._calculate_loudness_range()

        return {
            "momentary": float(momentary_lufs),
            "short_term": float(short_term_lufs),
            "integrated": float(integrated_lufs),
            "range": float(loudness_range),
            "units": "LUFS",
        }

    def _calculate_integrated_loudness(self) -> float:
        """Calculate gated integrated loudness."""
        if len(self.integrated_blocks) < 10:
            return -70.0

        # Convert block powers to loudness
        block_loudness = [
            -0.691 + 10 * np.log10(p + 1e-10) for p in self.integrated_blocks
        ]

        # First pass: absolute gate at -70 LUFS
        gated_blocks = [
            p
            for p, l in zip(self.integrated_blocks, block_loudness)
            if l > self.integrated_gate_threshold
        ]

        if not gated_blocks:
            return -70.0

        # Calculate ungated loudness
        ungated_power = np.mean(gated_blocks)
        ungated_loudness = -0.691 + 10 * np.log10(ungated_power + 1e-10)

        # Second pass: relative gate 10 LU below ungated
        relative_threshold = ungated_loudness + self.relative_gate_threshold

        final_blocks = [
            p
            for p, l in zip(self.integrated_blocks, block_loudness)
            if l > relative_threshold
        ]

        if not final_blocks:
            return ungated_loudness

        # Final integrated loudness
        final_power = np.mean(final_blocks)
        integrated_loudness = -0.691 + 10 * np.log10(final_power + 1e-10)

        return integrated_loudness

    def _calculate_loudness_range(self) -> float:
        """Calculate loudness range (LRA)."""
        if len(self.integrated_blocks) < 30:  # Need at least 3 seconds
            return 0.0

        # Calculate short-term loudness values
        st_window_blocks = int(self.short_term_window * 10)  # 10 blocks per second
        st_loudness_values = []

        for i in range(len(self.integrated_blocks) - st_window_blocks + 1):
            blocks = self.integrated_blocks[i: i + st_window_blocks]
            power = np.mean(blocks)
            loudness = -0.691 + 10 * np.log10(power + 1e-10)
            if loudness > -70.0:
                st_loudness_values.append(loudness)

        if len(st_loudness_values) < 2:
            return 0.0

        # Calculate percentiles
        st_loudness_values.sort()
        low_percentile = st_loudness_values[int(0.10 * len(st_loudness_values))]
        high_percentile = st_loudness_values[int(0.95 * len(st_loudness_values))]

        return high_percentile - low_percentile

    def _calculate_dynamic_range(self, audio_data: np.ndarray) -> Dict[str, float]:
        """Calculate various dynamic range metrics."""
        # Peak to average ratio
        peak = np.max(np.abs(audio_data))
        avg = np.mean(np.abs(audio_data))
        peak_to_avg = peak / (avg + 1e-10)

        # DR meter (simplified)
        # Based on difference between peak and RMS in loud parts
        rms = np.sqrt(np.mean(audio_data ** 2))
        dr_value = 20 * np.log10(peak / (rms + 1e-10))

        # Macro dynamics (variation in RMS over time)
        # This would need longer time windows in practice
        if hasattr(self, "_rms_history"):
            self._rms_history.append(rms)
            if len(self._rms_history) > 100:
                self._rms_history.pop(0)
            macro_dynamics = np.std(self._rms_history)
        else:
            self._rms_history = [rms]
            macro_dynamics = 0.0

        return {
            "peak_to_average": float(peak_to_avg),
            "dr_value": float(dr_value),
            "macro_dynamics": float(macro_dynamics),
            "micro_dynamics": float(np.std(audio_data)),
        }

    def _calculate_correlation(self, audio_data: np.ndarray) -> Dict[str, float]:
        """Calculate phase correlation for stereo signals."""
        if audio_data.ndim < 2:
            # Mono signal
            return {"correlation": 1.0, "balance": 0.0, "width": 0.0}

        left = audio_data[:, 0]
        right = audio_data[:, 1]

        # Correlation coefficient
        correlation = np.corrcoef(left, right)[0, 1]

        # Balance (L-R)
        left_power = np.mean(left ** 2)
        right_power = np.mean(right ** 2)
        total_power = left_power + right_power

        if total_power > 0:
            balance = (left_power - right_power) / total_power
        else:
            balance = 0.0

        # Width estimation
        mid = (left + right) / 2
        side = (left - right) / 2

        mid_power = np.mean(mid ** 2)
        side_power = np.mean(side ** 2)

        if mid_power > 0:
            width = side_power / mid_power
        else:
            width = 0.0

        return {
            "correlation": float(correlation),
            "balance": float(balance),
            "width": float(width),
        }

    def _analyze_spectrum_balance(self, audio_data: np.ndarray) -> Dict[str, float]:
        """Analyze frequency spectrum balance."""
        # Compute spectrum
        fft = np.fft.rfft(audio_data)
        magnitude = np.abs(fft)
        freqs = np.fft.rfftfreq(len(audio_data), 1 / self.sample_rate)

        # Define frequency bands
        bands = {
            "sub_bass": (20, 60),
            "bass": (60, 250),
            "low_mid": (250, 500),
            "mid": (500, 2000),
            "high_mid": (2000, 4000),
            "presence": (4000, 8000),
            "brilliance": (8000, 20000),
        }

        # Calculate energy in each band
        band_energy = {}
        total_energy = np.sum(magnitude ** 2)

        for band_name, (low, high) in bands.items():
            band_idx = np.where((freqs >= low) & (freqs < high))[0]
            if len(band_idx) > 0:
                energy = np.sum(magnitude[band_idx] ** 2)
                band_energy[band_name] = energy / (total_energy + 1e-10)
            else:
                band_energy[band_name] = 0.0

        # Calculate tilt (spectral slope)
        # Linear regression of log magnitude vs log frequency
        valid_idx = np.where((freqs > 20) & (freqs < self.sample_rate / 2))[0]
        if len(valid_idx) > 10:
            log_freq = np.log10(freqs[valid_idx])
            log_mag = np.log10(magnitude[valid_idx] + 1e-10)

            # Simple linear regression
            slope = np.polyfit(log_freq, log_mag, 1)[0]
            tilt = slope * 3  # Scale for readability
        else:
            tilt = 0.0

        return {
            "bands": band_energy,
            "tilt": float(tilt),
            "balance_score": self._calculate_balance_score(band_energy),
        }

    def _calculate_balance_score(self, band_energy: Dict[str, float]) -> float:
        """Calculate overall spectrum balance score."""
        # Ideal targets (simplified)
        ideal = {
            "sub_bass": 0.05,
            "bass": 0.15,
            "low_mid": 0.20,
            "mid": 0.30,
            "high_mid": 0.15,
            "presence": 0.10,
            "brilliance": 0.05,
        }

        # Calculate deviation from ideal
        deviation = 0.0
        for band, ideal_value in ideal.items():
            actual_value = band_energy.get(band, 0.0)
            deviation += abs(actual_value - ideal_value)

        # Convert to 0-1 score (1 = perfect balance)
        score = max(0, 1 - deviation)

        return float(score)

    def _calculate_crest_factor(self, peak: float, rms: float) -> float:
        """Calculate crest factor (peak to RMS ratio)."""
        if rms > 0:
            crest_factor = peak / rms
            crest_factor_db = 20 * np.log10(crest_factor)
        else:
            crest_factor = 0.0
            crest_factor_db = 0.0

        return {"ratio": float(crest_factor), "db": float(crest_factor_db)}

    def _calculate_headroom(self, peak: float) -> float:
        """Calculate headroom to digital full scale."""
        # Assuming normalized audio where 1.0 = 0 dBFS
        headroom_db = 20 * np.log10(1.0 / (peak + 1e-10))
        return float(max(0, headroom_db))

    def _detect_clipping(self, audio_data: np.ndarray) -> Dict[str, any]:
        """Detect clipping in audio signal."""
        # Threshold for clipping detection (slightly below full scale)
        clip_threshold = 0.999

        # Find clipped samples
        clipped = np.abs(audio_data) >= clip_threshold
        num_clipped = np.sum(clipped)

        # Find consecutive clipped samples
        if num_clipped > 0:
            # Find runs of clipped samples
            diff = np.diff(np.concatenate([[0], clipped.astype(int), [0]]))
            starts = np.where(diff == 1)[0]
            ends = np.where(diff == -1)[0]

            run_lengths = ends - starts
            max_run = np.max(run_lengths) if len(run_lengths) > 0 else 0

            # Duration of longest clip
            max_clip_duration = max_run / self.sample_rate
        else:
            max_run = 0
            max_clip_duration = 0.0

        return {
            "detected": bool(num_clipped > 0),
            "sample_count": int(num_clipped),
            "percentage": float(100 * num_clipped / len(audio_data)),
            "max_consecutive": int(max_run),
            "max_duration_ms": float(max_clip_duration * 1000),
        }
