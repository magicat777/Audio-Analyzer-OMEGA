"""
Genre classification analyzer for OMEGA-3.
Uses spectral features and machine learning for music genre detection.
"""

from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np

from .base import BaseAnalyzer


class GenreClassifier(BaseAnalyzer):
    """Genre classification based on audio features."""

    def __init__(self, sample_rate: int = 48000):
        super().__init__(sample_rate)
        self.genres = [
            "Electronic",
            "Rock",
            "Jazz",
            "Classical",
            "Hip-Hop",
            "Pop",
            "Metal",
            "Blues",
            "Country",
            "Reggae",
            "Folk",
            "R&B",
            "Ambient",
            "Techno",
            "House",
        ]

        # Feature extraction parameters
        self.n_mfcc = 13
        self.n_spectral_features = 7
        self.temporal_features = 5

        # Genre profiles (simplified feature vectors)
        self.genre_profiles = self._create_genre_profiles()

        # Feature history for temporal analysis
        self.feature_history = []
        self.history_size = 20

    def analyze(self, audio_data: np.ndarray) -> Dict[str, any]:
        """
        Analyze audio for genre classification.

        Returns:
            Dict containing:
            - genre: Primary genre classification
            - confidence: Confidence score (0-1)
            - genre_scores: Scores for all genres
            - features: Extracted features used for classification
            - subgenre: Detected subgenre if applicable
        """
        # Extract features
        features = self._extract_features(audio_data)

        # Update feature history
        self.feature_history.append(features)
        if len(self.feature_history) > self.history_size:
            self.feature_history.pop(0)

        # Get temporal features
        temporal_features = self._extract_temporal_features()

        # Combine all features
        combined_features = np.concatenate(
            [
                features["spectral"],
                features["rhythmic"],
                features["timbral"],
                temporal_features,
            ]
        )

        # Classify genre
        genre_scores = self._classify_genre(combined_features)

        # Get top genre and confidence
        top_genre_idx = np.argmax(genre_scores)
        genre = self.genres[top_genre_idx]
        confidence = genre_scores[top_genre_idx]

        # Detect subgenre
        subgenre = self._detect_subgenre(genre, combined_features)

        return {
            "genre": genre,
            "confidence": float(confidence),
            "genre_scores": {
                self.genres[i]: float(score) for i, score in enumerate(genre_scores)
            },
            "features": {
                "spectral": features["spectral"].tolist(),
                "rhythmic": features["rhythmic"].tolist(),
                "timbral": features["timbral"].tolist(),
                "temporal": temporal_features.tolist(),
            },
            "subgenre": subgenre,
            "characteristics": self._get_genre_characteristics(genre),
        }

    def _extract_features(self, audio_data: np.ndarray) -> Dict[str, np.ndarray]:
        """Extract audio features for genre classification."""
        features = {}

        # Spectral features
        features["spectral"] = self._extract_spectral_features(audio_data)

        # Rhythmic features
        features["rhythmic"] = self._extract_rhythmic_features(audio_data)

        # Timbral features (simplified MFCC)
        features["timbral"] = self._extract_timbral_features(audio_data)

        return features

    def _extract_spectral_features(self, audio_data: np.ndarray) -> np.ndarray:
        """Extract spectral features."""
        # Compute FFT
        fft = np.fft.rfft(audio_data)
        magnitude = np.abs(fft)
        freqs = np.fft.rfftfreq(len(audio_data), 1 / self.sample_rate)

        # Spectral centroid
        centroid = np.sum(freqs * magnitude) / (np.sum(magnitude) + 1e-10)

        # Spectral bandwidth
        bandwidth = np.sqrt(
            np.sum((freqs - centroid) ** 2 * magnitude) / (np.sum(magnitude) + 1e-10)
        )

        # Spectral rolloff
        cumsum = np.cumsum(magnitude)
        rolloff_idx = np.searchsorted(cumsum, 0.85 * cumsum[-1])
        rolloff = freqs[rolloff_idx] if rolloff_idx < len(freqs) else freqs[-1]

        # Spectral flux
        if hasattr(self, "_prev_magnitude"):
            flux = np.sum((magnitude - self._prev_magnitude) ** 2)
        else:
            flux = 0.0
        self._prev_magnitude = magnitude.copy()

        # Zero crossing rate
        zcr = np.sum(np.abs(np.diff(np.sign(audio_data)))) / (2 * len(audio_data))

        # Spectral contrast (simplified - difference between peaks and valleys)
        n_bands = 6
        contrast = np.zeros(n_bands)
        band_size = len(magnitude) // n_bands
        for i in range(n_bands):
            band = magnitude[i * band_size: (i + 1) * band_size]
            if len(band) > 0:
                contrast[i] = np.log(np.max(band) + 1e-10) - np.log(
                    np.mean(band) + 1e-10
                )

        return np.array([centroid, bandwidth, rolloff, flux, zcr] + contrast.tolist())

    def _extract_rhythmic_features(self, audio_data: np.ndarray) -> np.ndarray:
        """Extract rhythmic features."""
        # Onset detection (simplified)
        envelope = np.abs(audio_data)

        # Smooth envelope
        window_size = int(0.01 * self.sample_rate)  # 10ms window
        smoothed = np.convolve(
            envelope, np.ones(window_size) / window_size, mode="same"
        )

        # Detect onsets as peaks in envelope derivative
        derivative = np.diff(smoothed)
        onsets = np.where((derivative[:-1] > 0) & (derivative[1:] <= 0))[0]

        # Tempo estimation (simplified)
        if len(onsets) > 1:
            # Inter-onset intervals
            ioi = np.diff(onsets) / self.sample_rate

            # Estimate tempo from most common IOI
            if len(ioi) > 0:
                hist, bins = np.histogram(ioi, bins=50, range=(0.1, 2.0))
                tempo_idx = np.argmax(hist)
                tempo = 60 / bins[tempo_idx] if bins[tempo_idx] > 0 else 120
            else:
                tempo = 120

            # Beat strength (regularity of onsets)
            if len(ioi) > 1:
                beat_strength = 1 - np.std(ioi) / (np.mean(ioi) + 1e-10)
            else:
                beat_strength = 0.0
        else:
            tempo = 120
            beat_strength = 0.0

        # Rhythmic complexity (entropy of IOI distribution)
        if len(onsets) > 2:
            ioi_hist, _ = np.histogram(np.diff(onsets), bins=20)
            ioi_prob = ioi_hist / (np.sum(ioi_hist) + 1e-10)
            rhythmic_complexity = -np.sum(ioi_prob * np.log2(ioi_prob + 1e-10))
        else:
            rhythmic_complexity = 0.0

        # Percussiveness (high-frequency energy ratio)
        # Calculate from audio data since freqs/magnitude not defined in this scope
        fft_data = np.fft.rfft(audio_data)
        freqs = np.fft.rfftfreq(len(audio_data), 1/self.sample_rate)
        magnitude = np.abs(fft_data)
        high_freq_idx = np.where(freqs > 5000)[0]
        if len(high_freq_idx) > 0:
            percussiveness = np.sum(magnitude[high_freq_idx]) / (
                np.sum(magnitude) + 1e-10
            )
        else:
            percussiveness = 0.0

        return np.array(
            [tempo, beat_strength, rhythmic_complexity, percussiveness, len(onsets)]
        )

    def _extract_timbral_features(self, audio_data: np.ndarray) -> np.ndarray:
        """Extract timbral features (simplified MFCC)."""
        # Pre-emphasis
        pre_emphasized = np.append(
            audio_data[0], audio_data[1:] - 0.97 * audio_data[:-1]
        )

        # FFT
        fft = np.fft.rfft(pre_emphasized)
        magnitude = np.abs(fft)

        # Mel filterbank (simplified)
        n_mels = 40
        mel_filters = self._create_mel_filterbank(n_mels, len(magnitude))
        mel_spectrum = np.dot(mel_filters, magnitude)

        # Log mel spectrum
        log_mel = np.log(mel_spectrum + 1e-10)

        # DCT to get MFCCs
        mfcc = np.zeros(self.n_mfcc)
        for i in range(self.n_mfcc):
            mfcc[i] = np.sum(
                log_mel * np.cos(np.pi * i * (np.arange(n_mels) + 0.5) / n_mels)
            )

        # Normalize
        mfcc = mfcc / (np.max(np.abs(mfcc)) + 1e-10)

        return mfcc

    def _create_mel_filterbank(self, n_filters: int, n_fft: int) -> np.ndarray:
        """Create mel-scale filterbank."""
        # Simplified mel filterbank
        filterbank = np.zeros((n_filters, n_fft))

        # Convert frequency to mel scale
        mel_max = 2595 * np.log10(1 + (self.sample_rate / 2) / 700)
        mel_points = np.linspace(0, mel_max, n_filters + 2)

        # Convert back to Hz
        hz_points = 700 * (10 ** (mel_points / 2595) - 1)

        # Convert to FFT bin numbers
        bin_points = np.floor((n_fft + 1) * hz_points / self.sample_rate).astype(int)

        # Create triangular filters
        for i in range(1, n_filters + 1):
            left = bin_points[i - 1]
            center = bin_points[i]
            right = bin_points[i + 1]

            for j in range(left, center):
                if center > left:
                    filterbank[i - 1, j] = (j - left) / (center - left)

            for j in range(center, right):
                if right > center:
                    filterbank[i - 1, j] = (right - j) / (right - center)

        return filterbank

    def _extract_temporal_features(self) -> np.ndarray:
        """Extract temporal features from feature history."""
        if len(self.feature_history) < 2:
            return np.zeros(self.temporal_features)

        # Stack historical features
        spectral_history = np.array([f["spectral"] for f in self.feature_history])

        # Temporal statistics
        mean_features = np.mean(spectral_history, axis=0)
        std_features = np.std(spectral_history, axis=0)

        # Feature trajectory (rate of change)
        if len(self.feature_history) > 2:
            trajectory = np.mean(np.diff(spectral_history, axis=0), axis=0)
        else:
            trajectory = np.zeros_like(mean_features)

        # Select most informative temporal features
        temporal_features = np.concatenate(
            [
                [np.mean(mean_features[:3])],  # Average spectral shape
                [np.mean(std_features[:3])],  # Spectral variability
                [np.mean(trajectory[:3])],  # Spectral evolution
                [std_features[0]],  # Centroid variability
                [trajectory[0]],  # Centroid trajectory
            ]
        )

        return temporal_features

    def _create_genre_profiles(self) -> Dict[str, np.ndarray]:
        """Create characteristic profiles for each genre."""
        # Simplified genre profiles based on typical characteristics
        profiles = {}

        # Electronic - high spectral flux, regular beats, synthetic timbres
        profiles["Electronic"] = np.array([0.7, 0.8, 0.9, 0.6, 0.8, 0.7, 0.9, 0.5])

        # Rock - moderate tempo, strong beats, mid-range spectrum
        profiles["Rock"] = np.array([0.6, 0.7, 0.6, 0.7, 0.8, 0.7, 0.6, 0.7])

        # Jazz - complex rhythms, varied dynamics, rich harmonics
        profiles["Jazz"] = np.array([0.5, 0.4, 0.8, 0.9, 0.3, 0.8, 0.7, 0.9])

        # Classical - wide dynamic range, complex timbres, varied tempo
        profiles["Classical"] = np.array([0.4, 0.3, 0.9, 0.8, 0.2, 0.9, 0.8, 0.7])

        # Hip-Hop - strong beats, low frequency emphasis, regular rhythm
        profiles["Hip-Hop"] = np.array([0.8, 0.9, 0.4, 0.5, 0.9, 0.6, 0.8, 0.7])

        # Add more genre profiles...
        for genre in self.genres:
            if genre not in profiles:
                # Generate random profile for demonstration
                profiles[genre] = np.random.rand(8)

        return profiles

    def _classify_genre(self, features: np.ndarray) -> np.ndarray:
        """Classify genre based on features."""
        # Normalize features
        features_norm = features / (np.linalg.norm(features) + 1e-10)

        # Compare with genre profiles
        scores = np.zeros(len(self.genres))

        for i, genre in enumerate(self.genres):
            if genre in self.genre_profiles:
                # Simplified comparison - would use ML model in practice
                profile = self.genre_profiles[genre]

                # Resize profile to match features if needed
                if len(profile) < len(features_norm):
                    profile = np.pad(profile, (0, len(features_norm) - len(profile)))
                elif len(profile) > len(features_norm):
                    profile = profile[: len(features_norm)]

                # Cosine similarity
                similarity = np.dot(features_norm, profile) / (
                    np.linalg.norm(profile) + 1e-10
                )
                scores[i] = max(0, similarity)

        # Normalize scores
        scores = scores / (np.sum(scores) + 1e-10)

        return scores

    def _detect_subgenre(self, genre: str, features: np.ndarray) -> Optional[str]:
        """Detect subgenre based on primary genre and features."""
        subgenres = {
            "Electronic": ["House", "Techno", "Dubstep", "Trance", "Drum & Bass"],
            "Rock": ["Alternative", "Progressive", "Indie", "Hard Rock", "Punk"],
            "Jazz": ["Bebop", "Smooth Jazz", "Fusion", "Swing", "Free Jazz"],
            "Metal": [
                "Heavy Metal",
                "Death Metal",
                "Black Metal",
                "Progressive Metal",
                "Thrash",
            ],
            "Classical": [
                "Baroque",
                "Romantic",
                "Contemporary",
                "Chamber",
                "Orchestral",
            ],
        }

        if genre not in subgenres:
            return None

        # Simplified subgenre detection based on specific features
        # In practice, this would use a more sophisticated model
        feature_idx = int(features[0] * len(subgenres[genre])) % len(subgenres[genre])

        return subgenres[genre][feature_idx]

    def _get_genre_characteristics(self, genre: str) -> Dict[str, any]:
        """Get characteristic features of a genre."""
        characteristics = {
            "Electronic": {
                "tempo_range": [120, 140],
                "key_instruments": ["Synthesizer", "Drum Machine", "Sampler"],
                "typical_structure": "4/4 time, repetitive patterns",
                "frequency_emphasis": "Full spectrum with bass emphasis",
            },
            "Rock": {
                "tempo_range": [100, 140],
                "key_instruments": ["Electric Guitar", "Bass", "Drums", "Vocals"],
                "typical_structure": "Verse-Chorus-Verse",
                "frequency_emphasis": "Mid-range with distortion",
            },
            "Jazz": {
                "tempo_range": [60, 200],
                "key_instruments": ["Saxophone", "Piano", "Bass", "Drums", "Trumpet"],
                "typical_structure": "Improvisation over chord changes",
                "frequency_emphasis": "Rich harmonics, wide dynamic range",
            },
            "Classical": {
                "tempo_range": [40, 180],
                "key_instruments": ["Strings", "Woodwinds", "Brass", "Piano"],
                "typical_structure": "Multi-movement compositions",
                "frequency_emphasis": "Full orchestral range",
            },
            "Hip-Hop": {
                "tempo_range": [70, 110],
                "key_instruments": ["Drums", "Bass", "Samples", "Vocals"],
                "typical_structure": "Verse-Hook-Verse",
                "frequency_emphasis": "Heavy bass, crisp highs",
            },
        }

        return characteristics.get(
            genre,
            {
                "tempo_range": [80, 140],
                "key_instruments": ["Various"],
                "typical_structure": "Varied",
                "frequency_emphasis": "Genre-specific",
            },
        )
