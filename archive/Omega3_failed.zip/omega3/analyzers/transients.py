"""
Transient detection and analysis for OMEGA-3.
Identifies and characterizes transient events in audio signals.
"""

from collections import deque
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np

from .base import BaseAnalyzer


class TransientType:
    """Types of transient events."""

    ATTACK = "attack"
    DECAY = "decay"
    IMPULSE = "impulse"
    CLICK = "click"
    PLUCK = "pluck"
    HIT = "hit"
    UNKNOWN = "unknown"


class TransientAnalyzer(BaseAnalyzer):
    """Detects and analyzes transient events in audio."""

    def __init__(self, sample_rate: int = 48000):
        super().__init__(sample_rate)

        # Detection parameters
        self.detection_threshold = 3.0  # Standard deviations above mean
        self.min_transient_duration = 0.001  # 1ms minimum
        self.max_transient_duration = 0.1  # 100ms maximum
        self.pre_transient_time = 0.005  # 5ms before onset
        self.post_transient_time = 0.050  # 50ms after onset

        # Analysis windows
        self.short_window = int(0.002 * sample_rate)  # 2ms
        self.medium_window = int(0.010 * sample_rate)  # 10ms
        self.long_window = int(0.050 * sample_rate)  # 50ms

        # History for adaptive threshold
        self.energy_history = deque(maxlen=int(sample_rate * 0.5))  # 500ms history
        self.detected_transients = []
        self.transient_buffer = deque(maxlen=100)

        # Spectral flux history
        self.prev_spectrum = None

    def analyze(self, audio_data: np.ndarray) -> Dict[str, any]:
        """
        Detect and analyze transients in audio data.

        Returns:
            Dict containing:
            - transients: List of detected transient events
            - density: Transient density (events per second)
            - types: Distribution of transient types
            - sharpness: Average transient sharpness
            - spectral_characteristics: Spectral properties of transients
        """
        # Detect transient onsets
        onsets = self._detect_onsets(audio_data)

        # Extract and analyze individual transients
        transients = []
        for onset_idx in onsets:
            transient_data = self._extract_transient(audio_data, onset_idx)
            if transient_data is not None:
                analysis = self._analyze_transient(transient_data, onset_idx)
                transients.append(analysis)

        # Update transient buffer
        for t in transients:
            self.transient_buffer.append(t)

        # Calculate statistics
        density = len(transients) / (len(audio_data) / self.sample_rate)
        type_distribution = self._calculate_type_distribution(transients)
        avg_sharpness = (
            np.mean([t["sharpness"] for t in transients]) if transients else 0.0
        )

        # Analyze spectral characteristics
        spectral_chars = self._analyze_spectral_characteristics(transients, audio_data)

        return {
            "transients": transients,
            "density": float(density),
            "types": type_distribution,
            "average_sharpness": float(avg_sharpness),
            "spectral_characteristics": spectral_chars,
            "rhythmic_pattern": self._detect_rhythmic_pattern(),
            "dynamics": self._analyze_dynamics(transients),
        }

    def _detect_onsets(self, audio_data: np.ndarray) -> List[int]:
        """Detect onset positions using multiple methods."""
        # Method 1: Energy-based detection
        energy_onsets = self._energy_based_detection(audio_data)

        # Method 2: Spectral flux detection
        spectral_onsets = self._spectral_flux_detection(audio_data)

        # Method 3: Phase deviation detection
        phase_onsets = self._phase_deviation_detection(audio_data)

        # Combine and refine onsets
        all_onsets = sorted(set(energy_onsets + spectral_onsets + phase_onsets))

        # Remove closely spaced onsets
        refined_onsets = self._refine_onsets(all_onsets)

        return refined_onsets

    def _energy_based_detection(self, audio_data: np.ndarray) -> List[int]:
        """Detect onsets based on energy increases."""
        # Calculate short-time energy
        energy = self._calculate_energy_envelope(audio_data, self.short_window)

        # Update energy history
        self.energy_history.extend(energy)

        # Calculate adaptive threshold
        if len(self.energy_history) > 100:
            mean_energy = np.mean(self.energy_history)
            std_energy = np.std(self.energy_history)
            threshold = mean_energy + self.detection_threshold * std_energy
        else:
            threshold = np.mean(energy) + self.detection_threshold * np.std(energy)

        # Find peaks above threshold
        onsets = []
        for i in range(1, len(energy) - 1):
            if energy[i] > threshold:
                if energy[i] > energy[i - 1] and energy[i] > energy[i + 1]:
                    # Convert to sample index
                    onset_sample = i * self.short_window // 2
                    onsets.append(onset_sample)

        return onsets

    def _spectral_flux_detection(self, audio_data: np.ndarray) -> List[int]:
        """Detect onsets using spectral flux method."""
        onsets = []

        # Calculate spectrogram with overlap
        hop_length = self.short_window // 2
        n_frames = (len(audio_data) - self.short_window) // hop_length + 1

        spectral_flux = np.zeros(n_frames)

        for i in range(n_frames):
            start = i * hop_length
            end = start + self.short_window

            if end <= len(audio_data):
                # Compute spectrum
                window = audio_data[start:end] * np.hanning(self.short_window)
                spectrum = np.abs(np.fft.rfft(window))

                # Calculate flux
                if self.prev_spectrum is not None:
                    # Half-wave rectified spectral difference
                    diff = spectrum - self.prev_spectrum
                    flux = np.sum(np.maximum(0, diff))
                    spectral_flux[i] = flux

                self.prev_spectrum = spectrum

        # Find peaks in spectral flux
        if len(spectral_flux) > 3:
            mean_flux = np.mean(spectral_flux)
            std_flux = np.std(spectral_flux)
            threshold = mean_flux + self.detection_threshold * std_flux

            for i in range(1, len(spectral_flux) - 1):
                if spectral_flux[i] > threshold:
                    if (
                        spectral_flux[i] > spectral_flux[i - 1]
                        and spectral_flux[i] > spectral_flux[i + 1]
                    ):
                        onset_sample = i * hop_length
                        onsets.append(onset_sample)

        return onsets

    def _phase_deviation_detection(self, audio_data: np.ndarray) -> List[int]:
        """Detect onsets using phase deviation method."""
        onsets = []

        # This is a simplified version - full implementation would use
        # complex domain onset detection
        hop_length = self.short_window // 2
        n_frames = (len(audio_data) - self.short_window) // hop_length + 1

        phase_deviation = np.zeros(n_frames)
        prev_phase = None
        prev_phase2 = None

        for i in range(n_frames):
            start = i * hop_length
            end = start + self.short_window

            if end <= len(audio_data):
                window = audio_data[start:end] * np.hanning(self.short_window)
                fft = np.fft.rfft(window)
                phase = np.angle(fft)

                if prev_phase is not None and prev_phase2 is not None:
                    # Second-order phase difference
                    target_phase = 2 * prev_phase - prev_phase2
                    deviation = np.sum(np.abs(phase - target_phase))
                    phase_deviation[i] = deviation

                prev_phase2 = prev_phase
                prev_phase = phase

        # Find peaks in phase deviation
        if len(phase_deviation) > 3:
            threshold = np.mean(phase_deviation) + 2 * np.std(phase_deviation)

            for i in range(1, len(phase_deviation) - 1):
                if phase_deviation[i] > threshold:
                    onset_sample = i * hop_length
                    onsets.append(onset_sample)

        return onsets

    def _calculate_energy_envelope(
        self, audio_data: np.ndarray, window_size: int
    ) -> np.ndarray:
        """Calculate energy envelope of signal."""
        # Square the signal
        squared = audio_data ** 2

        # Apply moving average
        kernel = np.ones(window_size) / window_size
        envelope = np.convolve(squared, kernel, mode="same")

        return envelope

    def _refine_onsets(
        self, onsets: List[int], min_distance: Optional[int] = None
    ) -> List[int]:
        """Remove closely spaced onsets."""
        if not onsets:
            return []

        if min_distance is None:
            min_distance = int(0.030 * self.sample_rate)  # 30ms minimum spacing

        refined = [onsets[0]]
        for onset in onsets[1:]:
            if onset - refined[-1] >= min_distance:
                refined.append(onset)

        return refined

    def _extract_transient(
        self, audio_data: np.ndarray, onset_idx: int
    ) -> Optional[np.ndarray]:
        """Extract transient segment around onset."""
        pre_samples = int(self.pre_transient_time * self.sample_rate)
        post_samples = int(self.post_transient_time * self.sample_rate)

        start = max(0, onset_idx - pre_samples)
        end = min(len(audio_data), onset_idx + post_samples)

        if end - start < self.short_window:
            return None

        return audio_data[start:end]

    def _analyze_transient(
        self, transient_data: np.ndarray, onset_idx: int
    ) -> Dict[str, any]:
        """Analyze individual transient characteristics."""
        # Calculate temporal features
        attack_time = self._calculate_attack_time(transient_data)
        decay_time = self._calculate_decay_time(transient_data)
        sharpness = self._calculate_sharpness(transient_data)

        # Calculate spectral features
        spectral_features = self._calculate_spectral_features(transient_data)

        # Classify transient type
        transient_type = self._classify_transient(
            attack_time, decay_time, sharpness, spectral_features
        )

        # Calculate energy
        energy = np.sum(transient_data ** 2)

        return {
            "onset_time": float(onset_idx / self.sample_rate),
            "onset_sample": int(onset_idx),
            "type": transient_type,
            "attack_time": float(attack_time),
            "decay_time": float(decay_time),
            "sharpness": float(sharpness),
            "energy": float(energy),
            "spectral_centroid": float(spectral_features["centroid"]),
            "spectral_spread": float(spectral_features["spread"]),
            "high_frequency_content": float(spectral_features["hfc"]),
            "pitch": spectral_features.get("pitch", None),
        }

    def _calculate_attack_time(self, transient_data: np.ndarray) -> float:
        """Calculate attack time (10% to 90% of peak)."""
        envelope = np.abs(transient_data)
        peak_idx = np.argmax(envelope)
        peak_value = envelope[peak_idx]

        # Find 10% point
        threshold_10 = 0.1 * peak_value
        idx_10 = 0
        for i in range(peak_idx):
            if envelope[i] >= threshold_10:
                idx_10 = i
                break

        # Find 90% point
        threshold_90 = 0.9 * peak_value
        idx_90 = peak_idx
        for i in range(idx_10, peak_idx):
            if envelope[i] >= threshold_90:
                idx_90 = i
                break

        attack_samples = idx_90 - idx_10
        attack_time = attack_samples / self.sample_rate

        return attack_time

    def _calculate_decay_time(self, transient_data: np.ndarray) -> float:
        """Calculate decay time (peak to 10% of peak)."""
        envelope = np.abs(transient_data)
        peak_idx = np.argmax(envelope)
        peak_value = envelope[peak_idx]

        # Find 10% point after peak
        threshold_10 = 0.1 * peak_value
        idx_10 = len(envelope) - 1

        for i in range(peak_idx, len(envelope)):
            if envelope[i] <= threshold_10:
                idx_10 = i
                break

        decay_samples = idx_10 - peak_idx
        decay_time = decay_samples / self.sample_rate

        return decay_time

    def _calculate_sharpness(self, transient_data: np.ndarray) -> float:
        """Calculate transient sharpness (0-1)."""
        envelope = np.abs(transient_data)

        # Calculate temporal centroid
        time_axis = np.arange(len(envelope))
        temporal_centroid = np.sum(time_axis * envelope) / (np.sum(envelope) + 1e-10)

        # Calculate spread around centroid
        spread = np.sqrt(
            np.sum((time_axis - temporal_centroid) ** 2 * envelope)
            / (np.sum(envelope) + 1e-10)
        )

        # Normalize to 0-1 (lower spread = sharper transient)
        max_spread = len(envelope) / 4  # Empirical normalization
        sharpness = 1 - min(spread / max_spread, 1.0)

        return sharpness

    def _calculate_spectral_features(
        self, transient_data: np.ndarray
    ) -> Dict[str, float]:
        """Calculate spectral features of transient."""
        # Apply window
        window = np.hanning(len(transient_data))
        windowed = transient_data * window

        # Compute spectrum
        fft = np.fft.rfft(windowed)
        magnitude = np.abs(fft)
        freqs = np.fft.rfftfreq(len(windowed), 1 / self.sample_rate)

        # Spectral centroid
        centroid = np.sum(freqs * magnitude) / (np.sum(magnitude) + 1e-10)

        # Spectral spread
        spread = np.sqrt(
            np.sum((freqs - centroid) ** 2 * magnitude) / (np.sum(magnitude) + 1e-10)
        )

        # High frequency content
        hfc = np.sum(freqs * magnitude ** 2) / (np.sum(magnitude ** 2) + 1e-10)

        # Detect pitch if tonal
        pitch = self._detect_transient_pitch(magnitude, freqs)

        return {"centroid": centroid, "spread": spread, "hfc": hfc, "pitch": pitch}

    def _detect_transient_pitch(
        self, magnitude: np.ndarray, freqs: np.ndarray
    ) -> Optional[float]:
        """Detect pitch in transient if tonal."""
        # Simple pitch detection for transients
        # Look for strong harmonic content

        # Find peaks
        peaks = []
        for i in range(1, len(magnitude) - 1):
            if magnitude[i] > magnitude[i - 1] and magnitude[i] > magnitude[i + 1]:
                if magnitude[i] > 0.1 * np.max(magnitude):  # Significant peaks only
                    peaks.append(i)

        if len(peaks) < 2:
            return None

        # Check for harmonic relationship
        peak_freqs = [freqs[p] for p in peaks[:5]]  # Check first 5 peaks

        # Simple harmonic detection
        for i in range(len(peak_freqs)):
            fundamental = peak_freqs[i]
            harmonics_found = 0

            for j in range(i + 1, len(peak_freqs)):
                ratio = peak_freqs[j] / fundamental
                if abs(ratio - round(ratio)) < 0.05:  # Within 5% of integer ratio
                    harmonics_found += 1

            if harmonics_found >= 2:
                return fundamental

        return None

    def _classify_transient(
        self,
        attack_time: float,
        decay_time: float,
        sharpness: float,
        spectral_features: Dict[str, float],
    ) -> str:
        """Classify transient type based on features."""
        # Rule-based classification

        if attack_time < 0.001 and sharpness > 0.8:
            if spectral_features["hfc"] > 5000:
                return TransientType.CLICK
            else:
                return TransientType.IMPULSE

        elif attack_time < 0.005:
            if decay_time > 0.05 and spectral_features.get("pitch"):
                return TransientType.PLUCK
            else:
                return TransientType.HIT

        elif attack_time < 0.020:
            if decay_time < attack_time:
                return TransientType.ATTACK
            else:
                return TransientType.DECAY
        else:
            return TransientType.UNKNOWN

    def _calculate_type_distribution(
        self, transients: List[Dict[str, any]]
    ) -> Dict[str, float]:
        """Calculate distribution of transient types."""
        type_counts = {}
        total = len(transients)

        if total == 0:
            return {}

        for t in transients:
            t_type = t["type"]
            type_counts[t_type] = type_counts.get(t_type, 0) + 1

        return {t_type: count / total for t_type, count in type_counts.items()}

    def _detect_rhythmic_pattern(self) -> Dict[str, any]:
        """Detect rhythmic patterns in transient sequence."""
        if len(self.transient_buffer) < 4:
            return {"pattern": "none", "confidence": 0.0}

        # Extract onset times
        onset_times = [t["onset_time"] for t in self.transient_buffer]

        # Calculate inter-onset intervals
        ioi = np.diff(onset_times)

        if len(ioi) < 3:
            return {"pattern": "none", "confidence": 0.0}

        # Look for regular patterns
        # Simple autocorrelation approach
        autocorr = np.correlate(ioi, ioi, mode="full")
        autocorr = autocorr[len(autocorr) // 2:]

        # Find periodicity
        if len(autocorr) > 1:
            # Skip lag 0
            peaks = []
            for i in range(1, min(len(autocorr), 10)):
                if i < len(autocorr) - 1:
                    if autocorr[i] > autocorr[i - 1] and autocorr[i] > autocorr[i + 1]:
                        peaks.append((i, autocorr[i]))

            if peaks:
                # Find strongest periodicity
                best_period = max(peaks, key=lambda x: x[1])
                period_samples = best_period[0]
                confidence = best_period[1] / autocorr[0]

                # Estimate tempo from period
                avg_ioi = np.mean(ioi)
                tempo = 60 / (avg_ioi * period_samples) if avg_ioi > 0 else 0

                return {
                    "pattern": "periodic",
                    "period": int(period_samples),
                    "confidence": float(confidence),
                    "estimated_tempo": float(tempo),
                }

        return {"pattern": "irregular", "confidence": 0.0}

    def _analyze_dynamics(self, transients: List[Dict[str, any]]) -> Dict[str, float]:
        """Analyze dynamic characteristics of transients."""
        if not transients:
            return {"dynamic_range": 0.0, "average_energy": 0.0, "energy_variance": 0.0}

        energies = [t["energy"] for t in transients]

        # Convert to dB
        energies_db = 20 * np.log10(np.array(energies) + 1e-10)

        return {
            "dynamic_range": float(np.max(energies_db) - np.min(energies_db)),
            "average_energy": float(np.mean(energies)),
            "energy_variance": float(np.var(energies)),
            "peak_to_average": float(np.max(energies) / (np.mean(energies) + 1e-10)),
        }

    def _analyze_spectral_characteristics(
        self, transients: List[Dict[str, any]], audio_data: np.ndarray
    ) -> Dict[str, any]:
        """Analyze overall spectral characteristics of transients."""
        if not transients:
            return {"brightness": 0.0, "tonality": 0.0, "frequency_distribution": {}}

        # Aggregate spectral features
        centroids = [t["spectral_centroid"] for t in transients]
        hfcs = [t["high_frequency_content"] for t in transients]
        pitches = [t["pitch"] for t in transients if t["pitch"] is not None]

        # Calculate brightness (normalized HFC)
        brightness = np.mean(hfcs) / (self.sample_rate / 2) if hfcs else 0.0

        # Calculate tonality (ratio of tonal to non-tonal transients)
        tonality = len(pitches) / len(transients) if transients else 0.0

        # Frequency distribution
        freq_bins = [0, 200, 500, 1000, 2000, 5000, 10000, 20000]
        freq_dist = {}

        for i in range(len(freq_bins) - 1):
            low = freq_bins[i]
            high = freq_bins[i + 1]
            count = sum(1 for c in centroids if low <= c < high)
            freq_dist[f"{low}-{high}Hz"] = count / len(centroids) if centroids else 0.0

        return {
            "brightness": float(brightness),
            "tonality": float(tonality),
            "frequency_distribution": freq_dist,
            "average_centroid": float(np.mean(centroids)) if centroids else 0.0,
            "centroid_variance": float(np.var(centroids)) if centroids else 0.0,
        }
