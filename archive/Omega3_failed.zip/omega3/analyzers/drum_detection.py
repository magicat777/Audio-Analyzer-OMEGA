"""
Drum Detection Module
Enhanced kick, snare, and hi-hat detection with groove analysis
"""

import time
from collections import deque
from typing import Dict
from typing import Optional
from typing import Tuple

import numpy as np
from scipy import signal

from .base import AnalyzerResult
from .base import BaseAnalyzer


class DrumDetector(BaseAnalyzer):
    """Comprehensive drum detection and groove analysis"""

    def __init__(self, sample_rate: int = 48000):
        super().__init__(sample_rate, "DrumDetector")

        # Frequency ranges for drum elements
        self.kick_freq_range = (20, 120)  # Hz
        self.snare_freq_range = (150, 300)  # Hz
        self.hihat_freq_range = (6000, 16000)  # Hz

        # Detection parameters
        self.kick_threshold = 2.5
        self.snare_threshold = 2.0
        self.hihat_threshold = 1.5

        # Timing tracking
        self.kick_times = deque(maxlen=32)
        self.snare_times = deque(maxlen=32)
        self.hihat_times = deque(maxlen=64)

        # Energy history for onset detection
        self.kick_energy_history = deque(maxlen=20)
        self.snare_energy_history = deque(maxlen=20)
        self.hihat_energy_history = deque(maxlen=20)

        # Groove analysis
        self.groove_patterns = {
            "four_on_floor": {"kicks": 4, "pattern": [1, 0, 1, 0, 1, 0, 1, 0]},
            "breakbeat": {"kicks": 2, "pattern": [1, 0, 0, 0, 0, 0, 1, 0]},
            "hip_hop": {"kicks": 2, "pattern": [1, 0, 0, 1, 0, 0, 1, 0]},
            "jazz": {"kicks": 1, "pattern": [1, 0, 0, 0, 0, 0, 0, 0]},
        }

        # BPM detection
        self.bpm_history = deque(maxlen=10)
        self.last_beat_time = 0

    def extract_frequency_band(
        self, fft_data: np.ndarray, freqs: np.ndarray, freq_range: Tuple[float, float]
    ) -> float:
        """Extract energy in specific frequency band"""
        mask = (freqs >= freq_range[0]) & (freqs <= freq_range[1])
        return np.sum(fft_data[mask] ** 2)

    def detect_onset(
        self, current_energy: float, energy_history: deque, threshold: float
    ) -> bool:
        """Detect onset using spectral flux"""
        if len(energy_history) < 5:
            return False

        # Calculate mean and std of recent history
        recent = list(energy_history)[-10:]
        mean_energy = np.mean(recent)
        std_energy = np.std(recent) + 1e-6

        # Normalized energy
        normalized = (current_energy - mean_energy) / std_energy

        # Onset if energy spike exceeds threshold
        return normalized > threshold

    def analyze_kick(self, fft_data: np.ndarray, freqs: np.ndarray) -> Dict[str, any]:
        """Analyze kick drum presence"""
        kick_energy = self.extract_frequency_band(fft_data, freqs, self.kick_freq_range)

        # Check for onset
        kick_detected = self.detect_onset(
            kick_energy, self.kick_energy_history, self.kick_threshold
        )

        # Update history
        self.kick_energy_history.append(kick_energy)

        # Track timing
        current_time = time.time()
        if kick_detected:
            self.kick_times.append(current_time)

        # Calculate kick rate
        kick_rate = 0
        if len(self.kick_times) >= 2:
            time_diffs = []
            times = list(self.kick_times)
            for i in range(1, len(times)):
                time_diffs.append(times[i] - times[i - 1])

            if time_diffs:
                avg_interval = np.mean(time_diffs)
                if avg_interval > 0:
                    kick_rate = 60.0 / avg_interval  # BPM

        return {
            "detected": kick_detected,
            "energy": kick_energy,
            "normalized_energy": kick_energy
            / (np.mean(list(self.kick_energy_history)) + 1e-6),
            "rate_bpm": kick_rate,
        }

    def analyze_snare(self, fft_data: np.ndarray, freqs: np.ndarray) -> Dict[str, any]:
        """Analyze snare drum presence"""
        snare_energy = self.extract_frequency_band(
            fft_data, freqs, self.snare_freq_range
        )

        # Add transient detection for snare
        # Snares have sharp transients
        spectral_centroid = np.sum(freqs[: len(fft_data)] * fft_data) / (
            np.sum(fft_data) + 1e-6
        )

        # Check for onset
        snare_detected = self.detect_onset(
            snare_energy, self.snare_energy_history, self.snare_threshold
        )

        # Additional snare characteristics
        if snare_detected and spectral_centroid < 1000:
            snare_detected = False  # Likely a kick, not snare

        # Update history
        self.snare_energy_history.append(snare_energy)

        # Track timing
        if snare_detected:
            self.snare_times.append(time.time())

        return {
            "detected": snare_detected,
            "energy": snare_energy,
            "normalized_energy": snare_energy
            / (np.mean(list(self.snare_energy_history)) + 1e-6),
            "spectral_centroid": spectral_centroid,
        }

    def analyze_hihat(self, fft_data: np.ndarray, freqs: np.ndarray) -> Dict[str, any]:
        """Analyze hi-hat presence"""
        hihat_energy = self.extract_frequency_band(
            fft_data, freqs, self.hihat_freq_range
        )

        # Hi-hats have consistent high-frequency energy
        hihat_detected = self.detect_onset(
            hihat_energy, self.hihat_energy_history, self.hihat_threshold
        )

        # Update history
        self.hihat_energy_history.append(hihat_energy)

        # Track timing
        if hihat_detected:
            self.hihat_times.append(time.time())

        # Detect open vs closed hi-hat
        high_ratio = self.extract_frequency_band(fft_data, freqs, (10000, 16000))
        mid_ratio = self.extract_frequency_band(fft_data, freqs, (6000, 10000))
        openness = high_ratio / (mid_ratio + 1e-6)

        return {
            "detected": hihat_detected,
            "energy": hihat_energy,
            "normalized_energy": hihat_energy
            / (np.mean(list(self.hihat_energy_history)) + 1e-6),
            "openness": openness,
            "type": "open" if openness > 1.5 else "closed",
        }

    def detect_groove_pattern(self) -> Dict[str, any]:
        """Analyze groove pattern from recent drum hits"""
        if len(self.kick_times) < 4:
            return {"pattern": "unknown", "confidence": 0}

        # Calculate average tempo from kicks
        kick_intervals = []
        kicks = list(self.kick_times)
        for i in range(1, len(kicks)):
            interval = kicks[i] - kicks[i - 1]
            if 0.2 < interval < 2.0:  # Reasonable tempo range
                kick_intervals.append(interval)

        if not kick_intervals:
            return {"pattern": "unknown", "confidence": 0}

        avg_interval = np.mean(kick_intervals)
        tempo_bpm = 60.0 / avg_interval

        # Update BPM history
        self.bpm_history.append(tempo_bpm)

        # Determine pattern (simplified)
        if 118 < tempo_bpm < 130:
            pattern = "four_on_floor"
            confidence = 0.8
        elif 80 < tempo_bpm < 100:
            pattern = "hip_hop"
            confidence = 0.7
        elif 160 < tempo_bpm < 180:
            pattern = "breakbeat"
            confidence = 0.6
        else:
            pattern = "unknown"
            confidence = 0.3

        return {
            "pattern": pattern,
            "confidence": confidence,
            "tempo_bpm": tempo_bpm,
            "avg_bpm": np.mean(list(self.bpm_history)) if self.bpm_history else 0,
        }

    def process(
        self, audio_data: np.ndarray, fft_data: Optional[np.ndarray] = None
    ) -> AnalyzerResult:
        """Process audio for drum detection"""
        if fft_data is None or len(fft_data) == 0:
            return AnalyzerResult({}, 0, 0)

        # Generate frequency bins matching FFT data length
        # FFT size should be 2 * (len(fft_data) - 1)
        fft_size = 2 * (len(fft_data) - 1)
        freqs = np.fft.rfftfreq(fft_size, 1 / self.sample_rate)

        # Analyze each drum element
        kick_info = self.analyze_kick(fft_data, freqs)
        snare_info = self.analyze_snare(fft_data, freqs)
        hihat_info = self.analyze_hihat(fft_data, freqs)

        # Groove pattern detection
        groove_info = self.detect_groove_pattern()

        # Overall rhythm intensity
        total_energy = kick_info["energy"] + snare_info["energy"] + hihat_info["energy"]
        rhythm_intensity = min(1.0, total_energy / 1000.0)  # Normalized

        result_data = {
            "kick": kick_info,
            "snare": snare_info,
            "hihat": hihat_info,
            "groove": groove_info,
            "rhythm_intensity": rhythm_intensity,
            "drum_activity": {
                "kick_active": kick_info["detected"],
                "snare_active": snare_info["detected"],
                "hihat_active": hihat_info["detected"],
                "total_hits": sum(
                    [
                        kick_info["detected"],
                        snare_info["detected"],
                        hihat_info["detected"],
                    ]
                ),
            },
        }

        return AnalyzerResult(result_data, 0, 0)
