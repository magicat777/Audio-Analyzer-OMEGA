"""
Base classes for all analyzers
"""

import time
from abc import ABC
from abc import abstractmethod
from dataclasses import dataclass
from typing import Any
from typing import Dict
from typing import Optional

import numpy as np


@dataclass
class AnalyzerResult:
    """Result container for analyzer outputs"""

    data: Dict[str, Any]
    timestamp: float
    processing_time: float

    def get(self, key: str, default=None):
        """Safe getter for result data"""
        return self.data.get(key, default)


class BaseAnalyzer(ABC):
    """Base class for all audio analyzers"""

    def __init__(self, sample_rate: int = 48000, name: str = "BaseAnalyzer"):
        self.sample_rate = sample_rate
        self.name = name
        self.enabled = True
        self.last_result: Optional[AnalyzerResult] = None
        self.processing_times = []

    @abstractmethod
    def process(
        self, audio_data: np.ndarray, fft_data: Optional[np.ndarray] = None
    ) -> AnalyzerResult:
        """
        Process audio data and return analysis results

        Args:
            audio_data: Time-domain audio samples
            fft_data: Optional pre-computed FFT data

        Returns:
            AnalyzerResult containing analysis data
        """
        pass

    def process_with_timing(
        self, audio_data: np.ndarray, fft_data: Optional[np.ndarray] = None
    ) -> AnalyzerResult:
        """Process with performance timing"""
        if not self.enabled:
            return AnalyzerResult({}, time.time(), 0.0)

        start_time = time.perf_counter()
        result = self.process(audio_data, fft_data)
        processing_time = (time.perf_counter() - start_time) * 1000  # Convert to ms

        # Track performance
        self.processing_times.append(processing_time)
        if len(self.processing_times) > 100:
            self.processing_times.pop(0)

        result.processing_time = processing_time
        self.last_result = result
        return result

    def get_average_processing_time(self) -> float:
        """Get average processing time in milliseconds"""
        if not self.processing_times:
            return 0.0
        return sum(self.processing_times) / len(self.processing_times)

    def reset(self):
        """Reset analyzer state"""
        self.last_result = None
        self.processing_times.clear()
