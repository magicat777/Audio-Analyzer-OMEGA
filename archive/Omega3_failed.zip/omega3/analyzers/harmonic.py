"""
Harmonic Analysis Module
Detects harmonics, fundamentals, and chord structures
"""

import time
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
from scipy import signal

from .base import AnalyzerResult
from .base import BaseAnalyzer


class HarmonicAnalyzer(BaseAnalyzer):
    """Analyzes harmonic content and relationships"""

    def __init__(self, sample_rate: int = 48000):
        super().__init__(sample_rate, "HarmonicAnalyzer")

        # Musical note frequencies (A4 = 440Hz)
        self.note_names = [
            "C",
            "C#",
            "D",
            "D#",
            "E",
            "F",
            "F#",
            "G",
            "G#",
            "A",
            "A#",
            "B",
        ]
        self.a4_freq = 440.0

        # Harmonic detection parameters
        self.min_fundamental = 80  # E2
        self.max_fundamental = 2000  # B6
        self.harmonic_tolerance = 0.03  # 3% frequency tolerance
        self.min_harmonic_ratio = 0.1  # Minimum ratio to fundamental

        # Chord detection
        self.chord_templates = self._create_chord_templates()

    def _create_chord_templates(self) -> Dict[str, List[int]]:
        """Create chord interval templates (in semitones)"""
        return {
            "major": [0, 4, 7],
            "minor": [0, 3, 7],
            "dim": [0, 3, 6],
            "aug": [0, 4, 8],
            "maj7": [0, 4, 7, 11],
            "min7": [0, 3, 7, 10],
            "dom7": [0, 4, 7, 10],
            "sus2": [0, 2, 7],
            "sus4": [0, 5, 7],
        }

    def freq_to_midi(self, freq: float) -> float:
        """Convert frequency to MIDI note number"""
        if freq <= 0:
            return 0
        return 69 + 12 * np.log2(freq / self.a4_freq)

    def midi_to_freq(self, midi: float) -> float:
        """Convert MIDI note number to frequency"""
        return self.a4_freq * (2 ** ((midi - 69) / 12))

    def freq_to_note(self, freq: float) -> Tuple[str, int, float]:
        """Convert frequency to note name, octave, and cents deviation"""
        midi = self.freq_to_midi(freq)
        midi_rounded = round(midi)
        cents = (midi - midi_rounded) * 100

        note_idx = int(midi_rounded) % 12
        octave = int(midi_rounded) // 12 - 1

        return self.note_names[note_idx], octave, cents

    def find_harmonics(self, fft_data: np.ndarray, freqs: np.ndarray) -> Dict[str, any]:
        """Find fundamental frequency and harmonics"""
        # Find peaks in spectrum
        prominence = np.max(fft_data) * 0.1
        peaks, properties = signal.find_peaks(
            fft_data, prominence=prominence, distance=20
        )

        if len(peaks) == 0:
            return {}

        # Sort peaks by magnitude
        peak_mags = fft_data[peaks]
        sorted_indices = np.argsort(peak_mags)[::-1]
        sorted_peaks = peaks[sorted_indices]

        # Try each peak as potential fundamental
        best_fundamental = None
        best_harmonics = []
        best_score = 0

        for peak_idx in sorted_peaks[:5]:  # Check only top 5 peaks for performance
            if peak_idx >= len(freqs):
                continue

            fundamental_freq = freqs[peak_idx]
            if (
                fundamental_freq < self.min_fundamental
                or fundamental_freq > self.max_fundamental
            ):
                continue

            # Look for harmonics
            harmonics = []
            harmonic_sum = fft_data[peak_idx]

            for n in range(2, 8):  # Check up to 7th harmonic for performance
                expected_freq = fundamental_freq * n
                if expected_freq > freqs[-1]:
                    break

                # Find closest frequency bin
                closest_idx = np.argmin(np.abs(freqs - expected_freq))
                actual_freq = freqs[closest_idx]

                # Check if within tolerance
                if (
                    abs(actual_freq - expected_freq) / expected_freq
                    < self.harmonic_tolerance
                ):
                    harmonic_mag = fft_data[closest_idx]
                    if harmonic_mag > fft_data[peak_idx] * self.min_harmonic_ratio:
                        harmonics.append(
                            {
                                "number": n,
                                "frequency": actual_freq,
                                "magnitude": harmonic_mag,
                                "expected_freq": expected_freq,
                            }
                        )
                        harmonic_sum += harmonic_mag

            # Score based on number of harmonics and total energy
            score = len(harmonics) * harmonic_sum

            if score > best_score:
                best_score = score
                best_fundamental = fundamental_freq
                best_harmonics = harmonics

        if best_fundamental:
            note, octave, cents = self.freq_to_note(best_fundamental)
            return {
                "fundamental_freq": best_fundamental,
                "fundamental_note": f"{note}{octave}",
                "cents_offset": cents,
                "harmonics": best_harmonics,
                "harmonic_score": best_score,
            }

        return {}

    def detect_chord(
        self, peaks: List[Tuple[float, float]]
    ) -> Optional[Dict[str, any]]:
        """Detect chord from frequency peaks"""
        if len(peaks) < 3:
            return None

        # Convert peaks to MIDI notes
        midi_notes = []
        for freq, mag in peaks[:8]:  # Consider top 8 peaks
            if freq > 80 and freq < 2000:  # Musical range
                midi = self.freq_to_midi(freq)
                midi_notes.append((midi, mag))

        if len(midi_notes) < 3:
            return None

        # Sort by pitch
        midi_notes.sort(key=lambda x: x[0])

        # Try to match chord templates
        best_match = None
        best_score = 0

        for root_idx in range(len(midi_notes) - 2):
            root_midi = midi_notes[root_idx][0]

            for chord_type, intervals in self.chord_templates.items():
                score = 0
                matched_notes = [root_midi]

                for interval in intervals[1:]:  # Skip root
                    target_midi = root_midi + interval

                    # Find closest note
                    for note_midi, mag in midi_notes:
                        if abs(note_midi - target_midi) < 0.5:  # Within 50 cents
                            score += mag
                            matched_notes.append(note_midi)
                            break

                if len(matched_notes) >= len(intervals) * 0.75:  # At least 75% match
                    if score > best_score:
                        best_score = score
                        root_note, octave, _ = self.freq_to_note(
                            self.midi_to_freq(root_midi)
                        )
                        best_match = {
                            "chord_type": chord_type,
                            "root_note": f"{root_note}{octave}",
                            "confidence": score / sum(m[1] for m in midi_notes),
                            "matched_notes": matched_notes,
                        }

        return best_match

    def process(
        self, audio_data: np.ndarray, fft_data: Optional[np.ndarray] = None
    ) -> AnalyzerResult:
        """Process audio for harmonic analysis"""
        try:
            # Input validation
            if audio_data is None:
                raise ValueError("audio_data cannot be None")
            if not isinstance(audio_data, np.ndarray):
                raise ValueError(f"audio_data must be numpy array, got {type(audio_data)}")
            if audio_data.size == 0:
                raise ValueError("audio_data cannot be empty")
            if fft_data is not None and not isinstance(fft_data, np.ndarray):
                raise ValueError(f"fft_data must be numpy array or None, got {type(fft_data)}")
            if fft_data is not None and fft_data.size == 0:
                raise ValueError("fft_data cannot be empty")
            if fft_data is None or len(fft_data) == 0:
                return AnalyzerResult({}, time.time(), 0.0)

            # Generate frequency bins matching FFT data length
            fft_size = 2 * (len(fft_data) - 1)
            freqs = np.fft.rfftfreq(fft_size, 1 / self.sample_rate)

            # Find harmonics
            harmonic_info = self.find_harmonics(fft_data, freqs)

            # Find peaks for chord detection
            prominence = np.max(fft_data) * 0.15
            peaks, _ = signal.find_peaks(fft_data, prominence=prominence)

            peak_list = []
            if len(peaks) > 0:
                for peak in peaks:
                    if peak < len(freqs):
                        peak_list.append((freqs[peak], fft_data[peak]))

            # Detect chord
            chord_info = self.detect_chord(peak_list) if peak_list else None

            # Calculate harmonic distortion
            total_harmonic_energy = 0
            fundamental_energy = 0

            if harmonic_info and "harmonics" in harmonic_info:
                fundamental_idx = np.argmin(
                    np.abs(freqs - harmonic_info["fundamental_freq"])
                )
                fundamental_energy = fft_data[fundamental_idx] ** 2

                for harmonic in harmonic_info["harmonics"]:
                    if harmonic["number"] > 1:
                        total_harmonic_energy += harmonic["magnitude"] ** 2

            thd = (
                np.sqrt(total_harmonic_energy / max(fundamental_energy, 1e-10)) * 100
                if fundamental_energy > 0
                else 0
            )

            result_data = {
                "harmonic_info": harmonic_info,
                "chord_info": chord_info,
                "thd_percent": thd,
                "peak_count": len(peak_list),
            }

            return AnalyzerResult(result_data, time.time(), 0.0)
        except Exception as e:
            # Return empty result if analysis fails
            print(f"HarmonicAnalyzer error: {e}")
            return AnalyzerResult({}, time.time(), 0.0)
