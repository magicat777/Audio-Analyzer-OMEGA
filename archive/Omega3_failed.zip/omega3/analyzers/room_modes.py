"""
Room mode analysis for OMEGA-3.
Detects resonant frequencies and acoustic characteristics of the listening environment.
"""

from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np

from .base import BaseAnalyzer


class RoomModeAnalyzer(BaseAnalyzer):
    """Analyzes room acoustics and resonant modes."""

    def __init__(self, sample_rate: int = 48000):
        super().__init__(sample_rate)

        # Room mode detection parameters
        self.freq_resolution = 1.0  # Hz
        self.min_mode_freq = 20.0  # Hz
        self.max_mode_freq = 300.0  # Hz
        self.q_factor_threshold = 10.0  # Minimum Q for mode detection

        # Acoustic parameters
        self.speed_of_sound = 343.0  # m/s at 20°C

        # Analysis history
        self.mode_history = []
        self.history_size = 30
        self.detected_modes = {}

        # Room dimension estimation
        self.estimated_dimensions = None

    def analyze(self, audio_data: np.ndarray) -> Dict[str, any]:
        """
        Analyze audio for room modes and acoustic characteristics.

        Returns:
            Dict containing:
            - room_modes: List of detected resonant frequencies
            - mode_types: Classification of modes (axial, tangential, oblique)
            - rt60: Estimated reverberation time
            - room_dimensions: Estimated room dimensions
            - acoustic_problems: Identified acoustic issues
            - correction_suggestions: EQ and treatment recommendations
        """
        # Detect resonant peaks
        modes = self._detect_resonant_modes(audio_data)

        # Update mode history
        self._update_mode_history(modes)

        # Classify mode types
        mode_types = self._classify_modes(modes)

        # Estimate RT60
        rt60 = self._estimate_rt60(audio_data)

        # Estimate room dimensions
        if self.estimated_dimensions is None:
            self.estimated_dimensions = self._estimate_room_dimensions(modes)

        # Identify acoustic problems
        problems = self._identify_acoustic_problems(modes, rt60)

        # Generate correction suggestions
        corrections = self._generate_corrections(modes, problems)

        return {
            "room_modes": [
                {
                    "frequency": mode["frequency"],
                    "amplitude": mode["amplitude"],
                    "q_factor": mode["q_factor"],
                    "type": mode_types.get(mode["frequency"], "unknown"),
                }
                for mode in modes
            ],
            "mode_statistics": self._calculate_mode_statistics(modes),
            "rt60": rt60,
            "room_dimensions": self.estimated_dimensions,
            "acoustic_problems": problems,
            "correction_suggestions": corrections,
            "frequency_response_deviation": self._calculate_frequency_response_deviation(
                audio_data
            ),
        }

    def _detect_resonant_modes(self, audio_data: np.ndarray) -> List[Dict[str, float]]:
        """Detect resonant modes using high-resolution FFT."""
        # Use longer FFT for better frequency resolution
        n_fft = int(self.sample_rate / self.freq_resolution)

        # Zero-pad if necessary
        if len(audio_data) < n_fft:
            padded = np.pad(audio_data, (0, n_fft - len(audio_data)))
        else:
            padded = audio_data[:n_fft]

        # Compute FFT
        fft = np.fft.rfft(padded)
        magnitude = np.abs(fft)
        freqs = np.fft.rfftfreq(n_fft, 1 / self.sample_rate)

        # Focus on modal range
        modal_idx = np.where(
            (freqs >= self.min_mode_freq) & (freqs <= self.max_mode_freq)
        )[0]
        modal_freqs = freqs[modal_idx]
        modal_mag = magnitude[modal_idx]

        # Smooth spectrum for baseline estimation
        smoothed = self._smooth_spectrum(modal_mag, window_size=50)

        # Find peaks above smoothed baseline
        modes = []
        peaks = self._find_peaks(modal_mag, smoothed)

        for peak_idx in peaks:
            # Calculate Q factor
            q_factor = self._calculate_q_factor(
                modal_mag, peak_idx, modal_freqs[peak_idx]
            )

            if q_factor >= self.q_factor_threshold:
                modes.append(
                    {
                        "frequency": float(modal_freqs[peak_idx]),
                        "amplitude": float(modal_mag[peak_idx]),
                        "q_factor": float(q_factor),
                        "bandwidth": float(modal_freqs[peak_idx] / q_factor),
                    }
                )

        return sorted(modes, key=lambda x: x["frequency"])

    def _smooth_spectrum(self, spectrum: np.ndarray, window_size: int) -> np.ndarray:
        """Smooth spectrum using moving average."""
        kernel = np.ones(window_size) / window_size
        smoothed = np.convolve(spectrum, kernel, mode="same")

        # Handle edges
        smoothed[: window_size // 2] = spectrum[: window_size // 2]
        smoothed[-window_size // 2:] = spectrum[-window_size // 2:]

        return smoothed

    def _find_peaks(
        self, spectrum: np.ndarray, baseline: np.ndarray, threshold: float = 6.0
    ) -> List[int]:
        """Find peaks in spectrum above baseline."""
        # Calculate prominence
        prominence = 20 * np.log10(spectrum / (baseline + 1e-10))

        # Find local maxima above threshold
        peaks = []
        for i in range(1, len(prominence) - 1):
            if prominence[i] > threshold:
                if (
                    prominence[i] > prominence[i - 1]
                    and prominence[i] > prominence[i + 1]
                ):
                    peaks.append(i)

        return peaks

    def _calculate_q_factor(
        self, spectrum: np.ndarray, peak_idx: int, center_freq: float
    ) -> float:
        """Calculate Q factor of a resonant peak."""
        peak_amplitude = spectrum[peak_idx]
        half_power = peak_amplitude / np.sqrt(2)

        # Find -3dB points
        left_idx = peak_idx
        right_idx = peak_idx

        # Search left
        while left_idx > 0 and spectrum[left_idx] > half_power:
            left_idx -= 1

        # Search right
        while right_idx < len(spectrum) - 1 and spectrum[right_idx] > half_power:
            right_idx += 1

        # Calculate bandwidth
        bandwidth_bins = right_idx - left_idx
        if bandwidth_bins > 0:
            bandwidth_hz = bandwidth_bins * self.freq_resolution
            q_factor = center_freq / bandwidth_hz
        else:
            q_factor = 100.0  # Very narrow peak

        return q_factor

    def _update_mode_history(self, modes: List[Dict[str, float]]):
        """Update historical mode tracking."""
        self.mode_history.append(modes)
        if len(self.mode_history) > self.history_size:
            self.mode_history.pop(0)

        # Update persistent mode detection
        for mode in modes:
            freq = mode["frequency"]
            freq_key = round(freq)  # Round to nearest Hz

            if freq_key not in self.detected_modes:
                self.detected_modes[freq_key] = {
                    "frequency": freq,
                    "occurrences": 0,
                    "avg_amplitude": 0,
                    "avg_q": 0,
                }

            # Update statistics
            detected = self.detected_modes[freq_key]
            n = detected["occurrences"]
            detected["occurrences"] = n + 1
            detected["avg_amplitude"] = (
                n * detected["avg_amplitude"] + mode["amplitude"]
            ) / (n + 1)
            detected["avg_q"] = (n * detected["avg_q"] + mode["q_factor"]) / (n + 1)

    def _classify_modes(self, modes: List[Dict[str, float]]) -> Dict[float, str]:
        """Classify modes as axial, tangential, or oblique."""
        classifications = {}

        if self.estimated_dimensions:
            L, W, H = self.estimated_dimensions

            for mode in modes:
                freq = mode["frequency"]

                # Check for axial modes (single dimension)
                for dim, label in [(L, "Length"), (W, "Width"), (H, "Height")]:
                    for n in range(1, 10):
                        expected = n * self.speed_of_sound / (2 * dim)
                        if abs(freq - expected) < 2.0:  # 2 Hz tolerance
                            classifications[freq] = f"Axial ({label})"
                            break

                # Check for tangential modes (two dimensions)
                if freq not in classifications:
                    for n1 in range(0, 5):
                        for n2 in range(0, 5):
                            if n1 == 0 and n2 == 0:
                                continue
                            for dims in [(L, W), (L, H), (W, H)]:
                                expected = (
                                    self.speed_of_sound
                                    / 2
                                    * np.sqrt((n1 / dims[0]) ** 2 + (n2 / dims[1]) ** 2)
                                )
                                if abs(freq - expected) < 3.0:  # 3 Hz tolerance
                                    classifications[freq] = "Tangential"
                                    break

                # Remaining are likely oblique
                if freq not in classifications:
                    classifications[freq] = "Oblique"
        else:
            # Without room dimensions, classify by frequency spacing
            for mode in modes:
                classifications[mode["frequency"]] = "Unknown"

        return classifications

    def _estimate_room_dimensions(
        self, modes: List[Dict[str, float]]
    ) -> Optional[Tuple[float, float, float]]:
        """Estimate room dimensions from detected modes."""
        if len(modes) < 3:
            return None

        # Look for fundamental axial modes
        fundamentals = []
        for mode in modes:
            if mode["frequency"] < 100:  # Likely fundamental
                fundamentals.append(mode["frequency"])

        if len(fundamentals) >= 3:
            # Sort to get likely L, W, H order
            fundamentals.sort()

            # Calculate dimensions from fundamental frequencies
            # f = c / (2 * L)  =>  L = c / (2 * f)
            dimensions = [self.speed_of_sound / (2 * f) for f in fundamentals[:3]]

            # Sort dimensions (typically L > W > H)
            dimensions.sort(reverse=True)

            return tuple(dimensions)

        return None

    def _estimate_rt60(self, audio_data: np.ndarray) -> Dict[str, float]:
        """Estimate reverberation time using energy decay."""
        # Simplified RT60 estimation
        # In practice, would use impulse response or interrupted noise method

        # Calculate envelope
        envelope = np.abs(audio_data)

        # Smooth envelope
        window_size = int(0.01 * self.sample_rate)
        smoothed = np.convolve(
            envelope, np.ones(window_size) / window_size, mode="same"
        )

        # Find decay portions
        peak_idx = np.argmax(smoothed)
        decay_portion = smoothed[peak_idx:]

        if len(decay_portion) < 100:
            return {"overall": 0.0, "low": 0.0, "mid": 0.0, "high": 0.0}

        # Fit exponential decay
        decay_db = 20 * np.log10(decay_portion + 1e-10)
        time_axis = np.arange(len(decay_portion)) / self.sample_rate

        # Find -60dB point (or extrapolate)
        try:
            idx_5db = np.where(decay_db < decay_db[0] - 5)[0][0]
            idx_35db = np.where(decay_db < decay_db[0] - 35)[0][0]

            t_5 = time_axis[idx_5db]
            t_35 = time_axis[idx_35db]

            # RT60 = 2 * (t_35 - t_5)
            rt60_overall = 2 * (t_35 - t_5)
        except BaseException:
            rt60_overall = 0.5  # Default fallback

        # Frequency-dependent RT60 (simplified)
        return {
            "overall": float(rt60_overall),
            "low": float(rt60_overall * 1.2),  # Bass typically longer
            "mid": float(rt60_overall),
            "high": float(rt60_overall * 0.8),  # Treble typically shorter
        }

    def _identify_acoustic_problems(
        self, modes: List[Dict[str, float]], rt60: Dict[str, float]
    ) -> List[Dict[str, any]]:
        """Identify acoustic problems in the room."""
        problems = []

        # Check for modal density issues
        if len(modes) > 0:
            # Calculate modal density
            freq_range = self.max_mode_freq - self.min_mode_freq
            modal_density = len(modes) / freq_range

            if modal_density > 0.1:  # More than 1 mode per 10 Hz
                problems.append(
                    {
                        "type": "high_modal_density",
                        "severity": "moderate",
                        "description": "High density of room modes may cause uneven bass response",
                        "frequency_range": [self.min_mode_freq, self.max_mode_freq],
                    }
                )

            # Check for mode clusters
            for i in range(len(modes) - 1):
                if modes[i + 1]["frequency"] - modes[i]["frequency"] < 5.0:
                    problems.append(
                        {
                            "type": "mode_cluster",
                            "severity": "high",
                            "description": f"Clustered modes around {modes[i]['frequency']:.1f} Hz",
                            "frequencies": [
                                modes[i]["frequency"],
                                modes[i + 1]["frequency"],
                            ],
                        }
                    )

        # Check RT60 issues
        if rt60["overall"] > 0.8:
            problems.append({"type": "excessive_reverb",
                             "severity": "moderate",
                             "description": f"RT60 of {rt60['overall']:.2f}s is too high for critical listening",
                             "recommendation": "Add absorption treatment",
                             })
        elif rt60["overall"] < 0.2:
            problems.append(
                {
                    "type": "over_damped",
                    "severity": "low",
                    "description": "Room may sound too dead",
                    "recommendation": "Consider adding diffusion",
                }
            )

        # Check for dominant modes
        for mode in modes:
            if mode["q_factor"] > 30:
                problems.append(
                    {
                        "type": "resonant_peak",
                        "severity": "high",
                        "description": f"Strong resonance at {mode['frequency']:.1f} Hz (Q={mode['q_factor']:.1f})",
                        "frequency": mode["frequency"],
                    })

        return problems

    def _generate_corrections(
        self, modes: List[Dict[str, float]], problems: List[Dict[str, any]]
    ) -> Dict[str, any]:
        """Generate correction suggestions."""
        corrections = {
            "eq_suggestions": [],
            "treatment_suggestions": [],
            "positioning_suggestions": [],
        }

        # EQ suggestions for modes
        for mode in modes:
            if mode["q_factor"] > 15:
                corrections["eq_suggestions"].append(
                    {
                        "type": "notch",
                        "frequency": mode["frequency"],
                        "q": min(mode["q_factor"], 30),  # Limit Q to practical values
                        "gain": -min(6, mode["amplitude"] / 10),  # Limit to -6dB
                        "reason": f"Reduce room mode at {mode['frequency']:.1f} Hz",
                    }
                )

        # Treatment suggestions
        for problem in problems:
            if problem["type"] == "high_modal_density":
                corrections["treatment_suggestions"].append(
                    {
                        "type": "bass_traps",
                        "location": "corners",
                        "description": "Install broadband bass traps in room corners",
                    }
                )
            elif problem["type"] == "excessive_reverb":
                corrections["treatment_suggestions"].append(
                    {
                        "type": "absorption_panels",
                        "location": "first_reflection_points",
                        "description": "Add absorption at first reflection points and rear wall",
                    }
                )
            elif problem["type"] == "mode_cluster":
                corrections["treatment_suggestions"].append(
                    {
                        "type": "tuned_absorber",
                        "frequency": problem["frequencies"][0],
                        "description": f"Consider tuned absorber for {problem['frequencies'][0]:.1f} Hz",
                    })

        # Positioning suggestions
        if self.estimated_dimensions:
            L, W, H = self.estimated_dimensions
            corrections["positioning_suggestions"].append(
                {
                    "listener": f"Avoid sitting at {L/2:.1f}m, {W/2:.1f}m from walls",
                    "speakers": "Position speakers away from room boundaries",
                    "description": "Avoid positions at room dimension midpoints",
                }
            )

        return corrections

    def _calculate_mode_statistics(
        self, modes: List[Dict[str, float]]
    ) -> Dict[str, float]:
        """Calculate statistics about detected modes."""
        if not modes:
            return {
                "count": 0,
                "avg_q": 0.0,
                "avg_spacing": 0.0,
                "schroeder_frequency": 0.0,
            }

        q_factors = [m["q_factor"] for m in modes]
        frequencies = [m["frequency"] for m in modes]

        # Calculate average spacing
        if len(frequencies) > 1:
            spacings = np.diff(sorted(frequencies))
            avg_spacing = np.mean(spacings)
        else:
            avg_spacing = 0.0

        # Estimate Schroeder frequency
        if self.estimated_dimensions and hasattr(self, "rt60"):
            volume = np.prod(self.estimated_dimensions)
            rt60_mid = self.rt60.get("mid", 0.5)
            schroeder = 2000 * np.sqrt(rt60_mid / volume)
        else:
            schroeder = 200.0  # Default estimate

        return {
            "count": len(modes),
            "avg_q": float(np.mean(q_factors)),
            "avg_spacing": float(avg_spacing),
            "schroeder_frequency": float(schroeder),
            "modal_density": len(modes) / (self.max_mode_freq - self.min_mode_freq),
        }

    def _calculate_frequency_response_deviation(
        self, audio_data: np.ndarray
    ) -> Dict[str, float]:
        """Calculate frequency response deviation from flat."""
        fft = np.fft.rfft(audio_data)
        magnitude = np.abs(fft)
        freqs = np.fft.rfftfreq(len(audio_data), 1 / self.sample_rate)

        # Focus on audible range
        audible_idx = np.where((freqs >= 20) & (freqs <= 20000))[0]
        audible_mag = magnitude[audible_idx]

        # Calculate in dB
        mag_db = 20 * np.log10(audible_mag + 1e-10)

        # Calculate deviation statistics
        mean_db = np.mean(mag_db)
        std_db = np.std(mag_db)

        # Find maximum deviation
        max_deviation = np.max(np.abs(mag_db - mean_db))

        return {
            "std_deviation": float(std_db),
            "max_deviation": float(max_deviation),
            "flatness_score": float(max(0, 1 - std_db / 10)),  # 0-1 score
        }
