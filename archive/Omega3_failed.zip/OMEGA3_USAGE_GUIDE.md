# OMEGA-3 Professional Audio Analyzer - Usage Guide

## Quick Start

### Basic Usage (Auto-detect audio source)
```bash
python3 run_omega3.py
```

### Specify Audio Source
```bash
python3 run_omega3.py --source [AUDIO_SOURCE_NAME]
```

### Window Size Options
```bash
python3 run_omega3.py --width 1920 --height 1080
python3 run_omega3.py --bars 2048
```

## Audio Source Configuration

### Finding Available Sources
The application will automatically list available monitor sources on startup:
```
🔊 Available Monitor Sources:
==================================================
0: alsa_output.usb-Razer_Razer_Leviathan_V2_Pro_562404B03200239-01.analog-surround-71.monitor
1: alsa_output.pci-0000_00_1f.3-platform-skl_hda_dsp_generic.HiFi__hw_sofhdadsp__sink.monitor
2: alsa_output.usb-Focusrite_Scarlett_2i2_4th_Gen_S23DFQJ378797C-00.iec958-stereo.monitor
3: alsa_output.pci-0000_01_00.1.hdmi-stereo.monitor
==================================================
```

### Manual Source Selection
To specify a source manually:
```bash
python3 run_omega3.py --source alsa_output.usb-Focusrite_Scarlett_2i2_4th_Gen_S23DFQJ378797C-00.iec958-stereo.monitor
```

### Check Active Audio Devices
To see which audio devices are currently active:
```bash
pactl list short sinks
```
Look for devices with "RUNNING" status - their corresponding `.monitor` sources will have audio data.

## Important Notes

### Audio Source Requirements
- **Monitor sources** capture system audio output (what you hear)
- Sources must be **active** (playing audio) to show spectrum data
- **SUSPENDED** sources won't provide audio data
- **RUNNING** or **IDLE** sources are active and can provide audio

### Testing Audio Capture
If you see no spectrum activity:

1. **Check if audio is playing**: Make sure audio is actually playing through your system
2. **Verify active source**: Use `pactl list short sinks` to find active audio devices
3. **Use the correct monitor**: Specify the monitor source of the active device

### Example Audio Test
To test with a tone generator:
```bash
# In one terminal, generate a test tone
speaker-test -t sine -f 440 -l 1

# In another terminal, run OMEGA-3
python3 run_omega3.py --source [YOUR_ACTIVE_MONITOR_SOURCE]
```

## Command Line Options

### Full Syntax
```bash
python3 run_omega3.py [OPTIONS]

Options:
  --source TEXT      PipeWire monitor source name
  --width INTEGER    Window width (default: 1800)
  --height INTEGER   Window height (default: 1000)
  --bars INTEGER     Number of spectrum bars (default: 1024)
  --help            Show help message
```

### Window Presets
Instead of specifying dimensions, use keyboard shortcuts in the application:
- **1** - Professional Compact (1400x900)
- **2** - Professional Standard (1800x1000)
- **3** - Professional Wide (2200x1200)
- **7** - Full HD (1920x1080)
- **8** - 2K Monitor (2560x1440)
- **9** - 4K Monitor (3840x2160)

## Keyboard Controls

Press **H** in the application to see all available keyboard controls, including:
- Display toggles for all panels
- Audio gain controls
- OMEGA feature toggles
- Window presets
- Debug functions

## Troubleshooting

### No Spectrum Display
1. Check that audio is actually playing through your system
2. Verify the selected audio source is active:
   ```bash
   pactl list short sinks | grep RUNNING
   ```
3. Use the monitor source of the running sink
4. Try a different audio source from the auto-detected list

### Audio Permissions
If you get permission errors:
```bash
# Add user to audio group
sudo usermod -a -G audio $USER

# Logout and login again for changes to take effect
```

### PipeWire/PulseAudio Issues
If audio capture fails:
```bash
# Restart PipeWire
systemctl --user restart pipewire
systemctl --user restart pipewire-pulse
```

## Performance Tips

- Use **Y** key to toggle between quality and performance modes
- Lower resolution modes use fewer CPU resources
- Close unnecessary panels with keyboard shortcuts (M, J, Z, etc.)
- Use **D** key to check current performance metrics

## Professional Features

### OMEGA Feature Tiers
- **Base**: Real-time spectrum analysis with industry-standard frequency mapping
- **OMEGA** (P key): Advanced pitch detection and analysis
- **OMEGA-1** (K key): Chromagram and musical key detection
- **OMEGA-2** (N key): Real-time genre classification

### Audio Analysis Features
- Multi-resolution FFT processing
- Perceptual frequency mapping (Bark scale)
- Professional metering (LUFS, True Peak)
- Bass detail analysis (20-500Hz)
- Harmonic analysis and voice detection
- Classic VU meters with proper ballistics

## Examples

### Studio Monitoring Setup
```bash
# Professional studio setup with active Focusrite interface
python3 run_omega3.py \
  --source alsa_output.usb-Focusrite_Scarlett_2i2_4th_Gen_S23DFQJ378797C-00.iec958-stereo.monitor \
  --width 2560 --height 1440 --bars 2048
```

### Live Performance Monitoring
```bash
# Compact setup for live use
python3 run_omega3.py \
  --source [YOUR_MONITOR_SOURCE] \
  --width 1400 --height 900
```

### Broadcast Monitoring
```bash
# System output monitoring
python3 run_omega3.py \
  --source alsa_output.pci-0000_00_1f.3-platform-skl_hda_dsp_generic.HiFi__hw_sofhdadsp__sink.monitor
```